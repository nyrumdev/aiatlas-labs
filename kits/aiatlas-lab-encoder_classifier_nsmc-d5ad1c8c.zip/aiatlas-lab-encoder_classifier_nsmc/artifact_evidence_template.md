lab_id: lab.c.lab.encoder_classifier_nsmc

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 환경 — 1단계 끝의 python 줄 출력(파이썬 판 · torch 판과 +cu 꼬리표 · transformers 5.20.0 · accelerate 1.15.0 · True) 붙여 넣기 + 설치 출력에 'Uninstalling torch' 가 없었다는 1줄 -->
c1: 
<!-- c2(필수): 데이터 — fetch_data.py 출력(두 파일 모두 '기대값과 같음') + data\split_report.json 붙여 넣기(빈 글 학습 5 · 테스트 3 · 테스트 49997행 · train 과 val 행 수의 합 149995) + 검증 조각을 '같은 글은 한쪽에만' 나눈 이유 1줄 -->
c2: 
<!-- c3(필수): 기준선 — runs\baseline\candidates.json(후보 여섯의 검증 정확도·macro F1·특징 칸 수 · 고른 후보 · chosen_at_edge false) + test_metrics.json + 낱말 단위와 글자 묶음 후보의 차이를 읽은 1줄 + C_VALUES 를 넓혀 다시 돌렸다면 그 과정 1줄(넓히지 않았으면 '넓히지 않음') -->
c3: 
<!-- c4(필수): 작게 먼저 — 첫 걸음의 손실(loss) 줄 + runs\roberta_smoke\config.json 의 loading_info(missing 넷이 모두 classifier.* · unexpected 다섯이 모두 lm_head.*) · trainable_params · truncated + val_metrics.json + 이 폴더에 test_metrics.json 이 없다(테스트를 열지 않았다)는 1줄 -->
c4: 
<!-- c5(필수): 본 학습 — runs\roberta_s42 의 config.json(git_dirty false · git_commit = 7단계 코드 커밋 해시) · val_metrics.json(train_sec · max_gpu_mib) · test_metrics.json · preds_test.csv + 기준선 candidates.json 의 git_commit 도 같은 해시라는 1줄 -->
c5: 
<!-- c6(필수): 비교 — results.md(두 모델의 정확도 · macro F1 · 학습 파일에 없는 글만 정확도 · 혼동 행렬 + 같은 행 맞대기 2×2 표) + 3줄: ① 정확도 차이를 '인코더만 맞음 − 기준선만 맞음' 행 수로 다시 적기 ② '학습 파일에 없는 글만' 열이 전체 열과 얼마나 다른지 ③ 학습 시간·GPU 메모리를 붙여 이 차이가 그 비용에 값하는지 내 판단(조건 단서 — 학습 행 수 · 에폭 · 시드 하나 — 를 붙여서) -->
c6: 
<!-- c7(필수): 오류 20 — errors_20.csv(20행 · type 이 모두 여덟 유형 안 · note 칸마다 판단 근거 1줄) + error_types.md + 2줄: 가장 많은 유형과 그 대표 행 id · 기준선은 맞힌 오류가 몇 개이고 어느 유형에 몰렸는지 -->
c7: 
<!-- c8(필수): 판 기록과 커밋 — .gitignore 의 두 줄(encoder_nsmc/runs/*/ckpt/ · encoder_nsmc/runs/*/best/) · requirements.txt 의 transformers·accelerate 줄 · 다시 뽑은 requirements.lock.txt + 코드 커밋 해시와 결과 커밋 해시(git rev-parse HEAD 40자리) 2줄 + git ls-files 에 model.safetensors 가 없다는 1줄 -->
c8: 
<!-- c9(선택): (선택) 시드 둘 더 — runs\roberta_s1 · roberta_s2 + results.md 의 시드 줄(평균 · 표본 표준편차 · 최소 · 최대) + 기준선과의 정확도 차이가 시드 사이 흩어짐보다 큰지 1줄 -->
c9: 
<!-- c10(선택): (선택) 라벨 수 줄이기 — --train-n 2000 · 20000 본 학습 두 개(+ 에폭을 늘린 2000행 실행) + results.md 의 행들 + 학습 행이 몇 개일 때 기준선(학습 조각 전부)과 비슷해지는지 짐작 1줄 + 2000행이 덜 배운 것인지를 두 실행의 val_metrics.json 으로 읽은 1줄 -->
c10: 
