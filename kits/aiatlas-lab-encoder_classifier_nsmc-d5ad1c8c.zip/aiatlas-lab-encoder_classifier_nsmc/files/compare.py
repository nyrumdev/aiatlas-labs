"""compare.py — 기준선과 인코더의 테스트 예측을 같은 행끼리 맞대어 results.md 를 만든다.

실행(encoder_nsmc 폴더에서): python compare.py
읽는 것: runs\\baseline\\ · runs\\roberta_s*\\ 의 test_metrics.json · preds_test.csv
"""
import csv
import json
import re
import statistics

from nsmc_common import RUNS, load_jsonl

MAIN = "roberta_s42"  # 오류 분석에 쓰는 본 실행


def read_preds(run):
    with open(RUNS / run / "preds_test.csv", encoding="utf-8-sig") as f:
        return {r["id"]: int(r["pred"]) for r in csv.DictReader(f)}


def metrics(run):
    return json.loads((RUNS / run / "test_metrics.json").read_text(encoding="utf-8"))


def row(name, m):
    t, u = m["test"], m["test_unseen"]
    return f"| {name} | {t['accuracy']:.4f} | {t['macro_f1']:.4f} | {u['accuracy']:.4f} | {t['confusion']} |"


def main():
    test = load_jsonl("test")
    gold = {r["id"]: r["label"] for r in test}
    assert len(gold) == len(test), "테스트 id 가 겹친다 — 행을 id 로 맞댈 수 없다"
    runs = sorted(p.parent.name for p in RUNS.glob("roberta_s*/test_metrics.json"))
    lines = ["# NSMC 결과 — 같은 테스트 조각(공식 테스트 파일에서 빈 글만 뺌)", "",
             f"테스트 {len(test)}행 · 그중 학습 파일에 글자까지 같은 글이 있던 행 {sum(r['seen'] for r in test)}", "",
             "| 모델 | 정확도 | macro F1 | 학습 파일에 없는 글만 정확도 | 혼동 행렬 [[TN, FP], [FN, TP]] |",
             "|---|---|---|---|---|", row("TF-IDF + 로지스틱 회귀", metrics("baseline"))]
    lines += [row(r, metrics(r)) for r in runs]

    seeds = [r for r in runs if re.fullmatch(r"roberta_s\d+", r)]  # 행 수·에폭·학습률을 바꾼 선택 실행은 시드 묶음에서 뺀다
    if len(seeds) >= 2:
        accs = [metrics(r)["test"]["accuracy"] for r in seeds]
        lines += ["", f"시드 {len(seeds)}개 정확도: 평균 {statistics.mean(accs):.4f} · "
                      f"표본 표준편차 {statistics.stdev(accs):.4f} · 최소 {min(accs):.4f} · 최대 {max(accs):.4f}"]

    b, e = read_preds("baseline"), read_preds(MAIN)
    both = sum(b[i] == gold[i] and e[i] == gold[i] for i in gold)
    only_b = sum(b[i] == gold[i] and e[i] != gold[i] for i in gold)
    only_e = sum(b[i] != gold[i] and e[i] == gold[i] for i in gold)
    neither = len(gold) - both - only_b - only_e
    lines += ["", f"## 같은 행 맞대기 — 기준선 대 {MAIN}", "",
              "| | 인코더 맞음 | 인코더 틀림 |", "|---|---|---|",
              f"| 기준선 맞음 | {both} | {only_b} |", f"| 기준선 틀림 | {only_e} | {neither} |", "",
              f"정확도 차이는 '인코더만 맞음 {only_e} − 기준선만 맞음 {only_b}' 행에서 나온다."]
    (RUNS.parent / "results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
