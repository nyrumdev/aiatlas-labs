"""fetch_data.py — NSMC 원본 두 파일을 커밋을 고정한 주소에서 받아 SHA-256 으로 확인한다.

실행(encoder_nsmc 폴더에서): python fetch_data.py
만드는 파일: data\\raw\\ratings_train.txt · data\\raw\\ratings_test.txt
"""
import hashlib
import urllib.request

from nsmc_common import DATA

COMMIT = "cc0670e872d4ac27bfe36c87456783004b39ef6c"  # e9t/nsmc 의 master 마지막 커밋(2016-06-28)
EXPECTED = {  # 2026-10-16 이 커밋에서 받은 파일의 SHA-256
    "ratings_train.txt": "e03b7d14e9e41be8d464a28057cd25d7396c53e67aa7fd5f7e552c59b0ee2940",
    "ratings_test.txt": "8ac9f64052f11dbf6ae0acb5e038f03d90a76f0eda7820cfb3a92d02edfcebda",
}


def main():
    raw = DATA / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    for name, want in EXPECTED.items():
        path = raw / name
        if not path.exists():
            url = f"https://raw.githubusercontent.com/e9t/nsmc/{COMMIT}/{name}"
            print("받는 중:", url)
            urllib.request.urlretrieve(url, path)
        got = hashlib.sha256(path.read_bytes()).hexdigest()
        status = "같음" if got == want else "다름 — 파일을 지우고 다시 받는다"
        print(f"{name}: {path.stat().st_size} 바이트 · SHA-256 {got[:16]}… · 기대값과 {status}")
        if got != want:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
