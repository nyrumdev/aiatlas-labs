"""finetune.py — klue/roberta-base 에 분류 머리를 달아 NSMC 로 전체 파인튜닝한다(Trainer).

작게 먼저:  python finetune.py --smoke              (학습 2,000행 · 1에폭 · 테스트는 열지 않음)
본 학습:    python finetune.py --seed 42             (학습 조각 전부 · 끝에 테스트를 한 번 연다)
만드는 것: runs\\roberta_<이름>\\ 아래 config.json · best\\(모델·토크나이저) · val_metrics.json
           · (본 학습만) test_metrics.json · preds_test.csv · ckpt\\(에폭마다의 체크포인트)
"""
import argparse
import json
import platform
import time

import numpy as np
import torch
import transformers
from transformers import (AutoModelForSequenceClassification, AutoTokenizer, DataCollatorWithPadding,
                          Trainer, TrainingArguments, set_seed)

from nsmc_common import RUNS, git_state, load_jsonl, save_json, save_preds, scores

CKPT = "klue/roberta-base"
MAX_LEN = 128  # 토큰 수 상한 — 넘는 글은 자른다(몇 행이 잘렸는지 기록)


def encode(tok, rows):
    texts = [r["text"] for r in rows]
    enc = tok(texts, truncation=True, max_length=MAX_LEN)
    items = [{k: enc[k][i] for k in enc} | {"labels": r["label"]} for i, r in enumerate(rows)]
    cut = sum(len(ids) > MAX_LEN for ids in tok(texts)["input_ids"])  # 자르기 전 길이로 센다
    return items, cut


def compute_metrics(p):
    pred = np.argmax(p.predictions, axis=-1)
    s = scores(p.label_ids.tolist(), pred.tolist())
    return {"accuracy": s["accuracy"], "macro_f1": s["macro_f1"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true", help="학습 2,000행·1에폭으로 흐름만 확인(테스트 안 엶)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--train-n", type=int, default=None, help="(선택 과제) 학습 행 수를 줄여 본 학습")
    ap.add_argument("--epochs", type=float, default=2)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch", type=int, default=32)
    args = ap.parse_args()
    if args.smoke:
        args.train_n, args.epochs = 2000, 1
    name = "smoke" if args.smoke else (  # 기본값에서 바꾼 것만 이름에 붙인다 — 실행마다 폴더가 따로 쌓인다
        f"s{args.seed}" + (f"_n{args.train_n}" if args.train_n else "")
        + (f"_e{args.epochs:g}" if args.epochs != 2 else "") + (f"_lr{args.lr:g}" if args.lr != 2e-5 else ""))
    out = RUNS / f"roberta_{name}"
    cuda = torch.cuda.is_available()

    train, val = load_jsonl("train"), load_jsonl("val")
    if args.train_n:
        train = train[: args.train_n]  # train.jsonl 은 원본 파일 순서 — 앞에서 자르면 매번 같은 행이다
    tok = AutoTokenizer.from_pretrained(CKPT)
    train_ds, cut_tr = encode(tok, train)
    val_ds, cut_va = encode(tok, val)

    set_seed(args.seed)  # 새 머리의 무작위 시작값까지 고정하려면 모델을 부르기 전에
    model, info = AutoModelForSequenceClassification.from_pretrained(
        CKPT, num_labels=2, id2label={0: "부정", 1: "긍정"}, label2id={"부정": 0, "긍정": 1},
        output_loading_info=True)  # 버린 무게(unexpected)와 새로 만든 무게(missing)의 이름을 함께 받는다
    n_train_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    targs = TrainingArguments(
        output_dir=str(out / "ckpt"), learning_rate=args.lr, num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch, per_device_eval_batch_size=128, weight_decay=0.01,
        eval_strategy="epoch", save_strategy="epoch", save_total_limit=1, save_only_model=True,
        load_best_model_at_end=True, metric_for_best_model="macro_f1",
        logging_first_step=True, logging_steps=100,  # 첫 걸음의 손실도 찍는다(첫 손실 점검)
        bf16=cuda, seed=args.seed, report_to="none", push_to_hub=False)

    config = {"checkpoint": CKPT, "max_len": MAX_LEN, "train_rows": len(train), "val_rows": len(val),
              "train_label_1": sum(r["label"] for r in train),  # 쓴 학습 행 가운데 긍정 수
              "truncated": {"train": cut_tr, "val": cut_va}, "trainable_params": n_train_params,
              "loading_info": {"missing": sorted(info["missing_keys"]),
                               "unexpected": sorted(info["unexpected_keys"])},
              **vars(args), "bf16": targs.bf16, "fp16": targs.fp16,  # 실제로 넘긴 정밀도 설정을 적는다
              "device": torch.cuda.get_device_name(0) if cuda else "cpu",
              "versions": {"python": platform.python_version(), "torch": torch.__version__,
                           "transformers": transformers.__version__}, **git_state()}
    save_json(out / "config.json", config)
    print(json.dumps(config, ensure_ascii=False, indent=2))

    trainer = Trainer(model=model, args=targs, train_dataset=train_ds, eval_dataset=val_ds,
                      processing_class=tok, data_collator=DataCollatorWithPadding(tok),
                      compute_metrics=compute_metrics)
    if cuda:
        torch.cuda.reset_peak_memory_stats()
    t0 = time.perf_counter()
    trainer.train()
    train_sec = time.perf_counter() - t0
    val_m = trainer.evaluate()  # 가장 좋은 에폭으로 되돌린 모델의 검증 점수
    val_m["train_sec"] = round(train_sec, 1)
    val_m["max_gpu_mib"] = round(torch.cuda.max_memory_allocated() / 2**20) if cuda else None
    save_json(out / "val_metrics.json", val_m)
    trainer.save_model(str(out / "best"))
    print("검증:", json.dumps(val_m, ensure_ascii=False))
    if args.smoke:
        print("작게 먼저 끝 — 테스트는 열지 않았다.")
        return

    test = load_jsonl("test")  # 테스트는 여기서 한 번만 연다
    test_ds, cut_te = encode(tok, test)
    logits = trainer.predict(test_ds).predictions
    prob = torch.softmax(torch.tensor(logits, dtype=torch.float32), dim=-1)[:, 1].numpy()
    pred = logits.argmax(-1)
    y = [r["label"] for r in test]
    seen = np.array([r["seen"] for r in test])
    res = {"model": f"{CKPT}:{name}", "test_truncated": cut_te,
           "test": scores(y, pred.tolist()),
           "test_unseen": scores([v for v, s in zip(y, seen) if not s], pred[~seen].tolist())}
    save_json(out / "test_metrics.json", res)
    save_preds(out / "preds_test.csv", test, pred, prob)
    print(f"테스트 정확도 {res['test']['accuracy']:.4f} · macro F1 {res['test']['macro_f1']:.4f}"
          f" · 학습 파일에 없는 글만 정확도 {res['test_unseen']['accuracy']:.4f}")


if __name__ == "__main__":
    main()
