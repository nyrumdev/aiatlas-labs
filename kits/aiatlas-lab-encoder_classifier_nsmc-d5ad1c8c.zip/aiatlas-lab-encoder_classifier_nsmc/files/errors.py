"""errors.py — 인코더가 틀린 테스트 행에서 20개를 무작위로 뽑고(pick), 내가 붙인 유형을 센다(tally).

뽑기:  python errors.py pick      → errors_20.csv (type · note 칸은 비어 있다 — 내가 채운다)
세기:  python errors.py tally     → error_types.md
"""
import csv
import random
import sys

from nsmc_common import RUNS, load_jsonl

MAIN = "roberta_s42"
PICK_SEED = 2026
N = 20
TYPES = ["라벨의심", "반어", "대조", "비교", "부정", "신조어", "정보부족", "기타"]  # 순서 = 겹칠 때 고르는 우선순위(본문 표와 같음)
FIELDS = ["id", "text", "label", "enc_pred", "enc_prob_pos", "base_pred", "seen", "type", "note"]


def read_csv(path):
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def pick():
    test = {r["id"]: r for r in load_jsonl("test")}
    enc = read_csv(RUNS / MAIN / "preds_test.csv")
    base = {r["id"]: r["pred"] for r in read_csv(RUNS / "baseline" / "preds_test.csv")}
    wrong = [r for r in enc if r["pred"] != r["label"]]
    chosen = random.Random(PICK_SEED).sample(wrong, N)  # 고르지 않고 뽑는다 — 눈에 띄는 것만 모으면 유형 비율이 왜곡된다
    with open("errors_20.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for r in chosen:
            t = test[r["id"]]
            w.writerow({"id": r["id"], "text": t["text"], "label": r["label"], "enc_pred": r["pred"],
                        "enc_prob_pos": r["prob_pos"], "base_pred": base[r["id"]], "seen": int(t["seen"]),
                        "type": "", "note": ""})
    print(f"틀린 행 {len(wrong)}개 가운데 {N}개를 뽑아 errors_20.csv 에 썼다(뽑기 씨앗 {PICK_SEED}).")


def tally():
    rows = read_csv("errors_20.csv")
    assert len(rows) == N, f"행이 {len(rows)}개다 — {N}개여야 한다"
    bad = [r["id"] for r in rows if r["type"] not in TYPES]
    assert not bad, f"유형 칸이 비었거나 목록 밖이다: {bad} — 쓸 수 있는 유형 {TYPES}"
    assert all(r["note"].strip() for r in rows), "note 칸(판단 근거 한 줄)이 빈 행이 있다"
    lines = ["# 오류 유형 — 인코더가 틀린 테스트 20행(무작위 뽑기)", "",
             "| 유형 | 행 수 | 그중 기준선은 맞힘 | 그중 인코더 확신 0.9 이상 |", "|---|---|---|---|"]
    for t in TYPES:
        g = [r for r in rows if r["type"] == t]
        if not g:
            continue
        base_right = sum(r["base_pred"] == r["label"] for r in g)
        sure = sum(max(float(r["enc_prob_pos"]), 1 - float(r["enc_prob_pos"])) >= 0.9 for r in g)
        lines.append(f"| {t} | {len(g)} | {base_right} | {sure} |")
    lines += ["", f"합계 {N}행 · 기준선도 틀린 행 {sum(r['base_pred'] != r['label'] for r in rows)}"]
    with open("error_types.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    {"pick": pick, "tally": tally}[sys.argv[1]]()
