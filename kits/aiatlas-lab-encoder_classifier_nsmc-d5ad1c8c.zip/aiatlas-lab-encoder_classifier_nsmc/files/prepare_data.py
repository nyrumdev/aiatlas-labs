"""prepare_data.py — NSMC 원본 두 파일을 학습·검증·테스트 세 조각(jsonl)으로 나눈다.

실행(encoder_nsmc 폴더에서): python prepare_data.py
만드는 파일: data\\train.jsonl · data\\val.jsonl · data\\test.jsonl · data\\split_report.json
"""
import collections
import hashlib
import json
import random

from nsmc_common import DATA, save_json

VAL_ROWS = 10_000  # 학습 파일에서 떼어 낼 검증 행 수(목표치 — 같은 글은 한쪽에만 가므로 조금 넘을 수 있다)
SPLIT_SEED = 0


def read_raw(name):
    """탭으로 나뉜 세 칸(id · document · label)을 그대로 읽는다 — 따옴표는 글의 일부로 둔다."""
    raw = (DATA / "raw" / name).read_bytes()
    lines = raw.decode("utf-8").split("\n")
    assert lines[0] == "id\tdocument\tlabel", f"{name}: 머리 줄이 다르다 — {lines[0]!r}"
    rows, empty = [], 0
    for line in lines[1:]:
        if line == "":
            continue
        rid, text, label = line.split("\t")  # 칸이 셋이 아니면 여기서 멈춘다
        assert label in ("0", "1"), f"{name}: 라벨이 0·1 이 아니다 — {line!r}"
        if text.strip() == "":
            empty += 1  # 글이 빈 행은 뺀다(개수는 기록)
            continue
        rows.append({"id": rid, "text": text, "label": int(label)})
    return rows, empty, hashlib.sha256(raw).hexdigest()


def write_jsonl(name, rows):
    with open(DATA / f"{name}.jsonl", "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def main():
    pool, empty_tr, sha_tr = read_raw("ratings_train.txt")
    test, empty_te, sha_te = read_raw("ratings_test.txt")

    # 검증 조각: 서로 다른 글을 섞어 앞에서부터 담는다 — 똑같은 글은 학습·검증 가운데 한쪽에만 간다
    by_text = collections.defaultdict(list)
    for r in pool:
        by_text[r["text"]].append(r)
    texts = sorted(by_text)
    random.Random(SPLIT_SEED).shuffle(texts)
    val_texts, n = set(), 0
    for t in texts:
        if n >= VAL_ROWS:
            break
        val_texts.add(t)
        n += len(by_text[t])
    train = [r for r in pool if r["text"] not in val_texts]
    val = [r for r in pool if r["text"] in val_texts]

    # 테스트 행마다 '학습 파일에 글자까지 같은 글이 있었나'를 표시한다(채점 때 따로 셈)
    seen = set(by_text)
    for r in test:
        r["seen"] = r["text"] in seen

    for name, rows in (("train", train), ("val", val), ("test", test)):
        write_jsonl(name, rows)

    def count(rows):
        c = collections.Counter(r["label"] for r in rows)
        return {"rows": len(rows), "neg_0": c[0], "pos_1": c[1]}

    report = {
        "raw_sha256": {"ratings_train.txt": sha_tr, "ratings_test.txt": sha_te},
        "empty_removed": {"train_file": empty_tr, "test_file": empty_te},
        "train": count(train), "val": count(val), "test": count(test),
        "test_seen_in_train_file": sum(r["seen"] for r in test),
        "duplicate_rows_in_train_file": len(pool) - len(by_text),
        "split_seed": SPLIT_SEED,
    }
    save_json(DATA / "split_report.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
