"""nsmc_common.py — 이 실습의 스크립트가 함께 쓰는 읽기·채점·기록 도구."""
import json
import subprocess
from pathlib import Path

from sklearn.metrics import accuracy_score, confusion_matrix, f1_score

DATA = Path("data")
RUNS = Path("runs")


def load_jsonl(name):
    """data 폴더의 train·val·test 조각 하나를 행 목록으로 읽는다."""
    with open(DATA / f"{name}.jsonl", encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def scores(y_true, y_pred):
    """정확도 · macro F1 · 혼동 행렬(행 = 실제, 열 = 예측 · 0 부정 · 1 긍정)."""
    return {
        "n": len(y_true),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
        "confusion": confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist(),
    }


def git_state():
    """지금 코드의 커밋 해시와, 추적 중인 파일에 커밋 안 된 수정이 있는지 — 결과를 어느 코드가 냈는지 남긴다.

    --dirty 는 추적 중인 파일이 바뀌었을 때만 -dirty 를 붙인다(새로 생긴 결과 파일은 세지 않는다).
    """
    def run(*args):
        return subprocess.run(["git", *args], capture_output=True, text=True).stdout.strip()
    return {"git_commit": run("rev-parse", "HEAD"),
            "git_dirty": run("describe", "--always", "--dirty").endswith("-dirty")}


def save_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save_preds(path, rows, preds, probs):
    """테스트 행마다 정답·예측·긍정 확률을 CSV 로 남긴다(BOM 을 붙인 UTF-8 = utf-8-sig)."""
    import csv
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "label", "pred", "prob_pos"])
        for r, p, q in zip(rows, preds, probs):
            w.writerow([r["id"], r["label"], int(p), f"{float(q):.4f}"])
