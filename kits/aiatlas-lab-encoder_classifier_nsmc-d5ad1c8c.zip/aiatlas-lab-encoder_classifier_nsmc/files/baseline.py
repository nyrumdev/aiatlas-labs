"""baseline.py — TF-IDF + 로지스틱 회귀 기준선. 후보 여섯을 검증 조각으로 고르고, 고른 하나로 테스트를 한 번 연다.

실행(encoder_nsmc 폴더에서): python baseline.py
만드는 파일: runs\\baseline\\candidates.json · test_metrics.json · preds_test.csv
고른 C 가 C_VALUES 의 끝(가장 작은 값이나 가장 큰 값)이면 테스트를 열지 않고 멈춘다 — C_VALUES 를 넓혀 다시 돌린다.
"""
import time

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

from nsmc_common import RUNS, git_state, load_jsonl, save_json, save_preds, scores

# 후보 = 표현 둘 × C 셋. 낱말 단위는 기본 정규식(두 글자 이상) 대신 한 글자 낱말('굿'·'짱')도 살리는 정규식을 쓴다
# — 한 글자 낱말이 통째로 빠지는 교란 하나를 걷어 낸다(남은 차이는 5단계 설명을 본다)
FEATURES = {
    "word": dict(token_pattern=r"(?u)\b\w+\b", min_df=2),
    "char13": dict(analyzer="char_wb", ngram_range=(1, 3), min_df=2),
}
C_VALUES = [1.0, 4.0, 16.0]  # 작을수록 규제가 세다 — 고른 값이 끝이면 바깥쪽 값을 더한다
CANDIDATES = {f"{f}_C{c:g}": dict(vec=v, C=c) for f, v in FEATURES.items() for c in C_VALUES}


def fit(cfg, train):
    vec = TfidfVectorizer(**cfg["vec"])
    x = vec.fit_transform([r["text"] for r in train])  # 어휘와 idf 는 학습 조각에서만 배운다
    clf = LogisticRegression(C=cfg["C"], max_iter=2000)
    clf.fit(x, [r["label"] for r in train])
    return vec, clf


def main():
    train, val, test = load_jsonl("train"), load_jsonl("val"), load_jsonl("test")
    y_val = [r["label"] for r in val]
    results, models = {}, {}
    for name, cfg in CANDIDATES.items():
        t0 = time.perf_counter()
        vec, clf = fit(cfg, train)
        pred = clf.predict(vec.transform([r["text"] for r in val]))
        s = scores(y_val, pred)
        results[name] = {"val_accuracy": s["accuracy"], "val_macro_f1": s["macro_f1"],
                         "n_features": len(vec.vocabulary_), "fit_sec": round(time.perf_counter() - t0, 1)}
        models[name] = (vec, clf)
        print(f"{name:10s} 검증 정확도 {s['accuracy']:.4f} · macro F1 {s['macro_f1']:.4f} · 특징 {len(vec.vocabulary_)} 칸")

    best = max(results, key=lambda k: results[k]["val_macro_f1"])  # 고르는 일은 검증 조각으로만
    edge = CANDIDATES[best]["C"] in (min(C_VALUES), max(C_VALUES))
    print("고른 후보:", best)
    save_json(RUNS / "baseline" / "candidates.json",
              {"candidates": results, "chosen": best, "c_values": C_VALUES, "chosen_at_edge": edge, **git_state()})
    if edge:  # 범위 끝에서 고르면 바깥에 더 나은 값이 있을 수 있다 — 테스트를 열기 전에 멈춘다
        raise SystemExit(f"고른 C 가 후보 범위의 끝이다({best}) — 테스트를 열지 않았다. "
                         "C_VALUES 에 바깥쪽 값을 더하고 커밋한 뒤 다시 돌린다.")

    vec, clf = models[best]
    x_test = vec.transform([r["text"] for r in test])
    proba = clf.predict_proba(x_test)[:, list(clf.classes_).index(1)]  # 열 순서는 classes_ 를 따른다
    pred = (proba >= 0.5).astype(int)
    y_test = [r["label"] for r in test]
    seen = np.array([r["seen"] for r in test])
    out = {"model": f"tfidf_logreg:{best}",
           "test": scores(y_test, pred),
           "test_unseen": scores([y for y, s in zip(y_test, seen) if not s], pred[~seen])}
    save_json(RUNS / "baseline" / "test_metrics.json", out)
    save_preds(RUNS / "baseline" / "preds_test.csv", test, pred, proba)
    print(f"테스트 정확도 {out['test']['accuracy']:.4f} · macro F1 {out['test']['macro_f1']:.4f}"
          f" · 학습 파일에 없는 글만 정확도 {out['test_unseen']['accuracy']:.4f} ({out['test_unseen']['n']}행)")


if __name__ == "__main__":
    main()
