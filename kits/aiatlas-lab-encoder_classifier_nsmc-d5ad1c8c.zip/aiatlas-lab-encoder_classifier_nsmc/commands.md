# 한국어 인코더 파인튜닝으로 감성 분류(NSMC — TF-IDF 기준선과 같은 테스트 조각에서 견주기) — 명령·코드 모음

실습 id: `lab.c.lab.encoder_classifier_nsmc`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 판 고정

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
python -m pip install "transformers==5.20.0" "accelerate==1.15.0"
python -c "import sys, torch, transformers, accelerate; print(sys.version.split()[0], torch.__version__, transformers.__version__, accelerate.__version__, torch.cuda.is_available())"
mkdir encoder_nsmc
cd encoder_nsmc
```

## 2. 함께 쓰는 도구

- `files/nsmc_common.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git describe --always --dirty` — `git_state` 는 앞 실습처럼 `git describe --always --dirty` 로 '추적 중인 파일이 커밋 뒤에 바뀌었나'만 본다.

## 3. 데이터 받기

- `files/fetch_data.py` — 키트에 들어 있음 (python)

## 4. 세 조각 나누기

- `files/prepare_data.py` — 키트에 들어 있음 (python)

## 5. 기준선 스크립트

- `files/baseline.py` — 키트에 들어 있음 (python)

## 6. 인코더 스크립트

- `files/finetune.py` — 키트에 들어 있음 (python)

## 7. 커밋 먼저

```powershell
cd C:\work\ai-lab
Add-Content .gitignore "encoder_nsmc/runs/*/ckpt/", "encoder_nsmc/runs/*/best/"
git add .
git commit -m "NSMC 실습 — 데이터·기준선·인코더 코드"
git rev-parse HEAD
cd encoder_nsmc
```

## 8. 기준선 재기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python baseline.py` — 기준선 재기 — `python baseline.py` 로 실행한다.

## 9. 작게 먼저

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python finetune.py --smoke` — 작게 먼저 — `python finetune.py --smoke` 로 학습 2,000행·1에폭만 돌린다.

## 10. 본 학습

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python finetune.py --seed 42` — 본 학습 — `python finetune.py --seed 42` 로 학습 조각 전부를 2에폭 학습한다.

## 11. 같은 행끼리 견주기

- `files/compare.py` — 키트에 들어 있음 (python)

## 12. 틀린 행 읽기

- `files/errors.py` — 키트에 들어 있음 (python)

## 13. 판 기록과 결과 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 그다음 `git add .` 와 `git commit -m "NSMC 실습 — 결과 표·오류 유형·실행 기록"` 을 치고, `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다(S764).
- `git commit -m "NSMC 실습 — 결과 표·오류 유형·실행 기록"` — 그다음 `git add .` 와 `git commit -m "NSMC 실습 — 결과 표·오류 유형·실행 기록"` 을 치고, `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다(S764).
- `git rev-parse HEAD` — 그다음 `git add .` 와 `git commit -m "NSMC 실습 — 결과 표·오류 유형·실행 기록"` 을 치고, `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다(S764).
- `git ls-files | Select-String safetensors` — `git ls-files | Select-String safetensors` 가 아무것도 찍지 않아야 한다.

## 15. (선택) 시드 둘 더

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python finetune.py --seed 1` — (선택) 시드 둘 더 — encoder_nsmc 폴더에서 `python finetune.py --seed 1` 과 `python finetune.py --seed 2` 를 차례로 돌리고 `python compare.py` 를 다시 친다.
- `python finetune.py --seed 2` — (선택) 시드 둘 더 — encoder_nsmc 폴더에서 `python finetune.py --seed 1` 과 `python finetune.py --seed 2` 를 차례로 돌리고 `python compare.py` 를 다시 친다.
- `python compare.py` — (선택) 시드 둘 더 — encoder_nsmc 폴더에서 `python finetune.py --seed 1` 과 `python finetune.py --seed 2` 를 차례로 돌리고 `python compare.py` 를 다시 친다.

## 16. (선택) 라벨 수 줄이기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python finetune.py --seed 42 --train-n 2000` — (선택) 라벨 수 줄이기 — `python finetune.py --seed 42 --train-n 2000` 과 `python finetune.py --seed 42 --train-n 20000` 을 돌린다.
- `python finetune.py --seed 42 --train-n 20000` — (선택) 라벨 수 줄이기 — `python finetune.py --seed 42 --train-n 2000` 과 `python finetune.py --seed 42 --train-n 20000` 을 돌린다.
- `python finetune.py --seed 42 --train-n 2000 --epochs 6` — 묶음 32에서 2,000행은 에폭마다 갱신이 63번뿐이니, 덜 배운 것인지 라벨이 모자란 것인지 가르려면 `python finetune.py --seed 42 --train-n 2000 --epochs 6` 도 돌린다.
- `python compare.py` — 세 실행이 끝나면 `python compare.py` 를 다시 쳐 results.md 에 세 행을 붙인다.
- `git add .` — 저장소 맨 위로 올라가 `git add .` 와 `git commit -m "NSMC 실습 — 라벨 수 줄이기(선택)"` 로 결과를 한 번 더 올리고, `git status` 가 working tree clean 인지 본다.
- `git commit -m "NSMC 실습 — 라벨 수 줄이기(선택)"` — 저장소 맨 위로 올라가 `git add .` 와 `git commit -m "NSMC 실습 — 라벨 수 줄이기(선택)"` 로 결과를 한 번 더 올리고, `git status` 가 working tree clean 인지 본다.
- `git status` — 저장소 맨 위로 올라가 `git add .` 와 `git commit -m "NSMC 실습 — 라벨 수 줄이기(선택)"` 로 결과를 한 번 더 올리고, `git status` 가 working tree clean 인지 본다.

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python prepare_data.py` — … '기대값과 같음' 을 찍었는가 · split_report.json 의 빈 글이 5·3, 테스트가 49997행, train 과 val 행 수의 합이 149995 인가 · `python prepare_data.py` 를 한 번 더 돌려도 split_report.json 이 바뀌지 않는가
- `python errors.py tally` — errors_20.csv 가 20행이고 `python errors.py tally` 가 멈추지 않고 error_types.md 를 만들었는가 · note 가 모든 행에 있는가
- `git log --oneline` — `git log --oneline` 에 코드 커밋과 결과 커밋이 있고, `git ls-files` 에 data 폴더의 파일과 model.safetensors 가 없으며, requirements.txt 에 transformers·accelerate 줄이 있는가
- `git ls-files` — `git log --oneline` 에 코드 커밋과 결과 커밋이 있고, `git ls-files` 에 data 폴더의 파일과 model.safetensors 가 없으며, requirements.txt 에 transformers·accelerate 줄이 있는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -c "import torch; print(torch.__version__)"` — `python -c "import torch; print(torch.__version__)"` 의 꼬리표가 +cpu 로 바뀌었으면, 저장소 맨 위(C:\work\ai-lab)에서 `python -m pip install -r requirements.lock.txt` 로 앞 실습의 판을 …
- `python -m pip install -r requirements.lock.txt` — … -c "import torch; print(torch.__version__)"` 의 꼬리표가 +cpu 로 바뀌었으면, 저장소 맨 위(C:\work\ai-lab)에서 `python -m pip install -r requirements.lock.txt
- `python -V` — Ctrl+C 로 멈추고, 그 꾸러미 이름과 판, `python -V` 출력을 보고서에 적는다.
- `git status` — `git status` 로 바뀐 파일을 보고 커밋한 뒤 다시 돌린다.
- `git add` — 이미 `git add` 했다면 `git rm --cached` 로 인덱스에서 빼고 .gitignore 를 고친다(S763).
- `git rm --cached` — 이미 `git add` 했다면 `git rm --cached` 로 인덱스에서 빼고 .gitignore 를 고친다(S763).
- `python errors.py tally` — `python errors.py tally` 가 UnicodeDecodeError 로 멈춘다 → 엑셀이 CSV 를 UTF-8 이 아닌 인코딩으로 다시 저장했을 수 있다.
