# 한국어 인코더 파인튜닝으로 감성 분류(NSMC — TF-IDF 기준선과 같은 테스트 조각에서 견주기)

AI 아틀라스 앱의 실습 `lab.c.lab.encoder_classifier_nsmc`(L3 · 약 5시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\work\ai-lab\encoder_nsmc\nsmc_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 encoder_nsmc 폴더에 nsmc_common.py · fetch_data.py · prepare_data.py · baseline.py · finetune.py · compare.py · errors.py · results.md · errors_20.csv · error_types.md · runs 폴더(실행마다 config.json · val_metrics.json · 본 실행은 test_metrics.json · preds_test.csv).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — 앞 실습과 같이 CUDA 판 torch 가 GPU 를 쓰는 PC 를 전제로 한다(본 학습은 학습 조각 전부를 2에폭 돌리므로 CPU 로 대신하지 않는다)
- 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 만든 저장소 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch·numpy·scikit-learn 이 있고 env_report.json 의 cuda_is_available 이 true
- 앞 실습 [실습] 첫 신경망을 GPU로 학습시키기(Fashion-MNIST · 진단 점검 포함)를 마친 같은 저장소 — 루트 .gitignore 에 data/ 줄이 있고, 실행마다 config.json 에 git_commit·git_dirty 를 남기는 습관
- 인터넷 — transformers·accelerate 설치, NSMC 원본 두 파일(합쳐 약 19MB) 받기, klue/roberta-base 체크포인트를 Hugging Face Hub 에서 처음 한 번 받기에만 쓴다(모델을 Hub 에 올리지 않는다)
- 디스크 여유 — 체크포인트 캐시(사용자 폴더의 .cache\huggingface · klue/roberta-base 약 0.45GB)와 실행마다의 best·ckpt 폴더(학습이 끝나면 ckpt 에는 가장 좋은 에폭의 체크포인트 하나, best 에는 그 모델 하나 · 저장소에는 올리지 않는다). 2026-11-01 실측으로 실행 하나가 약 0.9GB 를 남겨, 필수 단계(작게 먼저 · 본 학습)만 하면 약 1.8GB, 선택 15·16 까지 하면 실행 8개로 약 6GB 다. 표를 다 만든 실행의 ckpt 폴더는 지워도 된다(가장 좋은 모델은 best 에 따로 있고, 이 실습은 끊긴 학습을 이어 가지 않는다)

## 들어 있는 파일
- `files/nsmc_common.py`
- `files/fetch_data.py`
- `files/prepare_data.py`
- `files/baseline.py`
- `files/finetune.py`
- `files/compare.py`
- `files/errors.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.encoder_classifier_nsmc` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
