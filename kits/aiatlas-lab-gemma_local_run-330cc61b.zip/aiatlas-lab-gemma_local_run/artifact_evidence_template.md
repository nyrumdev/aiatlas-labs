lab_id: lab.c.lab.gemma_local_run

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): `ollama --version` 출력 캡처 -->
c1: 
<!-- c2(필수): `ollama run gemma4:e4b --verbose --think=false` 에 질문 '토큰이 뭐야?' 를 붙여 실행한 1회차(모델이 내려가 있던 상태) 응답과 통계 캡처 -->
c2: 
<!-- c3(필수): 표: 모델 태그 · 파일 크기(ollama list) · 생각 켬/끔 · 적재 시간(1회차 load duration) · 생성 속도(eval rate · 초당 토큰) · 메모리(GPU 몫 = 올린 뒤 nvidia-smi memory.used − 모델 없을 때 · 시스템 몫 = 서버 로그의 CPU·CUDA_Host model buffer 줄 합) · ollama ps SIZE(교차 확인) · PROCESSOR · CONTEXT — 최소 1행 -->
c3: 
<!-- c4(필수): 같은 명령을 3회 따로 실행해 1회차의 적재 포함 첫 토큰 시간(load duration + prompt eval duration)과 2·3회차의 첫 토큰 시간(적재 제외 — prompt eval duration)을 나눠 기록 · 회차마다 prompt eval cached 줄이 찍혔는지 표시 -->
c4: 
<!-- c5(선택): `gemma4:12b` 도 시도해 같은 표에 1행 추가 -->
c5: 
<!-- c6(필수): 메모리 산정(파라미터×비트/8)으로 예측한 값과 실측(c3 의 GPU 몫 + 시스템 몫)의 차이 1문장 -->
c6: 
