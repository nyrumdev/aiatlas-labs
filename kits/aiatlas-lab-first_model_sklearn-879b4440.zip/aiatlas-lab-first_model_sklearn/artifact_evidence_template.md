lab_id: lab.c.lab.first_model_sklearn

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 판 맞추기 — part1_baseline_cv.py 첫 두 줄 출력(① python·sklearn·pandas 판 ② target_names 순서·행·열·악성 수)을 보고서에 붙여 넣기 + 악성이 target 0 이라 1 로 바꿨다는 1줄 + requirements.lock.txt 에 scikit-learn==1.9.1·pandas==3.0.6 줄과 맨 위 색인 줄 + requirements.txt 에 두 패키지의 범위 줄 -->
c1: 
<!-- c2(필수): 기준선과 5겹 교차검증 — part1_cv.csv(dummy_prior·scaler_logreg 두 모델 × accuracy·precision·recall·f1 네 지표의 평균·표준편차·폴드 다섯 값 = 8행) + 보고서에 ① 기준선 정확도와 357 ÷ 569 를 견준 1줄 ② 기준선의 재현율이 왜 0 인지 1줄 ③ 파이프라인이 기준선보다 나은 정도를 재현율·F1 로 적은 1줄 -->
c2: 
<!-- c3(필수): 문턱값 표 — part1_thresholds.csv(문턱 0.3·0.5·0.7 세 행 × 네 칸·정밀도·재현율·F1) + 보고서에 '악성을 놓치는 쪽이 더 비싸다'는 가정에서 고를 문턱과 이유 1줄 + 이 표가 테스트 점수가 아니라 폴드 밖 예측으로 만든 개발용 표라는 1줄 + 고른 문턱의 성적은 아직 재지 않았다는 1줄 -->
c3: 
<!-- c4(필수): 누출 재현 — part1_leakage.json + 보고서에 2×2 표(나누기 전 고르기 / 파이프라인 안 고르기 × 한 번 나누기 정확도 / 5겹 평균±표준편차)와 positive_share + 옳은 순서 쪽(대조군)보다 누출 쪽이 5겹 폴드 값의 흩어짐을 넘어 높았다면 그 이유, 아니었다면 그 사실과 5겹 폴드 값 1줄 -->
c4: 
<!-- c5(필수): 1부 커밋 — first_model 폴더(코드 2개·CSV 2개·JSON 1개·first_model_report.md)와 두 판 목록을 올린 커밋의 해시(git rev-parse HEAD 40자리) 1줄 + 그 커밋 직후 git status 가 working tree clean 이었다는 1줄 -->
c5: 
<!-- c6(선택): (선택 · 2부) 테스트 잠그기 — adult_lock.json(openml_id·openml_version·md5_checksum·data_home·행 수 셋·양성 비율 둘·test_index_sha256) + adult_test_index.txt 를 모델을 하나라도 학습시키기 전에 올린 '잠금 커밋' 해시 1줄 + 마지막에 git diff 잠금해시 HEAD -- first_model/adult_test_index.txt 가 빈 출력이라는 1줄 -->
c6: 
<!-- c7(선택): (선택 · 2부) 같은 폴드 비교 — part2_cv_compare.csv(logreg·hgb × 네 지표 + fit_seconds = 10행 + 마지막 행 f1_diff 의 폴드 다섯 값 = 11행) + 보고서에 9단계에서 탐색할 모델과 고른 이유 1줄(f1_diff 다섯 값(hgb − logreg)의 부호·크기 + 평균 차이와 폴드 표준편차) -->
c7: 
<!-- c8(선택): (선택 · 2부) 탐색과 테스트 한 번 — 측정 전 커밋 해시 1줄 + part2_test.json(chosen·best_params·best_score_cv_f1·test 의 네 칸과 지표) + 보고서에 best_score_cv_f1 과 테스트 f1 을 나란히 놓은 1줄 + git diff 측정전해시 HEAD -- first_model/part2_common.py first_model/part2_search_test.py 가 빈 출력이라는 1줄 + 커밋 이력상 part2_test.json 의 커밋이 하나라는 1줄(커밋 전에 지우고 다시 잰 일은 git 이 보여 주지 못하므로, 있었으면 '두 번 본 점수'라고 적는다) -->
c8: 
<!-- c9(선택): (선택 · 2부) 집단별 오류와 한계 — part2_groups.csv(sex·race 의 집단마다 n·기저율·양성 판정 비율·오류율·거짓 양성률·거짓 음성률) + 보고서에 가장 큰 차이 2줄(숫자와 집단 이름 · 표본이 작은 집단 표시) + '이 모델을 실제 결정에 쓰면 안 되는 이유' 절(근거 셋 이상) + 2부를 올린 마지막 커밋 해시 1줄 -->
c9: 
