"""2부 공용 — Adult 를 판을 고정해 읽고, 잠근 테스트 행을 확인해 나누며, 두 모델을 같은 전처리로 만든다."""
import hashlib
import json
from pathlib import Path

from sklearn.compose import ColumnTransformer
from sklearn.datasets import fetch_openml
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUM_COLS = ["age", "capital-gain", "capital-loss", "hours-per-week"]
CAT_COLS = ["workclass", "education", "marital-status", "occupation",
            "relationship", "race", "sex", "native-country"]
GROUP_COLS = ["sex", "race"]
LOCK_JSON = Path("adult_lock.json")
TEST_INDEX = Path("adult_test_index.txt")


def load_adult():
    """OpenML 'adult' 2판을 읽는다. 처음 한 번만 내려받고 그 뒤로는 data_home 캐시를 쓴다."""
    adult = fetch_openml("adult", version=2, as_frame=True)
    X = adult.data[NUM_COLS + CAT_COLS].copy()  # fnlwgt·education-num 은 여기서 뺀다
    X[CAT_COLS] = X[CAT_COLS].astype(object)  # 범주 자료형 → 글자 자료형(빈칸은 NaN 그대로)
    target = adult.target.astype(str)
    y = (target == ">50K").astype(int)  # 찾으려는 쪽 = 연 소득 50K 초과
    return adult, X, y, target


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_locked():
    """잠근 목록이 커밋한 그대로인지 확인한 뒤 (개발 X, 개발 y, 테스트 X, 테스트 y) 를 돌려준다."""
    _, X, y, _ = load_adult()
    lock = json.loads(LOCK_JSON.read_text(encoding="utf-8"))
    text = TEST_INDEX.read_text(encoding="utf-8")
    if sha256_text(text) != lock["test_index_sha256"]:
        raise SystemExit("잠근 테스트 행 목록이 바뀌었다 — adult_test_index.txt 를 잠금 커밋의 판으로 되돌린다")
    test_mask = X.index.isin([int(line) for line in text.split()])
    return X[~test_mask], y[~test_mask], X[test_mask], y[test_mask]


def make_preprocess():
    """숫자 열은 표준화, 범주 열은 빈칸을 'missing' 으로 채운 뒤 원-핫. 적지 않은 열은 버린다."""
    return ColumnTransformer([
        ("num", StandardScaler(), NUM_COLS),
        ("cat", make_pipeline(SimpleImputer(strategy="constant", fill_value="missing"),
                              OneHotEncoder(handle_unknown="ignore", sparse_output=False)), CAT_COLS),
    ])


def make_models():
    """같은 전처리 위에 모델만 다른 두 파이프라인."""
    return {
        "logreg": make_pipeline(make_preprocess(), LogisticRegression(max_iter=1000)),
        "hgb": make_pipeline(make_preprocess(), HistGradientBoostingClassifier(random_state=0)),
    }
