"""2부 8단계 — 개발 행만으로 로지스틱 회귀와 HistGradientBoosting 을 같은 5겹에서 비교한다."""
import pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_validate

from part2_common import load_locked, make_models

SCORING = ["accuracy", "precision", "recall", "f1"]

X_dev, y_dev, X_test, y_test = load_locked()
del X_test, y_test  # 이 단계는 테스트 행을 쓰지 않는다
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)  # 두 모델이 같은 폴드
rows = []
f1_by_model = {}
for name, model in make_models().items():
    res = cross_validate(model, X_dev, y_dev, cv=cv, scoring=SCORING)
    f1_by_model[name] = res["test_f1"]
    for metric in SCORING:
        s = res[f"test_{metric}"]
        rows.append({"model": name, "metric": metric, "mean": s.mean(), "std": s.std(),
                     "folds": " ".join(f"{v:.3f}" for v in s)})
    rows.append({"model": name, "metric": "fit_seconds", "mean": res["fit_time"].mean(),
                 "std": res["fit_time"].std(), "folds": ""})
d = f1_by_model["hgb"] - f1_by_model["logreg"]  # 같은 폴드끼리 뺀 F1 차이 다섯 개(반올림 전 값으로)
rows.append({"model": "hgb-logreg", "metric": "f1_diff", "mean": d.mean(), "std": d.std(),
             "folds": " ".join(f"{v:+.4f}" for v in d)})
table = pd.DataFrame(rows)
table.to_csv("part2_cv_compare.csv", index=False, float_format="%.4f")
print(table.to_string(index=False))
