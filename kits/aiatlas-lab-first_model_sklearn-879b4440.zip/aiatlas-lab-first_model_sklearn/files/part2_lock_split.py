"""2부 7단계 — 모델을 하나도 학습시키기 전에 테스트 행을 뽑아 파일로 잠근다(한 번만 실행)."""
import json
import sys

import pandas as pd
import sklearn
from sklearn.datasets import get_data_home
from sklearn.model_selection import train_test_split

from part2_common import LOCK_JSON, TEST_INDEX, load_adult, sha256_text

if TEST_INDEX.exists():
    raise SystemExit("이미 잠갔다 — 테스트 행은 다시 뽑지 않는다")
adult, X, y, target = load_adult()
print(target.value_counts())
if y.nunique() != 2:
    raise SystemExit("'>50K' 행을 찾지 못했다 — 위 value_counts 의 정답 이름을 보고 load_adult 를 고친다")

dev_idx, test_idx = train_test_split(X.index, test_size=0.2, stratify=y, random_state=0)
text = "\n".join(str(i) for i in sorted(test_idx)) + "\n"
TEST_INDEX.write_text(text, encoding="utf-8")
lock = {
    "dataset": "OpenML adult", "version_requested": 2,
    "openml_id": adult.details.get("id"), "openml_version": adult.details.get("version"),
    "md5_checksum": adult.details.get("md5_checksum"),
    "data_home": get_data_home(),
    "rows": len(X), "dev_rows": len(dev_idx), "test_rows": len(test_idx),
    "positive_rate_dev": float(y.loc[dev_idx].mean()),
    "positive_rate_test": float(y.loc[test_idx].mean()),
    "test_index_sha256": sha256_text(text),
    "python": sys.version.split()[0], "sklearn": sklearn.__version__, "pandas": pd.__version__,
}
LOCK_JSON.write_text(json.dumps(lock, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(lock, ensure_ascii=False, indent=2))
