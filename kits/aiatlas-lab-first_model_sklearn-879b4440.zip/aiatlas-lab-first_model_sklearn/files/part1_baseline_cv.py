"""1부 — 내장 유방암 진단 표로 기준선·파이프라인·5겹 교차검증·문턱값 표를 만든다(내려받기 없음)."""
import sys

import pandas as pd
import sklearn
from sklearn.datasets import load_breast_cancer
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import StratifiedKFold, cross_val_predict, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SCORING = ["accuracy", "precision", "recall", "f1"]
THRESHOLDS = [0.3, 0.5, 0.7]


def rate(num, den):
    """분모가 0 이면 나눌 수 없다는 뜻으로 nan 을 돌려준다."""
    return num / den if den else float("nan")


data = load_breast_cancer()
X = data.data
y = (data.target == 0).astype(int)  # target 0 = malignant(악성) → 찾으려는 쪽을 1(양성)로 바꾼다
print("python", sys.version.split()[0], "· sklearn", sklearn.__version__, "· pandas", pd.__version__)
print("target_names", data.target_names.tolist(), "· 행", len(y), "· 열", X.shape[1], "· 악성", int(y.sum()))

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)  # 정수로 고정 — 두 모델이 같은 폴드를 쓴다
models = {
    "dummy_prior": DummyClassifier(strategy="prior"),  # 입력을 보지 않는 기준선
    "scaler_logreg": make_pipeline(StandardScaler(), LogisticRegression()),
}
rows = []
for name, model in models.items():
    res = cross_validate(model, X, y, cv=cv, scoring=SCORING)
    for metric in SCORING:
        s = res[f"test_{metric}"]
        rows.append({"model": name, "metric": metric, "mean": s.mean(), "std": s.std(),
                     "folds": " ".join(f"{v:.3f}" for v in s)})
cv_table = pd.DataFrame(rows)
cv_table.to_csv("part1_cv.csv", index=False, float_format="%.4f")
print(cv_table.to_string(index=False))

# 문턱값 표 — 행마다 '그 행을 학습에 쓰지 않은 폴드 모델'이 낸 악성 확률(열 1 = classes_ 의 1)
proba = cross_val_predict(models["scaler_logreg"], X, y, cv=cv, method="predict_proba")[:, 1]
th_rows = []
for t in THRESHOLDS:
    pred = (proba >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel().tolist()
    th_rows.append({"threshold": t, "tp": tp, "fp": fp, "fn": fn, "tn": tn,
                    "precision": rate(tp, tp + fp), "recall": rate(tp, tp + fn),
                    "f1": rate(2 * tp, 2 * tp + fp + fn)})
th_table = pd.DataFrame(th_rows)
th_table.to_csv("part1_thresholds.csv", index=False, float_format="%.4f")
print(th_table.to_string(index=False))
