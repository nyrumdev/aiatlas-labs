"""2부 9단계 — 개발 행 안에서만 무작위 탐색으로 후보 하나를 고르고, 잠근 테스트에서 딱 한 번 잰다."""
import json
from pathlib import Path

import pandas as pd
from scipy.stats import loguniform, randint
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold

from part2_common import GROUP_COLS, load_locked, make_models

CHOSEN = ""  # 8단계에서 고른 이름("logreg" 또는 "hgb") — 차이가 흩어짐보다 작으면 시간·설명 쉬움으로 고른 쪽
SPACES = {
    "logreg": {"logisticregression__C": loguniform(1e-3, 1e2)},
    "hgb": {"histgradientboostingclassifier__learning_rate": loguniform(1e-2, 3e-1),
            "histgradientboostingclassifier__max_leaf_nodes": randint(8, 64),
            "histgradientboostingclassifier__min_samples_leaf": randint(10, 100)},
}
RESULT = Path("part2_test.json")


def rate(num, den):
    return num / den if den else float("nan")


def four_cells(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel().tolist()
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "accuracy": rate(tp + tn, tp + fp + fn + tn), "precision": rate(tp, tp + fp),
            "recall": rate(tp, tp + fn), "f1": rate(2 * tp, 2 * tp + fp + fn),
            "false_positive_rate": rate(fp, fp + tn), "false_negative_rate": rate(fn, fn + tp)}


if CHOSEN not in SPACES:
    raise SystemExit('CHOSEN 에 8단계에서 고른 이름("logreg" 또는 "hgb")을 적은 뒤 실행한다')
if RESULT.exists():
    raise SystemExit("잠근 테스트는 이미 한 번 쟀다 — 다시 재지 않는다")
X_dev, y_dev, X_test, y_test = load_locked()
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
search = RandomizedSearchCV(make_models()[CHOSEN], SPACES[CHOSEN], n_iter=20,
                            scoring="f1", cv=cv, random_state=0)
search.fit(X_dev, y_dev)  # 고르기는 개발 행 안에서만 — 끝나면 고른 설정으로 개발 행 전체에 다시 맞춘다
pred = search.predict(X_test)  # 잠근 테스트 — 처음이자 마지막

# 집단별 오류 — 같은 예측을 성별·인종 열로 나눠 센다
frame = X_test[GROUP_COLS].assign(y=y_test.to_numpy(), pred=pred)
rows = []
for col in GROUP_COLS:
    for value, part in frame.groupby(col):
        cells = four_cells(part["y"], part["pred"])
        rows.append({"column": col, "group": value, "n": len(part),
                     "base_rate": part["y"].mean(),  # 실제 양성 비율(기저율)
                     "predicted_positive_rate": part["pred"].mean(),
                     "error_rate": 1 - cells["accuracy"],
                     "false_positive_rate": cells["false_positive_rate"],
                     "false_negative_rate": cells["false_negative_rate"]})
groups = pd.DataFrame(rows)

result = {"chosen": CHOSEN, "n_iter": 20, "best_params": search.best_params_,
          "best_score_cv_f1": search.best_score_, "test_rows": len(y_test),
          "test": four_cells(y_test, pred)}
text = json.dumps(result, ensure_ascii=False, indent=2,
                  default=lambda o: o.item() if hasattr(o, "item") else str(o))  # randint 의 numpy 정수도 정수로
groups.to_csv("part2_groups.csv", index=False, float_format="%.4f")
RESULT.write_text(text + "\n", encoding="utf-8")  # 이 파일이 생기면 다시 재지 않는다
print(text)
print(groups.to_string(index=False))
