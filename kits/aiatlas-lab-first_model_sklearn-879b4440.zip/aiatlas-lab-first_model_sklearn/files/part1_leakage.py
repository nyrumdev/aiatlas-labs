"""1부 — 누출 재현: 나누기 전에 특징을 고르면, 맞힐 길이 없는 정답에서도 정확도가 부푼다(공식 문서 예제를 따름)."""
import json

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.feature_selection import SelectKBest
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import make_pipeline

n_samples, n_features, n_classes = 200, 10000, 2
rng = np.random.RandomState(42)
X = rng.standard_normal((n_samples, n_features))  # 아무 뜻 없는 숫자 1만 열
y = rng.choice(n_classes, n_samples)  # 정답은 동전 던지기 — 어떤 특징과도 무관하다

# 틀린 순서: 200행 전체로 특징 25개를 고른 뒤에 나눈다
X_selected = SelectKBest(k=25).fit_transform(X, y)
X_tr, X_te, y_tr, y_te = train_test_split(X_selected, y, random_state=42)
leaky = HistGradientBoostingClassifier(random_state=1).fit(X_tr, y_tr)
acc_leaky = accuracy_score(y_te, leaky.predict(X_te))

# 옳은 순서: 먼저 나누고, 고르기는 파이프라인 안에서 학습 쪽으로만
X_tr, X_te, y_tr, y_te = train_test_split(X, y, random_state=42)
pipe = make_pipeline(SelectKBest(k=25), HistGradientBoostingClassifier(random_state=1))
pipe.fit(X_tr, y_tr)
acc_pipe = accuracy_score(y_te, pipe.predict(X_te))

# 같은 5겹 교차검증으로 한 번 더: '미리 고른 표'를 넘기기 vs '파이프라인'을 넘기기
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
cv_leaky = cross_validate(HistGradientBoostingClassifier(random_state=1), X_selected, y, cv=cv)["test_score"]
cv_pipe = cross_validate(pipe, X, y, cv=cv)["test_score"]

result = {
    "split_accuracy": {"select_before_split": acc_leaky, "select_in_pipeline": acc_pipe},
    "cv5_accuracy": {
        "select_before_split": {"mean": cv_leaky.mean(), "std": cv_leaky.std(), "folds": cv_leaky.tolist()},
        "select_in_pipeline": {"mean": cv_pipe.mean(), "std": cv_pipe.std(), "folds": cv_pipe.tolist()},
    },
    "positive_share": float(y.mean()),  # 동전 정답의 1 비율 — 우연 수준을 읽는 기준
}
text = json.dumps(result, ensure_ascii=False, indent=2,
                  default=lambda o: o.item() if hasattr(o, "item") else str(o))  # numpy 수 → 파이썬 수(정수는 정수로)
with open("part1_leakage.json", "w", encoding="utf-8") as f:
    f.write(text + "\n")
print(text)
