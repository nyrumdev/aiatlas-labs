# 표데이터 첫 모델을 끝까지 — 기준선·파이프라인·교차검증·잠근 테스트·집단별 오류 — 명령·코드 모음

실습 id: `lab.c.lab.first_model_sklearn`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 판 맞추기 — 앞 실습에서 만든 가상환경을 켜고, 이 실습에 쓸 두 패키지의 판을 적어서 맞춘다. scikit-learn 1.9.1 은 2026-09-10 에, pandas 3.0.6 은 …

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install "scikit-learn==1.9.1" "pandas==3.0.6"
mkdir first_model
cd first_model
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python -m pip freeze | Out-File -Encoding utf8 ..\requirements.lock.txt`
- `pip freeze`

## 3. 기준선과 5겹 교차검증 — 아래를 `part1_baseline_cv.py` 로 저장하고 `python part1_baseline_cv.py` 로 실행한다.

- `files/part1_baseline_cv.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python part1_baseline_cv.py`

## 5. 누출 재현 — 이 과정에서 누출을 일부러 만들어 보는 곳은 여기 한 곳이다. scikit-learn 의 흔한 함정 문서 예제를 그대로 따른다(S954). 정답이 동전 던지기라 어떤 특징으로도 맞힐 수 없는 …

- `files/part1_leakage.py` — 키트에 들어 있음 (python)

## 6. 1부 보고서와 커밋 — `first_model_report.md` 를 앞 실습과 같은 증거 문서 형식으로 쓴다. 첫 부분에 `lab_id: lab.c.lab.first_model_sklearn` 한 줄을 …

```powershell
cd C:\work\ai-lab
git add first_model requirements.txt requirements.lock.txt
git commit -m "first_model 1부: 기준선·교차검증·문턱값·누출 재현"
git rev-parse HEAD
git status
```

```powershell
git add first_model\first_model_report.md
git commit -m "first_model 1부 보고서: 커밋 해시"
git status
```

## 7. 데이터를 판으로 받고, 모델보다 먼저 테스트를 잠근다 — 2부 스크립트는 모두 first_model 폴더에서 실행한다(파일을 현재 폴더 기준으로 읽고 쓴다). 6단계 커밋으로 저장소 맨 위에 나와 있거나 다른 …

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
cd first_model
```

- `files/part2_common.py` — 키트에 들어 있음 (python)

- `files/part2_lock_split.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add first_model\part2_common.py first_model\part2_lock_split.py first_model\adult_lock.json first_model\adult_test_index.txt
git commit -m "first_model 2부: 테스트 행 잠금"
git rev-parse HEAD
cd first_model
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python part2_lock_split.py`

## 8. 두 모델을 같은 폴드에서 비교 — 같은 전처리 묶음 위에 모델 둘을 올린다. ColumnTransformer 는 숫자 네 열을 표준화한다. 범주 여덟 열은 빈칸을 'missing' 이라는 글자로 채운 뒤 …

- `files/part2_compare.py` — 키트에 들어 있음 (python)

## 9. 탐색하고, 잠근 테스트에서 딱 한 번 잰다 — 고른 모델의 설정을 무작위 탐색으로 고른다. RandomizedSearchCV 는 분포에서 정한 수(n_iter)만큼 설정을 뽑는다(S3142). 자릿수가 다른 …

- `files/part2_search_test.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add first_model\part2_common.py first_model\part2_compare.py first_model\part2_cv_compare.csv first_model\part2_search_test.py
git commit -m "first_model 2부: 측정 전 — 고른 모델과 탐색 범위"
git rev-parse HEAD
git status --short
```

```powershell
cd first_model
python part2_search_test.py
```

## 11. 2부 보고서와 커밋 — 보고서의 세 절에 c6~c9 줄과 '한계' 문단을 더하고 올린다.

```powershell
cd C:\work\ai-lab
git add first_model
git commit -m "first_model 2부: 비교·탐색·잠근 테스트·집단별 오류"
git rev-parse HEAD
git diff 잠금해시 HEAD -- first_model/adult_test_index.txt
git diff 측정전해시 HEAD -- first_model/part2_common.py first_model/part2_search_test.py
git log --oneline -- first_model/part2_test.json
```

```powershell
git add first_model\first_model_report.md
git commit -m "first_model 2부 보고서: 커밋 해시"
git status
```

## 검증(자가)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git log --format=%H`
- `git log --oneline`
- `git status`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `cd C:\work\ai-lab`
- `git checkout 잠금해시 -- first_model/adult_test_index.txt`
- `cd first_model`
