# 선호 쌍으로 작은 모델 DPO 한 번 돌리기 — 마진 곡선 · 답 길이 · 회귀 — 명령·코드 모음

실습 id: `lab.c.lab.dpo_mini`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 실행 환경

```bash
mkdir -p ~/dpo-lab/env ~/dpo-lab/configs ~/dpo-lab/data ~/dpo-lab/results && cd ~/dpo-lab
source ~/ft-lab/.venv/bin/activate
{ python -m pip freeze | diff <(grep -v "^--" ~/ft-lab/env/requirements.lock.txt) - && echo "lock 과 같음"; } | tee env/lock_diff.txt
cp ~/ft-lab/env/requirements.lock.txt env/
python -c "import torch, trl, peft, trl.trainer.utils as u; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), torch.cuda.is_bf16_supported(), trl.__version__, peft.__version__, u._ChunkedLogProbFunction)" | tee env/env_check.txt
git init && git config user.name "$(git -C ~/ft-lab config user.name)" && git config user.email "$(git -C ~/ft-lab config user.email)"
printf "runs/*/final/\nruns/*/init/\n__pycache__/\n" > .gitignore && git config user.name && git config user.email
explorer.exe .
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git config user.name "내 이름"` — printf 줄 끝의 두 `git config` 가 내 이름과 메일을 찍어야 한다(빈 줄이면 `git config user.name "내 이름"` · `git config user.email "내 메일"` 로 직접 적는다).
- `git config user.email "내 메일"` — printf 줄 끝의 두 `git config` 가 내 이름과 메일을 찍어야 한다(빈 줄이면 `git config user.name "내 이름"` · `git config user.email "내 메일"` 로 직접 적는다).
- `wsl -l -v` — PowerShell 에서 친 `wsl -l -v` 출력은 리포트에 붙인다.
- `cd ~/dpo-lab && source ~/ft-lab/.venv/bin/activate` — Ubuntu 창을 새로 열 때마다 `cd ~/dpo-lab && source ~/ft-lab/.venv/bin/activate` 를 먼저 친다. (c1)

## 2. 모델·데이터의 커밋과 설정 파일

```bash
hf download Qwen/Qwen2.5-0.5B-Instruct                                              # 마지막 줄 snapshots/ 다음 40자 = 모델 커밋
hf download HuggingFaceH4/ultrafeedback_binarized --repo-type dataset --include "data/*_prefs-*"   # 같은 방식으로 데이터 커밋
```

- `files/configs/D0.json` — 키트에 들어 있음 (json)

## 3. 쌍 만들기와 길이 세기

- `files/dpo_common.py` — 키트에 들어 있음 (python)

- `files/make_pairs.py` — 키트에 들어 있음 (python)

```bash
python make_pairs.py
```

```bash
git add .gitignore *.py configs data env predict.md && git commit -m "쌍·설정·예측(학습 전)"
git log --oneline
```

## 4. 학습 전 측정

```bash
cp /mnt/c/work/evalh/data/eval.jsonl data/notes_eval.jsonl
```

- `files/gen_eval.py` — 키트에 들어 있음 (python)

```bash
python gen_eval.py --set notes --out samples/base_notes.jsonl
python gen_eval.py --set uf --out samples/base_uf.jsonl
```

## 5. 시운전 → 학습 → 마진 곡선

- `files/train_dpo.py` — 키트에 들어 있음 (python)

- `files/derive.py` — 키트에 들어 있음 (python)

```bash
python derive.py D0_smoke max_steps 2
python train_dpo.py configs/D0_smoke.json
grep -E "peak_mem_mib|train_seconds" runs/D0_smoke/run_meta.json
```

```bash
python train_dpo.py configs/D0.json
```

- `files/plot_margins.py` — 키트에 들어 있음 (python)

```bash
python plot_margins.py runs/D0/trainer_state.json --out runs/D0/margins.png
```

## 6. 학습 후 측정과 길이 표

```bash
python gen_eval.py --adapter runs/D0/final --set notes --out samples/D0_notes.jsonl
python gen_eval.py --adapter runs/D0/final --set uf --out samples/D0_uf.jsonl
```

- `files/compare.py` — 키트에 들어 있음 (python)

```bash
python compare.py samples/base_uf.jsonl samples/D0_uf.jsonl --out results/D0_uf
python compare.py samples/base_notes.jsonl samples/D0_notes.jsonl --out results/D0_notes
```

## 7. 회귀 찾기

```bash
mkdir -p /mnt/c/work/evalh/adapters
cp -rT runs/D0/init /mnt/c/work/evalh/adapters/D0_init
cp -rT runs/D0/final /mnt/c/work/evalh/adapters/D0
```

```powershell
Set-Location C:\work\evalh
.\.venv\Scripts\python -m pip show peft | Select-String '^Version'
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,revision=<모델 커밋 40자>,dtype=bfloat16,peft=C:/work/evalh/adapters/D0_init --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval_dpo\before --log_samples
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,revision=<모델 커밋 40자>,dtype=bfloat16,peft=C:/work/evalh/adapters/D0 --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval_dpo\after --log_samples
Get-ChildItem -Recurse results\lm_eval_dpo -Filter samples_notes_mc_*.jsonl
```

- `files/tools/lm_flips.py` — 키트에 들어 있음 (python)

## 8. 리포트

```bash
git add -A && git commit -m "D0 결과"
git log --oneline
```

```bash
git add dpo_report.md && git commit -m "리포트"
cp dpo_report.md /mnt/c/work/dpo_report.md
```

## 9. (선택) 길이 균형 쌍

```bash
python make_pairs.py --balanced
python derive.py D1 train_file '"data/pairs_train_balanced.jsonl"'
python -c "import json,sys; a,b=(json.load(open(p,encoding='utf-8')) for p in sys.argv[1:3]); [print(k, a.get(k), '->', b.get(k)) for k in dict.fromkeys([*a, *b]) if a.get(k) != b.get(k)]" configs/D0.json configs/D1.json
python train_dpo.py configs/D1.json
python gen_eval.py --adapter runs/D1/final --set uf --out samples/D1_uf.jsonl
python compare.py samples/base_uf.jsonl samples/D1_uf.jsonl --out results/D1_uf
```

## 10. (선택) 길이 정규화 손실

```bash
python derive.py D2 loss_type '["sigmoid_norm"]'
python train_dpo.py configs/D2.json
python plot_margins.py runs/D2/trainer_state.json --out runs/D2/margins.png
python gen_eval.py --adapter runs/D2/final --set uf --out samples/D2_uf.jsonl
python compare.py samples/base_uf.jsonl samples/D2_uf.jsonl --out results/D2_uf
```
