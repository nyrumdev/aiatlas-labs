# 첫 신경망을 GPU로 학습시키기(Fashion-MNIST · 진단 점검 포함)

AI 아틀라스 앱의 실습 `lab.c.lab.first_training_run`(L3 · 약 4시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 first_training_run\training_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · 64KiB 이내) · 같은 C:\work\ai-lab\first_training_run 폴더에 test_vs_torch.py · torch_check_log.txt · prepare_data.py · fmnist_common.py · checks.py · checks.json · train.py · pick_lr.py · lr_choice.json · summarize.py · results.md · curves.png · runs 폴더(실행마다 config.json · history.json · best.pt · 본 실행은 confusion.csv 도).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — GPU 가 없으면 5·7단계와 선택 14·15단계의 명령에서 cuda 를 cpu 로 바꾸고 summarize.py 도 --device cpu 로 실행하며, 9단계(c7)는 건너뛰고 그 사실을 보고서에 적는다(9단계는 7단계의 시드 0 폴더와 같은 이름에 3에폭 기록을 덮어쓴다)
- 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 만든 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch·numpy·scikit-learn·matplotlib 이 있고, env_report.json 의 cuda_is_available 이 true
- 앞 실습 [실습] 기울기를 손으로 — 순수 파이썬 경사하강·기울기 검사에서 작은 자동미분 엔진(micrograd)까지의 C:\work\ai-lab\gradients_by_hand\autograd 폴더(engine.py · engine_overwrite.py · nn.py)와, 그때 넣은 pytest
- 인터넷 — torchvision 설치와 Fashion-MNIST 내려받기(압축 파일 넷 · 학습 사진 묶음이 가장 크다)에만 쓴다
- 디스크 여유 — 내려받은 원본·풀어 놓은 파일·분할 파일(data 폴더)과 실행마다의 체크포인트(runs 폴더)

## 들어 있는 파일
- `files/test_vs_torch.py`
- `files/prepare_data.py`
- `files/fmnist_common.py`
- `files/checks.py`
- `files/train.py`
- `files/pick_lr.py`
- `files/summarize.py`
- `files/shift_check.py`
- `files/compare_runs.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.first_training_run` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
