"""checks.py — 본 학습 전 두 점검: ① 첫 손실이 −ln(1/10) 근처인가 ② 표본 20개를 손실 0 근처까지 외우는가.

실행: python checks.py --device cuda      (GPU 가 없으면 --device cpu)
만드는 파일: checks.json
"""
import argparse
import json
import math

import torch
from torch import nn

from fmnist_common import MODELS, load_split, make_model, evaluate

N_SMALL = 20        # 외우게 할 표본 수
STEPS = 500         # 같은 20개로 걷는 걸음 수
LR = 1e-3
INIT_TOL = 0.1      # 첫 손실이 기대값에서 이만큼 안이면 통과
SMALL_LOSS = 0.05   # 20개 손실이 이보다 작고 20개를 다 맞히면 통과


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = parser.parse_args()
    s = load_split()
    expected = -math.log(1 / 10)          # 열 부류에 고르게 1/10 씩 줄 때의 손실 = ln 10
    xs, ys = s["x_train"][:N_SMALL].to(args.device), s["y_train"][:N_SMALL].to(args.device)
    print(f"기대 첫 손실 −ln(1/10) = {expected:.4f} · 20개 안 부류 수 {len(set(ys.tolist()))}")

    results = {"expected_initial_loss": expected, "device": args.device, "models": {}}
    for name in MODELS:
        torch.manual_seed(0)
        model = make_model(name).to(args.device)
        init_loss, _, _ = evaluate(model, s["x_val"], s["y_val"], args.device)   # ① 학습 전, 검증 1만 장

        opt = torch.optim.Adam(model.parameters(), lr=LR)                       # ② 같은 20개만
        loss_fn = nn.CrossEntropyLoss()
        model.train()
        trace = []
        for step in range(1, STEPS + 1):
            loss = loss_fn(model(xs), ys)
            opt.zero_grad()
            loss.backward()
            opt.step()
            if step % 50 == 0:
                trace.append(round(loss.item(), 5))
        small_loss, small_acc, _ = evaluate(model, xs, ys, args.device)
        r = {
            "initial_loss": init_loss,
            "initial_ok": abs(init_loss - expected) < INIT_TOL,
            "overfit_trace_every50": trace,
            "overfit_final_loss": small_loss,
            "overfit_all_correct": small_acc == 1.0,
            "overfit_ok": small_loss < SMALL_LOSS and small_acc == 1.0,
        }
        results["models"][name] = r
        print(f"{name:6s} 첫 손실 {init_loss:.4f} ({'통과' if r['initial_ok'] else '확인 필요'}) | "
              f"20개 손실 {trace} → {small_loss:.5f} · 모두 맞힘 {r['overfit_all_correct']} "
              f"({'통과' if r['overfit_ok'] else '확인 필요'})")

    with open("checks.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("저장: checks.json")


if __name__ == "__main__":
    main()
