"""shift_check.py — (선택) 검증 사진을 오른쪽으로 k 칸 밀면 MLP 와 CNN 의 정확도가 어떻게 바뀌나.

실행: python shift_check.py --device cuda
만드는 파일: shift_check.json
"""
import argparse
import json

import torch

from fmnist_common import evaluate, load_split, make_model

SHIFTS = [0, 1, 2, 3]


def shift_right(x, k):
    """(N, 1, 28, 28) 사진을 오른쪽으로 k 칸 민다 — 왼쪽에 생긴 빈 칸은 0(검정)."""
    if k == 0:
        return x
    out = torch.zeros_like(x)
    out[..., k:] = x[..., :-k]
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    s = load_split()
    result = {}
    for name in ("mlp", "cnn"):
        model = make_model(name).to(args.device)
        ckpt = torch.load(f"runs/{name}_{args.device}_s0/best.pt", weights_only=True)
        model.load_state_dict(ckpt["model"])
        result[name] = {}
        for k in SHIFTS:
            _, acc, _ = evaluate(model, shift_right(s["x_val"], k), s["y_val"], args.device)
            result[name][k] = acc
        print(name, " · ".join(f"{k}칸 {acc:.4f}" for k, acc in result[name].items()))
    with open("shift_check.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print("저장: shift_check.json")


if __name__ == "__main__":
    main()
