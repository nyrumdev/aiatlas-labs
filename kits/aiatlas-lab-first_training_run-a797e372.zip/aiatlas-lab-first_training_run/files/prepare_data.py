"""prepare_data.py — Fashion-MNIST 를 한 번 내려받아 학습·검증·테스트 텐서로 나눠 한 파일에 저장한다.

실행: python prepare_data.py
만드는 파일: data\\FashionMNIST\\raw\\…(내려받은 원본) · data\\fmnist_split.pt
"""
import torch
from torchvision import datasets
from torchvision.transforms import v2

SPLIT_SEED = 0   # 분할 시드 — 학습 시드와 따로 두어, 모든 모델·시드가 같은 분할을 쓴다
N_VAL = 10_000   # 학습용 6만 장에서 떼어 낼 검증 몫
CLASSES = ["T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
           "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"]


def to_tensors(ds):
    """(사진, 정답) 짝을 모두 꺼내 (N, 1, 28, 28) uint8 텐서와 (N,) int64 정답 텐서로 쌓는다."""
    xs, ys = [], []
    for img, label in ds:
        xs.append(img)
        ys.append(label)
    return torch.stack(xs), torch.tensor(ys)   # stack 은 사진 형(Image)을 보통 텐서로 돌려준다


def main():
    to_image = v2.ToImage()   # PIL 사진 → uint8 텐서(값 0~255) · 0~1 로 바꾸는 일은 train.py 가 한다
    train_full = datasets.FashionMNIST(root="data", train=True, download=True, transform=to_image)
    test = datasets.FashionMNIST(root="data", train=False, download=True, transform=to_image)
    x_all, y_all = to_tensors(train_full)
    x_test, y_test = to_tensors(test)

    g = torch.Generator().manual_seed(SPLIT_SEED)
    perm = torch.randperm(len(y_all), generator=g)   # 0 ~ 59999 를 한 번 섞은 순서
    val_idx, train_idx = perm[:N_VAL], perm[N_VAL:]
    split = {
        "x_train": x_all[train_idx], "y_train": y_all[train_idx],
        "x_val": x_all[val_idx], "y_val": y_all[val_idx],
        "x_test": x_test, "y_test": y_test,
        "classes": CLASSES, "split_seed": SPLIT_SEED,
    }
    torch.save(split, "data/fmnist_split.pt")
    for part in ("train", "val", "test"):
        x, y = split["x_" + part], split["y_" + part]
        counts = [int((y == c).sum()) for c in range(10)]
        print(f"{part:5s} {tuple(x.shape)} {x.dtype} 값 {int(x.min())}~{int(x.max())} · 부류별 장수 {counts}")


if __name__ == "__main__":
    main()
