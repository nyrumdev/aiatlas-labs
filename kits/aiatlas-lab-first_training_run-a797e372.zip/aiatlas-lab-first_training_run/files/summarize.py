"""summarize.py — runs 폴더의 기록을 모아 결과 표(results.md)와 곡선 그림(curves.png)을 만든다.

실행: python summarize.py              (시드 평균·곡선은 GPU 실행으로 — 없으면 --device cpu)
만드는 파일: results.md · curves.png
"""
import argparse
import csv
import json
import statistics
from pathlib import Path

import matplotlib.pyplot as plt

from fmnist_common import MODELS


def load_runs():
    runs = []
    for f in sorted(Path("runs").glob("*/history.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        d["name"] = f.parent.name
        runs.append(d)
    return runs


def pick(runs, model, device):
    """한 모델·한 장치의 본 실행만(--tag 를 붙여 다시 돌린 실행은 뺀다) — 시드 순서대로."""
    return [r for r in runs if r["config"]["model"] == model
            and r["config"]["device"] == device and not r["config"].get("tag")]


def top_confusions(run_name, k=3):
    """혼동 행렬에서 대각선 밖 가장 큰 칸 k 개 — (실제, 예측, 장수)."""
    with open(Path("runs") / run_name / "confusion.csv", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    names = rows[0][1:]
    cells = [(int(v), rows[i][0], names[j])
             for i in range(1, len(rows)) for j, v in enumerate(rows[i][1:]) if rows[i][0] != names[j]]
    return sorted(cells, reverse=True)[:k]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    runs = load_runs()
    lines = ["# 결과 표", "", "## 실행마다", "",
             "| 실행 | 학습률 | 파라미터 | 가장 좋은 에폭(검증 손실) | 마지막 에폭(검증 손실) | 조기 종료 지점 "
             "| 테스트 정확도 | 에폭당 초(중앙값) | 최대 GPU 메모리(MiB) |",
             "|---|---|---|---|---|---|---|---|---|"]
    for r in runs:
        sm, h = r["summary"], r["history"]
        mem = "-" if sm["max_memory_allocated_mib"] is None else f"{sm['max_memory_allocated_mib']:.1f}"
        acc = "-" if sm["test_acc"] is None else f"{sm['test_acc']:.4f}"   # 후보 실행은 테스트를 열지 않았다
        stop = "-" if sm["early_stop_epoch"] is None else sm["early_stop_epoch"]   # 인내가 한 번도 차지 않았다
        lines.append(f"| {r['name']} | {r['config']['lr']:g} | {sm['params']:,} | "
                     f"{sm['best_epoch']} ({sm['best_val_loss']:.4f}) | {h[-1]['epoch']} ({h[-1]['val_loss']:.4f}) | "
                     f"{stop} | {acc} | {sm['median_epoch_sec']:.2f} | {mem} |")

    lines += ["", f"## 시드 평균({args.device})", "",
              "| 모델 | 시드 수 | 테스트 정확도 평균 | 표본 표준편차 | 가장 많이 헷갈린 칸(실제→예측: 장수 · 첫 시드) |",
              "|---|---|---|---|---|"]
    for m in MODELS:
        rs = pick(runs, m, args.device)
        if not rs:
            continue
        accs = [r["summary"]["test_acc"] for r in rs]
        sd = f"{statistics.stdev(accs):.4f}" if len(accs) >= 2 else "시드 2개 이상 필요"
        conf = " · ".join(f"{t}→{p_}: {n}" for n, t, p_ in top_confusions(rs[0]["name"]))
        lines.append(f"| {m} | {len(accs)} | {statistics.mean(accs):.4f} | {sd} | {conf} |")

    lines += ["", "## CPU 대 GPU(같은 모델 · 에폭당 학습 시간)", "",
              "| 모델 | CPU 초 | GPU 초 | CPU ÷ GPU |", "|---|---|---|---|"]
    for m in MODELS:
        t = {}
        for dev in ("cpu", "cuda"):
            rs = [r["summary"]["median_epoch_sec"] for r in pick(runs, m, dev)]
            t[dev] = statistics.mean(rs) if rs else None
        if t["cpu"] and t["cuda"]:
            lines.append(f"| {m} | {t['cpu']:.2f} | {t['cuda']:.2f} | {t['cpu'] / t['cuda']:.1f} |")
    Path("results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    fig, axes = plt.subplots(1, len(MODELS), figsize=(13, 3.6), sharey=True)
    for ax, m in zip(axes, MODELS):
        rs = pick(runs, m, args.device)
        if not rs:
            continue
        r = rs[0]
        ep = [h["epoch"] for h in r["history"]]
        ax.plot(ep, [h["train_loss"] for h in r["history"]], label="train")
        ax.plot(ep, [h["val_loss"] for h in r["history"]], label="val")
        ax.axvline(r["summary"]["best_epoch"], color="gray", linestyle="--", label="best val")
        if r["summary"]["early_stop_epoch"]:
            ax.axvline(r["summary"]["early_stop_epoch"], color="red", linestyle=":", label="early stop")
        ax.set_title(r["name"])
        ax.set_xlabel("epoch")
    axes[0].set_ylabel("cross-entropy")
    axes[0].legend()
    fig.savefig("curves.png", dpi=120, bbox_inches="tight")
    print(Path("results.md").read_text(encoding="utf-8"))
    print("저장: results.md · curves.png")


if __name__ == "__main__":
    main()
