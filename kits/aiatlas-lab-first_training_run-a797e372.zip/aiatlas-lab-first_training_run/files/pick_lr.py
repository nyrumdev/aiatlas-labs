"""pick_lr.py — 학습률 후보 실행(--tag lr…)의 검증 손실로 모델마다 학습률 하나를 고른다.

실행: python pick_lr.py --device cuda      (GPU 가 없으면 --device cpu)
만드는 파일: lr_choice.json — train.py 가 --lr 없이 돌 때 여기서 읽는다
"""
import argparse
import json
from pathlib import Path

from fmnist_common import MODELS


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    choice = {}
    for m in MODELS:
        cands = {}
        for f in sorted(Path("runs").glob(f"{m}_{args.device}_s0_lr*/history.json")):
            d = json.loads(f.read_text(encoding="utf-8"))
            cands[d["config"]["lr"]] = min(h["val_loss"] for h in d["history"])   # 이 학습률의 가장 낮은 검증 손실
        if not cands:
            raise SystemExit(f"{m} 의 후보 실행이 없다 — 7단계의 후보 명령부터 친다")
        lrs = sorted(cands)
        best = min(lrs, key=cands.get)
        edge = len(lrs) > 1 and best in (lrs[0], lrs[-1])
        choice[m] = {"lr": best, "best_val_loss": cands[best], "candidates": {str(k): cands[k] for k in lrs},
                     "at_edge": edge}
        print(f"{m:6s} " + " · ".join(f"lr {k:g}: {cands[k]:.4f}" for k in lrs)
              + f" → {best:g}" + (" (후보 범위 끝)" if edge else ""))
    Path("lr_choice.json").write_text(json.dumps(choice, ensure_ascii=False, indent=2), encoding="utf-8")
    print("저장: lr_choice.json")


if __name__ == "__main__":
    main()
