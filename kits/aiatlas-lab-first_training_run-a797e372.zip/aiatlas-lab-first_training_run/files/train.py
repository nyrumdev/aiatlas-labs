"""train.py — 모델 하나를 시드 하나로 학습하고, 에폭마다 학습·검증 손실과 시간을 남긴다.

실행 예: python train.py --model cnn --device cuda --seed 0
만드는 폴더: runs\\<모델>_<장치>_s<시드>\\ — config.json · history.json · best.pt · confusion.csv
"""
import argparse
import json
import platform
import statistics
import subprocess
import time
from pathlib import Path

import torch
from sklearn.metrics import confusion_matrix
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from fmnist_common import MODELS, count_params, evaluate, load_split, make_model


def git_commit():
    """지금 코드의 커밋 해시(40자리)와, 추적 중인 파일에 커밋하지 않은 수정이 있는지."""
    def run(*cmd):
        try:
            r = subprocess.run(["git", *cmd], capture_output=True, text=True)
        except FileNotFoundError:
            raise SystemExit("git 을 찾을 수 없다 — 앞 노드 git 기초의 설치부터 다시 본다")
        if r.returncode != 0:   # check 를 주지 않아 실패해도 예외가 없다 — 종료 코드를 직접 본다
            raise SystemExit(f"git {cmd[0]} 실패 — 6단계에서 커밋한 저장소 안에서 실행한다: {r.stderr.strip()}")
        return r.stdout.strip()
    return run("rev-parse", "HEAD"), run("describe", "--always", "--dirty").endswith("-dirty")


def sync(device):
    if device == "cuda":
        torch.cuda.synchronize()   # GPU 는 비동기 — 맡긴 일이 끝날 때까지 기다린 뒤 시계를 본다


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True, choices=MODELS)
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch", type=int, default=128)
    p.add_argument("--lr", type=float, default=None, help="안 주면 lr_choice.json 에서 이 모델의 값을 읽는다")
    p.add_argument("--patience", type=int, default=3)
    p.add_argument("--tag", default="", help="같은 설정을 다시 돌릴 때 폴더 이름 끝에 붙일 말")
    p.add_argument("--no-test", action="store_true", help="학습률 후보 실행 — 테스트 조각을 열지 않는다")
    args = p.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA 를 쓸 수 없다 — 앞 실습의 env_report.json 부터 다시 본다")
    if args.lr is None:                                        # 7단계 앞부분에서 모델마다 고른 학습률
        choice = Path("lr_choice.json")
        if not choice.exists():
            raise SystemExit("lr_choice.json 이 없다 — 7단계의 학습률 고르기(pick_lr.py)를 먼저 한다")
        args.lr = json.loads(choice.read_text(encoding="utf-8"))[args.model]["lr"]

    commit, dirty = git_commit()                              # 저장소 밖이면 폴더를 만들기 전에 멈춘다
    run_dir = Path("runs") / f"{args.model}_{args.device}_s{args.seed}{'_' + args.tag if args.tag else ''}"
    run_dir.mkdir(parents=True, exist_ok=True)
    config = {**vars(args), "torch": torch.__version__, "python": platform.python_version(),
              "device_name": torch.cuda.get_device_name(0) if args.device == "cuda" else platform.processor(),
              "git_commit": commit, "git_dirty": dirty}
    (run_dir / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    s = load_split()
    torch.manual_seed(args.seed)                              # 가중치 첫 값
    g = torch.Generator().manual_seed(args.seed)              # 섞는 순서
    loader = DataLoader(TensorDataset(s["x_train"], s["y_train"]),
                        batch_size=args.batch, shuffle=True, generator=g)
    model = make_model(args.model).to(args.device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()
    print(f"{run_dir.name} · 파라미터 {count_params(model):,}개 · {config['device_name']}")

    cuda = args.device == "cuda"
    history, best, stop_epoch, bad = [], float("inf"), None, 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        if cuda:
            torch.cuda.reset_peak_memory_stats()             # 이번 에폭 학습 루프의 최댓값만 보려고
        sync(args.device)
        start = time.perf_counter()
        total = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(args.device), yb.to(args.device)
            loss = loss_fn(model(xb), yb)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += loss.item() * len(yb)
        sync(args.device)
        sec = time.perf_counter() - start                     # 학습 루프만 잰 에폭 시간
        peak = torch.cuda.max_memory_allocated() / 2**20 if cuda else None   # MiB · 검증 전에 읽는다
        val_loss, val_acc, _ = evaluate(model, s["x_val"], s["y_val"], args.device)
        history.append({"epoch": epoch, "train_loss": total / len(loader.dataset),
                        "val_loss": val_loss, "val_acc": val_acc, "sec": sec, "peak_mib": peak})
        if val_loss < best:                                   # 검증 손실이 나아졌을 때만 저장
            best, bad = val_loss, 0
            torch.save({"epoch": epoch, "model": model.state_dict(), "opt": opt.state_dict()},
                       run_dir / "best.pt")
        else:
            bad += 1
            if bad == args.patience and stop_epoch is None:
                stop_epoch = epoch                            # 조기 종료라면 여기서 멈췄다(기록만 하고 계속 돈다)
        print(f"에폭 {epoch:2d} | 학습 {history[-1]['train_loss']:.4f} | 검증 {val_loss:.4f} | "
              f"검증 정확도 {val_acc:.4f} | {sec:.2f}초")

    ckpt = torch.load(run_dir / "best.pt", weights_only=True)  # 가장 좋았던 검증 손실의 가중치로
    test_loss = test_acc = None
    if not args.no_test:
        model.load_state_dict(ckpt["model"])
        test_loss, test_acc, preds = evaluate(model, s["x_test"], s["y_test"], args.device)   # 테스트는 여기서 한 번
        cm = confusion_matrix(s["y_test"].tolist(), preds.tolist(), labels=list(range(10)))
        with open(run_dir / "confusion.csv", "w", encoding="utf-8") as f:
            f.write("true\\pred," + ",".join(s["classes"]) + "\n")
            for name, row in zip(s["classes"], cm.tolist()):
                f.write(name + "," + ",".join(map(str, row)) + "\n")

    summary = {
        "best_epoch": ckpt["epoch"], "early_stop_epoch": stop_epoch,
        "best_val_loss": best, "last_val_loss": history[-1]["val_loss"],
        "test_loss": test_loss, "test_acc": test_acc,
        "median_epoch_sec": statistics.median(h["sec"] for h in history),   # 첫 에폭의 준비 시간에 덜 흔들리게
        "max_memory_allocated_mib": max(h["peak_mib"] for h in history) if cuda else None,
        "params": count_params(model),
    }
    (run_dir / "history.json").write_text(
        json.dumps({"config": config, "summary": summary, "history": history}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    acc = "열지 않음" if test_acc is None else f"{test_acc:.4f}"
    print(f"가장 좋은 에폭 {summary['best_epoch']} · 조기 종료 지점 {stop_epoch} · "
          f"테스트 정확도 {acc} · 저장: {run_dir}")


if __name__ == "__main__":
    main()
