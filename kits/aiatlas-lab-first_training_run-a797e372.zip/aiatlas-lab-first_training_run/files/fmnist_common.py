"""fmnist_common.py — 세 스크립트(checks · train · summarize)가 함께 쓰는 데이터·모델·평가 부품."""
import torch
from torch import nn

SPLIT_PATH = "data/fmnist_split.pt"
MODELS = ("logreg", "mlp", "cnn")


def load_split(path=SPLIT_PATH):
    """prepare_data.py 가 만든 파일을 읽고, 사진을 0~1 실수로 바꾼다."""
    s = torch.load(path, weights_only=True)
    for part in ("train", "val", "test"):
        s["x_" + part] = s["x_" + part].float() / 255   # uint8 0~255 → float32 0~1
    return s


def make_model(name):
    """이름 하나로 세 모델 가운데 하나를 만든다. 셋 다 마지막은 10칸 로짓이다."""
    if name == "logreg":   # 기준선: 784칸을 곧장 10칸 로짓으로 — 층 하나짜리 선형 분류기
        return nn.Sequential(nn.Flatten(), nn.Linear(28 * 28, 10))
    if name == "mlp":      # 은닉층 둘
        return nn.Sequential(
            nn.Flatten(),
            nn.Linear(28 * 28, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 10))
    if name == "cnn":      # 합성곱 두 번(3×3 · 가장자리 1칸 채움) + 2×2 최대 풀링 두 번
        return nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),   # → 16×14×14
            nn.Conv2d(16, 32, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),  # → 32×7×7
            nn.Flatten(),
            nn.Linear(32 * 7 * 7, 128), nn.ReLU(),
            nn.Linear(128, 10))
    raise ValueError(f"모르는 모델 이름: {name}")


def count_params(model):
    return sum(p.numel() for p in model.parameters())


@torch.no_grad()
def evaluate(model, x, y, device, batch=1000):
    """평균 손실·정확도·예측 전체를 돌려준다. 평가 모드 + 기록 끄기."""
    model.eval()
    loss_fn = nn.CrossEntropyLoss()
    total, preds = 0.0, []
    for i in range(0, len(y), batch):
        xb, yb = x[i:i + batch].to(device), y[i:i + batch].to(device)
        logits = model(xb)
        total += loss_fn(logits, yb).item() * len(yb)   # 묶음 평균 × 묶음 크기 = 묶음 합
        preds.append(logits.argmax(dim=1).cpu())
    preds = torch.cat(preds)
    return total / len(y), (preds == y.cpu()).float().mean().item(), preds
