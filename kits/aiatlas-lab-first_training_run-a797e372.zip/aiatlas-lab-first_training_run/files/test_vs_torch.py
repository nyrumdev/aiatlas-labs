"""test_vs_torch.py — 앞 실습의 손 엔진(engine.py · nn.py)이 낸 기울기를 torch.autograd 와 견준다.

실행(first_training_run 폴더에서): python -m pytest -v test_vs_torch.py
"""
import math
import random
import sys
from pathlib import Path

import torch

# 앞 실습 폴더의 엔진을 불러온다 — 파일을 복사하지 않고 원본을 그대로 시험한다
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "gradients_by_hand" / "autograd"))
from engine import Value  # noqa: E402
from nn import MLP  # noqa: E402

REL = 1e-9  # 두 쪽 모두 배정밀도(float64)라 차이는 반올림 몇 자리뿐이어야 한다


def close(a, b):
    return math.isclose(a, b, rel_tol=REL, abs_tol=1e-12)


def compare(fn_value, fn_torch, inputs):
    """같은 식을 두 엔진으로 계산해 출력값과 입력마다의 기울기를 견준다."""
    vals = [Value(x) for x in inputs]
    out_v = fn_value(vals)
    out_v.backward()
    ts = [torch.tensor(x, dtype=torch.float64, requires_grad=True) for x in inputs]
    out_t = fn_torch(ts)
    out_t.backward()
    assert close(out_v.data, out_t.item())
    for i, (v, t) in enumerate(zip(vals, ts)):
        assert close(v.grad, t.grad.item()), f"입력 {i}: 손 엔진 {v.grad} · torch {t.grad.item()}"


def test_add_mul():
    compare(lambda v: v[0] * v[1] + v[1] * v[2],
            lambda t: t[0] * t[1] + t[1] * t[2], [2.0, -3.0, 0.5])


def test_pow_tanh_sub():
    compare(lambda v: (v[0] * v[1] - 1).tanh() ** 2 + v[0] ** 3,
            lambda t: torch.tanh(t[0] * t[1] - 1) ** 2 + t[0] ** 3, [0.3, -0.7])


def test_reused_node():
    compare(lambda v: v[0] * v[0] + v[0], lambda t: t[0] * t[0] + t[0], [3.0])


def test_mlp_parameters():
    random.seed(1)
    model = MLP(2, [4, 4, 1])
    xs = [[0.5, -1.0], [1.5, 0.3], [-0.2, 0.8]]
    ys = [1.0, -1.0, 1.0]
    loss_v = sum((model(x) - y) ** 2 for x, y in zip(xs, ys))
    loss_v.backward()

    # 같은 가중치를 torch 텐서로 옮긴다 — 층마다 W(출력 수 × 입력 수)와 b(출력 수)
    Ws, bs = [], []
    for layer in model.layers:
        Ws.append(torch.tensor([[w.data for w in n.w] for n in layer.neurons],
                               dtype=torch.float64, requires_grad=True))
        bs.append(torch.tensor([n.b.data for n in layer.neurons],
                               dtype=torch.float64, requires_grad=True))
    h = torch.tensor(xs, dtype=torch.float64)
    for W, b in zip(Ws, bs):
        h = torch.tanh(h @ W.T + b)  # 모든 층에 tanh — nn.py 와 같은 짜임
    loss_t = ((h.squeeze(1) - torch.tensor(ys, dtype=torch.float64)) ** 2).sum()
    loss_t.backward()

    assert close(loss_v.data, loss_t.item())
    for L, layer in enumerate(model.layers):
        for j, n in enumerate(layer.neurons):
            for k, w in enumerate(n.w):
                assert close(w.grad, Ws[L].grad[j, k].item()), f"층 {L} 뉴런 {j} 가중치 {k}"
            assert close(n.b.grad, bs[L].grad[j].item()), f"층 {L} 뉴런 {j} 편향"


def test_overwrite_engine_is_caught():
    """앞 실습에서 일부러 망가뜨린 엔진은 torch 와 달라야 한다 — 이 시험 틀이 버그를 잡는다는 증거."""
    import engine_overwrite
    a = engine_overwrite.Value(3.0)
    (a * a + a).backward()
    t = torch.tensor(3.0, dtype=torch.float64, requires_grad=True)
    (t * t + t).backward()
    assert not close(a.grad, t.grad.item())
