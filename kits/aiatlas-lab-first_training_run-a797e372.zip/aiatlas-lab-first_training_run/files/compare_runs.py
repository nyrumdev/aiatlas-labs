"""compare_runs.py — (선택) 같은 설정으로 두 번 돌린 기록 둘을 에폭마다 견준다.

실행: python compare_runs.py runs\\cnn_cuda_s0 runs\\cnn_cuda_s0_again
"""
import json
import sys
from pathlib import Path


def load(run_dir):
    return json.loads((Path(run_dir) / "history.json").read_text(encoding="utf-8"))


a, b = load(sys.argv[1]), load(sys.argv[2])
diffs = [abs(x["val_loss"] - y["val_loss"]) for x, y in zip(a["history"], b["history"])]
same = sum(d == 0.0 for d in diffs)
print(f"검증 손실이 끝자리까지 같은 에폭 {same}/{len(diffs)} · 가장 큰 차이 {max(diffs):.3e}")
print(f"가장 좋은 에폭 {a['summary']['best_epoch']} 대 {b['summary']['best_epoch']} · "
      f"테스트 정확도 {a['summary']['test_acc']:.4f} 대 {b['summary']['test_acc']:.4f}")
