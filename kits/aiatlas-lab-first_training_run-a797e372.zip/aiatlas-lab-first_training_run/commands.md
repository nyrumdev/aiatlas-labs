# 첫 신경망을 GPU로 학습시키기(Fashion-MNIST · 진단 점검 포함) — 명령·코드 모음

실습 id: `lab.c.lab.first_training_run`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 torchvision

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -c "import torch; print(torch.__version__)"
python -m pip index versions torchvision --index-url https://download.pytorch.org/whl/cu132
python -m pip install "torchvision==0.29.2" --index-url https://download.pytorch.org/whl/cu132 --dry-run
python -m pip install "torchvision==0.29.2" --index-url https://download.pytorch.org/whl/cu132
python -c "import sys, torch, torchvision; print(sys.version); print(torch.__version__, torchvision.__version__, torch.cuda.is_available())"
mkdir first_training_run
cd first_training_run
```

## 2. 대조 먼저

- `files/test_vs_torch.py` — 키트에 들어 있음 (python)

```powershell
python -m pytest -v test_vs_torch.py
$LASTEXITCODE
python -m pytest -v test_vs_torch.py | Out-File -Encoding utf8 torch_check_log.txt
```

## 3. 데이터

- `files/prepare_data.py` — 키트에 들어 있음 (python)

## 4. 공용 부품

- `files/fmnist_common.py` — 키트에 들어 있음 (python)

## 5. 점검 먼저

- `files/checks.py` — 키트에 들어 있음 (python)

## 6. 코드를 먼저 커밋

- `files/train.py` — 키트에 들어 있음 (python)

- `files/pick_lr.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
Add-Content .gitignore "data/", "*.pt"
git add .
git commit -m "첫 학습 실습 — 대조·데이터·점검·학습 코드"
git rev-parse HEAD
cd first_training_run
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git describe --always --dirty` — 함께 `git describe --always --dirty` 를 부른다.

## 7. 학습률 고르기와 본 학습(GPU)

```powershell
foreach ($m in "logreg", "mlp", "cnn") { foreach ($lr in "3e-4", "1e-3", "3e-3", "1e-2") { python train.py --model $m --device cuda --seed 0 --epochs 10 --lr $lr --tag "lr$lr" --no-test } }
python pick_lr.py --device cuda
```

```powershell
python train.py --model logreg --device cuda --seed 0
python train.py --model logreg --device cuda --seed 1
python train.py --model logreg --device cuda --seed 2
python train.py --model mlp --device cuda --seed 0
python train.py --model mlp --device cuda --seed 1
python train.py --model mlp --device cuda --seed 2
python train.py --model cnn --device cuda --seed 0
python train.py --model cnn --device cuda --seed 1
python train.py --model cnn --device cuda --seed 2
```

```powershell
Get-ChildItem runs -Directory | ForEach-Object { $c = Get-Content (Join-Path $_.FullName config.json) -Raw -Encoding UTF8 | ConvertFrom-Json; '{0}  {1}  dirty={2}  lr={3}' -f $_.Name, $c.git_commit, $c.git_dirty, $c.lr }
```

## 8. 결과 모으기

- `files/summarize.py` — 키트에 들어 있음 (python)

## 9. CPU 시간

```powershell
python train.py --model logreg --device cpu --seed 0 --epochs 3
python train.py --model mlp --device cpu --seed 0 --epochs 3
python train.py --model cnn --device cpu --seed 0 --epochs 3
python summarize.py
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python summarize.py --device cpu` — 건너뛸 때도 아래 블록의 마지막 줄만은 `python summarize.py --device cpu` 로 친다.

## 12. 판 기록과 결과 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 그다음 `git add .` 와 `git commit -m "첫 학습 실습 — 결과 표·곡선·실행 기록"` 을 친다.
- `git commit -m "첫 학습 실습 — 결과 표·곡선·실행 기록"` — 그다음 `git add .` 와 `git commit -m "첫 학습 실습 — 결과 표·곡선·실행 기록"` 을 친다.
- `git rev-parse HEAD` — `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다(S764).
- `git status` — `git status` 에 data 폴더와 .pt 파일이 보이지 않는지도 본다.

## 13. 보고서

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 다 쓰면 first_training_run 폴더에서 `git add .` 와 `git commit -m "첫 학습 실습 — 보고서"` 로 보고서(선택 단계를 했다면 그 파일까지)를 올리고, `git status` 가 working tree clean 인지 본다.
- `git commit -m "첫 학습 실습 — 보고서"` — 다 쓰면 first_training_run 폴더에서 `git add .` 와 `git commit -m "첫 학습 실습 — 보고서"` 로 보고서(선택 단계를 했다면 그 파일까지)를 올리고, `git status` 가 working tree clean 인지 본다.
- `git status` — 다 쓰면 first_training_run 폴더에서 `git add .` 와 `git commit -m "첫 학습 실습 — 보고서"` 로 보고서(선택 단계를 했다면 그 파일까지)를 올리고, `git status` 가 working tree clean 인지 본다.

## 14. (선택) 밀어 보기

- `files/shift_check.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cd first_training_run` — 12단계에서 저장소 맨 위로 나왔으니 `cd first_training_run` 으로 돌아간다.

## 15. (선택) 같은 시드 다시

- `files/compare_runs.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python train.py --model cnn --device cuda --seed 0 --tag again` — (선택) 같은 시드 다시 — first_training_run 폴더에서 `python train.py --model cnn --device cuda --seed 0 --tag again` 로 같은 설정을 한 번 더 돌린다.
- `python compare_runs.py runs\cnn_cuda_s0 runs\cnn_cuda_s0_again` — 아래를 `compare_runs.py` 로 저장하고 `python compare_runs.py runs\cnn_cuda_s0 runs\cnn_cuda_s0_again` 을 친다.

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git log --oneline` — `git log --oneline` 에 코드 커밋과 결과 커밋이 있고, `git ls-files` 에 data 폴더와 .pt 파일이 없으며, requirements.txt 에 torchvision 줄이 있는가
- `git ls-files` — `git log --oneline` 에 코드 커밋과 결과 커밋이 있고, `git ls-files` 에 data 폴더와 .pt 파일이 없으며, requirements.txt 에 torchvision 줄이 있는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python --version` — torchvision 설치가 고른 판(예 `==0.29.2`)에 맞는 파일이 없다며 멈춘다 → `python --version` 이 정확히 3.14.1 이면 torchvision 0.29.1·0.29.2 는 설치되지 않는다.
- `py list` — `py list` 로 판을 보고, `py install --update` 로 설치 관리자가 관리하는 파이썬을 새 판으로 올린다(S160).
- `py install --update` — `py list` 로 판을 보고, `py install --update` 로 설치 관리자가 관리하는 파이썬을 새 판으로 올린다(S160).
- `py -V:3.14 -m venv .venv` — … `deactivate` → `Remove-Item -Recurse -Force .venv`(S161) → `py -V:3.14 -m venv .venv` → `.\.venv\Scripts\Activate.ps1` → …
- `python -m pip install -r requirements.lock.txt` — … -Force .venv`(S161) → `py -V:3.14 -m venv .venv` → `.\.venv\Scripts\Activate.ps1` → `python -m pip install -r requirements.lock.txt …
- `python check_gpu.py` — 그 뒤 `python check_gpu.py` 로 env_report.json 을 다시 만들고 1단계부터 다시 한다.
- `python -m pip uninstall torchvision` — `python -m pip uninstall torchvision` 뒤 1단계 명령을 다시 친다.
- `git status` — 그 폴더에서 `git status` 를 쳐 저장소 안인지 보고, 저장소 안의 폴더로 돌아가 다시 친다.
