# 단일 호출 vs 워크플로 vs 에이전트 — 같은 시나리오 셋으로 견주기(에이전트 레슨 4편 직접 해 보기 통합) — 명령·코드 모음

실습 id: `lab.c.lab.tool_agent`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기

```powershell
New-Item -ItemType Directory C:\work\agent\lessons -Force
Set-Location C:\work\agent
python -m venv .venv
.\.venv\Scripts\python -m pip install requests jsonschema
.\.venv\Scripts\python -m pip freeze | Out-File -Encoding utf8 requirements.txt
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py -m venv .venv` — 셋째 줄에서 `python` 을 찾을 수 없다고 나오거나 Microsoft Store 가 열리면, 그 줄만 `py -m venv .venv`(Windows 의 py 명령)로 바꿔 친다.
- `py --version` — 그 전에 `py --version` 이 3.10 이상인지 본다(선택 c9 는 3.11 이상).

## 2. 레슨 넷 가져오기

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 lessons\agent_eval_grade.py | Out-File -Encoding utf8 lessons\grade_check.txt
```

## 3. 모델과 주소 확인

- `files/check_env.py` — 키트에 들어 있음 (python)

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 check_env.py
```

## 4. 환경과 도구 — tools.py

- `files/tools.py` — 키트에 들어 있음 (python)

## 5. 세 안 — ways.py

- `files/ways.py` — 키트에 들어 있음 (python)

## 6. 시나리오 셋 — scenarios.csv

- `files/scenarios.csv` — 키트에 들어 있음 (text)

## 7. 채점기 먼저, 그다음 돌리기 — run.py

- `files/run.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python -X utf8 run.py --selftest` — 모델을 부르기 전에 `.\.venv\Scripts\python -X utf8 run.py --selftest` 로 채점기부터 시험한다.
- `.\.venv\Scripts\python -X utf8 run.py` — (c3) 그다음 남아 있던 results.csv·trace.jsonl 을 지우고 `.\.venv\Scripts\python -X utf8 run.py` 로 세 안을 모두 돌린다.

## 8. 한 표로 — summarize.py

- `files/summarize.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python -X utf8 summarize.py
```

## 9. 실패 읽기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"way": "agent", "id": "T09", "run": 1'` — 줄마다 way·id·run 이 앞에 붙으므로 `Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"way": "agent", "id": "T09", "run": 1'` 처럼 한 시도의 줄을 모아 읽는다.

## 11. (선택) 생각 켜기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python -X utf8 run.py agent+think` — `.\.venv\Scripts\python -X utf8 run.py agent+think` 로 ways.py 의 agent_think(같은 에이전트에 think 만 true)를 돌리면, results.csv 에 way 칸이 agent+think 인 행이 이어 쓰인다.

## 12. (선택) 도구 서버를 MCP 로

- `files/server.py` — 키트에 들어 있음 (python)

- `files/mcp_check.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python -X utf8 mcp_check.py
```

```powershell
$env:Path = (Resolve-Path .\.venv\Scripts).Path + ";" + $env:Path
.\.venv\Scripts\mcp dev server.py
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python -m pip install "mcp[cli]==2.3.0" uv` — `.\.venv\Scripts\python -m pip install "mcp[cli]==2.3.0" uv` 뒤 requirements.txt 를 다시 뽑는다.
- `uv run --with mcp… mcp run server.py` — SDK 의 dev 명령은 Inspector 를 npx 로, 서버를 `uv run --with mcp… mcp run server.py` 로 띄운다.

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama ps` — `ollama ps` 로 모델이 GPU 에 올라갔는지부터 본다.
- `ollama list` — 모델을 찾을 수 없다는 오류 → `ollama list` 에 gemma4:e4b 가 없다.
- `ollama pull gemma4:e4b` — `ollama pull gemma4:e4b` 로 받는다.
- `ollama serve` — PowerShell 창에서 `ollama serve` 로 띄웠다면 로그는 그 창에 찍힌다(S536).
- `mcp dev` — `mcp dev` 가 npx 를 찾을 수 없다고 하면 Node.js 를 설치한 뒤 새 PowerShell 창에서 다시 연다.
