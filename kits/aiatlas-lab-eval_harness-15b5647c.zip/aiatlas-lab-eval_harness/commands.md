# 내 평가 하네스 만들기(Inspect + lm-eval, 로컬 모델) — 명령·코드 모음

실습 id: `lab.c.lab.eval_harness`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기

```powershell
New-Item -ItemType Directory C:\work\evalh\data, C:\work\evalh\tasks\lm_eval, C:\work\evalh\tools, C:\work\evalh\results -Force
Set-Location C:\work\evalh
py install 3.13
py -V:3.13 -m venv .venv
.\.venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cu128
.\.venv\Scripts\python -m pip install "inspect-ai==0.3.281" openai "lm-eval[hf]==0.4.13"
"--extra-index-url https://download.pytorch.org/whl/cu128" | Out-File -Encoding utf8 requirements.lock.txt
.\.venv\Scripts\python -m pip freeze | Out-File -Append -Encoding utf8 requirements.lock.txt
```

```powershell
ollama list
py -V:3.13 --version | Out-File -Encoding utf8 results\env.md
ollama --version | Out-File -Append -Encoding utf8 results\env.md
.\.venv\Scripts\python -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())" | Out-File -Append -Encoding utf8 results\env.md
.\.venv\Scripts\python -m pip show inspect-ai lm-eval | Select-String '^(Name|Version)' | Out-File -Append -Encoding utf8 results\env.md
ollama show gemma4:e4b | Out-File -Append -Encoding utf8 results\env.md
```

```powershell
$env:OLLAMA_BASE_URL = "http://127.0.0.1:11434/v1"
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `pip install -r requirements.lock.txt` — 요구사항 파일 맨 위에 색인 줄을 두어야(S3455) 나중에 `pip install -r requirements.lock.txt` 가 같은 판을 찾는다.
- `ollama pull gemma4:e4b` — `ollama list` 에 gemma4:e4b 가 없으면 `ollama pull gemma4:e4b` 로 받고 마지막 줄을 다시 친다.

## 2. 평가셋 쓰기

```json
{"id": "t01", "kind": "term", "q": "평가 하네스에서 지난 실행과 이번 실행을 문항 id 로 맞대어 뒤집힌 문항을 뽑는 부품은?", "a": "리포터", "alias": ["reporter"], "wrong": ["로더", "실행기", "채점기"]}
{"id": "c01", "kind": "calc", "q": "사람과 심판이 30문항 가운데 24문항에서 같은 판정을 냈다. 일치율은 몇 퍼센트인가? 숫자만.", "a": "80", "alias": ["80%"]}
```

- `files/tools/check_data.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\check_data.py
```

## 3. 과제 파일

- `files/tasks/notes.py` — 키트에 들어 있음 (python)

- `files/tasks/judge.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `inspect log dump` — 로그에는 문항마다 모델 호출의 요청 본문이 남고, `inspect log dump` 가 로그를 JSON 으로 찍어 보여 준다(S3643).
- `ollama show gemma4:e4b` — 그러니 내가 받은 파일의 값은 1단계에서 env.md 에 남긴 `ollama show gemma4:e4b` 의 매개변수 줄로 읽는다.
- `ollama show` — 요청에 생각 칸이 없으면 Ollama 는 그 모델의 기본값을 쓰고, 그 값은 `ollama show` 출력의 Capabilities 아래 thinking 의 default 줄에 보인다(S9285).

## 4. 리포터 공통 부분과 시험 실행

- `files/tools/loglib.py` — 키트에 들어 있음 (python)

- `files/tools/peek.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --limit 2 --log-dir logs\smoke
.\.venv\Scripts\python tools\peek.py logs\smoke results\env.md
Get-Content -Encoding utf8 results\env.md
```

## 5. 첫 실행과 사람 채점

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\direct_run1
```

- `files/tools/export_sheet.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\export_sheet.py logs\direct_run1
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `inspect view` — 터미널 끝에 찍히는 전체 정답률은 보여도 괜찮지만, 문항별 점수가 보이는 `inspect view`(S3643)는 채점을 마친 뒤에 연다.

## 6. 같은 설정 두 번

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\direct_run2
```

- `files/tools/compare_runs.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\compare_runs.py logs\direct_run1 logs\direct_run2
```

## 7. 심판으로 다시 채점하고 일치율 재기

```powershell
$run1 = (Get-ChildItem logs\direct_run1\*.eval | Where-Object Name -NotLike "*-scored*" | Sort-Object Name | Select-Object -Last 1).FullName
$scored = $run1 -replace '\.eval$', '-scored.eval'
.\.venv\Scripts\inspect score $run1 --scorer tasks\judge.py@note_judge --action append --output-file $scored --overwrite
```

- `files/tools/agree.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\agree.py logs\direct_run1
```

## 8. few-shot 예시 순서 다섯 가지

```powershell
foreach ($o in "ABCD", "BCDA", "CDAB", "DABC", "DCBA") {
    .\.venv\Scripts\inspect eval tasks\notes.py@notes_fewshot -T order=$o --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\fewshot_$o
}
.\.venv\Scripts\inspect eval tasks\notes.py@notes_fewshot -T order=ABCD --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\fewshot_ABCD_again
```

- `files/tools/order_table.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\compare_runs.py logs\fewshot_ABCD logs\fewshot_ABCD_again repro_fewshot.md
.\.venv\Scripts\python tools\order_table.py
```

## 9. 자기 일관성 — 표본 수 1·3·5·8

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_sc --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\sc
```

- `files/tools/sc_table.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\sc_table.py logs\sc
```

```powershell
.\.venv\Scripts\python tools\peek.py logs\sc results\sc_peek.md
(Select-String -Path results\sc_peek.md -Encoding utf8 -SimpleMatch '출력 토큰 1024 ').Count
```

## 10. 가능도 과제는 lm-eval 의 HF 경로로

- `files/tools/make_mc.py` — 키트에 들어 있음 (python)

- `files/tasks/lm_eval/notes_mc.yaml` — 키트에 들어 있음 (yaml)

```powershell
.\.venv\Scripts\python tools\make_mc.py
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,dtype=bfloat16 --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval --log_samples
```

## 12. (선택) 같은 객관식을 생성 방식으로

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_mc_gen --model hf/Qwen/Qwen2.5-0.5B-Instruct -M do_sample=False --log-dir logs\mc_gen
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `inspect view` — 출력 토큰 합이 문항 수 × 64 와 같으면 모든 답이 잘린 것이니, 잘린 답 두셋을 `inspect view` 로 열어 choice 채점기가 어느 보기 글자를 읽었는지 확인하고 report.md 에 적는다.

## 13. (선택) 다른 심판

```powershell
New-Item -ItemType Directory logs\judge_12b -Force
$orig = (Get-ChildItem logs\direct_run1\*.eval | Where-Object Name -NotLike "*-scored*" | Sort-Object Name | Select-Object -Last 1).FullName
Copy-Item $orig logs\judge_12b\
$copy = (Get-ChildItem logs\judge_12b\*.eval | Where-Object Name -NotLike "*-scored*" | Select-Object -First 1).FullName
$copy_scored = $copy -replace '\.eval$', '-scored.eval'
.\.venv\Scripts\inspect score $copy --scorer tasks\judge.py@note_judge -S judge=ollama/gemma4:12b --action append --output-file $copy_scored --overwrite
.\.venv\Scripts\python tools\agree.py logs\judge_12b _12b
```

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py install 3.13` — `py install 3.13` 이 `can't open file '…\install'` 을 낸다 → 지금의 `py` 는 예전 Python launcher 다.
- `inspect eval` — `inspect eval`·`inspect score` 를 칠 때마다 `Control server failed to start … AF_UNIX` 경고가 뜬다 → Windows 의 파이썬에 그 소켓 종류가 없어서 나는 경고다.
- `inspect score` — `inspect eval`·`inspect score` 를 칠 때마다 `Control server failed to start … AF_UNIX` 경고가 뜬다 → Windows 의 파이썬에 그 소켓 종류가 없어서 나는 경고다.
- `ollama list` — 작업 표시줄에 Ollama 가 있는지, `ollama list` 가 답하는지 본다.
- `inspect log dump` — 둘 다 아니면 생성 설정이 전달되었는지 `inspect log dump`(S3643)로 로그의 plan 쪽 생성 설정을 확인한다.
- `inspect view` — 그 수가 많으면 `inspect view` 에서 그 문항의 심판 출력을 읽고, 지시문의 마지막 문장을 더 짧게 고친 뒤 judge.py 의 판을 올려 7단계를 다시 한다.
