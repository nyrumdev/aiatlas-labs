# 내 평가 하네스 만들기(Inspect + lm-eval, 로컬 모델)

AI 아틀라스 앱의 실습 `lab.c.lab.eval_harness`(L3 · 약 7시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — report.md(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c1:~c9: 줄 · 앱에 내는 파일 · 64KiB 이하) + evalh/ 폴더 — requirements.lock.txt · data/(eval.jsonl · shots.jsonl · notes_mc.jsonl) · tasks/(notes.py · judge.py · lm_eval/notes_mc.yaml) · tools/(loglib.py · check_data.py · peek.py · export_sheet.py · compare_runs.py · agree.py · order_table.py · sc_table.py · make_mc.py) · human.csv · logs/ · results/.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — 이 과정의 기준 PC 는 RTX 4070 Ti 12GB 다. Ollama 쪽은 GPU 가 없어도 끝까지 가지만(느린 숫자도 표의 값이다) lm-eval 단계는 CUDA 판 PyTorch 를 전제로 쓴다
- Ollama 와 gemma4:e4b — [실습] Gemma 4를 내 PC에서 돌리기에서 받은 그대로(S08). 이름에 cloud 가 붙은 태그는 남의 서버에서 돌므로 쓰지 않는다
- Python 3.13 — inspect-ai 0.3.281 은 3.11 이상(S3655), lm-eval 0.4.13 은 3.10 이상(S3656), PyTorch 의 Windows 판은 3.10~3.14 를 지원한다(S481). 판은 py install 로 골라 깐다(S160)
- 인터넷 — 꾸러미와 lm-eval 용 Hugging Face 모델(Qwen/Qwen2.5-0.5B-Instruct)을 한 번 받을 때만. 평가 중에는 모델 호출이 전부 이 PC 안에서 돈다
- 앞 레슨 셋의 기록 — 평가 하네스(오프라인/온라인)의 부품 넷, LLM 심판과 그 편향의 일치율·카파, few-shot 예시와 사고 사슬(CoT)의 손 측정 표. 손 측정을 하지 않았다면 그 사실을 report.md 에 적고 진행한다

## 들어 있는 파일
- `files/tools/check_data.py`
- `files/tasks/notes.py`
- `files/tasks/judge.py`
- `files/tools/loglib.py`
- `files/tools/peek.py`
- `files/tools/export_sheet.py`
- `files/tools/compare_runs.py`
- `files/tools/agree.py`
- `files/tools/order_table.py`
- `files/tools/sc_table.py`
- `files/tools/make_mc.py`
- `files/tasks/lm_eval/notes_mc.yaml`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.eval_harness` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
