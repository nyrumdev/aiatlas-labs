# tools/order_table.py — 예시 순서 다섯 가지의 정답률 분포 → results/fewshot_orders.md
from pathlib import Path

from loglib import newest, ok, write

lines = ["# few-shot 예시 순서별 정답", "", "| 순서 | 정답/문항 | term | calc |", "|---|---|---|---|"]
acc = {}
for d in sorted(Path("logs").glob("fewshot_*")):
    name, log = newest(d)
    order = d.name.removeprefix("fewshot_")
    by = {"term": [0, 0], "calc": [0, 0]}
    for s in log.samples:
        t = by[s.metadata["kind"]]
        t[0] += ok(s)
        t[1] += 1
    c, n = sum(ok(s) for s in log.samples), len(log.samples)
    if not order.endswith("_again"):
        acc[order] = c / n
    lines.append(f"| {order} | {c}/{n} | {by['term'][0]}/{by['term'][1]} | {by['calc'][0]}/{by['calc'][1]} |")
lo, hi = min(acc, key=acc.get), max(acc, key=acc.get)
lines += ["", f"- 순서 {len(acc)}가지 정답률: 최저 {acc[lo]:.2f}({lo}) · 최고 {acc[hi]:.2f}({hi}) · 폭 {acc[hi] - acc[lo]:.2f}",
          f"- 문항 하나의 몫: {1 / n:.3f} — 폭을 문항 수로 읽을 때 쓴다",
          "- 같은 순서 두 번의 갈림은 results/repro_fewshot.md 의 '정오가 뒤집힌 문항' 수로 읽는다"]
write("fewshot_orders.md", lines)
