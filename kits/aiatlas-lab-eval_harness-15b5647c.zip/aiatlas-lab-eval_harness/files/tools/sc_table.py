# tools/sc_table.py — 자기 일관성: 표본 수 k 별 다수결 정답률·일치도·출력 토큰 → results/sc_curve.md
import sys
from collections import Counter, defaultdict

from loglib import newest, out_tokens, write

KS = (1, 3, 5, 8)
name, log = newest(sys.argv[1] if len(sys.argv) > 1 else "logs/sc")
runs = defaultdict(list)
for s in log.samples:
    runs[s.id].append(s)
short = [str(i) for i, v in runs.items() if len(v) < max(KS)]
if short:
    sys.exit(f"표본이 {max(KS)}개보다 적은 문항: {short} — epochs 를 확인")


def vote(first):
    answers = [s.scores["note_answer"].answer for s in first if s.scores["note_answer"].answer]
    if not answers:
        return "", 0
    count = Counter(answers)
    top = max(count.values())
    return next(a for a in answers if count[a] == top), top          # 동률이면 먼저 나온 답


lines = [f"# 자기 일관성 — {name}", "",
         "| k | 다수결 정답/문항 | term | calc | 평균 일치도 | 문항당 평균 출력 토큰 |", "|---|---|---|---|---|---|"]
for k in KS:
    right = {"term": [0, 0], "calc": [0, 0]}
    agree, toks = [], []
    for sid, ss in runs.items():
        first = sorted(ss, key=lambda s: s.epoch)[:k]
        winner, top = vote(first)
        hit = bool(winner) and any(s.scores["note_answer"].answer == winner and s.scores["note_answer"].value == "C"
                                   for s in first)
        t = right[first[0].metadata["kind"]]
        t[0] += hit
        t[1] += 1
        agree.append(top / k)
        toks.append(sum(out_tokens(s) for s in first))
    total = right["term"][0] + right["calc"][0]
    lines.append(f"| {k} | {total}/{len(runs)} | {right['term'][0]}/{right['term'][1]} | {right['calc'][0]}/{right['calc'][1]} | "
                 f"{sum(agree) / len(agree):.2f} | {sum(toks) / len(toks):.0f} |")
same_answer = sum(len({s.scores["note_answer"].answer for s in ss}) == 1 for ss in runs.values())
same_text = sum(len({s.output.completion for s in ss}) == 1 for ss in runs.values())
lines += ["",
          f"- 표본 {max(KS)}개의 답이 모두 같은 문항(만장일치): {same_answer}/{len(runs)} — 확신이 높다는 뜻일 수 있다",
          f"- 표본 {max(KS)}개의 풀이 글이 글자까지 모두 같은 문항: {same_text}/{len(runs)} — 문항 대부분이 그렇다면 표본이 갈리지 않은 것(온도·seed 를 확인)"]
write("sc_curve.md", lines)
