# tools/check_data.py — 평가셋·예시 파일이 약속한 모양인지 돌리기 전에 확인한다
import json
import sys
from pathlib import Path


def rows(p):
    return [json.loads(x) for x in Path(p).read_text(encoding="utf-8").splitlines() if x.strip()]


ev, shots = rows("data/eval.jsonl"), rows("data/shots.jsonl")
bad = []
if len(ev) != 30:
    bad.append(f"eval.jsonl 문항 {len(ev)}개 — 30개여야 한다")
if len(shots) != 4:
    bad.append(f"shots.jsonl 예시 {len(shots)}개 — 4개여야 한다")
ids = [r.get("id") for r in ev + shots]
if len(set(ids)) != len(ids):
    bad.append("id 가 겹친다(평가셋과 예시를 통틀어 하나씩)")
for r in ev + shots:
    for k in ("id", "kind", "q", "a", "alias"):
        if k not in r:
            bad.append(f"{r.get('id')}: {k} 칸이 없다")
    if r.get("kind") not in ("term", "calc"):
        bad.append(f"{r.get('id')}: kind 는 term 또는 calc")
    if not isinstance(r.get("alias"), list):
        bad.append(f"{r.get('id')}: alias 는 목록([] 도 된다)")
for r in ev:
    if r.get("kind") == "term":
        wrong = r.get("wrong", [])
        if len(wrong) != 3 or r.get("a") in wrong:
            bad.append(f"{r.get('id')}: 용어 문항은 정답과 다른 오답 보기 wrong 3개")
kinds = [r.get("kind") for r in ev]
if kinds.count("term") != 20 or kinds.count("calc") != 10:
    bad.append(f"term {kinds.count('term')} · calc {kinds.count('calc')} — 20·10 이어야 한다")
if [r.get("kind") for r in shots] != ["term", "term", "calc", "calc"]:
    bad.append("shots.jsonl 은 위에서부터 term · term · calc · calc 순서여야 한다(A·B 용어 · C·D 계산)")
same_q = {r["q"] for r in ev if "q" in r} & {r["q"] for r in shots if "q" in r}
if same_q:
    bad.append(f"예시와 평가셋에 같은 질문: {sorted(same_q)}")
print("OK - eval 30 · shots 4" if not bad else "\n".join(bad))
sys.exit(1 if bad else 0)
