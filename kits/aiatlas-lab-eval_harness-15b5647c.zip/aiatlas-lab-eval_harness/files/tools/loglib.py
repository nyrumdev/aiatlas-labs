# tools/loglib.py — 리포터들이 같이 쓰는 로그 읽기(④ 리포터의 공통 부분)
import sys
from pathlib import Path

from inspect_ai.log import read_eval_log

sys.stdout.reconfigure(errors="replace")   # 출력을 파이프로 받을 때 cp949 에 없는 글자(— 등)는 ? 로 바꾸고 멈추지 않는다


def newest(path, need=None):
    """폴더면 그 안의 가장 늦은 .eval(이름 앞이 시각이라 이름순 = 시간순), 파일이면 그 파일.
    need 를 주면 그 이름의 점수가 든 로그만 고른다(예: inspect score 가 만든 note_judge 로그)."""
    p = Path(path)
    files = [p] if p.is_file() else sorted(p.glob("*.eval"))
    for f in reversed(files):
        log = read_eval_log(str(f))
        if need is None or all(need in (s.scores or {}) for s in log.samples):
            return f.name, log
    sys.exit(f"{path} 에 맞는 .eval 로그가 없다(need={need})")


def ok(sample, name="note_answer"):
    return sample.scores[name].value == "C"


def out_tokens(sample):
    return sum(u.output_tokens for u in sample.model_usage.values())


def write(name, lines):
    Path("results").mkdir(exist_ok=True)
    (Path("results") / name).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
