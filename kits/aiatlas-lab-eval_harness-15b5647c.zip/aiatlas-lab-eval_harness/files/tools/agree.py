# tools/agree.py — 사람·규칙 채점기·LLM 심판의 일치율과 카파 → results/agreement*.md · disagree*.csv
import csv
import sys
from pathlib import Path

from loglib import newest, ok, write

suffix = sys.argv[2] if len(sys.argv) > 2 else ""        # 심판을 바꿔 다시 잴 때 결과 이름 뒤에 붙인다(예 _12b)
name, log = newest(sys.argv[1], need="note_judge")
with open("human.csv", encoding="utf-8-sig", newline="") as f:
    human = {r["id"]: r["human"].strip() for r in csv.DictReader(f)}
blank = [i for i, v in human.items() if v not in ("0", "1")]
missing = [str(s.id) for s in log.samples if str(s.id) not in human]
if blank or missing:
    sys.exit(f"human 칸이 0·1 이 아닌 행: {blank} · human.csv 에 없는 문항: {missing}")

rows = []
for s in sorted(log.samples, key=lambda s: str(s.id)):
    j = s.scores["note_judge"]
    rows.append({"id": str(s.id), "question": s.input, "expected": s.target,
                 "answer": s.scores["note_answer"].answer,
                 "human": int(human[str(s.id)]), "rule": int(ok(s)), "judge": int(ok(s, "note_judge")),
                 "judge_value": j.value, "judge_why": (j.explanation or "")[-300:]})


def kappa(x, y):
    n = len(x)
    po = sum(p == q for p, q in zip(x, y)) / n
    pe = sum((x.count(c) / n) * (y.count(c) / n) for c in (0, 1))   # 우연히 겹칠 몫
    return po, ((po - pe) / (1 - pe) if pe < 1 else float("nan"))


# 심판이 GRADE 줄을 못 낸 문항은 0점이 아니라 무채점(NaN)으로 남는다(S3641) → 심판이 든 짝에서는 뺀다
judged = [r for r in rows if r["judge_value"] in ("C", "I")]
odd = [r["id"] for r in rows if r["judge_value"] not in ("C", "I")]
if not judged:
    sys.exit("심판 판정(C·I)이 있는 문항이 없다 — judge_why 를 읽고 지시문을 고친다")
lines = [f"# 채점자 일치 — {name}", "",
         "| 짝 | 문항 | 일치율 | 카파 | 앞=1·뒤=0 | 앞=0·뒤=1 |", "|---|---|---|---|---|---|"]
for a, b, label in (("human", "judge", "사람 대 심판"), ("human", "rule", "사람 대 규칙 채점기"),
                    ("rule", "judge", "규칙 채점기 대 심판")):
    use = judged if "judge" in (a, b) else rows
    x, y = [r[a] for r in use], [r[b] for r in use]
    po, k = kappa(x, y)
    lines.append(f"| {label} | {len(use)} | {po:.2f} | {k:.2f} | "
                 f"{sum(p == 1 and q == 0 for p, q in zip(x, y))} | {sum(p == 0 and q == 1 for p, q in zip(x, y))} |")
lines += ["", f"- 사람이 맞음으로 본 문항: {sum(r['human'] for r in rows)}/{len(rows)} · "
              f"심판이 맞음으로 본 문항: {sum(r['judge'] for r in judged)}/{len(judged)}",
          f"- 심판 판정이 C·I 가 아닌 문항(무채점 · 심판 짝에서 뺌): {', '.join(odd) or '없음'}"]
write(f"agreement{suffix}.md", lines)

with open(Path("results") / f"disagree{suffix}.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(r for r in judged if r["human"] != r["judge"])
