# tools/peek.py — 시험 실행 로그에서 생각 블록·토큰·마지막 줄을 문항마다 한 줄로(둘째 인자를 주면 그 파일에 UTF-8 로 덧붙인다)
import sys

from loglib import newest, out_tokens                 # loglib 가 화면에 못 찍는 글자를 ? 로 바꾸게 해 둔다

name, log = newest(sys.argv[1])
out = [f"로그 {name} · 모델 {log.eval.model}"]
for s in log.samples:
    parts = s.messages[-1].content if isinstance(s.messages[-1].content, list) else []
    think = [p for p in parts if type(p).__name__ == "ContentReasoning"]
    think_chars = sum(len(p.reasoning or "") for p in think)        # 생각 글의 분량(추론 토큰이 비어 있을 때 쓴다)
    reasoning = sum(u.reasoning_tokens or 0 for u in s.model_usage.values())
    text = s.output.completion.strip()
    last = text.splitlines()[-1] if text else "(빈 답)"
    out.append(f"{s.id} · 생각 블록 {'있음' if think else '없음'} · 생각 글자 {think_chars} · 출력 토큰 {out_tokens(s)} · "
               f"추론 토큰 {reasoning} · 마지막 줄: {last}")
if len(sys.argv) > 2:
    with open(sys.argv[2], "a", encoding="utf-8") as f:  # 파이프를 거치지 않고 파일에 직접 쓴다
        f.write("\n".join(out) + "\n")
print("\n".join(out))
