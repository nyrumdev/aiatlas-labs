# tools/export_sheet.py — 사람 채점표 human.csv 를 만든다(규칙 채점 결과는 싣지 않는다)
import csv
import sys
from pathlib import Path

from loglib import newest

if Path("human.csv").exists():
    sys.exit("human.csv 가 이미 있다 — 채점한 표를 덮어쓰지 않는다")
name, log = newest(sys.argv[1])
with open("human.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "kind", "question", "expected", "model_last_lines", "human"])
    for s in sorted(log.samples, key=lambda s: str(s.id)):
        tail = s.output.completion.strip().splitlines()[-3:]
        w.writerow([s.id, s.metadata.get("kind"), s.input, s.target, " / ".join(tail), ""])
print(f"human.csv ← {name} · {len(log.samples)}행 · human 칸에 1(맞음) 또는 0(틀림)")
