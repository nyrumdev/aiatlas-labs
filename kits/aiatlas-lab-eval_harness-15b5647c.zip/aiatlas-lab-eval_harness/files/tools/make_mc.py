# tools/make_mc.py — 평가셋의 용어 문항(오답 보기 wrong 3개)을 lm-eval 객관식 파일로 옮긴다
import json
from pathlib import Path

rows = [json.loads(x) for x in Path("data/eval.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
out = []
for i, r in enumerate(x for x in rows if x["kind"] == "term"):
    label = i % 4                                    # 정답 자리를 A·B·C·D 로 돌려 가며 놓는다
    choices = r["wrong"][:label] + [r["a"]] + r["wrong"][label:]
    out.append({"id": r["id"], "question": r["q"], "choices": choices, "label": label})
Path("data/notes_mc.jsonl").write_text("\n".join(json.dumps(o, ensure_ascii=False) for o in out) + "\n",
                                       encoding="utf-8")
print(f"{len(out)}문항 → data/notes_mc.jsonl")
