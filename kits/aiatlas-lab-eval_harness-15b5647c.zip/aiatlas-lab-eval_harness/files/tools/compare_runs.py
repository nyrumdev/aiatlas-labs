# tools/compare_runs.py — 같은 설정의 두 실행을 문항 id 로 맞댄다 → results/<이름>.md
import sys

from loglib import newest, ok, write

(na, la), (nb, lb) = newest(sys.argv[1]), newest(sys.argv[2])
a, b = {s.id: s for s in la.samples}, {s.id: s for s in lb.samples}
ids = sorted(set(a) & set(b), key=str)
same = [i for i in ids if a[i].output.completion == b[i].output.completion]
flips = [str(i) for i in ids if ok(a[i]) != ok(b[i])]
write(sys.argv[3] if len(sys.argv) > 3 else "repro.md", [
    f"# 같은 설정 두 번: {sys.argv[1]} 대 {sys.argv[2]}", "",
    f"- 로그: {na} · {nb}",
    f"- 맞댄 문항: {len(ids)}",
    f"- 정답 수: {sum(ok(a[i]) for i in ids)} 대 {sum(ok(b[i]) for i in ids)}",
    f"- 답 글자까지 같은 문항: {len(same)}/{len(ids)}",
    f"- 정오가 뒤집힌 문항: {', '.join(flips) or '없음'}",
])
