# tasks/judge.py — 이미 돈 로그를 다시 채점하는 LLM 심판(채점기 이름·판: note_judge@v1)
from inspect_ai.model import GenerateConfig, get_model
from inspect_ai.scorer import accuracy, model_graded_qa, scorer

INSTRUCTIONS = (
    "위 채점 기준(criterion)은 이 질문의 정답이다. 답안의 마지막 '답:' 줄이 정답과 같은 것을 가리키면 맞음, "
    "다른 것을 가리키거나 '답:' 줄이 없으면 틀림이다. 띄어쓰기·대소문자·영문 병기·단위 표기 차이는 같은 것으로 본다. "
    "이유를 한두 문장으로 쓴 뒤, 맨 마지막 줄에 GRADE: C(맞음) 또는 GRADE: I(틀림) 하나만 쓴다."
)


@scorer(metrics=[accuracy()])
def note_judge(judge: str = "ollama/gemma4:e4b"):
    return model_graded_qa(
        instructions=INSTRUCTIONS,
        model=get_model(judge, config=GenerateConfig(temperature=0, seed=42)),
    )
