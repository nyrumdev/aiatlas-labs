# tasks/notes.py — 내 학습 노트 30문항을 Inspect 과제로 (규칙 채점기 이름·판: note_answer@v1)
import json
import re
import unicodedata
from pathlib import Path

from inspect_ai import Task, task
from inspect_ai.dataset import FieldSpec, Sample, json_dataset
from inspect_ai.model import GenerateConfig
from inspect_ai.scorer import CORRECT, INCORRECT, Score, Target, accuracy, choice, scorer, stderr
from inspect_ai.solver import TaskState, generate, multiple_choice, prompt_template

DATA = Path(__file__).resolve().parent.parent / "data"
FIELDS = FieldSpec(input="q", target="a", id="id", metadata=["kind", "alias"])   # ① 로더
RULE = "내 학습 노트에서 낸 질문이다. 짧게 답하고, 마지막 줄은 반드시 '답: <답>' 한 줄로 끝낸다.\n\n"
COT_RULE = "내 학습 노트에서 낸 질문이다. 먼저 풀이를 단계별로 쓴 뒤, 마지막 줄은 반드시 '답: <답>' 한 줄로 끝낸다.\n\n"
ANSWER_LINE = re.compile(r"답\s*[:：]\s*(.+)")


def norm(s):
    """대조 전에 겉모양만 맞춘다 — 대소문자·공백·따옴표·괄호 안 병기·끝 문장부호·끝 '입니다' 류."""
    s = unicodedata.normalize("NFKC", s).strip().lower()
    s = re.sub(r"\([^)]*\)", "", s)                      # '리포터(reporter)' → '리포터'
    s = re.sub(r"[\s*`'\"“”‘’()\[\]]", "", s)
    s = s.rstrip(".,!?·")
    return re.sub(r"(입니다|이다|예요|이에요|임)$", "", s)


@scorer(metrics=[accuracy(), stderr()])
def note_answer():                                                                  # ③ 채점기
    async def score(state: TaskState, target: Target) -> Score:
        hits = ANSWER_LINE.findall(state.output.completion)
        got = norm(hits[-1]) if hits else ""
        accepted = {norm(target.text)} | {norm(a) for a in (state.metadata.get("alias") or [])}
        return Score(value=CORRECT if got and got in accepted else INCORRECT,
                     answer=got, explanation=state.output.completion[-300:])
    return score


def notes():
    return json_dataset(str(DATA / "eval.jsonl"), FIELDS)


@task
def notes_direct():                                                                 # ② 실행기 — 조건은 전부 여기
    return Task(dataset=notes(),
                solver=[prompt_template(RULE + "질문: {prompt}"), generate()],
                scorer=note_answer(),
                config=GenerateConfig(temperature=0, seed=42, max_tokens=1024))  # 생각 글 몫까지(3단계 셋째)


@task
def notes_fewshot(order: str = "ABCD"):
    assert sorted(order) == list("ABCD"), "order 는 A·B·C·D 를 한 번씩 쓴 글자 넷"
    lines = (DATA / "shots.jsonl").read_text(encoding="utf-8").splitlines()
    shots = dict(zip("ABCD", [json.loads(x) for x in lines if x.strip()]))
    block = "".join(f"질문: {shots[c]['q']}\n답: {shots[c]['a']}\n\n" for c in order)
    return Task(dataset=notes(),
                solver=[prompt_template(RULE + "{shots}질문: {prompt}", shots=block), generate()],
                scorer=note_answer(),
                config=GenerateConfig(temperature=0, seed=42, max_tokens=1024))  # 생각 글 몫까지(3단계 셋째)


@task
def notes_sc(samples: int = 8, temperature: float = 0.7):
    # 자기 일관성 — 같은 문항을 samples 번 뽑는다. seed 는 일부러 두지 않는다(같은 표본이 되풀이될 수 있다).
    return Task(dataset=notes(),
                solver=[prompt_template(COT_RULE + "질문: {prompt}"), generate()],
                scorer=note_answer(),
                epochs=samples,
                config=GenerateConfig(temperature=temperature, max_tokens=1024))


def mc_record(r):
    return Sample(input=r["question"], choices=r["choices"], target="ABCD"[r["label"]], id=r["id"])


@task
def notes_mc_gen():
    # (선택) 같은 객관식 문항을 '골라서 답하게' 하는 생성 방식 — lm-eval 의 가능도 방식과 견줄 때만 쓴다.
    return Task(dataset=json_dataset(str(DATA / "notes_mc.jsonl"), mc_record),
                solver=multiple_choice(),
                scorer=choice(),
                config=GenerateConfig(temperature=0, seed=42, max_tokens=64))
