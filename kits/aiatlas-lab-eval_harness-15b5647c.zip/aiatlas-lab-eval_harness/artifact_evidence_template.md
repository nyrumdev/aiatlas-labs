lab_id: lab.c.lab.eval_harness

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 작업대 — requirements.lock.txt(맨 위 --extra-index-url 줄 + pip freeze 출력) + results/env.md(파이썬 판 · ollama 판 · torch 판과 CUDA 사용 가능 여부 · inspect-ai 와 lm-eval 의 Name·Version 줄 · ollama show gemma4:e4b 출력(매개변수 줄) · 시험 실행에서 본 생각 블록 유무 · 생각 글자 수 · 추론 토큰 · Qwen 모델 카드에서 확인한 라이선스 1줄) -->
c1: 
<!-- c2(필수): 평가셋 — data/eval.jsonl 30행(term 20 · calc 10 · 줄마다 id·kind·q·a·alias · term 은 오답 보기 wrong 3개) + data/shots.jsonl 4행(평가셋과 겹치지 않는 예시) + tools/check_data.py 출력 'OK - eval 30 · shots 4' -->
c2: 
<!-- c3(필수): 과제 코드 — tasks/notes.py(과제 notes_direct · notes_fewshot · notes_sc · 채점기 note_answer) · tasks/judge.py(채점기 note_judge) · tools/ 리포터 파일 + logs/smoke 의 시험 로그와 tools/peek.py 출력(문항마다 마지막 줄이 '답: …' 꼴의 답 줄인지 확인한 1줄) -->
c3: 
<!-- c4(필수): 재현 — logs/direct_run1 · logs/direct_run2(같은 명령 두 번) + results/repro.md(정답 수 두 개 · 답 글자까지 같은 문항 수 · 정오가 뒤집힌 문항 id) + 뒤집힌 문항이 있으면 그 답 두 개를 읽고 report.md 의 재현 절에 적은 원인 추정 1줄 -->
c4: 
<!-- c5(필수): 채점자 일치 — human.csv(30행 · human 칸 0/1 · 규칙 채점과 심판 결과를 보기 전에 채운 것) + note_judge 점수가 붙은 로그 + results/agreement.md(사람 대 심판 · 사람 대 규칙 채점기 · 규칙 채점기 대 심판의 일치율·카파와 짝마다 센 문항 수) + results/disagree.csv(사람과 심판이 엇갈린 문항 모음) -->
c5: 
<!-- c6(필수): few-shot 순서 — logs/fewshot_ABCD · BCDA · CDAB · DABC · DCBA 와 같은 순서를 한 번 더 돈 logs/fewshot_ABCD_again + results/fewshot_orders.md(순서별 정답 · 최저·최고·폭) + results/repro_fewshot.md + report.md 의 예시 순서 절에 순서 사이 폭과 같은 순서 두 번의 갈림을 견준 1문장 -->
c6: 
<!-- c7(필수): 자기 일관성 — logs/sc(문항마다 표본 8개) + results/sc_curve.md(k = 1·3·5·8 의 다수결 정답 · term·calc 별 · 평균 일치도 · 문항당 평균 출력 토큰 · 답이 8개 모두 같은 문항 수 · 풀이 글이 글자까지 8개 모두 같은 문항 수) + 출력 토큰이 max_tokens 에 닿은 표본 수 1줄(9단계 results/sc_peek.md 에서 센 것) -->
c7: 
<!-- c8(필수): 가능도 과제 — data/notes_mc.jsonl(용어 20문항 · make_mc.py 출력) + tasks/lm_eval/notes_mc.yaml + results/lm_eval/ 아래 결과 JSON 과 --log_samples 문항 기록 + report.md 에 Ollama 경로로 돌리지 않은 이유 2문장 -->
c8: 
<!-- c9(필수): report.md — 첫 부분의 lab_id 줄 · ## 작업 · ## 결과(환경 · 평가셋 · 재현 · 채점자 일치 · 예시 순서 · 자기 일관성 · 가능도 과제 소제목 아래 results/ 의 표를 그대로 붙임) · ## 검증 · c1:~c9: 줄 + 결론 4문장 이상(문장마다 표의 숫자 하나 이상 · 이 심판을 이 셋에 쓸지 · 예시 순서를 고정할지 · 표본 수를 몇으로 둘지) -->
c9: 
<!-- c10(선택): (선택) 생성 방식으로 같은 객관식 — logs/mc_gen(notes_mc_gen 을 hf/Qwen/Qwen2.5-0.5B-Instruct 와 -M do_sample=False 로 · 끝에 Task interrupted 없이 끝난 로그) + report.md 에 lm-eval acc 와 Inspect choice 정답률을 나란히 놓은 표 1개 -->
c10: 
<!-- c11(선택): (선택) 다른 심판 — gemma4:12b 를 심판으로 한 results/agreement_12b.md · disagree_12b.csv + 두 심판의 카파를 견준 1줄 -->
c11: 
