# 추론 최적화 실험 + 벤치 리포트 — 명령·코드 모음

실습 id: `lab.c.lab.inference_opt_report`

앱 실습 화면의 절차와 같은 차례입니다.

## 2. 변수 축 결정 — 축은 최소 2개다. 양자화 수준은 같은 크기 모델의 양자화 태그끼리 비교한다. Ollama 의 `gemma4:e2b`·`e4b`·`12b`·`26b`·`31b` 는 크기가 다른 모델이지 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama show --parameters <태그>`

## 3. 장치에 들어가는 조합만 고른다 — 모델 파일 크기에 KV 캐시와 여유분을 더한 값이 VRAM 에 다 들어가야 한다. 예를 들어 VRAM 12GB 라면 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama ps`

## 5. 측정 스크립트 — 설정 × 프롬프트 10 × 회차 3 을 자동으로 돌리는 Python 스크립트를 만든다(`requests` 로 `http://127.0.0.1:11434/api/generate` 에 …

```python
import csv, datetime, requests
URL = "http://127.0.0.1:11434/api/generate"  # 숫자 주소 — localhost 는 PC 에 따라 호출마다 시간이 붙는다
def now():  # nvidia-smi timestamp 칸과 같은 현지 시각·밀리초 꼴
    return datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f")[:-3]
# bench_raw.csv 열: 설정·프롬프트·회차·첫 토큰 시간(초)·프리필 tok/s·디코드 tok/s·입력·캐시·출력 토큰·적재(초)·시작·끝
# (최고 메모리 열은 7단계에서 시작~끝 사이 최대값으로 채운다)
def measure(cfg, p, rnd, writer):  # 요청 1회 → 1행 · 예외는 부르는 쪽이 잡아 bench_failures.csv 로(8단계)
    head = f"[회차 {rnd}]\n"  # 회차마다 다른 머리 — 캐시 함정 막기(6단계 · 워밍업은 회차 0)
    body = {"model": cfg["tag"], "prompt": head + p["prompt"], "stream": False,
            "options": {"num_ctx": cfg["num_ctx"], "temperature": 0, "seed": 42,
                        "num_predict": 256, "draft_num_predict": 0}}  # 생성 설정은 예시 값 — 환경 고정 절에 적은 값으로
    start = now()
    r = requests.post(URL, json=body, timeout=600).json()
    end = now()
    if "error" in r:
        raise RuntimeError(r["error"])
    n_in, n_out = r["prompt_eval_count"], r["eval_count"]
    cached = r.get("prompt_eval_cached_count", 0)  # 값이 없으면 칸이 빠진다 — 그때는 0
    pe = r["prompt_eval_duration"] / 1e9
    writer.writerow([cfg["id"], p["id"], rnd, round(pe, 4), round((n_in - cached) / pe, 2),
                     round(n_out / (r["eval_duration"] / 1e9), 2), n_in, cached, n_out,
                     round(r.get("load_duration", 0) / 1e9, 3), start, end])
```

## 6. 캐시 함정 막기 — 같은 프롬프트를 되풀이하면 런타임이 앞서 계산해 둔 KV 캐시를 다시 써서 2·3회차의 첫 토큰 시간이 무너진다. 응답의 `prompt_eval_cached_count`(캐시에서 읽은 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama stop`

## 7. 메모리 최고치 — 작업관리자는 순간 최고치를 놓친다. NVIDIA GPU 라면 측정 동안 별도 창에서 `nvidia-smi --query-gpu=timestamp,memory.used …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `nvidia-smi --query-gpu=timestamp,memory.used --format=csv,noheader,nounits -lms 200 -f mem_log.csv`
- `ollama ps`

## 8. 실행 — 설정 하나를 끝까지(10×3) 돌리고 다음 설정으로 넘어간다. 설정 사이에 모델을 내려 메모리를 비운다(`ollama stop <태그>`). 중간에 실패한 실행은 bench_failures.csv 에 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama stop <태그>`

## 13. (선택) 스펙큘러티브 디코딩(S30·S103) 또는 Gemma 4 의 MTP 드래프터(S05)를 켜고 끄는 축을 추가한다. Ollama 에서는 드래프터가 든 q4_K_M 태그 하나로 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama show --parameters`
- `ollama -v`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama ps`
