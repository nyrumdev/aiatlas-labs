# c8_recheck.py — S56 '타일로 나눠 계산해도 근사 없는 같은 출력' 재검산(알고리즘 성질 · 속도·메모리 표는 범위 밖)
import sys
import numpy as np

SEED, N, D, BR, BC = 0, 257, 64, 16, 32          # 실행 전에 정한 통제(재현 시도 표에 먼저 적는다)
TOL = {"float64": 1e-12, "float32": 1e-5}        # 실행 전에 정한 허용 차이


def naive(q, k, v):                              # 보통 어텐션 softmax(QKᵀ/√d)V
    s = q @ k.T / np.sqrt(q.shape[1])
    p = np.exp(s - s.max(axis=1, keepdims=True))
    return p / p.sum(axis=1, keepdims=True) @ v


def tiled(q, k, v):                              # 블록마다 최댓값 m·지수 합 l 을 고쳐 가며 쌓고 끝에 한 번 나눈다
    out, scale = np.zeros_like(q), 1 / np.sqrt(q.shape[1])
    for i in range(0, len(q), BR):
        qi = q[i:i + BR]
        m, l, o = np.full(len(qi), -np.inf, q.dtype), np.zeros(len(qi), q.dtype), np.zeros_like(qi)
        for j in range(0, len(k), BC):
            s = qi @ k[j:j + BC].T * scale
            m_new = np.maximum(m, s.max(axis=1))
            p, c = np.exp(s - m_new[:, None]), np.exp(m - m_new)
            l, o, m = c * l + p.sum(axis=1), c[:, None] * o + p @ v[j:j + BC], m_new
        out[i:i + BR] = o / l[:, None]
    return out


rng = np.random.default_rng(SEED)
lines = [f"python {sys.version.split()[0]} · numpy {np.__version__} · N={N} D={D} 블록 {BR}x{BC} 시드 {SEED}"]
for name, tol in TOL.items():
    q, k, v = (rng.standard_normal((N, D)).astype(name) for _ in range(3))
    err = float(np.abs(naive(q, k, v) - tiled(q, k, v)).max())
    lines.append(f"{name} 최대 절대 차이 {err:.3e} · 허용 {tol:g} · 허용 안={err <= tol}")
open("c8_run.log", "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("\n".join(lines))
