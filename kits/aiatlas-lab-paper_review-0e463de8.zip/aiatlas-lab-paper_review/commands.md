# 논문 3편 요약 + 견해 1편 — 명령·코드 모음

실습 id: `lab.c.lab.paper_review`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 10. 재현 시도 — 절차 1 에서 내 PC 로 돌릴 수 있게 고른 논문에서 c3 에 지목한 표·그림 1개를 그 claim_id 와 함께 고른다. 돌리기 전에 원자료·코드의 판, 고정할 조건(시드·설정)과 허용할 …

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install numpy
.\.venv\Scripts\python.exe c8_recheck.py
```

- `files/c8_recheck.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `py -m venv .venv`
