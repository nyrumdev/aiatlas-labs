"""check_gpu.py — 이 PC 의 파이썬·PyTorch·GPU 상태를 재서 JSON 파일 하나로 남긴다.

실행 예:
    python check_gpu.py                        # env_report.json 에 쓴다
    python check_gpu.py --out env_report_high.json --precision high
"""
import argparse
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import torch

N = 4096                            # 정사각 행렬 한 변의 길이(N×N)
REPEAT = {"cpu": 5, "cuda": 50}     # 시간을 재는 곱셈 횟수 — 평균을 낸다(GPU 는 한 번이 짧아 더 많이)


def time_matmul(device):
    """device("cpu" 또는 "cuda")에서 N×N 행렬 곱 한 번의 평균 시간(밀리초)."""
    gen = torch.Generator().manual_seed(0)
    a = torch.rand(N, N, generator=gen).to(device)
    b = torch.rand(N, N, generator=gen).to(device)
    torch.matmul(a, b)              # 준비 운동 — 첫 호출의 라이브러리 적재 시간은 재지 않는다
    if device == "cuda":
        torch.cuda.synchronize()    # 앞서 맡긴 GPU 일이 다 끝날 때까지 기다린다
    start = time.perf_counter()
    for _ in range(REPEAT[device]):
        torch.matmul(a, b)
    if device == "cuda":
        torch.cuda.synchronize()    # GPU 는 비동기 — 기다리지 않으면 '맡긴 시간'만 잰다
    return (time.perf_counter() - start) / REPEAT[device] * 1000


def collect(source):
    """보고서 사전(dict)을 만든다. source 는 어디서 돌렸는지 적는 이름표."""
    report = {
        "source": source,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "python_version": sys.version,
        "python_executable": sys.executable,
        "in_venv": sys.prefix != sys.base_prefix,
        "os": platform.platform(),
        "torch_version": torch.__version__,
        "matmul_precision": torch.get_float32_matmul_precision(),
        "cpu_threads": torch.get_num_threads(),
        "matrix_size": N,
        "repeat": REPEAT,
        "cuda_is_available": torch.cuda.is_available(),
    }
    report["cpu_matmul_ms"] = round(time_matmul("cpu"), 3)
    if report["cuda_is_available"]:
        report["device_name"] = torch.cuda.get_device_name(0)
        major, minor = torch.cuda.get_device_capability(0)
        report["compute_capability"] = f"{major}.{minor}"
        torch.cuda.reset_peak_memory_stats(0)
        report["gpu_matmul_ms"] = round(time_matmul("cuda"), 3)
        peak = torch.cuda.max_memory_allocated(0)
        report["max_memory_allocated_mib"] = round(peak / 2**20, 1)
    return report


def save(report, out_path):
    """사전을 UTF-8 JSON 으로 저장한다(한글이 그대로 보이게)."""
    text = json.dumps(report, ensure_ascii=False, indent=2)
    Path(out_path).write_text(text + "\n", encoding="utf-8")
    return text


def main():
    parser = argparse.ArgumentParser(description="파이썬·PyTorch·GPU 상태를 JSON 으로 남긴다")
    parser.add_argument("--out", default="env_report.json", help="저장할 파일 이름")
    parser.add_argument("--source", default="script", help="보고서에 적을 실행 위치 이름표")
    parser.add_argument("--precision", choices=["highest", "high", "medium"],
                        help="float32 행렬 곱 정밀도(주지 않으면 기본값 그대로)")
    args = parser.parse_args()
    if args.precision:
        torch.set_float32_matmul_precision(args.precision)
    report = collect(args.source)
    print(save(report, args.out))
    if not report["cuda_is_available"]:
        print("경고: PyTorch 가 GPU 를 쓰지 못한다. torch 판 끝의 꼬리표(+cpu?)와 nvidia-smi 부터 본다",
              file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
