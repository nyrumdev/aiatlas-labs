# AI 실습 PC 세우기 — 파이썬 판 고르기·PyTorch GPU 확인·Jupyter·판 고정

AI 아틀라스 앱의 실습 `lab.c.lab.dev_setup`(L2 · 약 2시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱 제출 = dev_setup_report.md 파일 하나 · 같은 저장소에 env_report.json + env_report_nb.json + check_gpu.py + check_gpu.ipynb + matmul_time.png + requirements.lock.txt + requirements.txt (모두 C:\work\ai-lab 저장소 안).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU 와 그 드라이버(이 과정의 기준 PC 는 RTX 4070 Ti 12GB · S426) — 드라이버가 없으면 nvidia-smi 가 돌지 않으므로 NVIDIA 드라이버부터 설치한다
- Python 설치 관리자(Python Install Manager) — python.org 내려받기 쪽 또는 Microsoft Store(S160) · 앞 노드 파이썬 실습 환경에서 설치했다면 그대로 쓴다
- git — 앞 노드 git 기초에서 쓴 그대로(이름·메일 설정까지)
- 인터넷 — PyTorch CUDA 판과 JupyterLab 을 내려받는 데만 쓴다 · CUDA 판 torch 는 내려받기가 커서 디스크 여유를 넉넉히 둔다
- 웹 브라우저 — PyTorch 설치 선택기 쪽과 JupyterLab 화면용

## 들어 있는 파일
- `files/check_gpu.py`
- `files/requirements.txt`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.dev_setup` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
