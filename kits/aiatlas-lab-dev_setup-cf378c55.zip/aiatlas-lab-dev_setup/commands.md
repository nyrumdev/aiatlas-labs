# AI 실습 PC 세우기 — 파이썬 판 고르기·PyTorch GPU 확인·Jupyter·판 고정 — 명령·코드 모음

실습 id: `lab.c.lab.dev_setup`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 파이썬 판 고르기

```powershell
py list                   # 설치 관리자가 아는 판 목록
py list --online --one 3.14   # py install 3.14 가 받을 판 하나를 미리 본다
py install 3.14
py list                   # 3.14 가 생겼는지 다시 본다
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py install default` — 설치 관리자의 특수 태그 `default` 는 가장 최근의 권장 판을 고르므로(S160), 태그 대신 `default` 를 적어 `py install default` 를 치면 지금은 3.15 가 올 수 있다(앞 노드 파이썬 실습 환경이 3.14 를 태그로 적어 설치한 까닭이다).

## 2. 폴더와 가상환경

```powershell
mkdir C:\work\ai-lab
cd C:\work\ai-lab
py -V:3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
python --version
python -c "import sys; print(sys.prefix != sys.base_prefix)"
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py -V:<태그>` — `py -V:<태그>` 는 맨 앞에 와야 하는 옵션이다(S160).

## 3. 드라이버 확인

```powershell
nvidia-smi --version
nvidia-smi --query-gpu=name,memory.total,compute_cap --format=csv
```

## 4. CUDA 판 torch 설치

```powershell
python -m pip install torch --index-url https://download.pytorch.org/whl/cu132
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

## 5. GPU 점검 스크립트

- `files/check_gpu.py` — 키트에 들어 있음 (python)

## 7. JupyterLab 과 노트북

```powershell
python -m pip install jupyterlab numpy scikit-learn matplotlib
jupyter lab
```

```python
# 칸 1 — 실행 중인 파이썬 확인
import sys
print(sys.executable)          # C:\work\ai-lab\.venv 안의 python.exe 여야 한다

# 칸 2 — 같은 점검을 노트북에서 다시 돌린다
import check_gpu               # 같은 폴더의 check_gpu.py 를 불러온다
report = check_gpu.collect("notebook")
check_gpu.save(report, "env_report_nb.json")
report

# 칸 3 — 함께 설치한 패키지의 판
import numpy, sklearn, matplotlib
print(numpy.__version__, sklearn.__version__, matplotlib.__version__)

# 칸 4 — CPU 와 GPU 시간을 막대그래프로 저장
assert report["cuda_is_available"], "GPU 를 못 쓴다. 4단계의 꼬리표와 True/False 부터 다시 본다"
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(4, 3))
ax.bar(["CPU", "GPU"], [report["cpu_matmul_ms"], report["gpu_matmul_ms"]])
ax.set_yscale("log")           # 차이가 크면 GPU 막대가 안 보이므로 로그 눈금
ax.set_ylabel("milliseconds per matmul")
ax.set_title(f"{check_gpu.N}x{check_gpu.N} float32 matmul")
fig.savefig("matmul_time.png", dpi=120, bbox_inches="tight")
```

## 8. 판 고정

```powershell
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

- `files/requirements.txt` — 키트에 들어 있음 (text)

## 9. 첫 커밋

```powershell
git init
Set-Content .gitignore ".venv/", ".venv_check/", "__pycache__/", ".ipynb_checkpoints/"
git status
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Add-Content .gitignore "폴더이름/"` — 그 밖에 내가 만들지 않은 폴더가 보이면 `Add-Content .gitignore "폴더이름/"` 으로 한 줄 더하고 `git status` 를 다시 본다.
- `git add .` — 그다음 `git add .`, `git commit -m "AI 실습 PC 첫 기록"` 을 친다.
- `git commit -m "AI 실습 PC 첫 기록"` — 그다음 `git add .`, `git commit -m "AI 실습 PC 첫 기록"` 을 친다.
- `git rev-parse HEAD` — `git rev-parse HEAD` 의 40자리를 적어 두고(S764), `git status` 가 working tree clean 인지 확인한다.

## 10. (선택) 다시 세우기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py -V:3.14 -m venv .venv_check` — 같은 폴더에서 `py -V:3.14 -m venv .venv_check` 로 빈 가상환경을 만든다.

## 11. (선택) 정밀도 바꿔 재기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python check_gpu.py --out env_report_high.json --precision high` — (선택) 정밀도 바꿔 재기 — `python check_gpu.py --out env_report_high.json --precision high` 를 실행한다.

## 12. 보고서

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add` — 다 쓰면 보고서와, 선택 단계를 했다면 그 결과 파일(env_report_check.json·env_report_high.json)까지 `git add` 해서 커밋 하나로 올리고, `git status` 가 다시 working tree clean 인지 본다.
- `git status` — 다 쓰면 보고서와, 선택 단계를 했다면 그 결과 파일(env_report_check.json·env_report_high.json)까지 `git add` 해서 커밋 하나로 올리고, `git status` 가 다시 working tree clean 인지 본다.

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git log --oneline` — `git log --oneline` 에 보고서에 적은 40자리 해시의 앞부분과 같은 짧은 해시의 커밋이 있고, 그 위에는 해시를 적은 보고서(선택 단계를 했다면 그 결과 파일까지)를 올린 커밋 하나만 있으며, 마지막 `git status` 가 깨끗하고, 추적 파일 목록( …
- `git status` — … 에 보고서에 적은 40자리 해시의 앞부분과 같은 짧은 해시의 커밋이 있고, 그 위에는 해시를 적은 보고서(선택 단계를 했다면 그 결과 파일까지)를 올린 커밋 하나만 있으며, 마지막 `git status` 가 깨끗하고, 추적 파일 목록(`git ls-files`)에 .venv 가 없는가
- `git ls-files` — … 에 보고서에 적은 40자리 해시의 앞부분과 같은 짧은 해시의 커밋이 있고, 그 위에는 해시를 적은 보고서(선택 단계를 했다면 그 결과 파일까지)를 올린 커밋 하나만 있으며, 마지막 `git status` 가 깨끗하고, 추적 파일 목록(`git ls-files`)에 .venv 가 없는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` — 앞 노드 파이썬 실습 환경대로 `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` 를 한 번 실행하고 새 창에서 다시 활성화한다(S161).
- `jupyter lab` — 정책을 바꾸기 싫으면 이후 명령의 `python` 을 `.\.venv\Scripts\python.exe` 로, `jupyter lab` 을 `.\.venv\Scripts\jupyter.exe lab` 으로 바꿔 친다.
- `.\.venv\Scripts\jupyter.exe lab` — 정책을 바꾸기 싫으면 이후 명령의 `python` 을 `.\.venv\Scripts\python.exe` 로, `jupyter lab` 을 `.\.venv\Scripts\jupyter.exe lab` 으로 바꿔 친다.
- `py list` — `py list` 가 "can't open file 'list'" 를 낸다 → 지금의 `py` 는 예전 Python launcher 다.
- `pip install torch` — `pip install torch` 가 맞는 파일이 없다며 멈춘다 → 색인 줄(`--index-url`) 없이 PyPI 에서 받으려 했고, 가상환경 파이썬이 그날의 torch 가 아직 Windows 파일을 내지 않은 판이다.
- `python --version` — `python --version` 을 본다.
- `py -V:3.14 -m venv .venv` — 판이 다르면 `deactivate` 로 빠져나와 `Remove-Item -Recurse -Force .venv` 로 가상환경을 지우고(S161), `py -V:3.14 -m venv .venv` 로 다시 만들어 활성화한다.
- `python -m pip uninstall torch` — `python -m pip uninstall torch` 뒤 4단계 명령을 다시 친다.
- `python -m pip uninstall -y torch` — 높으면 `python -m pip uninstall -y torch` 로 지운 뒤 선택기에서 그보다 낮은 칸의 색인(예 cu134 를 골랐다면 …
- `python -m pip install torch --index-url https://download.pytorch.org/whl/cu132` — … -y torch` 로 지운 뒤 선택기에서 그보다 낮은 칸의 색인(예 cu134 를 골랐다면 `python -m pip install torch --index-url https://download.pytorch.org/whl/cu132
- `jupyter kernelspec list` — 그래도 다르면 `jupyter kernelspec list` 로 커널이 어느 폴더에서 오는지 본다.
- `git add` — git status 에 .venv 가 보인다 → .gitignore 보다 `git add` 가 먼저였다.
- `git rm --cached` — 앞 노드 git 기초의 `git rm --cached` 로 추적을 풀고 커밋한다.
