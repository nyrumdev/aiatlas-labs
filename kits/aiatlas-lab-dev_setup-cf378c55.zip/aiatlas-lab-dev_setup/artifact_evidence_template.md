lab_id: lab.c.lab.dev_setup

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 파이썬 판 — py list 출력 붙여 넣기 + 고른 판 태그와 고른 이유 1줄(PyTorch Windows 지원 범위 안 · 아직 설치 파일이 나오는 판) + env_report.json 의 python_version 이 그 판으로 시작하고 python_executable 이 C:\work\ai-lab\.venv 안이며 in_venv 가 true -->
c1: 
<!-- c2(필수): 드라이버와 torch 설치 — nvidia-smi --version 출력과 --query-gpu(name·memory.total·compute_cap) 출력 붙여 넣기 + 선택기에서 고른 CUDA 판(cu…)이 드라이버의 CUDA 판보다 높지 않다는 비교 1줄 + 실제로 친 torch 설치 명령 1줄 -->
c2: 
<!-- c3(필수): env_report.json — cuda_is_available true · torch_version 끝의 +cu… 꼬리표 · device_name · compute_capability(NVIDIA 표 값과 같은지 1줄) · cpu_matmul_ms 와 gpu_matmul_ms(몇 배인지 1줄) · max_memory_allocated_mib(행렬 셋 몫 어림과의 차이 1줄) · matmul_precision -->
c3: 
<!-- c4(필수): check_gpu.ipynb(실행 결과가 남은 채 저장) + env_report_nb.json + matmul_time.png — 노트북의 sys.executable 이 c1 의 .venv 와 같다는 1줄 + 두 보고서의 torch_version·device_name·compute_capability 가 같은지 1줄 -->
c4: 
<!-- c5(필수): requirements.lock.txt(pip freeze 출력 · 맨 위 --extra-index-url 줄) + requirements.txt(손으로 쓴 범위 · 직접 고른 다섯 패키지와 같은 색인 줄) + 두 파일의 차이 3줄(줄 수 · 판 표기 · 언제 무엇에 쓰나) -->
c5: 
<!-- c6(필수): git — .gitignore 에 .venv/ 가 있음 + 첫 커밋 해시 1줄(git rev-parse HEAD 출력 40자리) + 첫 커밋 직후 git status 가 working tree clean 이었다는 확인 1줄 -->
c6: 
<!-- c7(선택): (선택) 다시 세우기 — 새 가상환경 .venv_check 에 requirements.lock.txt 로 설치하고 check_gpu.py 로 env_report_check.json 을 만들어 torch_version·cuda_is_available 을 env_report.json 과 대조한 1줄 -->
c7: 
<!-- c8(선택): (선택) 정밀도 바꿔 재기 — --precision high 로 env_report_high.json 을 만들어 gpu_matmul_ms 를 기본값(highest)과 견준 1줄 -->
c8: 
