"""test_once.py: 검증 NLL 로 고른 모델 하나를 테스트 조각에서 딱 한 번 잰다. 두 번째 실행은 거절한다.

실행: python test_once.py --model mlp        (count · neural · mlp 가운데 하나: 꼬리표 실행은 --tag 로)
만드는 파일: results\\test_once.json
"""
import argparse
import datetime
import json
import sys

import torch
import torch.nn.functional as F

from common import RESULTS, bigram_pairs, context_rows, load_split, make_stoi, save_json
from count_bigram import mean_nll

LOCK = RESULTS / "test_once.json"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=["count", "neural", "mlp"])
    ap.add_argument("--tag", default="")
    args = ap.parse_args()
    if LOCK.exists():
        with open(LOCK, encoding="utf-8") as f:
            done = json.load(f)
        sys.exit(f"이미 테스트를 쟀다({done['model']} · {done['measured_at']}): 다시 재지 않는다")

    s = load_split()
    stoi = make_stoi(s["itos"])
    tag = f"_{args.tag}" if args.tag else ""
    if args.model in ("count", "neural"):
        xva, yva = bigram_pairs(s["val"], stoi)
        xte, yte = bigram_pairs(s["test"], stoi)
        if args.model == "count":
            P = torch.load(RESULTS / f"count_bigram{tag}.pt")["P"]
        else:
            P = F.softmax(torch.load(RESULTS / f"neural_bigram{tag}.pt")["W"], dim=1)
        val, test, n = mean_nll(P, xva, yva), mean_nll(P, xte, yte), len(yte)
    else:
        from mlp_lm import evaluate
        saved = torch.load(RESULTS / f"mlp{tag}_best.pt")
        block = saved["config"]["block"]
        Xva, Yva = context_rows(s["val"], stoi, block)
        Xte, Yte = context_rows(s["test"], stoi, block)
        val, test, n = evaluate(saved["params"], Xva, Yva), evaluate(saved["params"], Xte, Yte), len(Yte)

    result = {"model": args.model, "tag": args.tag, "val_nll": val, "test_nll": test, "test_targets": n,
              "measured_at": datetime.datetime.now().isoformat(timespec="seconds")}
    print(f"{args.model}{tag} · 검증 NLL {val:.4f} · 테스트 NLL {test:.4f} · 테스트 맞힐 글자 {n}개")
    save_json(LOCK, result)


if __name__ == "__main__":
    main()
