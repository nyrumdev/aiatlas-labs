"""common.py: 세 모델이 함께 쓰는 도구: 분할 읽기 · 글자 번호 · 맞힐 글자 만들기 · 결과 저장.

이 파일은 직접 실행하지 않는다. 다른 스크립트가 import 한다.
"""
import json
from pathlib import Path

import torch

DATA = Path("data")
RESULTS = Path("results")
SPLIT_FILE = DATA / "split.json"
END = "."            # 이름의 시작과 끝을 함께 나타내는 표시(번호 0)
SAMPLE_SEED = 2026   # 표본을 뽑는 생성기의 시드: 세 모델이 같은 값을 쓴다


def load_split():
    """prepare_names.py 가 만든 분할을 읽는다. 돌려주는 값: 사전(itos · train · val · test …)."""
    with open(SPLIT_FILE, encoding="utf-8") as f:
        return json.load(f)


def make_stoi(itos):
    """글자 → 번호 사전. itos[0] 이 끝 표시 '.' 이다."""
    return {ch: i for i, ch in enumerate(itos)}


def bigram_pairs(words, stoi):
    """'.' + 이름 + '.' 의 이웃한 두 글자 짝 → (앞 글자 번호, 다음 글자 번호) 텐서 둘.

    이름 하나에서 짝이 (글자 수 + 1)개 나온다. 맞힐 글자(ys)는 이름의 글자들과 끝 표시다.
    """
    xs, ys = [], []
    for w in words:
        chs = [END] + list(w) + [END]
        for a, b in zip(chs, chs[1:]):
            xs.append(stoi[a])
            ys.append(stoi[b])
    return torch.tensor(xs), torch.tensor(ys)


def context_rows(words, stoi, block):
    """MLP 용: 앞 block 글자(이름 앞쪽에서 모자라면 '.' 으로 채움) → 다음 글자.

    맞힐 글자 Y 는 bigram_pairs 의 ys 와 순서·개수가 같다. 그래서 세 모델의 손실이 같은 글자들 위의 평균이 된다.
    """
    X, Y = [], []
    for w in words:
        ctx = [0] * block
        for ch in list(w) + [END]:
            ix = stoi[ch]
            X.append(ctx)
            Y.append(ix)
            ctx = ctx[1:] + [ix]
    return torch.tensor(X), torch.tensor(Y)


def save_json(path, obj):
    """결과를 UTF-8 JSON 으로 저장한다(한글이 \\u 로 바뀌지 않게)."""
    RESULTS.mkdir(exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    print(f"저장: {path}")
