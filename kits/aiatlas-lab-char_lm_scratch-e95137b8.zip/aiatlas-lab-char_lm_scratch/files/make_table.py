"""make_table.py: results 폴더의 JSON 을 모아 검증 NLL 비교표 results\\table.md 를 만든다.

실행: python make_table.py
꼬리표를 붙인 실행(선택 과제)은 표 아래 '추가 실행' 줄로 들어간다.
"""
import json
import math

from common import RESULTS


def read(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def main():
    count = read(RESULTS / "count_bigram.json")
    neural = read(RESULTS / "neural_bigram.json")
    mlp = read(RESULTS / "mlp.json")
    V = count["vocab"]
    ln_v = math.log(V)
    head = ["| 모델 | 앞 글자 | 학습하는 값 | 학습 NLL | 검증 NLL | 고르게 찍기보다 낮아진 만큼(검증) |",
            "|---|---|---|---|---|---|"]

    def row(name, ctx, params, tr, va):
        return f"| {name} | {ctx} | {params} | {tr:.4f} | {va:.4f} | {ln_v - va:.4f} |"

    lines = ["# 글자 단위 언어 모델: 같은 분할 · 같은 맞힐 글자 위의 평균 음의 로그 우도(NLL)", ""] + head
    lines.append(row(f"고르게 찍기 ln({V})", 0, "없음", ln_v, ln_v))
    lines.append(row(f"글자 빈도(평활 {count['alpha']:g})", 0, "없음(센다)", count["train_nll_unigram"], count["val_nll_unigram"]))
    lines.append(row(f"셈 bigram(평활 {count['alpha']:g})", 1, "없음(센다)", count["train_nll"], count["val_nll"]))
    lines.append(row(f"신경망 bigram({neural['steps']}걸음)", 1, neural["params"], neural["train_nll"], neural["val_nll"]))
    lines.append(row(f"MLP(걸음 {mlp['best_step']})", mlp["config"]["block"], mlp["params"], mlp["train_nll"], mlp["val_nll"]))
    lines += ["",
              f"- 셈 bigram 의 학습 NLL 하한(평활 없음): {count['train_nll_raw']:.4f}"
              f" · 평활 없이 잰 검증 NLL: {count['val_nll_raw']} (검증에서 처음 보는 짝 {count['val_unseen_pairs']}개)",
              f"- 신경망 bigram 의 첫 손실 점검: {neural['first_check']} · 마지막 기록에서도 검증이 내려가는 중: "
              f"{'예' if neural['still_falling_at_end'] else '아니오'} · 셈 bigram 과의 검증 차이 {neural['gap_val_vs_count']:+.4f}",
              f"- MLP 의 첫 손실 점검: {mlp['first_check']} · 마지막 기록의 학습/검증 NLL "
              f"{mlp['final_train_nll']:.4f} / {mlp['final_val_nll']:.4f}"]

    extra = []
    for path in sorted(RESULTS.glob("*.json")):
        if path.name == "test_once.json":   # 테스트 기록은 이 표에 넣지 않는다(보고서에 따로)
            continue
        r = read(path)
        if not r.get("tag"):                # 꼬리표 없는 기본 실행은 위 표에 이미 있다
            continue
        if r.get("model") == "count_bigram":
            extra.append(row(f"셈 bigram(평활 {r['alpha']:g}) [{r['tag']}]", 1, "없음(센다)", r["train_nll"], r["val_nll"]))
        elif r.get("model") == "neural_bigram":
            extra.append(row(f"신경망 bigram({r['steps']}걸음 · 정규화 {r['reg']:g}) [{r['tag']}]", 1, r["params"], r["train_nll"], r["val_nll"]))
        elif r.get("model") == "mlp":
            extra.append(row(f"MLP(걸음 {r['best_step']}) [{r['tag']}]", r["config"]["block"], r["params"], r["train_nll"], r["val_nll"]))
    if extra:
        lines += ["", "## 추가 실행(선택 과제 · 설정 하나씩만 바꿈)", ""] + head + extra

    with open(RESULTS / "table.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"저장: {RESULTS / 'table.md'}")


if __name__ == "__main__":
    main()
