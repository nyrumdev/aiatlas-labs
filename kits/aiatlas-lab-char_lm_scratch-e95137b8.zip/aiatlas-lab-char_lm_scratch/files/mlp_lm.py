"""mlp_lm.py: 앞 몇 글자를 글자 임베딩으로 바꿔 이어 붙이고, 은닉층 하나(tanh)를 지나 다음 글자를 맞히는 작은 MLP(CPU).

실행: python mlp_lm.py                                   (앞 3글자 · 임베딩 10 · 은닉 200 · 묶음 32 · 60000걸음)
      python mlp_lm.py --block 5 --tag block5           (선택 과제: 설정 하나만 바꿔 한 번 더)
만드는 파일: results\\mlp<꼬리표>.json · results\\mlp<꼬리표>_best.pt
"""
import argparse
import math
import time

import torch
import torch.nn.functional as F

from common import RESULTS, SAMPLE_SEED, bigram_pairs, context_rows, load_split, make_stoi, save_json


def init_params(V, block, emb, hidden, g):
    """파라미터 다섯 개. 출력층을 아주 작게 시작해 첫 손실이 ln(어휘) 근처에 오게 한다."""
    C = torch.randn((V, emb), generator=g)                                   # 글자 임베딩 표
    W1 = torch.randn((block * emb, hidden), generator=g) / math.sqrt(block * emb)
    b1 = torch.zeros(hidden)
    W2 = torch.randn((hidden, V), generator=g) * 0.01
    b2 = torch.zeros(V)
    params = {"C": C, "W1": W1, "b1": b1, "W2": W2, "b2": b2}
    for p in params.values():
        p.requires_grad_(True)
    return params


def logits_of(params, X):
    """X: (줄 수, block) 글자 번호 → (줄 수, V) 로짓."""
    emb = params["C"][X]                                  # (줄 수, block, emb)
    h = torch.tanh(emb.view(X.shape[0], -1) @ params["W1"] + params["b1"])
    return h @ params["W2"] + params["b2"]


def evaluate(params, X, Y):
    with torch.no_grad():
        return F.cross_entropy(logits_of(params, X), Y).item()


def sample_names(params, itos, block, n=10, seed=SAMPLE_SEED, max_len=30):
    g = torch.Generator().manual_seed(seed)
    out = []
    with torch.no_grad():
        for _ in range(n):
            ctx, name = [0] * block, ""
            while len(name) < max_len:
                probs = F.softmax(logits_of(params, torch.tensor([ctx])), dim=1)
                ix = torch.multinomial(probs, num_samples=1, generator=g).item()
                if ix == 0:
                    break
                name += itos[ix]
                ctx = ctx[1:] + [ix]
            out.append(name)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", type=int, default=3, help="앞 몇 글자를 보나(문맥 길이)")
    ap.add_argument("--emb", type=int, default=10, help="글자 임베딩 차원")
    ap.add_argument("--hidden", type=int, default=200)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--steps", type=int, default=60000)
    ap.add_argument("--lr", type=float, default=0.1, help="앞 절반의 학습률: 뒤 절반은 이 값의 0.1배")
    ap.add_argument("--eval_every", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--tag", default="")
    args = ap.parse_args()
    torch.set_num_threads(1)   # 묶음 32 의 작은 연산은 스레드 하나가 빠르기 쉽다: 여러 스레드는 나눠 맡기는 비용이 더 크다

    RESULTS.mkdir(exist_ok=True)
    s = load_split()
    itos = s["itos"]
    stoi = make_stoi(itos)
    V = len(itos)
    Xtr, Ytr = context_rows(s["train"], stoi, args.block)
    Xva, Yva = context_rows(s["val"], stoi, args.block)
    same_targets = torch.equal(Ytr, bigram_pairs(s["train"], stoi)[1])
    print(f"학습 줄 {len(Ytr)} · 검증 줄 {len(Yva)} · 맞힐 글자가 bigram 과 같은가: {'같음' if same_targets else '다름'}")

    g = torch.Generator().manual_seed(args.seed)
    params = init_params(V, args.block, args.emb, args.hidden, g)
    n_params = sum(p.numel() for p in params.values())
    first = evaluate(params, Xva, Yva)
    first_ok = abs(first - math.log(V)) < 0.05 * math.log(V)
    print(f"파라미터 {n_params}개 · 첫 검증 손실 {first:.4f} · ln({V}) = {math.log(V):.4f}"
          f" → {'통과' if first_ok else '확인 필요'}")

    history, best = [], {"val_nll": float("inf"), "step": 0}
    drop_at = args.steps // 2
    t0 = time.perf_counter()
    for step in range(1, args.steps + 1):
        ix = torch.randint(0, Xtr.shape[0], (args.batch,), generator=g)    # 무작위 작은 묶음
        loss = F.cross_entropy(logits_of(params, Xtr[ix]), Ytr[ix])
        for p in params.values():
            p.grad = None
        loss.backward()
        lr = args.lr if step <= drop_at else args.lr * 0.1
        with torch.no_grad():
            for p in params.values():
                p -= lr * p.grad
        if step % args.eval_every == 0 or step == args.steps:
            tr, va = evaluate(params, Xtr, Ytr), evaluate(params, Xva, Yva)
            history.append({"step": step, "lr": lr, "train_nll": tr, "val_nll": va})
            mark = ""
            if va < best["val_nll"]:
                best = {"val_nll": va, "train_nll": tr, "step": step}
                torch.save({"config": vars(args), "itos": itos,
                            "params": {k: v.detach().clone() for k, v in params.items()}},
                           RESULTS / f"mlp{'_' + args.tag if args.tag else ''}_best.pt")
                mark = " ← 지금까지 가장 낮은 검증"
            print(f"걸음 {step:6d} · 학습률 {lr:g} · 학습 NLL {tr:.4f} · 검증 NLL {va:.4f}{mark}")
    seconds = time.perf_counter() - t0

    tag = f"_{args.tag}" if args.tag else ""
    saved = torch.load(RESULTS / f"mlp{tag}_best.pt")
    best_params = saved["params"]
    samples = sample_names(best_params, itos, args.block)
    train_set = set(s["train"])
    result = {
        "model": "mlp",
        "tag": args.tag,
        "config": vars(args),
        "params": n_params,
        "same_targets_as_bigram": same_targets,
        "first_val_loss": first,
        "first_check": "통과" if first_ok else "확인 필요",
        "history": history,
        "best_step": best["step"],
        "train_nll": best["train_nll"],
        "val_nll": best["val_nll"],
        "final_train_nll": history[-1]["train_nll"],
        "final_val_nll": history[-1]["val_nll"],
        "samples": samples,
        "samples_in_train": sum(n in train_set for n in samples),
        "seconds": seconds,
    }
    print(f"가장 낮은 검증 NLL {best['val_nll']:.4f}(걸음 {best['step']}) · 그때 학습 NLL {best['train_nll']:.4f}")
    print("표본:", " ".join(samples), f"(학습 이름과 같은 것 {result['samples_in_train']}개)")
    print(f"걸린 시간 {seconds:.1f}초")
    save_json(RESULTS / f"mlp{tag}.json", result)


if __name__ == "__main__":
    main()
