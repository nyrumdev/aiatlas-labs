"""prepare_names.py: data\\names.txt 를 읽어 어휘를 만들고, 이름 단위로 학습 80% · 검증 10% · 테스트 10% 로 나눈다.

실행: python prepare_names.py
만드는 파일: data\\split.json (세 모델이 모두 이 한 파일의 분할을 쓴다)
"""
import json
import math
import sys

import torch

from common import DATA, END, SPLIT_FILE

SPLIT_SEED = 42   # 섞는 순서를 정하는 시드: 바꾸면 분할이 달라지니 처음 정한 값을 끝까지 쓴다


def main():
    path = DATA / "names.txt"
    with open(path, encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    words = list(dict.fromkeys(lines))   # 같은 이름이 두 번 이상 있으면 처음 것만 남긴다(순서 유지)
    chars = sorted(set("".join(words)))
    if END in chars:
        sys.exit(f"이름 안에 끝 표시 '{END}' 가 들어 있다: 다른 글자로 바꿔야 한다")
    itos = [END] + chars

    g = torch.Generator().manual_seed(SPLIT_SEED)
    order = torch.randperm(len(words), generator=g).tolist()
    shuffled = [words[i] for i in order]
    n1 = int(0.8 * len(words))
    n2 = int(0.9 * len(words))
    split = {
        "source": str(path),
        "lines": len(lines),
        "split_seed": SPLIT_SEED,
        "itos": itos,
        "train": shuffled[:n1],
        "val": shuffled[n1:n2],
        "test": shuffled[n2:],
    }
    with open(SPLIT_FILE, "w", encoding="utf-8") as f:
        json.dump(split, f, ensure_ascii=False)

    targets = {k: sum(len(w) + 1 for w in split[k]) for k in ("train", "val", "test")}
    tr, va, te = set(split["train"]), set(split["val"]), set(split["test"])
    lengths = [len(w) for w in words]
    print(f"줄 {len(lines)}개 · 겹친 이름을 뺀 이름 {len(words)}개(뺀 줄 {len(lines) - len(words)}개) · 길이 {min(lengths)}~{max(lengths)}")
    print(f"어휘 {len(itos)}개(끝 표시 포함): {''.join(itos)} · ln(어휘) = {math.log(len(itos)):.4f}")
    print(f"이름 수   학습 {len(split['train'])} · 검증 {len(split['val'])} · 테스트 {len(split['test'])}")
    print(f"맞힐 글자 학습 {targets['train']} · 검증 {targets['val']} · 테스트 {targets['test']}")
    print(f"두 조각에 함께 든 같은 이름: 학습∩검증 {len(tr & va)} · 학습∩테스트 {len(tr & te)} · 검증∩테스트 {len(va & te)}")
    print(f"저장: {SPLIT_FILE}")


if __name__ == "__main__":
    main()
