"""count_bigram.py: 학습 이름만 세어 bigram 표를 만들고, 학습·검증의 평균 음의 로그 우도(NLL)를 잰다.

실행: python count_bigram.py              (평활 alpha = 1)
      python count_bigram.py --alpha 0.1 --tag a0.1   (선택 과제: 평활만 바꿔 한 번 더)
만드는 파일: results\\count_bigram<꼬리표>.json · results\\count_bigram<꼬리표>.pt
"""
import argparse
import math

import torch

from common import RESULTS, SAMPLE_SEED, bigram_pairs, load_split, make_stoi, save_json


def count_table(xs, ys, V):
    """(앞 글자, 다음 글자) 짝의 횟수를 V × V 표로 센다. 칸 번호 = 앞 × V + 다음."""
    return torch.bincount(xs * V + ys, minlength=V * V).view(V, V)


def probs_from_counts(N, alpha):
    """모든 칸에 alpha 를 더한 뒤 줄마다 합으로 나눠 확률표로 바꾼다(alpha = 0 이면 평활 없음)."""
    P = N.float() + alpha
    return P / P.sum(1, keepdim=True)


def mean_nll(P, xs, ys):
    """짝마다 −log P[앞, 다음] 의 평균. 한 칸이라도 확률 0 이면 inf 가 된다."""
    return (-P[xs, ys].log()).mean().item()


def sample_names(P, itos, n=10, seed=SAMPLE_SEED, max_len=30):
    """'.' 에서 시작해 표의 줄에서 다음 글자를 뽑고, '.' 이 나오면 이름 하나를 끝낸다."""
    g = torch.Generator().manual_seed(seed)
    out = []
    for _ in range(n):
        ix, name = 0, ""
        while len(name) < max_len:
            ix = torch.multinomial(P[ix], num_samples=1, replacement=True, generator=g).item()
            if ix == 0:
                break
            name += itos[ix]
        out.append(name)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alpha", type=float, default=1.0, help="모든 칸에 더할 평활 값")
    ap.add_argument("--tag", default="", help="결과 파일 이름 꼬리표(선택 과제용)")
    args = ap.parse_args()

    s = load_split()
    itos = s["itos"]
    stoi = make_stoi(itos)
    V = len(itos)
    xtr, ytr = bigram_pairs(s["train"], stoi)
    xva, yva = bigram_pairs(s["val"], stoi)

    N = count_table(xtr, ytr, V)
    assert N.sum().item() == len(xtr), "센 횟수의 합이 학습 짝 수와 다르다"
    top = torch.topk(N.flatten(), 5)
    print("가장 흔한 짝 5개:", " · ".join(
        f"{itos[i // V]}{itos[i % V]} {c}" for c, i in zip(top.values.tolist(), top.indices.tolist())))

    P_raw = probs_from_counts(N, 0.0)            # 평활 없는 표 = 학습 짝을 가장 잘 맞추는 bigram
    unseen = int((N[xva, yva] == 0).sum().item())  # 검증 짝 가운데 학습에서 한 번도 못 본 짝
    P = probs_from_counts(N, args.alpha)
    rows_ok = torch.allclose(P.sum(1), torch.ones(V))
    # 앞 글자를 보지 않는 글자 빈도표(같은 평활): 셈 bigram 과의 차이가 '앞 글자 하나'의 몫이다
    uni = torch.bincount(ytr, minlength=V).float() + args.alpha
    uni = uni / uni.sum()

    result = {
        "model": "count_bigram",
        "tag": args.tag,
        "alpha": args.alpha,
        "vocab": V,
        "ln_vocab": math.log(V),
        "train_pairs": len(xtr),
        "val_pairs": len(xva),
        "train_nll_unigram": (-uni[ytr].log()).mean().item(),
        "val_nll_unigram": (-uni[yva].log()).mean().item(),
        "train_nll_raw": mean_nll(P_raw, xtr, ytr),   # 어떤 bigram 도 학습 조각에서 이보다 낮을 수 없다
        "val_nll_raw": mean_nll(P_raw, xva, yva),     # 못 본 짝이 하나라도 있으면 inf
        "val_unseen_pairs": unseen,
        "train_nll": mean_nll(P, xtr, ytr),
        "val_nll": mean_nll(P, xva, yva),
        "rows_sum_to_one": rows_ok,
        "samples": sample_names(P, itos),
    }
    train_set = set(s["train"])
    result["samples_in_train"] = sum(name in train_set for name in result["samples"])

    print(f"고르게 찍기 ln({V}) = {result['ln_vocab']:.4f}")
    print(f"글자 빈도(앞 글자 없음 · 평활 {args.alpha:g})  학습 NLL {result['train_nll_unigram']:.4f}"
          f" · 검증 NLL {result['val_nll_unigram']:.4f}")
    print(f"평활 없음  학습 NLL {result['train_nll_raw']:.4f} · 검증 NLL {result['val_nll_raw']:.4f}"
          f" · 검증에서 처음 보는 짝 {unseen}개")
    print(f"평활 {args.alpha:g}  학습 NLL {result['train_nll']:.4f} · 검증 NLL {result['val_nll']:.4f}"
          f" · 줄 합 = 1 {'통과' if rows_ok else '실패'}")
    print("표본:", " ".join(result["samples"]), f"(학습 이름과 같은 것 {result['samples_in_train']}개)")

    tag = f"_{args.tag}" if args.tag else ""
    save_json(RESULTS / f"count_bigram{tag}.json", result)
    torch.save({"N": N, "P": P, "alpha": args.alpha, "itos": itos}, RESULTS / f"count_bigram{tag}.pt")


if __name__ == "__main__":
    main()
