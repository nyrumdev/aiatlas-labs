"""neural_bigram.py: 같은 bigram 을 'V × V 가중치 행렬 + 소프트맥스' 로 두고 경사하강법으로 학습해 셈 표와 견준다.

실행: python neural_bigram.py                         (학습률 50 · 500걸음 · 정규화 없음)
      python neural_bigram.py --reg 0.01 --tag reg0.01   (선택 과제: 가중치 제곱 벌점을 더해 한 번 더)
먼저 count_bigram.py 를 돌려 results\\count_bigram.pt 가 있어야 한다.
만드는 파일: results\\neural_bigram<꼬리표>.json · results\\neural_bigram<꼬리표>.pt · results\\row_diff<꼬리표>.md
"""
import argparse
import json
import math
import time

import torch
import torch.nn.functional as F

from common import RESULTS, bigram_pairs, load_split, make_stoi, save_json
from count_bigram import mean_nll, sample_names


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lr", type=float, default=50.0)
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--reg", type=float, default=0.0, help="손실에 더할 reg × (W 제곱의 평균)")
    ap.add_argument("--log_every", type=int, default=25)
    ap.add_argument("--tag", default="")
    args = ap.parse_args()

    s = load_split()
    itos = s["itos"]
    stoi = make_stoi(itos)
    V = len(itos)
    xtr, ytr = bigram_pairs(s["train"], stoi)
    xva, yva = bigram_pairs(s["val"], stoi)
    count = torch.load(RESULTS / "count_bigram.pt")   # 텐서와 기본 자료형만 든 사전이라 기본값(weights_only)으로 읽힌다
    N, P_count = count["N"], count["P"]

    xenc_tr = F.one_hot(xtr, num_classes=V).float()   # (학습 짝 수, V): 앞 글자 자리만 1
    xenc_va = F.one_hot(xva, num_classes=V).float()
    W = torch.zeros((V, V), requires_grad=True)        # 0 에서 시작 → 모든 줄이 고른 분포

    first = F.cross_entropy(xenc_tr @ W, ytr).item()
    first_ok = abs(first - math.log(V)) < 1e-4
    print(f"첫 손실 {first:.4f} · ln({V}) = {math.log(V):.4f} → {'통과' if first_ok else '확인 필요'}")

    history = []
    t0 = time.perf_counter()
    for step in range(1, args.steps + 1):
        logits = xenc_tr @ W                                   # 원-핫 곱 = W 의 줄 꺼내기
        data_loss = F.cross_entropy(logits, ytr)               # 소프트맥스 + 정답 칸의 −log 평균
        loss = data_loss + args.reg * (W ** 2).mean()
        W.grad = None
        loss.backward()
        with torch.no_grad():
            W -= args.lr * W.grad
        if step % args.log_every == 0 or step == args.steps:
            with torch.no_grad():
                val = F.cross_entropy(xenc_va @ W, yva).item()
            history.append({"step": step, "train_nll": data_loss.item(), "val_nll": val})
            print(f"걸음 {step:4d} · 학습 NLL {data_loss.item():.4f} · 검증 NLL {val:.4f}")
    seconds = time.perf_counter() - t0

    with torch.no_grad():
        same_as_rows = torch.allclose(xenc_va @ W, W[xva])     # 원-핫 곱과 줄 꺼내기가 같은 값인가
        P_net = F.softmax(W, dim=1)
        train_nll = mean_nll(P_net, xtr, ytr)
        val_nll = mean_nll(P_net, xva, yva)
    with open(RESULTS / "count_bigram.json", encoding="utf-8") as f:
        cj = json.load(f)
    below_floor = train_nll < cj["train_nll_raw"] - 1e-4      # 학습 조각에서 셈 표(평활 없음)보다 낮으면 무언가 어긋났다

    # 줄마다(앞 글자마다) 두 표의 차이: 학습에서 그 앞 글자가 몇 번 나왔는지와 함께
    P_raw = N.float() / N.sum(1, keepdim=True).clamp(min=1)   # 평활 없는 셈 표(학습 조각의 비율 그대로)
    rows = []
    for i in range(V):
        rows.append((int(N[i].sum().item()), itos[i],
                     (P_net[i] - P_count[i]).abs().max().item(),
                     (P_net[i] - P_raw[i]).abs().max().item()))
    rows.sort()
    tag = f"_{args.tag}" if args.tag else ""
    lines = [f"| 앞 글자 | 학습에서 나온 횟수 | 셈 표(평활 {count['alpha']:g})와의 최대 차이 | 평활 없는 셈 표와의 최대 차이 |",
             "|---|---|---|---|"]
    lines += [f"| {ch} | {n} | {d1:.4f} | {d0:.4f} |" for n, ch, d1, d0 in rows]
    with open(RESULTS / f"row_diff{tag}.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    samples = sample_names(P_net, itos)
    same_samples = sum(a == b for a, b in zip(samples, cj["samples"]))
    result = {
        "model": "neural_bigram",
        "tag": args.tag,
        "lr": args.lr,
        "steps": args.steps,
        "reg": args.reg,
        "params": V * V,
        "first_loss": first,
        "first_check": "통과" if first_ok else "확인 필요",
        "onehot_equals_row_lookup": same_as_rows,
        "history": history,
        "still_falling_at_end": len(history) > 1 and history[-1]["val_nll"] < history[-2]["val_nll"],
        "train_nll": train_nll,
        "val_nll": val_nll,
        "count_train_nll_raw": cj["train_nll_raw"],
        "count_val_nll": cj["val_nll"],
        "gap_val_vs_count": val_nll - cj["val_nll"],
        "below_count_floor": below_floor,
        "samples": samples,
        "samples_same_as_count": same_samples,
        "seconds": seconds,
    }
    print(f"원-핫 곱 = 줄 꺼내기: {'같음' if same_as_rows else '다름'}")
    print(f"신경망 bigram  학습 NLL {train_nll:.4f} · 검증 NLL {val_nll:.4f}")
    print(f"셈 bigram      학습 NLL 하한(평활 없음) {cj['train_nll_raw']:.4f} · 검증 NLL {cj['val_nll']:.4f}"
          f" → 검증 차이 {val_nll - cj['val_nll']:+.4f}")
    if below_floor:
        print("경고: 학습 NLL 이 셈 표의 하한보다 낮다: 두 스크립트가 같은 분할을 읽었는지 본다")
    print("표본:", " ".join(samples), f"(같은 시드의 셈 bigram 표본과 같은 것 {same_samples}개)")
    print(f"걸린 시간 {seconds:.1f}초")
    save_json(RESULTS / f"neural_bigram{tag}.json", result)
    torch.save({"W": W.detach(), "itos": itos}, RESULTS / f"neural_bigram{tag}.pt")


if __name__ == "__main__":
    main()
