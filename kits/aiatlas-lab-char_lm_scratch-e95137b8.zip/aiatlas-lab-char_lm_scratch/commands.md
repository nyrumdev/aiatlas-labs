# 글자 단위 언어 모델 — 세어서 만든 bigram → 신경망 bigram → 작은 MLP(CPU) — 명령·코드 모음

실습 id: `lab.c.lab.char_lm_scratch`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업 폴더와 가상환경 — PowerShell 을 열고 아래를 차례로 친다.

```powershell
py list
py install 3.14
mkdir C:\work\char-lm
cd C:\work\char-lm
py -V:3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install torch
python -c "import sys, torch; print(sys.version); print(torch.__version__)" | Out-File -Encoding utf8 versions.txt
Get-Content versions.txt
mkdir data
```

## 2. 데이터 받기 — makemore 저장소의 이름 목록을 받는다. 미국 사회보장국(ssa.gov) 2018년 자료에서 가장 흔한 이름을 모은 파일이고, 저장소는 MIT 라이선스다(S6280).

```powershell
curl.exe -L -o data\names.txt https://raw.githubusercontent.com/karpathy/makemore/master/names.txt
Get-Content data\names.txt -TotalCount 5
(Get-Content data\names.txt).Count
```

## 3. 공통 도구 — 아래를 `common.py` 로 저장한다. 세 모델이 같은 분할 · 같은 맞힐 글자를 쓰게 만드는 파일이다.

- `files/common.py` — 키트에 들어 있음 (python)

## 4. 이름 단위 분할 — 아래를 `prepare_names.py` 로 저장하고 실행한다.

- `files/prepare_names.py` — 키트에 들어 있음 (python)

```powershell
python prepare_names.py
```

## 5. 셈 bigram — 아래를 `count_bigram.py` 로 저장하고 실행한다.

- `files/count_bigram.py` — 키트에 들어 있음 (python)

```powershell
python count_bigram.py
```

## 7. 신경망 bigram — 아래를 `neural_bigram.py` 로 저장하고 실행한다. 5단계의 count_bigram.pt 를 읽으므로 그 뒤에 돌린다.

- `files/neural_bigram.py` — 키트에 들어 있음 (python)

```powershell
python neural_bigram.py
```

## 8. 두 bigram 견주기 — 출력과 neural_bigram.json 에서 다섯 가지를 확인해 보고서에 적는다. (c3)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python neural_bigram.py --steps 2000 --tag s2000`

## 9. 작은 MLP — 아래를 `mlp_lm.py` 로 저장하고 실행한다. 기본 60000걸음이다. 걸린 시간은 끝에 초로 찍힌다.

- `files/mlp_lm.py` — 키트에 들어 있음 (python)

```powershell
python mlp_lm.py
```

## 10. (선택) 평활과 정규화 — 셈 표의 평활과 신경망의 가중치 벌점을 견준다. 셈 bigram 은 꼬리표를 붙여 평활만 바꾸고, 신경망 bigram 은 손실에 0.01 × (W 제곱의 평균)을 더한다. 강의 …

```powershell
python count_bigram.py --alpha 0.1 --tag a0.1
python count_bigram.py --alpha 10 --tag a10
python neural_bigram.py --reg 0.01 --tag reg0.01
```

## 11. (선택) MLP 설정 하나 바꾸기 — 13단계(테스트) 전에 한다. 문맥 길이나 임베딩 크기 하나만 바꿔 같은 걸음 수로 돌린다.

```powershell
python mlp_lm.py --block 5 --tag block5
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python mlp_lm.py --emb 2 --tag emb2`

## 12. 비교표 — 아래를 `make_table.py` 로 저장하고 실행한다.

- `files/make_table.py` — 키트에 들어 있음 (python)

```powershell
python make_table.py
```

## 13. 테스트 한 번 — table.md 의 검증 NLL 이 가장 낮은 모델을 고르고, 아래를 `test_once.py` 로 저장한다.

- `files/test_once.py` — 키트에 들어 있음 (python)

```powershell
# 고른 모델이 MLP 기본 설정일 때의 두 줄 — 꼬리표 모델(예: block5)이면 끝에 --tag block5 를 붙여 친다 · 첫 줄을 치면 다른 모델로 다시 잴 수 없다(아래 설명)
python test_once.py --model mlp
python test_once.py --model mlp
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python test_once.py --model mlp --tag block5`

## 14. 판 기록 — 설치된 판을 남긴다.

```powershell
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
Get-Content requirements.lock.txt
```

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Get-Content data\names.txt -TotalCount 5`
- `pip install torch`
- `python -V`
- `py -V:3.14 -m venv .venv`
- `cd C:\work\char-lm`
- `python test_once.py`
