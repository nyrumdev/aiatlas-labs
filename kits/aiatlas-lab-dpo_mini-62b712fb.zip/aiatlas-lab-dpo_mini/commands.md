# 선호 쌍으로 작은 모델 DPO 한 번 돌리기 — 마진 곡선 · 답 길이 · 회귀 — 명령·코드 모음

실습 id: `lab.c.lab.dpo_mini`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 실행 환경 — 앞 노드 [실습] 파인튜닝 1회 + 평가 리포트의 WSL 환경을 그대로 쓴다. 이유도 같다. TRL 1.15.0 의 DPOTrainer 는 만들 때 정책 모델(과 따로 둔 참조 모델)에 '융합 …

```bash
mkdir -p ~/dpo-lab/env ~/dpo-lab/configs ~/dpo-lab/data ~/dpo-lab/results && cd ~/dpo-lab
source ~/ft-lab/.venv/bin/activate
{ python -m pip freeze | diff <(grep -v "^--" ~/ft-lab/env/requirements.lock.txt) - && echo "lock 과 같음"; } | tee env/lock_diff.txt
cp ~/ft-lab/env/requirements.lock.txt env/
python -c "import torch, trl, peft, trl.trainer.utils as u; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), torch.cuda.is_bf16_supported(), trl.__version__, peft.__version__, u._ChunkedLogProbFunction)" | tee env/env_check.txt
git init && git config user.name "$(git -C ~/ft-lab config user.name)" && git config user.email "$(git -C ~/ft-lab config user.email)"
printf "runs/*/final/\nruns/*/init/\n__pycache__/\n" > .gitignore && git config user.name && git config user.email
explorer.exe .
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git config user.name "내 이름"`
- `git config user.email "내 메일"`
- `wsl -l -v`
- `cd ~/dpo-lab && source ~/ft-lab/.venv/bin/activate`

## 2. 모델·데이터의 커밋과 설정 파일 — 앞 노드 Hugging Face Hub와 모델 카드에서 본 대로, 받은 저장소의 커밋을 적어야 '같은 모델·같은 데이터'라고 말할 수 있다. `hf download` 는 …

```bash
hf download Qwen/Qwen2.5-0.5B-Instruct                                              # 마지막 줄 snapshots/ 다음 40자 = 모델 커밋
hf download HuggingFaceH4/ultrafeedback_binarized --repo-type dataset --include "data/*_prefs-*"   # 같은 방식으로 데이터 커밋
```

- `files/configs/D0.json` — 키트에 들어 있음 (json)

## 3. 쌍 만들기와 길이 세기 — 두 파일을 함께 쓴다. `dpo_common.py` 는 파일을 읽고 쓰는 일과 노트 문항 채점 규칙을 맡는다. 채점 규칙은 앞 노드 평가 하네스 실습의 note_answer@v1 과 …

- `files/dpo_common.py` — 키트에 들어 있음 (python)

- `files/make_pairs.py` — 키트에 들어 있음 (python)

```bash
python make_pairs.py
```

```bash
git add .gitignore *.py configs data env predict.md && git commit -m "쌍·설정·예측(학습 전)"
git log --oneline
```

## 4. 학습 전 측정 — 학습에 손대기 전에 같은 측정을 '전' 열로 채운다. 생성 측정은 두 묶음이다. 노트 묶음은 앞 실습의 30문항이고, 검증 묶음은 학습에 쓰지 않은 검증 쌍 50개의 질문이다. 앞 실습의 …

```bash
cp /mnt/c/work/evalh/data/eval.jsonl data/notes_eval.jsonl
```

- `files/gen_eval.py` — 키트에 들어 있음 (python)

```bash
python gen_eval.py --set notes --out samples/base_notes.jsonl
python gen_eval.py --set uf --out samples/base_uf.jsonl
```

## 5. 시운전 → 학습 → 마진 곡선 — 학습 스크립트는 설정 파일 하나만 읽는다. 다만 시작할 때 3단계에서 말한 대로 predict.md 의 커밋을 git 에서 확인한다. ref_model 을 넘기지 않고 …

- `files/train_dpo.py` — 키트에 들어 있음 (python)

- `files/derive.py` — 키트에 들어 있음 (python)

```bash
python derive.py D0_smoke max_steps 2
python train_dpo.py configs/D0_smoke.json
grep -E "peak_mem_mib|train_seconds" runs/D0_smoke/run_meta.json
```

```bash
python train_dpo.py configs/D0.json
```

- `files/plot_margins.py` — 키트에 들어 있음 (python)

```bash
python plot_margins.py runs/D0/trainer_state.json --out runs/D0/margins.png
```

## 6. 학습 후 측정과 길이 표 — 4단계와 같은 스크립트·같은 설정에서 어댑터만 켠다.

```bash
python gen_eval.py --adapter runs/D0/final --set notes --out samples/D0_notes.jsonl
python gen_eval.py --adapter runs/D0/final --set uf --out samples/D0_uf.jsonl
```

- `files/compare.py` — 키트에 들어 있음 (python)

```bash
python compare.py samples/base_uf.jsonl samples/D0_uf.jsonl --out results/D0_uf
python compare.py samples/base_notes.jsonl samples/D0_notes.jsonl --out results/D0_notes
```

## 7. 회귀 찾기 — 회귀는 세 묶음에서 찾는다. 첫째, 노트 30문항의 회귀 목록(results/D0_notes_regressions.csv)이다. 전에 맞았는데 후에 틀린 문항(correct_lost)과, 전에는 …

```bash
mkdir -p /mnt/c/work/evalh/adapters
cp -rT runs/D0/init /mnt/c/work/evalh/adapters/D0_init
cp -rT runs/D0/final /mnt/c/work/evalh/adapters/D0
```

```powershell
Set-Location C:\work\evalh
.\.venv\Scripts\python -m pip show peft | Select-String '^Version'
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,revision=<모델 커밋 40자>,dtype=bfloat16,peft=C:/work/evalh/adapters/D0_init --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval_dpo\before --log_samples
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,revision=<모델 커밋 40자>,dtype=bfloat16,peft=C:/work/evalh/adapters/D0 --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval_dpo\after --log_samples
Get-ChildItem -Recurse results\lm_eval_dpo -Filter samples_notes_mc_*.jsonl
```

- `files/tools/lm_flips.py` — 키트에 들어 있음 (python)

## 8. 리포트 — dpo_report.md 를 쓴다. 이 파일이 앱에 내는 증거 문서다(.md 한 파일 · 64KiB 이하). 첫 줄에 `lab_id: lab.c.lab.dpo_mini` 를 적고 절은 셋으로 …

```bash
git add -A && git commit -m "D0 결과"
git log --oneline
```

```bash
git add dpo_report.md && git commit -m "리포트"
cp dpo_report.md /mnt/c/work/dpo_report.md
```

## 9. (선택) 길이 균형 쌍 — 같은 수의 쌍을 선호 답이 더 긴 쌍과 짧은 쌍이 반씩 되게 뽑아, 쌍 말고는 아무것도 바꾸지 않고 한 번 더 돌린다. 앞 노드 DPO 가 쌍을 다 모은 뒤 선호·비선호 길이 분포를 …

```bash
python make_pairs.py --balanced
python derive.py D1 train_file '"data/pairs_train_balanced.jsonl"'
python -c "import json,sys; a,b=(json.load(open(p,encoding='utf-8')) for p in sys.argv[1:3]); [print(k, a.get(k), '->', b.get(k)) for k in dict.fromkeys([*a, *b]) if a.get(k) != b.get(k)]" configs/D0.json configs/D1.json
python train_dpo.py configs/D1.json
python gen_eval.py --adapter runs/D1/final --set uf --out samples/D1_uf.jsonl
python compare.py samples/base_uf.jsonl samples/D1_uf.jsonl --out results/D1_uf
```

## 10. (선택) 길이 정규화 손실 — TRL 의 loss_type 'sigmoid_norm' 은 SimPO 저자들이 원래 sigmoid 손실의 길이 편향을 다루려고, 가리지 않은 토큰 수로 나눈 …

```bash
python derive.py D2 loss_type '["sigmoid_norm"]'
python train_dpo.py configs/D2.json
python plot_margins.py runs/D2/trainer_state.json --out runs/D2/margins.png
python gen_eval.py --adapter runs/D2/final --set uf --out samples/D2_uf.jsonl
python compare.py samples/base_uf.jsonl samples/D2_uf.jsonl --out results/D2_uf
```
