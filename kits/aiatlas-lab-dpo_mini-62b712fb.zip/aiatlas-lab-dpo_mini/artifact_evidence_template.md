lab_id: lab.c.lab.dpo_mini

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): env/ — env_check.txt(torch 판 · cuda True · GPU 이름 · bf16 지원 · trl 1.15.0 · peft 0.21.2 · 맨 끝 값이 None 이 아님) + requirements.lock.txt(앞 실습 lock 의 사본) + lock_diff.txt(지금 가상환경의 freeze 와 그 lock 을 대조한 결과 — 'lock 과 같음' 또는 달라진 줄) + configs/D0.json(model_revision · dataset_revision 이 40자 커밋) + 리포트에 붙인 wsl -l -v 출력(VERSION 2) -->
c1: 
<!-- c2(필수): data/ — pairs_train.jsonl 150행 이상(기본 200) · pairs_val.jsonl 50행 · pairs_meta.csv + make_pairs.py 출력 붙여 넣기(rows · overlap 0 · skipped · train·val 길이 두 줄) + predict.md(선호 답이 더 긴 쌍의 수와 학습 뒤 답 길이의 예측 방향 · 이유 1줄) — runs/D0/run_meta.json 의 predict_commit 해시가 git log 의 '쌍·설정·예측(학습 전)' 커밋과 같고 그 시각이 started_at 보다 앞섬 · git log -- predict.md 의 커밋이 모두 started_at 보다 앞섬 -->
c2: 
<!-- c3(필수): 학습 전 생성 측정 — samples/base_notes.jsonl · samples/base_uf.jsonl 과 두 .meta.json(생성 설정 · 배치 · dtype 이 적힘) -->
c3: 
<!-- c4(필수): runs/D0/ — run_config.json · run_meta.json(predict_commit · started_at · 판 · GPU · peak_mem_mib · train_seconds · train_rows) · trainer_state.json · init/(학습 직전 어댑터) · final/adapter_model.safetensors + margins.png(왼쪽 학습·검증 마진 · 오른쪽 선호·비선호 보상) + margins_points.csv + 그림 아래 해석 3줄(검증 마진의 처음과 끝 · rewards/chosen 이 0 아래로 내려갔는지 · rewards/accuracies 의 학습 마지막 10걸음 평균과 검증 마지막 점 — plot_margins.py 출력) -->
c4: 
<!-- c5(필수): results/D0_uf_length.csv · D0_notes_length.csv(전·후·차 세 줄 · 평균·중앙값 토큰 · 잘림 수) + D0_uf_items.csv + 가장 길어진 5문항의 전후 답을 읽고 늘어난 까닭을 한 단어로 붙인 표 + predict.md 의 예측이 맞았는지 1줄 -->
c5: 
<!-- c6(필수): 회귀 — results/D0_notes_regressions.csv + C:\work\evalh\results\lm_eval_dpo\before · after 아래 results_….json 과 samples_notes_mc_….jsonl(어댑터 폴더 D0_init → D0 와 출력 폴더 before → after 만 다른 명령 2줄과 함께) + lm_flips.py 출력(acc 전후 · 맞았다가 틀린 doc_id) + results/D0_uf_items.csv 에서 trunc_before 0 → trunc_after 1 인 id + 리포트 '회귀' 절에 회귀 문항마다 id · 종류(정답 잃음 · 형식 잃음 · 가능도 뒤집힘 · 길어져 잘림) · 원인 추정 1문장 — 하나도 없으면 대조한 세 묶음(노트 30 · 가능도 20 · 검증 질문 50)과 그 사실 -->
c6: 
<!-- c7(필수): dpo_report.md — 첫 줄 lab_id · ## 작업(돌린 명령 한 줄씩) · ## 결과(마진 곡선 · 답 길이 · 회귀 소제목 아래 results/ 의 표를 그대로) · ## 검증(c1:~c6: 줄) · 결론 3문장 이상(문장마다 표의 숫자 하나 이상 · 이 쌍이 무엇을 가르쳤는지 · 무엇을 망가뜨렸는지) -->
c7: 
<!-- c8(선택): (선택) 길이 균형 쌍 D1 — make_pairs.py --balanced 출력(train 길이 줄의 chosen·rejected 평균·중앙값 포함) · configs/D0.json 과 D1.json 을 칸 단위로 견준 출력(run · train_file · output_dir 세 줄 · 9단계 셋째 줄) · results/D1_uf_length.csv 와 D0 줄을 나란히 놓은 표 1개 -->
c8: 
<!-- c9(선택): (선택) 길이 정규화 손실 D2 — configs/D2.json(loss_type sigmoid_norm) · results/D2_uf_length.csv · margins.png 와 D0 의 차이 2줄 -->
c9: 
