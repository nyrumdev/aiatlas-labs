"""compare.py — 전후 표본을 문항 id 로 맞대어 길이 표 · 문항 표 · 회귀 목록을 만든다.

실행 예:
    python compare.py samples/base_uf.jsonl samples/D0_uf.jsonl --out results/D0_uf
    python compare.py samples/base_notes.jsonl samples/D0_notes.jsonl --out results/D0_notes
"""
import argparse
import csv
import json
import statistics
import sys
from pathlib import Path

import dpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("before")
ap.add_argument("after")
ap.add_argument("--out", required=True)
a = ap.parse_args()

b = {r["id"]: r for r in common.read_jsonl(a.before)}
f = {r["id"]: r for r in common.read_jsonl(a.after)}
gb = json.loads(Path(a.before + ".meta.json").read_text(encoding="utf-8"))["generation"]
ga = json.loads(Path(a.after + ".meta.json").read_text(encoding="utf-8"))["generation"]
if b.keys() != f.keys() or gb != ga:
    sys.exit("문항 id 또는 생성 설정이 전후에 다르다 — 같은 스크립트·같은 설정으로 다시 뽑는다")
ids = sorted(b)
graded = "correct" in b[ids[0]]                         # 노트 문항이면 정오·형식 칸이 있다
Path(a.out).parent.mkdir(parents=True, exist_ok=True)


def summary(side, rows):
    n = [r["n_tokens"] for r in rows]
    row = {"side": side, "items": len(rows), "mean_tokens": round(statistics.mean(n), 1),
           "median_tokens": statistics.median(n), "truncated": sum(r["truncated"] for r in rows)}
    if graded:
        row.update(correct=sum(r["correct"] for r in rows), fmt_ok=sum(r["fmt_ok"] for r in rows))
    return row


table = [summary("before", [b[i] for i in ids]), summary("after", [f[i] for i in ids])]
diffs = {i: f[i]["n_tokens"] - b[i]["n_tokens"] for i in ids}
table.append({"side": "after-before", "items": len(ids),
              "mean_tokens": round(table[1]["mean_tokens"] - table[0]["mean_tokens"], 1),
              "median_tokens": table[1]["median_tokens"] - table[0]["median_tokens"],
              "truncated": table[1]["truncated"] - table[0]["truncated"],
              **({"correct": table[1]["correct"] - table[0]["correct"],
                  "fmt_ok": table[1]["fmt_ok"] - table[0]["fmt_ok"]} if graded else {})})
with open(a.out + "_length.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(table[0]))
    w.writeheader()
    w.writerows(table)

cols = ["id", "tokens_before", "tokens_after", "diff", "trunc_before", "trunc_after"]
if graded:
    cols += ["kind", "correct_before", "correct_after", "fmt_before", "fmt_after", "pred_before", "pred_after"]
with open(a.out + "_items.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(cols)
    for i in sorted(ids, key=lambda x: -diffs[x]):          # 가장 길어진 문항부터
        row = [i, b[i]["n_tokens"], f[i]["n_tokens"], diffs[i], b[i]["truncated"], f[i]["truncated"]]
        if graded:
            row += [b[i]["kind"], b[i]["correct"], f[i]["correct"], b[i]["fmt_ok"], f[i]["fmt_ok"],
                    b[i]["pred"], f[i]["pred"]]
        w.writerow(row)

lost = []
if graded:                                             # 회귀 = 전에 맞았는데 틀림 · 전에 '답:' 줄이 있었는데 사라짐
    for i in ids:
        why = [k for k, bad in (("correct_lost", b[i]["correct"] and not f[i]["correct"]),
                                ("format_lost", b[i]["fmt_ok"] and not f[i]["fmt_ok"])) if bad]
        if why:
            lost.append({"id": i, "kind": b[i]["kind"], "regression": "+".join(why),
                         "tokens_before": b[i]["n_tokens"], "tokens_after": f[i]["n_tokens"],
                         "before_tail": b[i]["text"][-200:], "after_tail": f[i]["text"][-200:]})
    with open(a.out + "_regressions.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "kind", "regression", "tokens_before", "tokens_after",
                                           "before_tail", "after_tail"])
        w.writeheader()
        w.writerows(lost)

for r in table:
    print(r)
print("가장 길어진 5문항:", ", ".join(f"{i}(+{diffs[i]})" for i in sorted(ids, key=lambda x: -diffs[x])[:5]))
if graded:
    print("회귀", len(lost), "문항:", ", ".join(f"{x['id']}[{x['regression']}]" for x in lost) or "없음")
