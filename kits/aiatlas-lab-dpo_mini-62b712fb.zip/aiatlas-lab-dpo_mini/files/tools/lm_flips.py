r"""tools/lm_flips.py — lm-eval 의 문항 기록 두 개(학습 전 · 학습 후)를 doc_id 로 맞대어 정오가 바뀐 문항을 찾는다.

실행 예(PowerShell · evalh 폴더):
    .\.venv\Scripts\python tools\lm_flips.py <전 samples_notes_mc_….jsonl> <후 samples_notes_mc_….jsonl>
"""
import json
import sys


def acc_by_doc(path):
    """doc_id → (정오, 내 문항 id) — 문항 기록의 doc 칸에 notes_mc.jsonl 의 그 줄이 그대로 들어 있다."""
    with open(path, encoding="utf-8") as f:
        rows = [json.loads(line) for line in f if line.strip()]
    return {r["doc_id"]: (int(r["acc"]), r["doc"]["id"]) for r in rows}


before, after = acc_by_doc(sys.argv[1]), acc_by_doc(sys.argv[2])
assert before.keys() == after.keys(), "두 기록의 문항이 다르다"
lost = [f"{d}({before[d][1]})" for d in sorted(before) if before[d][0] and not after[d][0]]
gained = [f"{d}({before[d][1]})" for d in sorted(before) if after[d][0] and not before[d][0]]
print(f"acc  전 {sum(v[0] for v in before.values())}/{len(before)}  후 {sum(v[0] for v in after.values())}/{len(after)}")
print("맞았다가 틀림 doc_id(문항 id):", ", ".join(lost) or "없음")
print("틀렸다가 맞음 doc_id(문항 id):", ", ".join(gained) or "없음")
