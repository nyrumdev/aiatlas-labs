"""plot_margins.py — trainer_state.json 의 기록(log_history)에서 마진·보상·정확도를 꺼내
그림 한 장(margins.png · 왼쪽 마진 · 오른쪽 선호/비선호 보상)과 점 목록(margins_points.csv)으로 남긴다.

실행 예:
    python plot_margins.py runs/D0/trainer_state.json --out runs/D0/margins.png
"""
import argparse
import csv
import json
import statistics
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # 창을 띄우지 않고 파일로만 그린다
import matplotlib.pyplot as plt

KEYS = ["rewards/margins", "rewards/chosen", "rewards/rejected", "rewards/accuracies", "logps/chosen", "logps/rejected"]


def read_points(state_path):
    """학습 기록은 'rewards/margins', 검증 기록은 'eval_rewards/margins' 칸으로 가른다."""
    history = json.loads(Path(state_path).read_text(encoding="utf-8"))["log_history"]
    train = [{"step": h["step"], **{k: h[k] for k in KEYS}} for h in history if "rewards/margins" in h]
    val = [{"step": h["step"], **{k: h["eval_" + k] for k in KEYS}} for h in history if "eval_rewards/margins" in h]
    return train, val


def main():
    ap = argparse.ArgumentParser(description="DPO 마진·보상 곡선을 그린다")
    ap.add_argument("state", help="trainer_state.json 경로")
    ap.add_argument("--out", default="margins.png")
    a = ap.parse_args()

    train, val = read_points(a.state)
    if not train or not val:
        print("학습 또는 검증 기록에 rewards/margins 가 없다 — logging_steps · eval_strategy · 검증 파일을 확인한다",
              file=sys.stderr)
        return 1

    fig, (left, right) = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")   # 두 칸의 축 글자가 겹치지 않게
    left.plot([p["step"] for p in train], [p["rewards/margins"] for p in train], label="train margin")
    left.plot([p["step"] for p in val], [p["rewards/margins"] for p in val], marker="o", label="validation margin")
    left.axhline(0, color="gray", linewidth=0.8)
    left.set_xlabel("step")
    left.set_ylabel("reward margin")
    left.legend()
    right.plot([p["step"] for p in train], [p["rewards/chosen"] for p in train], label="chosen reward")
    right.plot([p["step"] for p in train], [p["rewards/rejected"] for p in train], label="rejected reward")
    right.axhline(0, color="gray", linewidth=0.8)
    right.set_xlabel("step")
    right.set_ylabel("implicit reward (train)")
    right.legend()
    fig.savefig(a.out, dpi=120, bbox_inches="tight")

    csv_path = Path(a.out).with_name("margins_points.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["kind", "step"] + KEYS)
        for kind, pts in (("train", train), ("validation", val)):
            w.writerows([kind, p["step"]] + [p[k] for k in KEYS] for p in pts)
    print(f"학습 점 {len(train)}개 · 검증 점 {len(val)}개 → {a.out} · {csv_path}")
    print("검증 마진(걸음: 값)", ", ".join(f"{p['step']}: {p['rewards/margins']:.4f}" for p in val))
    tail = train[-10:]                 # 학습 기록은 걸음마다 8쌍이라 한 점이 크게 흔들린다 — 마지막 10걸음 평균으로 본다
    print(f"rewards/accuracies  학습 마지막 {len(tail)}걸음 평균 {statistics.mean(p['rewards/accuracies'] for p in tail):.3f}"
          f"  검증 마지막 점(걸음 {val[-1]['step']}) {val[-1]['rewards/accuracies']:.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
