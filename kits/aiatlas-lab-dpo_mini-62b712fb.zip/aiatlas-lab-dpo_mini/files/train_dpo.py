"""train_dpo.py — python train_dpo.py configs/D0.json  (설정 파일 하나만 읽어 DPO + LoRA 를 돌린다)"""
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import datasets
import peft
import torch
import transformers
import trl
from datasets import load_dataset
from peft import LoraConfig
from trl import DPOConfig, DPOTrainer


def git(*args):
    return subprocess.run(["git", *args], capture_output=True, text=True).stdout.strip()


# 학습보다 먼저 예측이 커밋되었는지 본다 — 마지막 커밋(해시 · 시각)을 run_meta.json 에 남긴다
predict_commit = git("log", "-1", "--format=%H %cI", "--", "predict.md")
if not predict_commit:
    sys.exit("predict.md 가 아직 커밋되지 않았다 — 3단계의 예측 커밋부터 한다")
if git("status", "--porcelain", "--", "predict.md"):
    sys.exit("predict.md 에 커밋하지 않은 고침이 있다 — 고친 예측을 커밋하거나 되돌린 뒤 학습한다")

cfg = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
out = Path(cfg["output_dir"])
out.mkdir(parents=True, exist_ok=True)
(out / "run_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

data = load_dataset("json", data_files={"train": cfg["train_file"], "val": cfg["val_file"]})
args = DPOConfig(
    output_dir=str(out), seed=cfg["seed"],
    beta=cfg["beta"], loss_type=cfg["loss_type"], max_length=cfg["max_length"],
    learning_rate=cfg["learning_rate"], num_train_epochs=cfg["num_train_epochs"], max_steps=cfg["max_steps"],
    per_device_train_batch_size=cfg["per_device_train_batch_size"],
    per_device_eval_batch_size=cfg["per_device_eval_batch_size"],
    gradient_accumulation_steps=cfg["gradient_accumulation_steps"],
    logging_steps=cfg["logging_steps"],
    eval_strategy="steps", eval_steps=cfg["eval_steps"], eval_on_start=True,   # 0 걸음에도 검증 마진을 잰다
    save_strategy="no", bf16=cfg["bf16"],
    model_init_kwargs={"dtype": cfg["dtype"], "revision": cfg["model_revision"]},
)
lora = LoraConfig(r=cfg["lora_r"], lora_alpha=cfg["lora_alpha"], lora_dropout=cfg["lora_dropout"],
                  bias="none", task_type="CAUSAL_LM", target_modules=cfg["lora_target_modules"])
# ref_model 을 주지 않는다 — 어댑터를 끈 같은 모델이 참조가 된다
trainer = DPOTrainer(model=cfg["model_id"], args=args, train_dataset=data["train"],
                     eval_dataset=data["val"], peft_config=lora)

trainer.model.save_pretrained(str(out / "init"))   # 학습 직전 어댑터 — 7단계 lm-eval '전' 측정이 '후'와 같은 peft= 경로를 지나게
if torch.cuda.is_available():
    torch.cuda.reset_peak_memory_stats()
started_at = datetime.now().astimezone().isoformat(timespec="seconds")   # git 의 %cI 와 같은 꼴(…+09:00)
t0 = time.perf_counter()
trainer.train()
trainer.save_state()                               # runs/<이름>/trainer_state.json (log_history)
trainer.save_model(str(out / "final"))             # 어댑터만 저장된다
meta = {
    "predict_commit": predict_commit, "started_at": started_at,   # 예측 커밋이 학습 시작보다 앞서는지 이 두 칸으로 본다
    "versions": {"torch": torch.__version__, "transformers": transformers.__version__, "trl": trl.__version__,
                 "peft": peft.__version__, "datasets": datasets.__version__},
    "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    "peak_mem_mib": round(torch.cuda.max_memory_allocated() / 2**20) if torch.cuda.is_available() else None,
    "train_seconds": round(time.perf_counter() - t0),
    "train_rows": len(data["train"]), "val_rows": len(data["val"]),
    "resolved_args": json.loads(args.to_json_string()),
}
(out / "run_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
print("global_step", trainer.state.global_step, "→", out / "final")
