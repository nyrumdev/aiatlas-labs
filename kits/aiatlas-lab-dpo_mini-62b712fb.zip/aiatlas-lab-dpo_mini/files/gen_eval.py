"""gen_eval.py — 같은 문항을 같은 설정으로 탐욕 생성해 답 길이(토큰)·잘림·답을 jsonl 로 남긴다.
어댑터를 주지 않으면 학습 전 모델, 주면 학습 후 모델이다. 그 밖에는 아무것도 바꾸지 않는다.

실행 예:
    python gen_eval.py --set notes --out samples/base_notes.jsonl
    python gen_eval.py --set uf --out samples/base_uf.jsonl
    python gen_eval.py --adapter runs/D0/final --set notes --out samples/D0_notes.jsonl
"""
import argparse
import json
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

import dpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("--config", default="configs/D0.json")    # 모델 id·커밋·dtype·최대 생성 길이를 학습과 같은 파일에서 읽는다
ap.add_argument("--adapter", default=None)                 # 없으면 학습 전 모델
ap.add_argument("--set", choices=["notes", "uf"], required=True)
ap.add_argument("--batch", type=int, default=8)
ap.add_argument("--out", required=True)
a = ap.parse_args()

cfg = json.loads(Path(a.config).read_text(encoding="utf-8"))
SETS = {"notes": ("data/notes_eval.jsonl", cfg["max_new_notes"]),   # 내 노트 30문항(앞 실습 평가셋) · 256 은 앞 실습과 같은 값이라 바꾸지 않는다
        "uf": ("data/pairs_val.jsonl", cfg["max_new_uf"])}         # 검증 쌍 50개의 질문(학습에 안 쓴 것)
device = "cuda" if torch.cuda.is_available() else "cpu"
tok = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg["model_revision"])
tok.padding_side = "left"                                  # 생성은 왼쪽 채움
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
model = AutoModelForCausalLM.from_pretrained(cfg["model_id"], revision=cfg["model_revision"],
                                             dtype=getattr(torch, cfg["dtype"])).to(device)   # 학습과 같은 dtype
if a.adapter:
    model = PeftModel.from_pretrained(model, a.adapter)
model.eval()
eos = model.generation_config.eos_token_id
eos = set(eos if isinstance(eos, list) else [eos])

path, max_new = SETS[a.set]
rows = common.read_jsonl(path)
# 저장소 generation_config.json 의 값이 끼어들지 않게 생성 설정을 모두 적는다 — 탐욕 · 반복 벌점은 저장소 기본값 그대로
gen = dict(do_sample=False, repetition_penalty=1.1, max_new_tokens=max_new, pad_token_id=tok.pad_token_id)

out = []
for s in range(0, len(rows), a.batch):
    part = rows[s:s + a.batch]
    if a.set == "notes":
        convs = [[{"role": "user", "content": common.NOTES_RULE + "질문: " + r["q"]}] for r in part]
        ids_ = [r["id"] for r in part]
    else:
        convs = [r["prompt"] for r in part]
        ids_ = [f"v{s + j:03d}" for j in range(len(part))]  # 검증 쌍 파일의 줄 번호
    texts = [tok.apply_chat_template(c, tokenize=False, add_generation_prompt=True) for c in convs]
    enc = tok(texts, return_tensors="pt", padding=True).to(device)
    with torch.no_grad():
        seqs = model.generate(**enc, **gen)
    for j, ids in enumerate(seqs[:, enc["input_ids"].shape[1]:].tolist()):
        n = next((i for i, t in enumerate(ids) if t in eos), len(ids))   # 첫 끝 토큰 앞까지가 답
        text = tok.decode(ids[:n], skip_special_tokens=True)
        rec = {"id": ids_[j], "n_tokens": n, "truncated": int(n == len(ids)), "text": text}
        if a.set == "notes":
            got = common.answer_of(text)
            rec.update(kind=part[j]["kind"], pred=got, fmt_ok=int(bool(got)),
                       correct=int(common.is_correct(got, part[j])))
        out.append(rec)
    print(f"{min(s + a.batch, len(rows))}/{len(rows)}", flush=True)

Path(a.out).parent.mkdir(parents=True, exist_ok=True)
common.write_jsonl(a.out, out)
# 배치 구성과 dtype 도 탐욕 출력을 바꿀 수 있으므로 생성 설정과 함께 적어 compare.py 가 전후를 맞대게 한다
meta = {"args": vars(a), "model_id": cfg["model_id"], "model_revision": cfg["model_revision"],
        "generation": {**{k: v for k, v in gen.items() if k != "pad_token_id"}, "batch": a.batch, "dtype": cfg["dtype"]}}
Path(a.out + ".meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
