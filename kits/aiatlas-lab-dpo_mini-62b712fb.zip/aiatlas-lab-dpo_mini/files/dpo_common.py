"""dpo_common.py — 파일 읽고 쓰기와 노트 문항 채점 규칙(앞 실습의 note_answer@v1 과 같은 규칙)을 함께 쓴다."""
import json
import re
import unicodedata

# 앞 실습 평가 하네스의 notes_direct 와 같은 지시문 · 같은 '답:' 줄 규칙
NOTES_RULE = "내 학습 노트에서 낸 질문이다. 짧게 답하고, 마지막 줄은 반드시 '답: <답>' 한 줄로 끝낸다.\n\n"
ANSWER_LINE = re.compile(r"답\s*[:：]\s*(.+)")


def norm(s):
    """대조 전에 겉모양만 맞춘다 — 대소문자·공백·따옴표·괄호 안 병기·끝 문장부호·끝 '입니다' 류."""
    s = unicodedata.normalize("NFKC", s).strip().lower()
    s = re.sub(r"\([^)]*\)", "", s)
    s = re.sub(r"[\s*`'\"“”‘’()\[\]]", "", s)
    s = s.rstrip(".,!?·")
    return re.sub(r"(입니다|이다|예요|이에요|임)$", "", s)


def answer_of(text):
    """답안의 마지막 '답:' 줄에서 답을 뽑는다. 없으면 빈 글자."""
    hits = ANSWER_LINE.findall(text)
    return norm(hits[-1]) if hits else ""


def is_correct(got, row):
    accepted = {norm(row["a"])} | {norm(x) for x in (row.get("alias") or [])}
    return bool(got) and got in accepted


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
