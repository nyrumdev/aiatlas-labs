"""make_pairs.py — UltraFeedback 이진화판에서 학습 쌍·검증 쌍을 뽑아 대화형 선호 쌍 파일로 쓴다.

실행 예:
    python make_pairs.py                 # data/pairs_train.jsonl · data/pairs_val.jsonl · data/pairs_meta.csv
    python make_pairs.py --balanced      # (선택 과제) 길이 균형 학습 쌍 · data/pairs_train_balanced.jsonl
"""
import argparse
import csv
import json
import random
import statistics
from collections import Counter
from pathlib import Path

from datasets import load_dataset
from transformers import AutoTokenizer

import dpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("--config", default="configs/D0.json")       # 모델·데이터 커밋과 max_length 를 학습과 같은 파일에서 읽는다
ap.add_argument("--n_train", type=int, default=200)
ap.add_argument("--n_val", type=int, default=50)
ap.add_argument("--seed", type=int, default=1234)
ap.add_argument("--balanced", action="store_true")           # 선호 답이 더 긴 쌍과 짧은 쌍을 반씩
a = ap.parse_args()

cfg = json.loads(Path(a.config).read_text(encoding="utf-8"))
tok = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg["model_revision"])
ds = load_dataset("HuggingFaceH4/ultrafeedback_binarized", revision=cfg["dataset_revision"],
                  data_files={"train_prefs": "data/train_prefs-*.parquet",     # 두 분할 파일만 읽는다
                              "test_prefs": "data/test_prefs-*.parquet"})


def n_tokens(text):
    return len(tok(text, add_special_tokens=False)["input_ids"])


def chat_len(messages):
    """채팅 틀을 씌운 전체 길이 — 학습기가 자를지 미리 본다."""
    return n_tokens(tok.apply_chat_template(messages, tokenize=False))


def pick(split, n, seed, used, balanced, skipped):
    order = list(range(len(split)))
    random.Random(seed).shuffle(order)
    rows, meta, longer = [], [], 0
    for i in order:
        r = split[i]
        prompt = r["chosen"][0]["content"].strip()
        if r["score_chosen"] <= r["score_rejected"]:      # 점수가 같으면 어느 쪽이 선호인지 데이터가 말하지 않는다
            skipped["tie"] += 1
            continue
        if prompt in used:
            skipped["dup_prompt"] += 1
            continue
        pair = {"prompt": [r["chosen"][0]], "chosen": [r["chosen"][1]], "rejected": [r["rejected"][1]]}
        if max(chat_len(pair["prompt"] + pair["chosen"]), chat_len(pair["prompt"] + pair["rejected"])) > cfg["max_length"]:
            skipped["too_long"] += 1                      # 잘린 답으로 길이를 배우지 않게 아예 뺀다
            continue
        lc, lr = n_tokens(pair["chosen"][0]["content"]), n_tokens(pair["rejected"][0]["content"])
        if balanced and ((lc > lr and longer >= n // 2) or (lc <= lr and len(rows) - longer >= n - n // 2)):
            skipped["balance"] += 1
            continue
        used.add(prompt)
        rows.append(pair)
        meta.append({"prompt_id": r["prompt_id"], "score_chosen": r["score_chosen"],
                     "score_rejected": r["score_rejected"], "tok_chosen": lc, "tok_rejected": lr})
        longer += lc > lr
        if len(rows) == n:
            return rows, meta
    raise SystemExit(f"조건에 맞는 쌍이 {len(rows)}개뿐이다 — n 을 줄이거나 max_length 를 확인한다")


skipped = {"val": Counter(), "train": Counter()}
used = set()
val, val_meta = pick(ds["test_prefs"], a.n_val, a.seed, used, False, skipped["val"])
train, train_meta = pick(ds["train_prefs"], a.n_train, a.seed, used, a.balanced, skipped["train"])

Path("data").mkdir(exist_ok=True)
suffix = "_balanced" if a.balanced else ""
common.write_jsonl(f"data/pairs_train{suffix}.jsonl", train)
common.write_jsonl("data/pairs_val.jsonl", val)
with open(f"data/pairs_meta{suffix}.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["split", "row", "prompt_id", "score_chosen", "score_rejected",
                                      "tok_chosen", "tok_rejected"])
    w.writeheader()
    for split, m in (("train", train_meta), ("val", val_meta)):
        for i, x in enumerate(m):
            w.writerow({"split": split, "row": i, **x})

tp = {p["prompt"][0]["content"].strip() for p in train}
vp = {p["prompt"][0]["content"].strip() for p in val}
print("rows  train", len(train), " val", len(val), " overlap", len(tp & vp))
print("skipped  val", dict(skipped["val"]), " train", dict(skipped["train"]))
for split, m in (("train", train_meta), ("val", val_meta)):
    c = [x["tok_chosen"] for x in m]
    r = [x["tok_rejected"] for x in m]
    print(f"{split}  chosen mean {statistics.mean(c):.1f} median {statistics.median(c)}"
          f"  rejected mean {statistics.mean(r):.1f} median {statistics.median(r)}"
          f"  chosen_longer {sum(x > y for x, y in zip(c, r))}/{len(m)}")
