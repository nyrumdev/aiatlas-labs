# 선호 쌍으로 작은 모델 DPO 한 번 돌리기 — 마진 곡선 · 답 길이 · 회귀

AI 아틀라스 앱의 실습 `lab.c.lab.dpo_mini`(L3 · 약 5시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — dpo_report.md(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c1:~c6: 줄 · 64KiB 이하) + WSL 의 ~/dpo-lab — env/ · configs/ · data/ · predict.md · runs/D0/ · samples/ · results/ · 파이썬 파일 7개 + C:\work\evalh — results\lm_eval_dpo\(before · after) · tools\lm_flips.py · adapters\(D0_init · D0) (앱에 낼 dpo_report.md 는 Windows 쪽으로 복사).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 11 · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) 와 Windows 쪽 NVIDIA 드라이버 — WSL 2 안에는 리눅스용 디스플레이 드라이버를 설치하지 않는다(S3593)
- 앞 노드 [실습] 파인튜닝 1회 + 평가 리포트의 WSL 2 Ubuntu 와 가상환경 ~/ft-lab/.venv(torch 2.14.1 · trl 1.15.0 · transformers 5.19.0 · peft 0.21.2 · datasets 5.1.0 · accelerate 1.15.0 · matplotlib 3.11.2)와 그 lock 파일 ~/ft-lab/env/requirements.lock.txt — TRL 1.15.0 의 DPOTrainer 도 학습 걸음마다 Triton 커널을 거치므로 Windows 파이썬에서는 첫 걸음에서 멈춘다(S6401·S3595·S3597 · 1.16.0 은 Triton 이 없으면 같은 계산을 PyTorch 연산으로 대신한다 · S8920·S8921). 이 실습은 앞 실습의 lock 그대로 1.15.0 을 쓰므로 학습은 WSL 안에서 한다. 없으면 그 실습 2단계를 먼저 한다
- 앞 노드 [실습] 내 평가 하네스 만들기(Inspect + lm-eval, 로컬 모델)의 C:\work\evalh 폴더 — data\eval.jsonl(내 노트 30문항) · tasks\lm_eval\notes_mc.yaml · lm-eval 0.4.13 이 든 .venv. 평가 하네스 쪽은 그 실습처럼 Windows PowerShell 에서 돈다
- 인터넷 — 모델 Qwen/Qwen2.5-0.5B-Instruct(apache-2.0 · 게이트 없음 · S3585)와 데이터 HuggingFaceH4/ultrafeedback_binarized 의 두 분할 파일(MIT · S6402)을 한 번 받을 때만. 학습과 측정은 전부 이 PC 안에서 돈다
- git — 앞 실습 ~/ft-lab 저장소에 적은 이름·메일(그 저장소 전용 설정이라 1단계에서 이 저장소에 다시 적는다)

## 들어 있는 파일
- `files/configs/D0.json`
- `files/dpo_common.py`
- `files/make_pairs.py`
- `files/gen_eval.py`
- `files/train_dpo.py`
- `files/derive.py`
- `files/plot_margins.py`
- `files/compare.py`
- `files/tools/lm_flips.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.dpo_mini` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
