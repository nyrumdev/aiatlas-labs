lab_id: lab.c.lab.quant_quality

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 해석
(본문 절차가 이 절에 적으라고 한 것)

## 출처 표기
(본문 절차가 이 절에 적으라고 한 것)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): env.md — llama.cpp 빌드 번호와 zip 이름 두 개 · llama-perplexity.exe --version 출력 · nvidia-smi 첫 표(GPU 이름·드라이버 판 · GPU 가 없으면 CPU 이름) · 모델 파일 SHA-256 이 S6426 의 값과 같다는 True 1줄 · wikitext zip SHA-256 대조 True 1줄 · winogrande-debiased-eval.csv SHA-256 대조 True 1줄(다르면 바이트 수와 내가 받은 해시) · 가상환경의 python --version 과 matplotlib 판 -->
c1: 
<!-- c2(필수): 사다리 — models 폴더에 BF16 + Q8_0·Q6_K·Q5_K_M·Q4_K_M·Q3_K_M·Q2_K 여섯 파일, logs 에 dryrun_<형식>.log · quantize_<형식>.log 여섯 개씩 + 보고서 '사다리 표'(형식 · --dry-run 이 예측한 quant size · 실제 파일 바이트 · BPW · token_embd 와 per_layer_token_embd 가 받은 형식) 7행 -->
c2: 
<!-- c3(필수): 기준 로짓 — logs\ppl_BF16.log(조각 수 50 · Final estimate 줄 · -lv 4 로 찍힌 offloaded … layers to GPU 줄) + base_wiki.kld 의 실제 바이트 수 + 절차 6 의 식으로 미리 계산한 예측 바이트 수와 견준 1줄 -->
c3: 
<!-- c4(필수): 바닥 — logs\kld_BF16.log(BF16 모델을 자기 기준 로짓에 견준 평균 KLD ± · 99.0% KLD · 1.0% KLD · 최솟값 · Same top p · offloaded … layers to GPU 줄이 ppl_BF16.log 와 같은지) + 바닥의 크기와 까닭 1줄(평균이 0.000000 으로 찍히면 '소수 여섯째 자리 아래'로 적고 1.0%~99.0% 폭을 함께) -->
c4: 
<!-- c5(필수): KLD 사다리 — logs\kld_<형식>.log 여섯 개 + results.csv 의 ppl_q · ln_ppl_ratio · ln_ppl_vs_bf16(BF16 행은 0) · kld_mean · kld_unc · kld_p99 · same_top_p_pct · above_floor · gpu_layers 열이 7행 모두 채워짐 -->
c5: 
<!-- c6(필수): 과제 정답률 — logs\wg_<형식>.log 일곱 개(BF16 포함 · 모두 Winogrande 1,267문제 전부) + results.csv 의 wg_acc_pct · wg_lo_pct · wg_hi_pct · flip_lost · flip_gained · mcnemar_z 열 -->
c6: 
<!-- c7(필수): quant_quality.png — 왼쪽 칸: 파일 크기(GiB) 대 평균 KLD(로그 눈금 · ± 막대 · BF16 바닥 점선 — 바닥이 0.000000 이면 점선 대신 '바닥 < 0.000001' 글) · 오른쪽 칸: 파일 크기 대 Winogrande 정답률(95% Wilson 구간 막대 · BF16 점선) + qq_report.py -->
c7: 
<!-- c8(필수): quant_quality_report.md — 첫 줄 lab_id 줄 · ## 작업 · ## 결과(사다리 표 · results.csv 표 · 그림) · ## 해석(아래 절차 11 의 다섯 물음에 표의 숫자를 넣어 한 문장씩 + 내가 고를 형식과 그 까닭) · ## 출처 표기 · ## 검증(c1: ~ c8: 로 시작하는 줄) 다섯 절 -->
c8: 
<!-- c9(선택): (선택) 한국어 글로 기준 로짓을 따로 만들어 Q4_K_M·Q2_K 의 평균 KLD 를 Wikitext 값과 나란히 놓은 2행 표 + 1문장 -->
c9: 
<!-- c10(선택): (선택) wiki.train.raw 로 만든 중요도 행렬(imatrix)로 Q3_K_M 을 다시 만들어 같은 base_wiki.kld 로 잰 평균 KLD 를 imatrix 없는 Q3_K_M 과 나란히 놓은 1행 + 평가 글과 보정 글을 왜 나눴는지 1문장 -->
c10: 
