# qq_report.py — logs 폴더의 로그와 models 폴더의 파일 크기를 읽어 results.csv 와 quant_quality.png 를 만든다
import csv
import math
import re
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # 창을 띄우지 않고 파일로만 그린다
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
MODELS, LOGS = ROOT / "models", ROOT / "logs"
PREFIX = "gemma-4-E2B-it-"
TYPES = ["BF16", "Q8_0", "Q6_K", "Q5_K_M", "Q4_K_M", "Q3_K_M", "Q2_K"]
NUM = r"(-?\d+(?:\.\d+)?)"
Z95 = 1.95996398454  # 95% 구간의 z — llama-perplexity 의 Wilson 구간 코드와 같은 값


def read(path):
    if not path.exists():
        sys.exit(f"없음: {path}")
    return path.read_text(encoding="utf-8", errors="replace")


def grab(text, label, with_unc=False):
    """'라벨 : 값 ± 불확실성' 줄에서 숫자를 읽는다(라벨은 정규식)."""
    pat = label + r"\s*:\s*" + NUM + (r"\s*±\s*" + NUM if with_unc else "")
    m = re.search(pat, text)
    if not m:
        sys.exit(f"못 찾음: {label}")
    vals = [float(v) for v in m.groups()]
    return vals if with_unc else vals[0]


def grab_re(text, pat, what):
    """정규식 pat 의 첫 묶음을 숫자로 읽는다(못 찾으면 무엇을 못 찾았는지 적고 멈춘다)."""
    m = re.search(pat, text)
    if not m:
        sys.exit(f"못 찾음: {what}")
    return float(m.group(1))


def winogrande(text):
    """과제마다 찍히는 줄(번호 · 누적 정답률 · 두 점수 · 고른 답 · 정답)에서 과제 번호와 맞음(1)/틀림(0)을 읽는다."""
    rows = re.findall(r"^(\d+)\t[\d.]+\t[ \t]*\S+[ \t]+\S+[ \t]+([12])[ \t]+([12])[ \t\r]*$", text, re.M)
    if not rows:
        sys.exit("Winogrande 결과 줄이 없음")
    final = re.search(r"Final Winogrande score\((\d+) tasks\)", text)
    if not final or int(final.group(1)) != len(rows):
        sys.exit("Winogrande 마지막 줄이 없거나 과제 수가 줄 수와 다름: 그 실행이 끝까지 돌았는지 본다")
    return [int(i) for i, _, _ in rows], [1 if got == ans else 0 for _, got, ans in rows]


def wilson(k, n):
    """맞힌 수 k · 문제 수 n 의 정답률과 95% Wilson 점수 구간(백분율)."""
    p, z2 = k / n, Z95 * Z95
    mid = (p + z2 / (2 * n)) / (1 + z2 / n)
    half = Z95 / (1 + z2 / n) * (p * (1 - p) / n + z2 / (4 * n * n)) ** 0.5
    return 100 * p, 100 * (mid - half), 100 * (mid + half)


def gpu_layers(text):
    """모델을 불러올 때 찍힌 'offloaded A/B layers to GPU' 의 마지막 값(없으면 '-')."""
    found = re.findall(r"offloaded (\d+/\d+) layers to GPU", text)
    return found[-1] if found else "-"


def embd_types(text):
    """양자화 로그에서 두 임베딩 표가 받은 형식을 읽는다(양자화하지 않았으면 원래 형식)."""
    found = {}
    for name, cur, new in re.findall(
        r"\]\s+(per_layer_token_embd|token_embd)\.weight\s+-\s+\[[^\]]*\], type =\s*(\w+), (?:converting to (\w+))?", text
    ):
        found[name] = new or cur
    return found.get("token_embd", "?"), found.get("per_layer_token_embd", "?")


# 이름표를 놓아 볼 자리(점에서 띄울 포인트 · 가로가 음수면 점 왼쪽) — 앞에서부터 맞는 첫 자리를 쓴다
LABEL_AT = [(6, 6), (-6, 6), (6, -16), (-6, -16), (6, 20), (-6, 20), (6, -30), (-6, -30), (6, 34), (-6, 34)]


def box_of(artist):
    """그린 것의 상자(화면 픽셀): (왼쪽, 아래, 오른쪽, 위)."""
    b = artist.get_window_extent()
    return b.x0, b.y0, b.x1, b.y1


def hits(a, b):
    """두 상자가 겹치는가."""
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def place_labels(ax, pts):
    """점마다 이름표를 놓되, 축 밖으로 나가거나 다른 이름표·점과 겹치면 다음 자리로 비켜 놓고 가는 선으로 점과 잇는다."""
    frame = box_of(ax)
    taken = []
    for _, x, y in pts:  # 점 자리(사방 5픽셀)도 비워 둔다
        px, py = ax.transData.transform((x, y))
        taken.append((px - 5, py - 5, px + 5, py + 5))
    for name, x, y in pts:
        for dx, dy in LABEL_AT:
            t = ax.annotate(name, (x, y), textcoords="offset points", xytext=(dx, dy), ha="left" if dx > 0 else "right")
            box = box_of(t)
            inside = frame[0] <= box[0] and box[2] <= frame[2] and frame[1] <= box[1] and box[3] <= frame[3]
            if inside and not any(hits(box, b) for b in taken):
                break
            t.remove()
        else:  # 맞는 자리가 없으면 첫 자리에 둔다
            dx, dy = LABEL_AT[0]
            t = ax.annotate(name, (x, y), textcoords="offset points", xytext=(dx, dy))
            box = box_of(t)
        if (dx, dy) != LABEL_AT[0]:  # 비켜 놓은 이름표는 가는 선으로 점과 잇는다
            t.remove()
            ax.annotate(name, (x, y), textcoords="offset points", xytext=(dx, dy), ha="left" if dx > 0 else "right",
                        arrowprops=dict(arrowstyle="-", color="gray", lw=0.6))
        taken.append(box)


rows = []
base_ids = base_right = base_kl = base_ppl = None
for t in TYPES:
    kld = read(LOGS / f"kld_{t}.log")
    ids, right = winogrande(read(LOGS / f"wg_{t}.log"))
    if t == "BF16":
        base_ids, base_right, emb = ids, right, ("bf16", "bf16")
    else:
        emb = embd_types(read(LOGS / f"quantize_{t}.log"))
    if ids != base_ids:
        sys.exit(f"{t}: 푼 과제가 BF16 과 다름: 같은 CSV 를 같은 인자로 다시 돌린다")
    size = (MODELS / f"{PREFIX}{t}.gguf").stat().st_size
    ppl_q, ppl_q_u = grab(kld, r"Mean PPL\(Q\)", True)
    lnr, lnr_u = grab(kld, r"Mean ln\(PPL\(Q\)/PPL\(base\)\)", True)
    kl, kl_u = grab(kld, r"Mean\s+KLD", True)
    top, top_u = grab(kld, r"Same top p", True)
    if t == "BF16":
        base_kl, base_ppl = (kl, kl_u), ppl_q
    # 이 실습의 판정 기준: (평균 − 2×불확실성)이 (바닥 + 2×바닥의 불확실성)보다 커야 '바닥과 구별됨'
    above = "-" if t == "BF16" else ("yes" if kl - 2 * kl_u > base_kl[0] + 2 * base_kl[1] else "no")
    acc, lo, hi = wilson(sum(right), len(right))
    lost = sum(1 for b, q in zip(base_right, right) if b == 1 and q == 0)
    gained = sum(1 for b, q in zip(base_right, right) if b == 0 and q == 1)
    rows.append({
        "type": t, "file_bytes": size, "file_gib": round(size / 2**30, 3),
        "bpw": grab_re(kld, r"file size\s*=\s*[\d.]+ [GM]iB \(([\d.]+) BPW\)",
                       f"kld_{t}.log 의 file size … BPW 줄(절차 6~8 의 명령 끝에 -lv 4 를 붙였는지 본다)"),
        "gpu_layers": gpu_layers(kld),
        "ppl_q": ppl_q, "ppl_q_unc": ppl_q_u, "ppl_base": grab(kld, r"Mean PPL\(base\)"),
        "ln_ppl_ratio": lnr, "ln_ppl_ratio_unc": lnr_u,
        # BF16 의 실제 PPL(BF16 행의 PPL(Q)) 에 견준 값 — 잘려 적힌 기준 파일의 PPL(base) 대신(절차 7)
        "ln_ppl_vs_bf16": round(math.log(ppl_q / base_ppl), 6),
        "kld_mean": kl, "kld_unc": kl_u, "kld_p99": grab(kld, r"99\.0%\s+KLD"),
        "kld_p01": grab(kld, r" 1\.0%\s+KLD"), "above_floor": above,
        "rms_dp_pct": grab(kld, r"RMS Δp"), "same_top_p_pct": top, "same_top_p_unc": top_u,
        "wg_tasks": len(right), "wg_acc_pct": round(acc, 2), "wg_lo_pct": round(lo, 2), "wg_hi_pct": round(hi, 2),
        "flip_lost": lost, "flip_gained": gained,
        # 맥니마 검정의 정규 근사: 한쪽만 맞힌 문제 수만 쓴다(양수 = BF16 보다 나빠진 쪽)
        "mcnemar_z": round((lost - gained) / (lost + gained) ** 0.5, 3) if lost + gained else 0.0,
        "token_embd": emb[0], "per_layer_token_embd": emb[1],
    })

ppl_log = read(LOGS / "ppl_BF16.log")
ppl_layers = gpu_layers(ppl_log)
no_layers = [r["type"] for r in rows if r["gpu_layers"] == "-"] + (["ppl_BF16"] if ppl_layers == "-" else [])
if no_layers:
    print(f"주의: offloaded … layers to GPU 줄이 없는 로그: {', '.join(no_layers)} — 절차 6~8 의 명령 끝에 -lv 4 를 붙였는지 본다")
if ppl_layers != rows[0]["gpu_layers"]:
    print(f"주의: GPU 층 배치가 기준 실행({ppl_layers})과 바닥 실행({rows[0]['gpu_layers']})에서 다름, 절차 6·7 을 다시 본다")
ppl_final = grab_re(ppl_log, r"Final estimate: PPL\s*=\s*" + NUM, "ppl_BF16.log 의 Final estimate 줄")
if abs(rows[0]["ppl_q"] / ppl_final - 1) > 1e-4:
    print(f"주의: BF16 행 ppl_q({rows[0]['ppl_q']})가 ppl_BF16.log 의 Final estimate({ppl_final})와 다름, 절차 6·7 을 같은 설정으로 돌렸는지 본다")

with open(ROOT / "results.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)

plt.rcParams["font.family"] = "Malgun Gothic"  # 한글 축 이름
plt.rcParams["axes.unicode_minus"] = False
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.8))
quant = [r for r in rows if r["type"] != "BF16"]
base = rows[0]

ax1.errorbar([r["file_gib"] for r in quant], [r["kld_mean"] for r in quant],
             yerr=[r["kld_unc"] for r in quant], fmt="o-", capsize=3)
if base["kld_mean"] > 0:
    ax1.axhline(base["kld_mean"], linestyle=":", color="gray", label="바닥: BF16 대 자기 기준 로짓")
    ax1.legend()
else:  # 로그가 0.000000 으로 찍은 바닥은 로그 눈금에 그릴 수 없어 글로 남긴다
    ax1.annotate("바닥(BF16 대 자기 기준) < 0.000001", (0.98, 0.97), xycoords="axes fraction", ha="right", va="top", color="gray")
ax1.set_yscale("log")
ax1.yaxis.set_major_formatter("{x:g}")  # 10의 거듭제곱 대신 0.001 꼴 눈금 글자
ax1.yaxis.set_minor_formatter("")
ax1.set_xlabel("파일 크기 (GiB)")
ax1.set_ylabel("평균 KL 발산 (BF16 기준 · 로그 눈금)")
ax1.set_title("파일 크기 대 평균 KLD (막대 = ± 불확실성)")

ax2.errorbar([r["file_gib"] for r in rows], [r["wg_acc_pct"] for r in rows],
             yerr=[[r["wg_acc_pct"] - r["wg_lo_pct"] for r in rows], [r["wg_hi_pct"] - r["wg_acc_pct"] for r in rows]],
             fmt="s", capsize=3)
ax2.axhline(base["wg_acc_pct"], linestyle=":", color="gray", label="BF16 정답률")
ax2.set_xlabel("파일 크기 (GiB)")
ax2.set_ylabel(f"Winogrande 정답률 (%, 과제 {base['wg_tasks']}개)")
ax2.set_title("파일 크기 대 과제 정답률 (막대 = 95% Wilson 구간)")

fig.draw_without_rendering()  # 축 범위를 정해 둔 뒤에 이름표 상자의 크기를 잰다
place_labels(ax1, [(r["type"], r["file_gib"], r["kld_mean"]) for r in quant])
place_labels(ax2, [(r["type"], r["file_gib"], r["wg_acc_pct"]) for r in rows])
ax2.legend()

fig.savefig(ROOT / "quant_quality.png", dpi=150, bbox_inches="tight")
print(f"results.csv {len(rows)}행 · quant_quality.png 저장")
for r in rows:
    print(f"{r['type']:7s} {r['file_gib']:6.2f}GiB  ln(PPL/BF16) {r['ln_ppl_vs_bf16']:+.4f}  KLD {r['kld_mean']:.6f} (바닥 위 {r['above_floor']})  "
          f"top {r['same_top_p_pct']:.2f}%  WG {r['wg_acc_pct']:.2f}% [{r['wg_lo_pct']:.2f}, {r['wg_hi_pct']:.2f}]  "
          f"잃음 {r['flip_lost']} 얻음 {r['flip_gained']} z {r['mcnemar_z']:+.2f}  GPU 층 {r['gpu_layers']}")
