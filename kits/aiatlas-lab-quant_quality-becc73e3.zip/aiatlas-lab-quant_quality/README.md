# 양자화가 깎는 품질 재기 — BF16 기준과 여섯 양자화 단계의 KL 발산·퍼플렉서티·과제 정답률

AI 아틀라스 앱의 실습 `lab.c.lab.quant_quality`(L4 · 약 6시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\work\quant_quality\quant_quality_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 폴더에 env.md + results.csv + quant_quality.png + qq_report.py + logs 폴더(dryrun_* · quantize_* · ppl_BF16 · kld_* · wg_*) · 모델 파일과 base_wiki.kld 는 크니 제출하지 않는다.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — llama.cpp 의 CUDA 12.4 판을 쓴다. CUDA 드라이버는 하위 호환이라 12.x 를 지원하는 드라이버면 돈다(S3443). GPU 가 없으면 같은 빌드의 cpu-x64 zip 으로 돈다 — 절차 2 에서 llama.cpp zip 이름만 cpu-x64 판으로 바꾸고 cudart zip 줄은 건너뛰며, 푼 폴더를 $B 로 둔다(S6425). 걸린 시간은 직접 재어 적는다 — 이 과정이 기준 PC(RTX 4070 Ti 12GB · i7-14700KF · 받기 초당 약 80MB)에서 2026-11 에 재어 보니 필수 1~10단계의 받기와 계산을 모두 합쳐 8분 남짓(받기 약 2분 반 포함)이었다. GPU·CPU·인터넷 속도가 다르면 이 시간도 달라진다 — 같은 PC 에서 GPU 에 층을 올리지 않고(-ngl 0) 돌린 절차 7 한 번은 GPU 때의 3배쯤(37초 대 11초)이었다. 이 실습에 드는 시간의 대부분은 계산이 아니라 본문 읽기·해석·보고서 쓰기다
- 디스크 여유 50GB 이상 — BF16 원본 9.3GB(S6426) + 양자화 파일 여섯 개(가장 큰 Q8_0 도 원본의 절반쯤 · 정확한 합은 절차 4 의 --dry-run 으로 먼저 계산) + 기준 로짓 파일 약 6.2GiB(50조각 · 절차 6 의 식)
- RAM 16GB 이상 — llama.cpp 양자화 문서는 양자화할 때 모델을 통째로 메모리에 올린다고 적는다(S51)
- 인터넷 — 모델 9.3GB · llama.cpp zip 두 개 · 데이터 파일 두 개를 처음 한 번 받는다. 계정·토큰은 필요 없다(저장소 gated false · S6426)
- Python 3.11 이상 — 앞 실습에서 측정 스크립트를 돌린 그 PC. 이 실습 폴더에 가상환경을 따로 만들고 matplotlib==3.11.2 를 넣는다(S6434)
- 앞 실습 [실습] 추론 최적화 실험 + 벤치 리포트를 마쳤을 것 — 같은 양자화 이름(Q4_K_M·Q8_0)으로 속도·메모리를 재 본 경험이 이 실습의 출발점이다(GPU 로 했다면 nvidia-smi 사용법도)
- 양자화 레슨의 K-양자화 이름 읽기(Q4_K_M 의 숫자·K·M)와 교차 엔트로피 레슨의 KL 발산·퍼플렉서티 정의를 안다

## 들어 있는 파일
- `files/qq_report.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.quant_quality` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
