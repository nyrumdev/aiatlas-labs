# 양자화가 깎는 품질 재기 — BF16 기준과 여섯 양자화 단계의 KL 발산·퍼플렉서티·과제 정답률 — 명령·코드 모음

실습 id: `lab.c.lab.quant_quality`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대

```powershell
New-Item -ItemType Directory -Force C:\work\quant_quality\models, C:\work\quant_quality\data, C:\work\quant_quality\logs | Out-Null
Set-Location C:\work\quant_quality
Get-PSDrive C | Select-Object Used, Free
nvidia-smi
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama stop <태그>` — Ollama 가 모델을 올려 둔 상태라면 앞 실습처럼 `ollama stop <태그>` 로 내려 GPU 메모리를 비운다.

## 2. llama.cpp 빌드 고정

```powershell
$BUILD = "b11696"
$REL = "https://github.com/ggml-org/llama.cpp/releases/download/$BUILD"
curl.exe -L -o llama-cuda.zip "$REL/llama-$BUILD-bin-win-cuda-12.4-x64.zip"
curl.exe -L -o cudart.zip "$REL/cudart-llama-bin-win-cuda-12.4-x64.zip"
Expand-Archive llama-cuda.zip -DestinationPath C:\work\llama-bin-cuda -Force
Expand-Archive cudart.zip -DestinationPath C:\work\llama-bin-cuda -Force
$B = "C:\work\llama-bin-cuda"
& "$B\llama-perplexity.exe" --version
```

## 3. 모델과 데이터 받기

```powershell
$REV = "b4243c156154b6dca9324415f8c7ccc098b4aed1"
curl.exe -L -C - -o models\gemma-4-E2B-it-BF16.gguf "https://huggingface.co/ggml-org/gemma-4-E2B-it-GGUF/resolve/$REV/gemma-4-E2B-it-BF16.gguf"
(Get-FileHash models\gemma-4-E2B-it-BF16.gguf -Algorithm SHA256).Hash -eq "246c5fb19e64b941b531e86639f070bc67b00f20e9ec8556a6c02653321bc65d"
curl.exe -L -o data\wikitext-2-raw-v1.zip "https://huggingface.co/datasets/ggml-org/ci/resolve/main/wikitext-2-raw-v1.zip"
(Get-FileHash data\wikitext-2-raw-v1.zip -Algorithm SHA256).Hash -eq "ef7edb566e3e2b2d31b29c1fdb0c89a4cc683597484c3dc2517919c615435a11"
Expand-Archive data\wikitext-2-raw-v1.zip -DestinationPath data -Force
curl.exe -L -o data\winogrande-debiased-eval.csv "https://huggingface.co/datasets/ikawrakow/winogrande-eval-for-llama.cpp/resolve/93f7fb0697ca6cd2c7e5727dcba3b7200fa4014c/winogrande-debiased-eval.csv"
(Get-FileHash data\winogrande-debiased-eval.csv -Algorithm SHA256).Hash -eq "6726173ef65ffdc4abb0d28b755375d288ffb3eb41633bd833288c411c8ebf7c"
```

## 4. 사다리 만들기

```powershell
$BF16 = "models\gemma-4-E2B-it-BF16.gguf"
$TYPES = "Q8_0", "Q6_K", "Q5_K_M", "Q4_K_M", "Q3_K_M", "Q2_K"
foreach ($t in $TYPES) {
    cmd /c "$B\llama-quantize.exe --dry-run $BF16 $t > logs\dryrun_$t.log 2>&1"
    Select-String -Path "logs\dryrun_$t.log" -Pattern "quant size"
}
```

```powershell
foreach ($t in $TYPES) {
    cmd /c "$B\llama-quantize.exe $BF16 models\gemma-4-E2B-it-$t.gguf $t > logs\quantize_$t.log 2>&1"
    Get-Item "models\gemma-4-E2B-it-$t.gguf" | Select-Object Name, Length
}
```

## 5. 사다리 표

```powershell
foreach ($t in $TYPES) {
    "== $t"
    Select-String -Path "logs\quantize_$t.log" -Pattern "quant size", "token_embd.weight"
}
```

## 6. 기준 로짓 만들기

```powershell
& "$B\llama-perplexity.exe" -m $BF16 -f data\wikitext-2-raw\wiki.test.raw --chunks 50 --kl-divergence-base base_wiki.kld --log-file logs\ppl_BF16.log -lv 4
(Get-Item base_wiki.kld).Length
Select-String -Path logs\ppl_BF16.log -Pattern "Final estimate", "computing over|calculating perplexity over", "offloaded"
```

## 7. 바닥 재기

```powershell
& "$B\llama-perplexity.exe" -m $BF16 --kl-divergence-base base_wiki.kld --kl-divergence --log-file logs\kld_BF16.log -lv 4
Select-String -Path logs\kld_BF16.log -Pattern "Mean\s+KLD", "99.0%\s+KLD", " 1.0%\s+KLD", "Minimum KLD", "Same top p", "offloaded"
```

## 8. KLD 사다리

```powershell
foreach ($t in $TYPES) {
    & "$B\llama-perplexity.exe" -m "models\gemma-4-E2B-it-$t.gguf" --kl-divergence-base base_wiki.kld --kl-divergence --log-file "logs\kld_$t.log" -lv 4
}
```

## 9. 과제 정답률

```powershell
foreach ($t in @("BF16") + $TYPES) {
    & "$B\llama-perplexity.exe" -m "models\gemma-4-E2B-it-$t.gguf" -f data\winogrande-debiased-eval.csv --winogrande --log-file "logs\wg_$t.log"
    Select-String -Path "logs\wg_$t.log" -Pattern "loaded .* tasks", "Final Winogrande score"
}
```

## 10. 집계와 그림

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install matplotlib==3.11.2
.\.venv\Scripts\python.exe --version
.\.venv\Scripts\python.exe qq_report.py
```

- `files/qq_report.py` — 키트에 들어 있음 (python)

## 13. (선택) 한국어 글로 다시

```powershell
& "$B\llama-perplexity.exe" -m $BF16 -f data\ko_text.txt --chunks 50 --kl-divergence-base base_ko.kld --log-file logs\ppl_BF16_ko.log -lv 4
foreach ($t in "Q4_K_M", "Q2_K") {
    & "$B\llama-perplexity.exe" -m "models\gemma-4-E2B-it-$t.gguf" --kl-divergence-base base_ko.kld --kl-divergence --log-file "logs\kld_ko_$t.log" -lv 4
}
```

## 14. (선택) 중요도 행렬로 다시

```powershell
& "$B\llama-imatrix.exe" -m $BF16 -f data\wikitext-2-raw\wiki.train.raw --chunks 100 -o imatrix_wiki.gguf --log-file logs\imatrix.log
cmd /c "$B\llama-quantize.exe --imatrix imatrix_wiki.gguf $BF16 models\gemma-4-E2B-it-Q3_K_M-imat.gguf Q3_K_M > logs\quantize_Q3_K_M-imat.log 2>&1"
& "$B\llama-perplexity.exe" -m models\gemma-4-E2B-it-Q3_K_M-imat.gguf --kl-divergence-base base_wiki.kld --kl-divergence --log-file logs\kld_Q3_K_M-imat.log -lv 4
```

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Select-String … "offloaded"` — `못 찾음: kld_… 의 file size … BPW 줄` 로 멈춤, 또는 `Select-String … "offloaded"` 가 아무것도 찍지 않음 → 절차 6·7·8 의 llama-perplexity 줄 끝에 `-lv 4` 를 빠뜨렸다.
