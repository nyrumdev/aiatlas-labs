"""test_engine.py — 내 엔진의 기울기를 중심 차분과 견준다. 실행: python -m pytest -v"""
from engine import Value

H = 1e-5      # 중심 차분에서 미는 크기
TOL = 1e-6    # 상대 오차 허용치


def rel_error(a, b):
    denom = max(abs(a), abs(b))
    return 0.0 if denom == 0 else abs(a - b) / denom


def check(fn, inputs):
    """fn 은 Value 목록을 받아 Value 하나를 돌려준다. 입력마다 엔진 기울기와 중심 차분을 견준다."""
    vals = [Value(x) for x in inputs]
    fn(vals).backward()
    for i, v in enumerate(vals):
        plus, minus = list(inputs), list(inputs)
        plus[i] += H
        minus[i] -= H
        up = fn([Value(x) for x in plus]).data
        down = fn([Value(x) for x in minus]).data
        num = (up - down) / (2 * H)
        err = rel_error(v.grad, num)
        assert err < TOL, f"입력 {i}: 엔진 {v.grad} · 중심 차분 {num} · 상대 오차 {err:.2e}"


def test_add_mul():
    check(lambda v: v[0] * v[1] + v[1] * v[2], [2.0, -3.0, 0.5])


def test_pow_tanh_sub():
    check(lambda v: (v[0] * v[1] - 1).tanh() ** 2 + v[0] ** 3, [0.3, -0.7])


def test_reused_node():
    check(lambda v: v[0] * v[0] + v[0], [3.0])        # 같은 노드 a 를 세 자리에서 쓴다
