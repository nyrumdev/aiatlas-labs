"""reuse_demo.py — 같은 노드를 여러 번 쓰는 식에서 '더하는 엔진'과 '덮어쓰는 엔진'의 기울기를 견준다."""
import engine
import engine_overwrite

H = 1e-5
CASES = [
    ("b = a + a", lambda a: a + a),
    ("y = a*a + a", lambda a: a * a + a),
]

for title, f in CASES:
    numeric = (f(3.0 + H) - f(3.0 - H)) / (2 * H)   # 숫자만으로 잰 기울기
    print(f"{title}  (a = 3)  중심 차분 {numeric:.6f}")
    for name, mod in [("engine(+=)", engine), ("engine_overwrite(=)", engine_overwrite)]:
        a = mod.Value(3.0)
        f(a).backward()
        print(f"    {name:22s} a.grad = {a.grad}")
