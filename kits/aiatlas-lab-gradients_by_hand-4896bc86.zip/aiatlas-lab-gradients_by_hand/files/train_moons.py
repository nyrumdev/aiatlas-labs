"""train_moons.py — 내 엔진으로 만든 MLP 로 make_moons 점을 학습하고, 예측을 산점도로 그린다.

실행: python train_moons.py
만드는 파일: train_log.txt · ../moons_pred.png
"""
import random
import time

import matplotlib.pyplot as plt
from sklearn.datasets import make_moons

from nn import MLP

SEED = 0
N_POINTS = 100
HIDDEN = [16, 16]      # 은닉층 둘, 각 16개 뉴런
LR = 0.1
STEPS = 100
GRID = 30              # 예측 배경을 칠할 격자 한 변의 칸 수

random.seed(SEED)      # 가중치 첫 값(random.uniform)을 매번 같게
X, y = make_moons(n_samples=N_POINTS, noise=0.1, random_state=SEED)
xs = X.tolist()        # NumPy 배열을 파이썬 리스트로 바꿔 쓴다(이후로는 리스트만)
ys = [1.0 if label == 1 else -1.0 for label in y.tolist()]   # tanh 출력에 맞춰 −1·+1

model = MLP(2, HIDDEN + [1])
params = model.parameters()
print("파라미터", len(params), "개")

log_lines = []
start = time.perf_counter()
for step in range(STEPS):
    preds = [model(x) for x in xs]
    loss = sum((p - t) ** 2 for p, t in zip(preds, ys)) * (1.0 / len(xs))
    acc = sum((p.data > 0) == (t > 0) for p, t in zip(preds, ys)) / len(xs)

    for p in params:
        p.grad = 0.0   # 지난 걸음의 기울기를 비운다 — 엔진이 += 로 더하므로 안 비우면 쌓인다
    loss.backward()
    for p in params:
        p.data -= LR * p.grad

    line = f"step {step:3d}  loss {loss.data:.4f}  acc {acc:.2f}"
    log_lines.append(line)
    if step % 10 == 0 or step == STEPS - 1:
        print(line)
elapsed = time.perf_counter() - start
log_lines.append(f"seconds {elapsed:.1f}")
with open("train_log.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(log_lines) + "\n")

# 예측 그림 — 바탕은 격자 점마다 모델의 판정, 위에 학습 점(○ 맞힘 · × 틀림)
x_min, x_max = min(p[0] for p in xs) - 0.5, max(p[0] for p in xs) + 0.5
y_min, y_max = min(p[1] for p in xs) - 0.5, max(p[1] for p in xs) + 0.5
gx, gy, gc = [], [], []
for i in range(GRID):
    for j in range(GRID):
        a = x_min + (x_max - x_min) * i / (GRID - 1)
        b = y_min + (y_max - y_min) * j / (GRID - 1)
        gx.append(a)
        gy.append(b)
        gc.append("tab:orange" if model([a, b]).data > 0 else "tab:blue")

right = ([], [], [])     # 맞힌 점의 x · y · 색
wrong = ([], [], [])     # 틀린 점의 x · y · 색
for (px, py), t in zip(xs, ys):
    hit = (model([px, py]).data > 0) == (t > 0)
    bucket = right if hit else wrong
    bucket[0].append(px)
    bucket[1].append(py)
    bucket[2].append("tab:orange" if t > 0 else "tab:blue")

fig, ax = plt.subplots(figsize=(5, 4))
ax.scatter(gx, gy, c=gc, s=12, alpha=0.15, marker="s")
ax.scatter(right[0], right[1], c=right[2], s=25, marker="o")
if wrong[0]:
    ax.scatter(wrong[0], wrong[1], c=wrong[2], s=60, marker="x")
ax.set_title(f"MLP(2, {HIDDEN + [1]}) after {STEPS} steps")
fig.savefig("../moons_pred.png", dpi=120, bbox_inches="tight")
print("저장: train_log.txt · ../moons_pred.png")
