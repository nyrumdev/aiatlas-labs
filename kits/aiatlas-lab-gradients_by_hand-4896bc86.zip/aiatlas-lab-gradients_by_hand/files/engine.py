"""engine.py — 숫자 하나를 담는 Value 와, 위상정렬로 줄 세워 뒤에서 앞으로 도는 backward()."""
import math


class Value:
    def __init__(self, data, children=(), op=""):
        self.data = float(data)        # 순전파 값
        self.grad = 0.0                # 출력이 이 값에 얼마나 민감한가(역전파가 채운다)
        self._backward = lambda: None  # 잎(입력·파라미터)은 뒤로 넘길 곳이 없다
        self._prev = set(children)     # 이 값을 만든 재료들
        self._op = op

    def __repr__(self):
        return f"Value(data={self.data:.6g}, grad={self.grad:.6g})"

    def __add__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data + other.data, (self, other), "+")

        def _backward():
            self.grad += out.grad              # 더하기의 국소 기울기는 1
            other.grad += out.grad
        out._backward = _backward
        return out

    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other), "*")

        def _backward():
            pass  # 8단계에서 직접 쓴다 — self.grad 와 other.grad 에 각각 '국소 기울기 × out.grad' 를 += 로 더한다
        out._backward = _backward
        return out

    def __pow__(self, k):
        assert isinstance(k, (int, float)), "지수는 상수만 받는다"
        out = Value(self.data ** k, (self,), f"**{k}")

        def _backward():
            self.grad += k * self.data ** (k - 1) * out.grad
        out._backward = _backward
        return out

    def tanh(self):
        t = math.tanh(self.data)
        out = Value(t, (self,), "tanh")

        def _backward():
            pass  # 8단계에서 직접 쓴다 — self.grad 에 '국소 기울기 × out.grad' 를 += 로 더한다(t 를 쓴다)
        out._backward = _backward
        return out

    def backward(self):
        topo, visited = [], set()

        def build(v):
            if v not in visited:
                visited.add(v)
                for child in v._prev:
                    build(child)
                topo.append(v)             # 재료가 모두 들어간 뒤에 나를 넣는다
        build(self)
        self.grad = 1.0                    # 출력이 출력에 주는 영향은 1
        for v in reversed(topo):           # 출력 쪽에서 입력 쪽으로
            v._backward()

    # 아래는 위 연산을 조합해 만든다 — 새 _backward 가 필요 없다
    def __neg__(self):
        return self * -1

    def __sub__(self, other):
        return self + (-other)

    def __rsub__(self, other):             # 숫자 − Value
        return other + (-self)

    def __radd__(self, other):             # 숫자 + Value (sum() 의 첫 0 + Value 도 여기로 온다)
        return self + other

    def __rmul__(self, other):             # 숫자 × Value
        return self * other
