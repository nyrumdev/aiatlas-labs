"""logreg_by_hand.py — 리스트와 반복문만으로 로지스틱 회귀의 손실·기울기·경사하강을 쓴다(NumPy 없음).

실행: python logreg_by_hand.py
만드는 파일: gradcheck_table.md · lr_sweep.json · lr_sweep.png
"""
import json
import math
import random
import sys

import matplotlib.pyplot as plt

SEED = 0
N_PER_CLASS = 20                   # 부류마다 점 20개 → 모두 40개
CENTERS = [(1.0, 1.0), (2.0, 2.0)] # 부류 0 과 부류 1 의 가운데(두 부류가 꽤 겹친다)
LEARNING_RATES = [0.1, 1.0, 3.0, 10.0]
STEPS = 100
TAIL = 20                          # 끝 몇 걸음을 보고 '끝내 내려오지 못했다'를 판정하나
H = 1e-5                           # 중심 차분에서 파라미터를 미는 크기
BURN_IN = 10                       # 기울기 검사 전에 걷는 걸음 수
H_SWEEP = [1e-1, 1e-3, 1e-5, 1e-7, 1e-9, 1e-11]
NAMES = ["w1", "w2", "b"]


def make_points(n_per_class=N_PER_CLASS, seed=SEED):
    """부류마다 가운데 둘레에 점을 흩뿌린다. 같은 seed 면 같은 점이 나온다."""
    rng = random.Random(seed)
    xs, ys = [], []
    for label, (cx, cy) in enumerate(CENTERS):
        for _ in range(n_per_class):
            xs.append([rng.gauss(cx, 1.0), rng.gauss(cy, 1.0)])
            ys.append(label)
    return xs, ys


def sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)                # z 가 아주 작아도 exp 가 넘치지 않게 나눠 쓴다
    return e / (1.0 + e)


def softplus(z):
    """log(1 + e^z) 를 넘침 없이 계산한다."""
    return max(z, 0.0) + math.log1p(math.exp(-abs(z)))


def weighted_sum(params, x):
    w1, w2, b = params
    return w1 * x[0] + w2 * x[1] + b


def loss(params, xs, ys):
    """평균 교차 엔트로피. 점 하나의 −[y·log p + (1−y)·log(1−p)] 는 softplus(z) − y·z 와 같다."""
    total = 0.0
    for x, y in zip(xs, ys):
        z = weighted_sum(params, x)
        total += softplus(z) - y * z
    return total / len(xs)


def grad(params, xs, ys):
    """해석 기울기 — 4단계에서 직접 채운다. 채우기 전에는 [0, 0, 0] 을 돌려준다."""
    g = [0.0, 0.0, 0.0]          # w1 · w2 · b 의 기울기를 모을 칸
    for x, y in zip(xs, ys):
        p = sigmoid(weighted_sum(params, x))
        # 여기를 채운다 — 이 점의 (p − y) 에 각 입력을 곱해 g[0]·g[1]·g[2] 에 더한다(편향의 입력은 1)
    return [gi / len(xs) for gi in g]


def numeric_grad(params, xs, ys, i, h=H, centered=True):
    """파라미터 i 하나만 밀어 손실이 변한 비율을 잰다."""
    plus = list(params)
    plus[i] += h
    if not centered:               # 한쪽 차분: (L(p+h) − L(p)) / h
        return (loss(plus, xs, ys) - loss(params, xs, ys)) / h
    minus = list(params)
    minus[i] -= h
    return (loss(plus, xs, ys) - loss(minus, xs, ys)) / (2 * h)


def rel_error(a, b):
    """상대 오차 |a − b| / max(|a|, |b|) — 둘 다 0 이면 0."""
    denom = max(abs(a), abs(b))
    return 0.0 if denom == 0 else abs(a - b) / denom


def train(lr, steps, xs, ys):
    """가중치 0 에서 출발해 전체 점으로 steps 걸음 걷고, 걸음마다 손실을 남긴다."""
    params = [0.0, 0.0, 0.0]
    history = [loss(params, xs, ys)]
    for _ in range(steps):
        g = grad(params, xs, ys)
        params = [p - lr * gi for p, gi in zip(params, g)]
        history.append(loss(params, xs, ys))
    return params, history


def main():
    xs, ys = make_points()
    print("python", sys.version.split()[0], "· 점", len(xs), "개")

    # 1) 가중치 0 에서 첫 손실 — 모든 점에 확률 0.5 를 주므로 −ln(0.5) 여야 한다
    first = loss([0.0, 0.0, 0.0], xs, ys)
    expected = -math.log(0.5)
    print(f"첫 손실 {first:.6f} · -ln(0.5) = {expected:.6f}")
    assert math.isclose(first, expected), "첫 손실이 -ln(0.5) 와 다르다 — loss() 를 다시 본다"

    # 2) 기울기 검사 — 몇 걸음 걸은 자리(가중치 0 이 아닌 곳)에서 해석 기울기와 중심 차분을 견준다.
    #    그 자리까지는 grad() 가 아니라 수치 기울기로 걷는다 — grad() 가 틀려도 검사 자리는 같다
    params = [0.0, 0.0, 0.0]
    for _ in range(BURN_IN):
        g = [numeric_grad(params, xs, ys, i) for i in range(len(params))]
        params = [p - LEARNING_RATES[0] * gi for p, gi in zip(params, g)]
    analytic = grad(params, xs, ys)
    lines = ["| 파라미터 | 해석 기울기 | 중심 차분(h=1e-5) | 상대 오차 |", "|---|---|---|---|"]
    for i, name in enumerate(NAMES):
        num = numeric_grad(params, xs, ys, i)
        lines.append(f"| {name} | {analytic[i]:.10f} | {num:.10f} | {rel_error(analytic[i], num):.2e} |")
    lines += ["", "| h | 중심 차분 상대 오차(w1) | 한쪽 차분 상대 오차(w1) |", "|---|---|---|"]
    for h in H_SWEEP:
        c = rel_error(analytic[0], numeric_grad(params, xs, ys, 0, h, centered=True))
        o = rel_error(analytic[0], numeric_grad(params, xs, ys, 0, h, centered=False))
        lines.append(f"| {h:.0e} | {c:.2e} | {o:.2e} |")
    table = "\n".join(lines) + "\n"
    with open("gradcheck_table.md", "w", encoding="utf-8") as f:
        f.write(table)
    print(table)

    # 3) 학습률 네 개 — 같은 출발점·같은 걸음 수로 손실 곡선을 남긴다
    histories = {}
    for lr in LEARNING_RATES:
        _, hist = train(lr, STEPS, xs, ys)
        histories[str(lr)] = hist
        jumps = [t for t, value in enumerate(hist) if value > hist[0]]
        stuck = all(value > hist[0] for value in hist[-TAIL:])
        print(f"lr={lr}: 끝 손실 {hist[-1]:.4f} · 최대 {max(hist):.4f} · "
              f"첫 손실보다 커진 걸음 {jumps[:5]}{' …' if len(jumps) > 5 else ''} · "
              f"끝 {TAIL}걸음이 모두 첫 손실보다 큼 {stuck}")
    with open("lr_sweep.json", "w", encoding="utf-8") as f:
        json.dump(histories, f, indent=1)

    fig, ax = plt.subplots(figsize=(6, 4))
    for lr, hist in histories.items():
        ax.plot(hist, label=f"lr={lr}")
    ax.axhline(expected, color="gray", linestyle=":", label="-ln(0.5)")
    ax.set_yscale("log")           # 큰 튐과 작은 차이를 한 그림에 보이게
    ax.set_xlabel("step")
    ax.set_ylabel("mean cross-entropy")
    ax.legend()
    fig.savefig("lr_sweep.png", dpi=120, bbox_inches="tight")
    print("저장: gradcheck_table.md · lr_sweep.json · lr_sweep.png")


if __name__ == "__main__":
    main()
