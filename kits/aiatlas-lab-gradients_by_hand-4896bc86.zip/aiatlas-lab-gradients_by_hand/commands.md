# 기울기를 손으로 — 순수 파이썬 경사하강·기울기 검사에서 작은 자동미분 엔진(micrograd)까지 — 명령·코드 모음

실습 id: `lab.c.lab.gradients_by_hand`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 준비 — 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)의 저장소에서 가상환경을 켜고 pytest 를 더 넣는다. pytest 는 파이썬 …

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install pytest
python -m pytest --version
python -c "import sys, matplotlib, sklearn; print(sys.version); print(matplotlib.__version__, sklearn.__version__)"
mkdir gradients_by_hand\autograd
cd gradients_by_hand
```

## 2. A부 코드 — 아래를 `logreg_by_hand.py` 로 저장한다. 점 40개를 만들고, 손실·기울기·기울기 검사·학습을 함수 하나씩으로 나눴다. 실행은 맨 아래 `if __name__ == …

- `files/logreg_by_hand.py` — 키트에 들어 있음 (python)

## 3. 실행과 첫 손실 — `python logreg_by_hand.py` 를 친다. 맨 위에 '첫 손실'과 -ln(0.5) 가 나란히 찍힌다. 가중치와 편향이 모두 0 이면 모든 점에서 z = 0 이고 p = …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python logreg_by_hand.py`

## 4. 기울기 직접 쓰기 — `grad()` 의 '여기를 채운다' 주석 자리에 내가 코드를 쓴다. 앞 노드 로지스틱 회귀에서 본 대로 가중치 하나의 기울기는 (p − y) × 그 입력이고, 편향은 입력을 1 로 보아 …

```python
def grad(params, xs, ys):
    """해석 기울기 — 점마다 (p − y)·입력 을 더해 점 개수로 나눈다. 편향의 입력은 1 로 본다."""
    g = [0.0, 0.0, 0.0]          # w1 · w2 · b 의 기울기를 모을 칸
    for x, y in zip(xs, ys):
        p = sigmoid(weighted_sum(params, x))
        err = p - y
        g[0] += err * x[0]
        g[1] += err * x[1]
        g[2] += err
    return [gi / len(xs) for gi in g]
```

## 7. B부 엔진 — 이제 기울기 식을 손으로 쓰지 않는다. 엔진이 아는 것은 연산 하나하나의 국소 기울기뿐이다. 국소 기울기는 그 연산 하나만 떼어 볼 때 입력을 조금 밀면 출력이 몇 배로 움직이는지다. 앞 노드 …

- `files/engine.py` — 키트에 들어 있음 (python)

## 8. 직접 쓰고 시험으로 판정 — 먼저 아래를 `autograd\test_engine.py` 로 저장한다. pytest 는 `test_` 로 시작하는 파일에서 `test_` 로 시작하는 함수를 모아 돌리고 …

- `files/test_engine.py` — 키트에 들어 있음 (python)

```powershell
cd autograd
python -m pytest -v
$LASTEXITCODE
```

```python
    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other), "*")

        def _backward():
            self.grad += other.data * out.grad  # 곱하기의 국소 기울기는 상대편 값
            other.grad += self.data * out.grad
        out._backward = _backward
        return out

    def tanh(self):
        t = math.tanh(self.data)
        out = Value(t, (self,), "tanh")

        def _backward():
            self.grad += (1 - t ** 2) * out.grad   # tanh 의 도함수 = 1 − tanh²
        out._backward = _backward
        return out
```

## 9. 덮어쓰기 실패 재현 — 모든 `_backward` 가 `=` 가 아니라 `+=` 로 기울기를 쌓는다. 앞 노드 역전파의 '길이 갈라지면 길마다의 곱을 더한다'가 이 한 글자다. 같은 값이 식의 여러 자리에서 …

- `files/reuse_demo.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Copy-Item engine.py engine_overwrite.py`
- `python reuse_demo.py`

## 10. MLP — 아래를 `autograd\nn.py` 로 저장한다. 뉴런은 입력마다 가중치를 곱해 더하고 편향을 얹은 뒤 tanh 를 씌운다. 층은 같은 입력을 받는 뉴런의 목록이고, MLP 는 층을 이어 붙인 …

- `files/nn.py` — 키트에 들어 있음 (python)

## 11. MLP 시험 더하기와 기록 — test_engine.py 맨 아래에 다음 시험을 더한다. MLP 의 파라미터 하나하나를 밀어 보며 엔진 기울기와 견준다. CS231n 은 기울기 검사에 데이터 점 2~3개면 …

```python
def test_mlp_parameters():
    import random                 # nn.py 를 만든 뒤에 더하는 시험이라 import 를 함수 안에 둔다
    from nn import MLP

    random.seed(1)
    model = MLP(2, [4, 4, 1])
    xs = [[0.5, -1.0], [1.5, 0.3], [-0.2, 0.8]]
    ys = [1.0, -1.0, 1.0]

    def total_loss():
        return sum((model(x) - y) ** 2 for x, y in zip(xs, ys))

    total_loss().backward()
    for k, p in enumerate(model.parameters()):
        old = p.data
        p.data = old + H
        up = total_loss().data
        p.data = old - H
        down = total_loss().data
        p.data = old
        num = (up - down) / (2 * H)
        err = rel_error(p.grad, num)
        assert err < TOL, f"파라미터 {k}: 엔진 {p.grad} · 중심 차분 {num} · 상대 오차 {err:.2e}"
```

```powershell
python -m pytest -v
$LASTEXITCODE
python -m pytest -v | Out-File -Encoding utf8 test_log.txt
```

## 12. 반달 점 학습 — 아래를 `autograd\train_moons.py` 로 저장하고 `python train_moons.py` 로 실행한다. make_moons 는 서로 맞물린 반원 두 개를 만든다. 점 …

- `files/train_moons.py` — 키트에 들어 있음 (python)

## 13. 판 기록과 커밋 — 저장소 맨 위로 돌아가 앞 실습과 같은 방법으로 판을 다시 적는다.

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
Add-Content .gitignore ".pytest_cache/"
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git add .`
- `git commit -m "기울기를 손으로 — 로지스틱 회귀와 자동미분 엔진"`
- `git rev-parse HEAD`
- `git status`

## 15. (선택) 꺾인 점 — autograd 폴더로 돌아가(`cd C:\work\ai-lab\gradients_by_hand\autograd`) engine.py 의 tanh 아래에 relu 를 더한다. 국소 …

```python
    def relu(self):
        out = Value(self.data if self.data > 0 else 0.0, (self,), "relu")

        def _backward():
            self.grad += (1.0 if self.data > 0 else 0.0) * out.grad
        out._backward = _backward
        return out
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `cd C:\work\ai-lab\gradients_by_hand\autograd`
- `python -m pytest -v`

## 16. (선택) 기울기 비우기 빼기 — autograd 폴더로 돌아가(`cd C:\work\ai-lab\gradients_by_hand\autograd`) train_moons.py 의 `p.grad = 0.0` …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `cd C:\work\ai-lab\gradients_by_hand\autograd`
- `python train_moons.py`
- `Get-ChildItem train_log*.txt, ..\moons_pred*.png`

## 검증(자가)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python -m pytest --version`
- `Compare-Object (Get-Content -Encoding UTF8 autograd\engine.py) (Get-Content -Encoding UTF8 autograd\engine_overwrite.py)`
- `git log --oneline`
- `git ls-files`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Get-ChildItem autograd`
