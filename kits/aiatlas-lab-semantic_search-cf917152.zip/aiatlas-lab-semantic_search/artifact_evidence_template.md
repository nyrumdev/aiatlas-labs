lab_id: lab.c.lab.semantic_search

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 데이터와 잠금 — data\corpus.jsonl(문서 60개 이상) + data\queries.jsonl(말 바꿈 para 12 · 글자 그대로 exact 9 · 언어 넘기 cross 9 = 30문항 · 문항마다 정답 문서 id 목록 rel) + check_data.py 의 'OK' 출력 1줄 + 첫 검색을 돌리기 전에 데이터와 코드만 올린 잠금 커밋 해시(git rev-parse HEAD 40자리) 1줄 -->
c1: 
<!-- c2(필수): 환경과 입력 한도 — results\env.md(판·장치·모델 커밋·prompts·max_seq_length) + common.py 의 REVISION 이 env.md 의 커밋과 같다는 1줄 + 모델이 스스로 붙이는 접두사가 없다는 것을 env.md 의 어느 줄로 확인했는지 1줄 + results\tokens.md 의 '한도를 넘는 문서' 줄(0개가 아니면 나눈 문서 id 와 다시 잠근 커밋 해시) -->
c2: 
<!-- c3(필수): 의미 검색 — search.py 로 para·exact·cross 문항을 하나씩(세 질문) 돌린 출력 붙여 넣기 + results\index_prefix.json(이름표) + 두 번째 실행에서 '저장된 색인을 그대로 쓴다'가 찍힌 출력 1줄 + 1위~5위 점수가 몰린 구간과, 그래서 점수 절댓값으로 문턱을 정하지 않는 이유 1줄 -->
c3: 
<!-- c4(필수): 평가기와 내 계산 — results\run_e5small_prefix.json + results\e5small_prefix 폴더의 평가기 CSV + run_dense.py 출력의 '내 코드와 평가기의 차이 … 같다' 줄 + 평가기를 돌리기 전에 손으로 계산한 두 문항(정답 순위 · Recall@5 몫 · MRR@10 몫)과 per_query.csv 의 순위가 같은지 1줄 -->
c4: 
<!-- c5(필수): 두 기준선 — results\run_e5small_noprefix.json(실행 출력의 '같다' 줄 포함) + results\run_bm25_char2.json -->
c5: 
<!-- c6(필수): 비교와 결론 — results\summary.md · results\pairs.md · results\per_query.csv + 보고서의 결론 3문장(접두사 있음 대 없음 · 의미 검색 대 BM25 · 갈래별로 갈린 곳) — 문장마다 summary 의 숫자와 pairs 의 '더 위' 문항 수(③은 pairs 의 갈래별 줄)를 인용하고, 두 '더 위' 수의 차나 '만 5위 안' 문항 수의 차가 2 이하이면 '이 묶음으로는 가르지 못한다'로 쓴다 -->
c6: 
<!-- c7(필수): 실패 표 — 세 실행(prefix·noprefix·bm25) 가운데 하나에서라도 처음 나온 정답이 5위 밖인 문항 전부(문항 id · 갈래 · 실패한 실행 · 그 실행의 1위 문서 id · 원인 추정 1줄) + 원인 갈래별 개수 -->
c7: 
<!-- c8(필수): 판 기록과 커밋 — requirements.txt 의 sentence-transformers~=6.1.0 · rank-bm25==0.2.2 두 줄 + 다시 뽑은 requirements.lock.txt 맨 위 색인 줄과 torch 줄의 +cu 꼬리표 + 실습 파일·결과·보고서를 올린 커밋 해시 1줄 -->
c8: 
<!-- c9(선택): (선택) 접두사 바꿔 붙이기 — results\run_e5small_swapped.json + pairs.md 의 e5small_prefix 대 e5small_swapped 줄 + 해석 1줄 -->
c9: 
<!-- c10(선택): (선택) 다른 모델 하나 — 다른 임베딩 모델을 커밋 해시와 함께 같은 30문항으로 잰 run 파일 + summary.md 의 행 + 그 모델의 이름표(모델 · 커밋 · 질문 접두사 · 문서 접두사 · 차원) 1줄 -->
c10: 
