# 한국어 의미 검색 만들고 Recall@k 로 재기 — multilingual-e5-small 접두사 규약·평가기·키워드 기준선

AI 아틀라스 앱의 실습 `lab.c.lab.semantic_search`(L2 · 약 4시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 semantic_search\search_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 C:\work\ai-lab\semantic_search 폴더에 data(corpus.jsonl · queries.jsonl) + 파이썬 파일 8개(common · env_check · check_data · token_check · search · run_dense · run_bm25 · compare) + results 폴더.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 만든 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch 와 numpy·scikit-learn 이 들어 있고, git 저장소와 requirements.txt·requirements.lock.txt 가 있다 · GPU 가 있으면 모델이 GPU 에 올라가지만, 문서 수십 개 규모라 CPU 로도 끝까지 돈다
- 인터넷 — sentence-transformers·rank-bm25 설치와 모델 파일 내려받기에만 쓴다(모델의 model.safetensors 한 파일이 약 470MB · S6325) · Hugging Face 계정·토큰은 필요 없다
- 내 글 — AI 공부 노트·정리 글처럼 내가 쓴 한국어 글(영어 용어가 섞여도 좋다) · 한 가지 내용만 담은 문단 60개 이상을 뽑을 만큼(모자라면 4단계의 안내대로 레슨을 내 말로 요약해 채운다)
- 메모장 등 글 편집기 — 파이썬 파일과 데이터 파일을 UTF-8 로 저장한다

## 들어 있는 파일
- `files/common.py`
- `files/env_check.py`
- `files/check_data.py`
- `files/token_check.py`
- `files/search.py`
- `files/run_dense.py`
- `files/run_bm25.py`
- `files/compare.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.semantic_search` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
