# 한국어 의미 검색 만들고 Recall@k 로 재기 — multilingual-e5-small 접두사 규약·평가기·키워드 기준선 — 명령·코드 모음

실습 id: `lab.c.lab.semantic_search`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 설치

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install "sentence-transformers~=6.1.0" "rank-bm25==0.2.2"
python -c "import torch, sentence_transformers; print(torch.__version__, torch.cuda.is_available(), sentence_transformers.__version__)"
mkdir semantic_search
mkdir semantic_search\data
cd semantic_search
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `pip install -U sentence-transformers` — 설치 안내는 `pip install -U sentence-transformers` 인데(S6320), 여기서는 -U 없이 판의 범위를 정해 넣는다.

## 2. 공용 코드

- `files/common.py` — 키트에 들어 있음 (python)

## 3. 환경과 모델 고정

- `files/env_check.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python env_check.py` — 환경과 모델 고정 — 아래를 `env_check.py` 로 저장하고 `python env_check.py` 로 실행한다.

## 4. 평가 데이터 쓰기

```text
{"id": "p001", "text": "vanishing gradient 정리 — 층이 깊을수록 앞쪽 층의 기울기가 0에 가까워져 학습이 거의 멈춘다. 잔차 연결이 이 문제를 덜어 준다."}
{"id": "p005", "text": "오류 코드 CUDA_ERROR_OUT_OF_MEMORY 가 나면 배치 크기를 줄이거나 시퀀스 길이를 줄인다."}
{"id": "p008", "text": "학습률이 너무 크면 손실이 줄지 않고 튀거나 발산한다. 너무 작으면 학습이 느리다."}
{"id": "p011", "text": "Dropout 은 학습 중에 뉴런 일부를 무작위로 꺼서 특정 뉴런에 기대는 것을 막는다."}
```

```text
{"id": "q01", "kind": "para", "text": "깊은 신경망에서 앞단이 거의 안 배우는 이유", "rel": ["p001"]}
{"id": "q04", "kind": "exact", "text": "CUDA_ERROR_OUT_OF_MEMORY", "rel": ["p005"]}
{"id": "q07", "kind": "cross", "text": "randomly turning off neurons during training", "rel": ["p011"]}
```

## 5. 데이터 점검

- `files/check_data.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python check_data.py` — 데이터 점검 — 아래를 `check_data.py` 로 저장하고 `python check_data.py` 로 실행한다.

## 6. 입력 한도와 잠금

- `files/token_check.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
Add-Content .gitignore "semantic_search/results/index_*.npy"
Add-Content .gitignore "!semantic_search/data/"
git add .gitignore semantic_search/data semantic_search/*.py
git commit -m "의미 검색 평가 데이터 잠금"
git show --stat HEAD
git rev-parse HEAD
cd semantic_search
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python token_check.py` — 입력 한도와 잠금 — 아래를 `token_check.py` 로 저장하고 `python token_check.py` 로 실행한다.

## 7. 의미 검색 만들기

- `files/search.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python search.py "질문"` — `python search.py "질문"` 으로 para·exact·cross 문항을 하나씩 돌려 출력을 붙인다.

## 8. 손으로 먼저

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python search.py "질문" -k 10` — 손으로 먼저 — 평가기를 돌리기 전에, 내 질문 두 개를 골라 `python search.py "질문" -k 10` 으로 돌린다.

## 9. 평가기로 재기

- `files/run_dense.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_dense.py --cond prefix` — 평가기로 재기 — 아래를 `run_dense.py` 로 저장하고 `python run_dense.py --cond prefix` 로 실행한다.

## 10. 접두사 빼기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_dense.py --cond noprefix` — 접두사 빼기 — `python run_dense.py --cond noprefix` 를 실행한다.

## 11. 키워드 기준선

- `files/run_bm25.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_bm25.py` — 키워드 기준선 — 아래를 `run_bm25.py` 로 저장하고 `python run_bm25.py` 로 실행한다.

## 12. 비교

- `files/compare.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python compare.py` — 비교 — 아래를 `compare.py` 로 저장하고 `python compare.py` 로 실행한다.

## 14. (선택) 접두사 바꿔 붙이기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_dense.py --cond swapped` — `python run_dense.py --cond swapped` 로 질문에 'passage: ', 문서에 'query: ' 를 붙여 잰다.
- `python compare.py e5small_prefix,e5small_swapped` — 그다음 `python compare.py e5small_prefix,e5small_swapped` 로 그 한 쌍만 비교한다.
- `python compare.py` — 이 실행까지 마쳤으면 `python compare.py` 를 인자 없이 한 번 더 돌린다.

## 15. (선택) 다른 모델 하나

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -c "from huggingface_hub import model_info; print(model_info('intfloat/multilingual-e5-base').sha)"` — 커밋 해시는 `python -c "from huggingface_hub import model_info; print(model_info('intfloat/multilingual-e5-base').sha)"` 로 얻는다.
- `python run_dense.py --cond prefix --model intfloat/multilingual-e5-base --revision <해시> --tag e5base` — `python run_dense.py --cond prefix --model intfloat/multilingual-e5-base --revision <해시> --tag e5base` 로 잰다.
- `python compare.py` — 끝나면 `python compare.py` 를 다시 돌려 summary.md 에 행을 더하고, 그 모델의 이름표(모델 · 커밋 · 질문 접두사 · 문서 접두사 · 차원)를 한 줄로 적는다.
- `python -c "from sentence_transformers import SentenceTransformer as S; print(S('intfloat/multilingual-e5-base', revision='<해시>').get_embedding_dimension())"` — 차원은 run 파일에 적히지 않으므로 …

## 17. 판 기록과 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

```powershell
git add requirements.txt requirements.lock.txt semantic_search
git commit -m "의미 검색 — e5-small 접두사·BM25 기준선 비교"
git rev-parse HEAD
```

```powershell
git add semantic_search/search_report.md
git commit -m "의미 검색 보고서 — c8 커밋 해시"
git status
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git show --stat <잠금 해시>` — … 가 OK 를 냈고, 잠금 커밋에 data 폴더와 파이썬 파일이 들어 있으며(`git show --stat <잠금 해시>`), 그 커밋 시각(`git log -1 --format=%ci <잠금 해시>`)이 results 폴더의 index_prefix.json 과 모든 …
- `git log -1 --format=%ci <잠금 해시>` — … 가 OK 를 냈고, 잠금 커밋에 data 폴더와 파이썬 파일이 들어 있으며(`git show --stat <잠금 해시>`), 그 커밋 시각(`git log -1 --format=%ci <잠금 해시>`)이 results 폴더의 index_prefix.json 과 모든 …
- `git status` — requirements.lock.txt 의 torch 줄에 +cu 꼬리표가 있고, 마지막 `git status` 가 깨끗한가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -m pip uninstall -y torch` — 앞 실습의 흔한 실패대로 `python -m pip uninstall -y torch` 뒤 앞 실습 4단계의 색인 명령으로 다시 넣는다.
- `git add` — 6단계의 `git add` 가 'The following paths are ignored by one of your .gitignore files … semantic_search/data … hint: Use -f' 를 찍고, `git show --stat` 에 data 두 파일이 없다 …
- `git show --stat` — … by one of your .gitignore files … semantic_search/data … hint: Use -f' 를 찍고, `git show --stat` 에 data 두 파일이 없다 → 6단계 셋째 줄(`!semantic_search/data/`)을 빠뜨렸다.
- `git add .gitignore semantic_search/data` — 아직 검색을 한 번도 돌리지 않았으면 그 줄을 더한 뒤 `git add .gitignore semantic_search/data` 와 `git commit --amend --no-edit` 로 잠금 커밋을 고쳐 쓰고 `git show --stat` 을 다시 본다.
- `git commit --amend --no-edit` — 아직 검색을 한 번도 돌리지 않았으면 그 줄을 더한 뒤 `git add .gitignore semantic_search/data` 와 `git commit --amend --no-edit` 로 잠금 커밋을 고쳐 쓰고 `git show --stat` 을 다시 본다.
