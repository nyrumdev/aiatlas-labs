# token_check.py — 접두사를 붙인 문서가 모델의 입력 한도 안에 드는지 센다(넘치면 오류 없이 잘린다)
from sentence_transformers import SentenceTransformer

from common import MODEL, RESULTS, REVISION, load

if REVISION is None:
    raise SystemExit("common.py 의 REVISION 이 비어 있다 — env_check.py 가 찍어 준 해시를 먼저 적는다")
model = SentenceTransformer(MODEL, revision=REVISION)
corpus, queries = load()
limit = model.max_seq_length


def n_tokens(text):
    return len(model.tokenizer(text)["input_ids"])  # 앞뒤 특수 토큰까지 센다


docs = sorted(((n_tokens("passage: " + t), i) for i, t in corpus.items()), reverse=True)
over = [i for n, i in docs if n > limit]
longest_q = max(n_tokens("query: " + q["text"]) for q in queries)
lines = ["# 토큰 수", "",
         f"- 입력 한도 {limit} 토큰",
         f"- 가장 긴 문서 {docs[0][1]} — {docs[0][0]} 토큰 · 그 문서의 글자 수 {len(corpus[docs[0][1]])}",
         f"- 한도를 넘는 문서 {len(over)}개: {', '.join(over) or '없음'}",
         f"- 가장 긴 질문 {longest_q} 토큰",
         "- 긴 순서 다섯: " + " · ".join(f"{i} {n}" for n, i in docs[:5])]
RESULTS.mkdir(exist_ok=True)
(RESULTS / "tokens.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
