# common.py — 데이터 읽기 · 글자 2-gram · 순위 지표(Recall@k · MRR@k)를 한 곳에 둔다
import json
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA, RESULTS = ROOT / "data", ROOT / "results"
MODEL = "intfloat/multilingual-e5-small"
REVISION = None  # env_check.py 가 찍어 준 모델 커밋 해시 40자리를 따옴표 안에 넣는다
CUTS = (1, 5, 10)
KINDS = ("para", "exact", "cross")
# 조건 이름 → (질문 앞에 붙일 말, 문서 앞에 붙일 말)
CONDITIONS = {
    "prefix": ("query: ", "passage: "),    # 모델 카드의 규약 그대로
    "noprefix": ("", ""),                  # 접두사를 뺀다
    "swapped": ("passage: ", "query: "),   # (선택) 두 접두사를 바꿔 붙인다
}


def rows(name):
    out = []
    text = (DATA / name).read_text(encoding="utf-8-sig")
    for n, line in enumerate(text.splitlines(), start=1):
        if line.strip():
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise SystemExit(f"{name} {n}번째 줄이 JSON 이 아니다 — {e.msg} (따옴표·쉼표·중괄호를 본다)")
    return out


def load():
    docs = rows("corpus.jsonl")
    corpus = {r["id"]: r["text"] for r in docs}
    if len(corpus) != len(docs):
        seen = [r["id"] for r in docs]
        twice = sorted({i for i in seen if seen.count(i) > 1})
        raise SystemExit(f"corpus.jsonl 에 같은 문서 id 가 두 번 이상 있다: {twice} — 앞 줄이 조용히 사라지므로 id 를 고친다")
    return corpus, rows("queries.jsonl")


def grams(text, n=2):
    """글자 2-gram — 공백을 빼고 두 글자씩 겹쳐 자른다. '환불은'·'환불' 이 '환불' 조각을 함께 갖는다."""
    t = "".join(unicodedata.normalize("NFKC", text).lower().split())
    return [t[i:i + n] for i in range(len(t) - n + 1)] or [t]


def first_rank(ranked, rel):
    """ranked = 위에서부터 늘어선 문서 id. 처음 나온 정답 문서의 순위(1부터) · 없으면 None."""
    for i, doc in enumerate(ranked, start=1):
        if doc in rel:
            return i
    return None


def metrics(ranked_by_q, queries, cuts=CUTS, mrr_k=10):
    """Recall@k = 위 k 개 안의 정답 문서 수 ÷ 그 질문의 정답 문서 수(질문마다 낸 뒤 평균)
    MRR@k = 위 k 개 안에서 처음 나온 정답의 순위 r 로 1/r(없으면 0)을 질문마다 낸 뒤 평균"""
    n = len(queries)
    out = {}
    for k in cuts:
        out[f"recall@{k}"] = sum(len(set(ranked_by_q[q["id"]][:k]) & set(q["rel"])) / len(q["rel"])
                                 for q in queries) / n
    rr = [first_rank(ranked_by_q[q["id"]][:mrr_k], set(q["rel"])) for q in queries]
    out[f"mrr@{mrr_k}"] = sum(1 / r for r in rr if r) / n
    return out


def save_run(name, info, ranked_by_q, queries):
    RESULTS.mkdir(exist_ok=True)
    info = dict(info, name=name, n_queries=len(queries),
                metrics=metrics(ranked_by_q, queries),
                ranks={q["id"]: first_rank(ranked_by_q[q["id"]], set(q["rel"])) for q in queries},
                top1={q["id"]: (ranked_by_q[q["id"]] or [None])[0] for q in queries})
    path = RESULTS / f"run_{name}.json"
    path.write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(name, " · ".join(f"{k} {v:.3f}" for k, v in info["metrics"].items()))
    return info
