# search.py — 문서를 한 번 벡터로 바꿔 이름표와 함께 저장해 두고(색인), 질문마다 가까운 문서 k 개를 보여 준다
import argparse
import hashlib
import json

import numpy as np
from sentence_transformers import SentenceTransformer

from common import CONDITIONS, MODEL, RESULTS, REVISION, load

ap = argparse.ArgumentParser(description="한국어 의미 검색 — 질문 하나에 가까운 문서 k 개")
ap.add_argument("question")
ap.add_argument("-k", type=int, default=5)
ap.add_argument("--cond", choices=sorted(CONDITIONS), default="prefix")
a = ap.parse_args()
if REVISION is None:
    raise SystemExit("common.py 의 REVISION 이 비어 있다 — env_check.py 가 찍어 준 해시를 먼저 적는다")

q_prompt, d_prompt = CONDITIONS[a.cond]
corpus, _ = load()
ids = sorted(corpus)
# 이름표 — 이 가운데 하나라도 바뀌면 저장해 둔 벡터는 버리고 다시 만든다
label = {"model": MODEL, "revision": REVISION, "query_prompt": q_prompt, "doc_prompt": d_prompt,
         "n_docs": len(ids),
         "corpus_sha256": hashlib.sha256("\n".join(i + "\t" + corpus[i] for i in ids).encode("utf-8")).hexdigest()}
meta_path, vec_path = RESULTS / f"index_{a.cond}.json", RESULTS / f"index_{a.cond}.npy"

model = SentenceTransformer(MODEL, revision=REVISION)
saved = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else None
if saved == label and vec_path.exists():
    docs = np.load(vec_path)
    print(f"저장된 색인을 그대로 쓴다 — {vec_path.name} · 문서 {len(ids)}개")
else:
    docs = model.encode_document([corpus[i] for i in ids], prompt=d_prompt)
    RESULTS.mkdir(exist_ok=True)
    np.save(vec_path, docs)
    meta_path.write_text(json.dumps(label, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"색인을 새로 만들었다 — {vec_path.name} · 벡터 {docs.shape[0]}개 × {docs.shape[1]}차원")

q = model.encode_query([a.question], prompt=q_prompt)
scores = model.similarity(q, docs)[0]  # 질문 1개 × 문서 N개의 코사인 유사도
top = scores.topk(min(a.k, len(ids)))
print(f"질문: {a.question}  (조건 {a.cond} · 질문 앞 {q_prompt!r} · 문서 앞 {d_prompt!r})")
for rank, (s, j) in enumerate(zip(top.values.tolist(), top.indices.tolist()), start=1):
    print(f"{rank}. {s:.3f}  {ids[j]}  {corpus[ids[j]][:50]}")
