# compare.py — 실행 결과(run_*.json)를 한 표로 · 문항별 순위 표 · 두 실행의 짝 비교를 만든다
import csv
import json
import sys

from common import KINDS, RESULTS, load

corpus, queries = load()
runs = {}
for p in sorted(RESULTS.glob("run_*.json")):
    r = json.loads(p.read_text(encoding="utf-8"))
    runs[r["name"]] = r
if not runs:
    sys.exit("results 에 run_*.json 이 없다 — run_dense.py · run_bm25.py 를 먼저 돌린다")
names = list(runs)
n = len(queries)
by_kind = {k: [q for q in queries if q["kind"] == k] for k in KINDS}


def hit(rank, k):
    return rank is not None and rank <= k


lines = ["# 검색 성적 요약", "",
         "| 실행 | Recall@1 | Recall@5 | Recall@10 | MRR@10 | " + " | ".join(f"{k} 위 5개 안" for k in KINDS) + " |",
         "|---" * (5 + len(KINDS)) + "|"]
for name in names:
    m, rk = runs[name]["metrics"], runs[name]["ranks"]
    kind_cells = [f"{sum(hit(rk[q['id']], 5) for q in qs)}/{len(qs)}" for qs in by_kind.values()]
    lines.append(f"| {name} | {m['recall@1']:.3f} | {m['recall@5']:.3f} | {m['recall@10']:.3f} | {m['mrr@10']:.3f} | "
                 + " | ".join(kind_cells) + " |")
lines += ["", f"- 질문 {n}개 · 문서 {len(corpus)}개 · 질문 하나의 몫 {1 / n:.3f}(정답 문서가 하나뿐인 질문이면 Recall@k 한 칸이 이만큼 움직인다)",
          "- 'kind 위 5개 안' = 그 갈래 질문 가운데 처음 나온 정답이 5위 안에 든 질문 수"]
(RESULTS / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

with open(RESULTS / "per_query.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "kind", "query", "rel"] + [f"rank_{x}" for x in names] + [f"top1_{x}" for x in names])
    for q in queries:
        w.writerow([q["id"], q["kind"], q["text"], " ".join(q["rel"])]
                   + [runs[x]["ranks"][q["id"]] or "" for x in names]
                   + [runs[x]["top1"][q["id"]] or "" for x in names])

# 짝 비교 — 같은 질문에서 처음 나온 정답의 순위가 어느 쪽이 더 위인가(찾지 못함은 맨 아래로 친다)
pairs = [tuple(x.split(",")) for x in sys.argv[1:]] or [(a, b) for i, a in enumerate(names) for b in names[i + 1:]]
out = ["# 짝 비교(같은 질문끼리)", ""]
for a, b in pairs:
    if a not in runs or b not in runs:
        sys.exit(f"없는 실행 이름: {a} 또는 {b} — 있는 이름 {names}")
    ra, rb = runs[a]["ranks"], runs[b]["ranks"]
    big = len(corpus) + 1
    sa = {q["id"]: ra[q["id"]] or big for q in queries}
    sb = {q["id"]: rb[q["id"]] or big for q in queries}
    a_up = [q["id"] for q in queries if sa[q["id"]] < sb[q["id"]]]
    b_up = [q["id"] for q in queries if sb[q["id"]] < sa[q["id"]]]
    only_a = [q["id"] for q in queries if hit(ra[q["id"]], 5) and not hit(rb[q["id"]], 5)]
    only_b = [q["id"] for q in queries if hit(rb[q["id"]], 5) and not hit(ra[q["id"]], 5)]
    out += [f"## {a} 대 {b}",
            f"- {a} 가 더 위: {len(a_up)} · {b} 가 더 위: {len(b_up)} · 같음: {n - len(a_up) - len(b_up)}"]
    for kind, qs in by_kind.items():  # 같은 셈을 갈래마다
        ka = sum(sa[q["id"]] < sb[q["id"]] for q in qs)
        kb = sum(sb[q["id"]] < sa[q["id"]] for q in qs)
        out.append(f"  - {kind} {len(qs)}문항: {a} 가 더 위 {ka} · {b} 가 더 위 {kb} · 같음 {len(qs) - ka - kb}")
    out += [f"- {a} 만 5위 안: {', '.join(only_a) or '없음'}",
            f"- {b} 만 5위 안: {', '.join(only_b) or '없음'}", ""]
(RESULTS / "pairs.md").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
