# run_dense.py — 임베딩 검색을 평가기로 재고, 평가기가 남긴 순위로 내 지표 코드를 다시 돌려 두 값을 맞춘다
import argparse
import json

from sentence_transformers import SentenceTransformer
from sentence_transformers.sentence_transformer.evaluation import InformationRetrievalEvaluator

from common import CONDITIONS, CUTS, MODEL, RESULTS, REVISION, load, save_run

ap = argparse.ArgumentParser()
ap.add_argument("--cond", choices=sorted(CONDITIONS), required=True)
ap.add_argument("--model", default=MODEL)
ap.add_argument("--revision", default=None, help="--model 을 바꿀 때 그 모델의 커밋 해시")
ap.add_argument("--tag", default="e5small", help="결과 이름 앞에 붙는 모델 별명")
a = ap.parse_args()
revision = REVISION if a.model == MODEL else a.revision
if revision is None:
    raise SystemExit("모델 커밋 해시가 비어 있다 — common.py 의 REVISION(또는 --revision)을 먼저 채운다")

corpus, queries = load()
q_prompt, d_prompt = CONDITIONS[a.cond]
name = f"{a.tag}_{a.cond}"
model = SentenceTransformer(a.model, revision=revision)
evaluator = InformationRetrievalEvaluator(
    queries={q["id"]: q["text"] for q in queries},
    corpus=corpus,
    relevant_docs={q["id"]: set(q["rel"]) for q in queries},
    accuracy_at_k=list(CUTS), precision_recall_at_k=list(CUTS),
    mrr_at_k=[10], ndcg_at_k=[10], map_at_k=[100],
    query_prompt=q_prompt, corpus_prompt=d_prompt,
    name=name, write_predictions=True,
)
out = RESULTS / name
scores = evaluator(model, output_path=str(out))
fn = model.similarity_fn_name

# 평가기가 쓴 질문별 순위(점수 내림차순 · 같으면 문서 id 오름차순)를 읽는다
pred = out / f"Information-Retrieval_evaluation_{name}_predictions_{fn}.jsonl"
ranked = {}
for line in pred.read_text(encoding="utf-8").splitlines():
    p = json.loads(line)
    ranked[p["query_id"]] = [r["corpus_id"] for r in p["results"]]

info = save_run(name, {"model": a.model, "revision": revision, "query_prompt": q_prompt,
                       "doc_prompt": d_prompt, "score_function": fn, "device": str(model.device)},
                ranked, queries)
evaluator_says = {k: scores[f"{name}_{fn}_{k}"] for k in info["metrics"]}
gap = max(abs(evaluator_says[k] - v) for k, v in info["metrics"].items())
print("평가기 값:", " · ".join(f"{k} {v:.3f}" for k, v in evaluator_says.items()))
print(f"내 코드와 평가기의 차이 최댓값 {gap:.2e} →", "같다" if gap < 1e-9 else "다르다 — common.py 의 metrics 를 다시 본다")
