# env_check.py — 판·장치·모델 커밋 해시·모델이 스스로 붙이는 접두사·입력 한도를 results/env.md 에 남긴다
import platform
import sys
from importlib.metadata import version

import torch
from huggingface_hub import model_info
from sentence_transformers import SentenceTransformer

from common import MODEL, RESULTS

sha = model_info(MODEL).sha
model = SentenceTransformer(MODEL, revision=sha)
lines = [
    "# 환경", "",
    f"- python {platform.python_version()} · {sys.executable}",
    f"- torch {torch.__version__} · cuda {torch.cuda.is_available()} · 모델이 앉은 장치 {model.device}",
    f"- sentence-transformers {version('sentence-transformers')} · transformers {version('transformers')}"
    f" · rank-bm25 {version('rank-bm25')}",
    f"- 모델 {MODEL} · 커밋 {sha}",
    f"- 입력 한도 max_seq_length {model.max_seq_length} · 유사도 함수 {model.similarity_fn_name}",
    f"- 모델 설정에 든 기본 접두사(prompts) {model.prompts or '없음'} · default_prompt_name {model.default_prompt_name}",
]
RESULTS.mkdir(exist_ok=True)
(RESULTS / "env.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
print(f'\ncommon.py 의 REVISION 줄을 이렇게 고친다 → REVISION = "{sha}"')
