# run_bm25.py — 키워드 기준선: 글자 2-gram 위의 BM25 로 같은 질문·같은 문서·같은 지표를 잰다
from rank_bm25 import BM25Okapi

from common import grams, load, save_run

corpus, queries = load()
ids = sorted(corpus)
bm25 = BM25Okapi([grams(corpus[i]) for i in ids])  # 기본값 k1=1.5 · b=0.75 · epsilon=0.25
ranked = {}
for q in queries:
    s = bm25.get_scores(grams(q["text"]))
    order = sorted(range(len(ids)), key=lambda j: (-s[j], ids[j]))  # 평가기와 같은 줄 세우기
    ranked[q["id"]] = [ids[j] for j in order if s[j] > 0][:100]       # 점수 0 = 겹친 조각이 없거나 그 가중치가 모두 0 → 찾지 못한 것
save_run("bm25_char2", {"model": "BM25Okapi(k1=1.5, b=0.75, epsilon=0.25) · 글자 2-gram"}, ranked, queries)
