# check_data.py — 문서·질문 파일이 약속한 모양인지, 문항 갈래가 이름값을 하는지 돌리기 전에 확인한다
import re
import sys

from common import KINDS, grams, load

MIN_DOCS = 60
NEED = {"para": 12, "exact": 9, "cross": 9}
MAX_OVERLAP = 0.5  # 말 바꿈 문항이 정답 문서와 나눠 가져도 되는 글자 2-gram 몫의 상한


def hangul(s):
    letters = re.findall(r"[가-힣A-Za-z]", s)
    return sum("가" <= c <= "힣" for c in letters) / max(len(letters), 1)


def squash(s):
    return "".join(s.lower().split())


corpus, queries = load()
bad = []
if len(corpus) < MIN_DOCS:
    bad.append(f"문서 {len(corpus)}개 — {MIN_DOCS}개 이상이어야 한다")
ids = [q.get("id") for q in queries]
if len(set(ids)) != len(ids):
    bad.append("질문 id 가 겹친다")
for q in queries:
    qid, kind, text, rel = q.get("id"), q.get("kind"), q.get("text", ""), q.get("rel")
    if kind not in KINDS:
        bad.append(f"{qid}: kind 는 {'·'.join(KINDS)} 가운데 하나")
        continue
    if not isinstance(rel, list) or not rel or any(r not in corpus for r in rel):
        bad.append(f"{qid}: rel 은 corpus.jsonl 에 있는 문서 id 목록(하나 이상)")
        continue
    docs = [corpus[r] for r in rel]
    g = set(grams(text))
    overlap = max(len(g & set(grams(d))) / len(g) for d in docs)
    if kind == "para" and overlap > MAX_OVERLAP:
        bad.append(f"{qid}: 말 바꿈 문항인데 정답 문서와 글자 2-gram 이 {overlap:.0%} 겹친다 — 다시 쓰거나 exact 로 옮긴다")
    if kind == "exact" and not any(squash(text) in squash(d) for d in docs):
        bad.append(f"{qid}: 글자 그대로 문항인데 질문 전체가 정답 문서 안에 그대로 들어 있지 않다 — 앞뒤 말을 빼고 글자열만 남긴다")
    if kind == "cross" and all(abs(hangul(text) - hangul(d)) < 0.5 for d in docs):
        bad.append(f"{qid}: 언어 넘기 문항인데 질문과 정답 문서의 한글 비율이 비슷하다 — 한국어 문서는 영어로 묻는다")
for kind, n in NEED.items():
    have = sum(q.get("kind") == kind for q in queries)
    if have != n:
        bad.append(f"{kind} 문항 {have}개 — {n}개여야 한다")
same = {q["text"] for q in queries if "text" in q} & set(corpus.values())
if same:
    bad.append(f"문서와 글자까지 같은 질문: {sorted(same)}")
print(f"OK — 문서 {len(corpus)} · 질문 {len(queries)}" if not bad else "\n".join(bad))
sys.exit(1 if bad else 0)
