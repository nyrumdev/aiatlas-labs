# 기울기를 손으로 — 순수 파이썬 경사하강·기울기 검사에서 작은 자동미분 엔진(micrograd)까지 — 명령·코드 모음

실습 id: `lab.c.lab.gradients_by_hand`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 준비

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install pytest
python -m pytest --version
python -c "import sys, matplotlib, sklearn; print(sys.version); print(matplotlib.__version__, sklearn.__version__)"
mkdir gradients_by_hand\autograd
cd gradients_by_hand
```

## 2. A부 코드

- `files/logreg_by_hand.py` — 키트에 들어 있음 (python)

## 3. 실행과 첫 손실

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python logreg_by_hand.py` — 실행과 첫 손실 — `python logreg_by_hand.py` 를 친다.

## 4. 기울기 직접 쓰기

```python
def grad(params, xs, ys):
    """해석 기울기 — 점마다 (p − y)·입력 을 더해 점 개수로 나눈다. 편향의 입력은 1 로 본다."""
    g = [0.0, 0.0, 0.0]          # w1 · w2 · b 의 기울기를 모을 칸
    for x, y in zip(xs, ys):
        p = sigmoid(weighted_sum(params, x))
        err = p - y
        g[0] += err * x[0]
        g[1] += err * x[1]
        g[2] += err
    return [gi / len(xs) for gi in g]
```

## 7. B부 엔진

- `files/engine.py` — 키트에 들어 있음 (python)

## 8. 직접 쓰고 시험으로 판정

- `files/test_engine.py` — 키트에 들어 있음 (python)

```powershell
cd autograd
python -m pytest -v
$LASTEXITCODE
```

```python
    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other), "*")

        def _backward():
            self.grad += other.data * out.grad  # 곱하기의 국소 기울기는 상대편 값
            other.grad += self.data * out.grad
        out._backward = _backward
        return out

    def tanh(self):
        t = math.tanh(self.data)
        out = Value(t, (self,), "tanh")

        def _backward():
            self.grad += (1 - t ** 2) * out.grad   # tanh 의 도함수 = 1 − tanh²
        out._backward = _backward
        return out
```

## 9. 덮어쓰기 실패 재현

- `files/reuse_demo.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Copy-Item engine.py engine_overwrite.py` — autograd 폴더에서 `Copy-Item engine.py engine_overwrite.py` 로 복사하고, `notepad engine_overwrite.py` 로 열어 `__add__` 와 `__mul__` 의 `_backward` 안 네 줄에서 `+=` 를 `=` 로 바꿔 …
- `python reuse_demo.py` — `python reuse_demo.py` 를 친다.

## 10. MLP

- `files/nn.py` — 키트에 들어 있음 (python)

## 11. MLP 시험 더하기와 기록

```python
def test_mlp_parameters():
    import random                 # nn.py 를 만든 뒤에 더하는 시험이라 import 를 함수 안에 둔다
    from nn import MLP

    random.seed(1)
    model = MLP(2, [4, 4, 1])
    xs = [[0.5, -1.0], [1.5, 0.3], [-0.2, 0.8]]
    ys = [1.0, -1.0, 1.0]

    def total_loss():
        return sum((model(x) - y) ** 2 for x, y in zip(xs, ys))

    total_loss().backward()
    for k, p in enumerate(model.parameters()):
        old = p.data
        p.data = old + H
        up = total_loss().data
        p.data = old - H
        down = total_loss().data
        p.data = old
        num = (up - down) / (2 * H)
        err = rel_error(p.grad, num)
        assert err < TOL, f"파라미터 {k}: 엔진 {p.grad} · 중심 차분 {num} · 상대 오차 {err:.2e}"
```

```powershell
python -m pytest -v
$LASTEXITCODE
python -m pytest -v | Out-File -Encoding utf8 test_log.txt
```

## 12. 반달 점 학습

- `files/train_moons.py` — 키트에 들어 있음 (python)

## 13. 판 기록과 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
Add-Content .gitignore ".pytest_cache/"
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 그다음 `git add .` 와 `git commit -m "기울기를 손으로 — 로지스틱 회귀와 자동미분 엔진"` 을 치고 `git rev-parse HEAD` 의 40자리를 보고서에 적는다(S764).
- `git commit -m "기울기를 손으로 — 로지스틱 회귀와 자동미분 엔진"` — 그다음 `git add .` 와 `git commit -m "기울기를 손으로 — 로지스틱 회귀와 자동미분 엔진"` 을 치고 `git rev-parse HEAD` 의 40자리를 보고서에 적는다(S764).
- `git rev-parse HEAD` — 그다음 `git add .` 와 `git commit -m "기울기를 손으로 — 로지스틱 회귀와 자동미분 엔진"` 을 치고 `git rev-parse HEAD` 의 40자리를 보고서에 적는다(S764).
- `git status` — `git status` 에 `.pytest_cache` 가 보이지 않는지도 본다.

## 15. (선택) 꺾인 점

```python
    def relu(self):
        out = Value(self.data if self.data > 0 else 0.0, (self,), "relu")

        def _backward():
            self.grad += (1.0 if self.data > 0 else 0.0) * out.grad
        out._backward = _backward
        return out
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cd C:\work\ai-lab\gradients_by_hand\autograd` — (선택) 꺾인 점 — autograd 폴더로 돌아가(`cd C:\work\ai-lab\gradients_by_hand\autograd`) engine.py 의 tanh 아래에 relu 를 더한다.
- `python -m pytest -v` — test_engine.py 에 `check(lambda v: v[0].relu(), [1e-6])` 를 부르는 시험 함수를 하나 더 쓰고 `python -m pytest -v` 로 돌린다.

## 16. (선택) 기울기 비우기 빼기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cd C:\work\ai-lab\gradients_by_hand\autograd` — (선택) 기울기 비우기 빼기 — autograd 폴더로 돌아가(`cd C:\work\ai-lab\gradients_by_hand\autograd`) train_moons.py 의 `p.grad = 0.0` 줄을 `pass # p.grad = 0.0` 으로 바꿔 막는다.
- `python train_moons.py` — 기록 파일 이름을 `train_log_nozero.txt` 로, 그림 저장 이름을 `../moons_pred_nozero.png` 로 바꾸는 두 줄도 고친 뒤, 같은 autograd 폴더에서 `python train_moons.py` 로 다시 돌린다.
- `Get-ChildItem train_log*.txt, ..\moons_pred*.png` — 끝나면 고친 세 줄을 원래대로 되돌리고, `Get-ChildItem train_log*.txt, ..\moons_pred*.png` 로 새 두 파일이 생겼는지와 train_log.txt·moons_pred.png 의 수정 시각이 c6 때 그대로인지 본다.

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -m pytest --version` — 1단계 출력에 파이썬 판(3.14 로 시작)·matplotlib·scikit-learn 판이 있고, `python -m pytest --version` 이 돌았는가
- `Compare-Object (Get-Content -Encoding UTF8 autograd\engine.py) (Get-Content -Encoding UTF8 autograd\engine_overwrite.py)` — gradients_by_hand 폴더에서 `Compare-Object (Get-Content -Encoding UTF8 autograd\engine.py) (Get-Content -Encoding UTF8 autograd\engine_overwrite.py)` 를 치면 양쪽에서 `+=` …
- `git log --oneline` — 커밋 해시가 `git log --oneline` 에 있고, `git ls-files` 에 .pytest_cache 와 __pycache__ 가 없으며, requirements.txt 에 pytest 줄이 있는가
- `git ls-files` — 커밋 해시가 `git log --oneline` 에 있고, `git ls-files` 에 .pytest_cache 와 __pycache__ 가 없으며, requirements.txt 에 pytest 줄이 있는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Get-ChildItem autograd` — 파일 이름이 `test_` 로 시작하는지, 함수 이름이 `test_` 로 시작하는지(S3464), `Get-ChildItem autograd` 로 파일이 `test_engine.py.txt` 처럼 .txt 가 붙어 저장되지 않았는지 본다.
