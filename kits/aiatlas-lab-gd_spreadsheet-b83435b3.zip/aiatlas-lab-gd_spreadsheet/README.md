# 스프레드시트로 경사하강법 한 걸음씩 — 코드 없이 직선 하나 맞추기

AI 아틀라스 앱의 실습 `lab.c.lab.gd_spreadsheet`(L1 · 약 2시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 gd_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 폴더에 gd_sheet.xlsx(또는 .ods) + capture_lr_0.05.png + capture_lr_0.3.png + capture_lr_0.5.png + capture_check.png.
3. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 PC · 스프레드시트 프로그램 하나 — Excel 이 있으면 그대로 쓰고, 없으면 무료·오픈 소스인 LibreOffice 의 Calc 를 설치한다(S3427). 내려받기 쪽(S3426)에서 그때의 최근 안정 판을 받는다. 어느 쪽이든 프로그램의 정보(About) 창에 뜨는 판 번호를 보고서 첫머리에 적는다 — 이것이 이 실습의 판 고정이다
- 코드·설치 명령·계정·인터넷 없음 — 프로그램을 설치한 뒤에는 오프라인으로 끝난다
- 앞 노드 세 레슨(손실 함수 · 미분과 기울기(필요분) · 경사하강법)을 읽은 상태 — 평균 제곱 오차, '살짝 밀어 보고 재기', '새 파라미터 = 지금 파라미터 − 학습률 × 기울기' 세 가지를 이 실습에서 칸으로 옮긴다
- 화면 캡처 도구(Windows 기본 캡처 도구면 된다)와 보고서를 쓸 메모장 등 글 편집기

## 들어 있는 파일
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.gd_spreadsheet` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
