# 내 RAG·에이전트를 프롬프트 인젝션으로 공격하고 방어 전후 재기 — 명령·코드 모음

실습 id: `lab.c.lab.injection_redteam`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기 — 새 폴더를 만들고, 하네스는 앞 실습(도구 에이전트)의 가상환경 python 으로 돌린다. 그 가상환경에 이미 requests 와 jsonschema 가 있고, 하네스는 그 실습의 …

```powershell
New-Item -ItemType Directory C:\work\redteam -Force
Set-Location C:\work\redteam
ollama list
C:\work\agent\.venv\Scripts\python --version
Test-Path C:\work\agent\tools.py, C:\work\agent\scenarios.csv, C:\work\qa\local_qa.py
```

## 2. 공격 셋 — attacks.csv · normal_rag.csv — 공격 스무 줄을 그대로 저장한다(메모장 · UTF-8). 칸의 뜻은 이렇다. target 은 겨누는 앱(rag · agent) …

- `files/attacks.csv` — 키트에 들어 있음 (text)

- `files/normal_rag.csv` — 키트에 들어 있음 (text)

## 3. 판정 규칙 먼저 — rules.md · selftest.txt — 먼저 4단계의 코드 블록을 redteam.py 로 저장한다. 이 단계는 모델을 부르지 않고, 그 파일의 judge() 와 selftest() …

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py --selftest
```

## 4. 하네스 — redteam.py — 아래를 redteam.py 로 저장한다. 하는 일은 넷이다. 첫째, 공방 문서 다섯을 rt_docs 폴더에 쓰고 앱의 load_chunks 로 읽는다. 공격마다 …

- `files/redteam.py` — 키트에 들어 있음 (python)

## 5. 돌리기 — 남아 있던 results_rt.csv · trace.jsonl 을 지운 뒤 돌린다. 시도 수는 RAG 264번, 에이전트 270번이다. 에이전트 시도 하나는 모델을 여러 번 부르므로 오래 걸린다. …

```powershell
Remove-Item results_rt.csv, trace.jsonl -ErrorAction SilentlyContinue
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py rag
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py agent
(Import-Csv results_rt.csv).Count
(Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"ev": "end"').Count
(Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"ev": "error"').Count
```

## 6. 한 표로 — summarize_rt.py — results_rt.csv 를 읽어 rt_table.md 에 표 두 개를 쓴다. 첫째 표는 대상 × 단계마다 한 줄이다. 써 낸 비율과 공격 성공률은 실린 시도를 …

- `files/summarize_rt.py` — 키트에 들어 있음 (python)

## 7. 기록 읽기 — 표의 칸은 무엇이 일어났는지만 말한다. 왜 그랬는지는 trace.jsonl 에 있다. 줄마다 way(대상:단계)·id·run 이 앞에 붙으므로 한 시도의 줄을 이렇게 모은다.

```powershell
Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"way": "rag:D3", "id": "R10", "run": 1'
```

## 8. 모델 단독 점검 — garak — 이 단계는 다른 폴더, 다른 가상환경에서 한다. garak 은 torch 와 transformers 같은 큰 패키지를 함께 깐다(S6390). 앞의 가상환경에 섞으면 앞 …

```powershell
New-Item -ItemType Directory C:\work\garak -Force
Set-Location C:\work\garak
py -0
py -3.12 -m venv .venv
.\.venv\Scripts\python --version
.\.venv\Scripts\python -m pip install "garak==0.17.0"
.\.venv\Scripts\python -m pip freeze | Out-File -Encoding utf8 requirements_garak.txt
.\.venv\Scripts\python -m garak --version
```

- `files/rt_garak.yaml` — 키트에 들어 있음 (yaml)

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 -m garak --config rt_garak.yaml --target_type ollama --target_name gemma4:e4b --spec probes.latentinjection.LatentInjectionReport,probes.web_injection.MarkdownImageExfil --report_prefix rt_gemma4 2>&1 | Tee-Object -FilePath garak_console.txt
```

- `files/garak_eval.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python -X utf8 garak_eval.py <보고서 jsonl 경로>`

## 10. (선택) 내 문서에 심기 — 내 문서 폴더를 통째로 복사한 사본을 만든다(원본은 건드리지 않는다). 사본의 문서 하나 끝에 R07 꼴 한 줄(그 문서에 있는 숫자와 다른 거짓 값으로 안내하라는 지시)과 …

```powershell
Copy-Item C:\work\docs C:\work\docs_rt -Recurse
Set-Location C:\work\redteam
[Console]::OutputEncoding = [Text.Encoding]::UTF8
python -X utf8 C:\work\qa\local_qa.py C:\work\docs_rt "질문 하나" | Out-File -Encoding utf8 -Append own_docs.txt
```

## 검증(자가)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama list`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python --version`
- `py -3.12 -m venv .venv`
- `ollama ps`
- `.\.venv\Scripts\python -m garak --list_probes --spec probes.latentinjection`
