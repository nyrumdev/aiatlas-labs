# 내 RAG·에이전트를 프롬프트 인젝션으로 공격하고 방어 전후 재기

AI 아틀라스 앱의 실습 `lab.c.lab.injection_redteam`(L3 · 약 7시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — redteam_report.md(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c1:~c7: 줄 · 앱에 내는 파일 · 64KiB 이하) + redteam 폴더(attacks.csv · normal_rag.csv · rules.md · redteam.py · summarize_rt.py · selftest.txt · rt_docs/ · results_rt.csv · trace.jsonl · rt_table.md) + garak 폴더(requirements_garak.txt · rt_garak.yaml · garak_console.txt · garak_eval.py · garak_table.md).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — 이 과정의 기준 PC 는 RTX 4070 Ti 12GB 지만 CPU 로 돌아도 이 실습은 끝까지 간다(느린 숫자도 표의 값이다)
- [실습·통합] 단일 호출 vs 워크플로 vs 에이전트 — 같은 시나리오 셋으로 견주기(에이전트 레슨 4편 직접 해 보기 통합)를 마친 폴더 그대로 — tools.py · ways.py · run.py · scenarios.csv · lessons 폴더의 네 파일 · 가상환경(requests·jsonschema). 이 실습의 하네스는 그 가상환경의 python 으로 돈다
- [실습] 로컬 QA 앱 만들기의 local_qa.py — 청킹(load_chunks)·검색(search)·창 크기(NUM_CTX)를 그대로 불러 쓴다. 검색을 임베딩으로 바꿨다면 search 가 (점수, 조각) 목록을 돌려주는지 먼저 확인한다
- Ollama 와 gemma4:e4b — 앞 실습에서 '이 PC' 로 확인한 그 태그 하나만 쓴다(S08). 이름에 cloud 가 붙은 태그는 남의 서버에서 돌므로 쓰지 않는다
- garak 단계용 두 번째 가상환경 — 파이썬 3.11~3.13(garak 0.17.0 은 3.11 이상을 요구하고, 패키지 분류표에는 3.11·3.12·3.13 을 적는다 · S6381 · S6390). garak 은 torch·transformers 같은 큰 패키지를 함께 깔므로 앞의 가상환경과 섞지 않는다(S6390)

## 들어 있는 파일
- `files/attacks.csv`
- `files/normal_rag.csv`
- `files/redteam.py`
- `files/summarize_rt.py`
- `files/rt_garak.yaml`
- `files/garak_eval.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.injection_redteam` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
