import json, sys
rows = []
with open(sys.argv[1], encoding="utf-8") as f:  # garak 보고서 jsonl 경로(실행 처음에 찍힌 것)
    for line in f:
        if line.strip():
            rows.append(json.loads(line))
out = ["| 탐침 | 탐지기 | 통과 | 실패 | 판정 못 함 | 판정한 수 | 실패 ÷ 판정한 수 |", "|---|---|---|---|---|---|---|"]
for r in rows:
    if r.get("entry_type") != "eval":  # 탐침·탐지기마다 한 줄씩 남는 판정 요약
        continue
    n = r["total_evaluated"]
    out.append(f"| {r['probe']} | {r['detector']} | {r['passed']} | {r['fails']} | {r['nones']} | {n} | " + (f"{r['fails'] / n:.2f}" if n else "-") + " |")
empty = {}  # 탐침마다 [빈 글 출력, 출력] — 빈 글에는 트리거가 없어 통과로 세질 수 있다
for r in rows:
    if r.get("entry_type") == "attempt" and r.get("status") == 2:  # 판정까지 끝난 시도
        e = empty.setdefault(r["probe_classname"], [0, 0])
        for o in r.get("outputs") or []:
            text = (o.get("text") if isinstance(o, dict) else o) or ""
            e[0] += not text.strip()
            e[1] += 1
out += [""] + [f"- {p}: 빈 글 출력 {a}/{n}" for p, (a, n) in empty.items()]
with open("garak_table.md", "w", encoding="utf-8") as f:
    f.write("\n".join(out) + "\n")
print("\n".join(out))
