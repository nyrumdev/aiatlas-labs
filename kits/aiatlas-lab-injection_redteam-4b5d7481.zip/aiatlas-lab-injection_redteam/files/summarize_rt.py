import csv
from collections import defaultdict
with open("results_rt.csv", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
with open("attacks.csv", encoding="utf-8-sig", newline="") as f:
    tech = {a["id"]: a["technique"] for a in csv.DictReader(f)}
NAME = {"0": "D0 기준", "1": "D1 +동작 제한", "2": "D2 +분리 표시", "3": "D3 +출력 검사", "4": "D4 +사람 승인"}
s = lambda rs, col: sum(int(r[col]) for r in rs)
rate = lambda num, den: f"{num / den:.2f}" if den else "-"
def per_run(rs, col, base):  # 회차 0·1·2 를 따로 센 비율 — 같은 단계가 회차마다 얼마나 흔들리나
    return "/".join(rate(s([r for r in rs if r["run"] == k], col), len([r for r in base if r["run"] == k])) for k in "012")
by = defaultdict(list)
for r in rows:
    by[(r["target"], r["stage"])].append(r)
out = ["| 대상 | 단계 | 공격 시도 | 실린 시도 | 써 낸 비율 | 공격 성공률 | 회차별 공격 성공률 | 공격 중 과제 성공률 | 정상 정답률 | 회차별 정상 정답률 | 평균 모델 호출 | 평균 초 |",
       "|---|---|---|---|---|---|---|---|---|---|---|---|"]
for (target, stage), rs in sorted(by.items()):
    at = [r for r in rs if r["set"] == "attack"]
    lo = [r for r in at if r["loaded"] == "1"]  # 공격 글이 모델에게 실린 시도만 분모로
    no = [r for r in rs if r["set"] == "normal"]
    out.append(f"| {target} | {NAME[stage]} | {len(at)} | {len(lo)} | {rate(s(lo, 'wrote'), len(lo))} | {rate(s(lo, 'hit'), len(lo))} | "
               f"{per_run(lo, 'hit', lo)} | {rate(s(at, 'task_ok'), len(at))} | {rate(s(no, 'task_ok'), len(no))} | {per_run(no, 'task_ok', no)} | "
               f"{s(rs, 'llm') / len(rs):.1f} | {sum(float(r['sec']) for r in rs) / len(rs):.1f} |")
stages = sorted({r["stage"] for r in rows})
out += ["", "| 공격 | 기법 | " + " | ".join(NAME[k] for k in stages) + " |", "|---|---|" + "---|" * len(stages)]
for aid in sorted({r["id"] for r in rows if r["set"] == "attack"}):
    cells = []
    for k in stages:
        rs = [r for r in rows if r["id"] == aid and r["stage"] == k and r["set"] == "attack"]
        lo = [r for r in rs if r["loaded"] == "1"]  # 성공 수도 실린 시도 안에서만
        cells.append(f"{s(lo, 'hit')}/{len(lo)}" if rs else "해당 없음")
    out.append(f"| {aid} | {tech[aid]} | " + " | ".join(cells) + " |")
with open("rt_table.md", "w", encoding="utf-8") as f:
    f.write("\n".join(out) + "\n")
print("\n".join(out))
