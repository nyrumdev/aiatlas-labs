# 한국어 BPE 토크나이저를 직접 짜고 Gemma 4 토크나이저와 비교하기

AI 아틀라스 앱의 실습 `lab.c.lab.tokenizer_build`(L2 · 약 4시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰이나 PC)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱 제출 = tokenizer_report.md 파일 하나 · 같은 C:\work\ai-lab\tokenizer_build 폴더에 my_bpe.py + check_roundtrip.py + sweep.py + gemma_cases.py + longest_tokens.py + roundtrip.csv + sweep.csv + sweep.png + sweep_info.json + tok_4096.model/.vocab(개인 글로 학습했다면 커밋하지 않음) + gemma_cases.csv (선택 과제를 했다면 hf_sweep.csv · sweep_other.*).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- 앞 노드 [실습] AI 실습 PC 세우기에서 만든 C:\work\ai-lab 저장소와 그 안의 가상환경 .venv(파이썬 3.14 · matplotlib 포함) — 이 실습은 GPU 를 쓰지 않는다(파이썬만으로 CPU 에서 돈다)
- git — minbpe 저장소를 내려받아 커밋을 고정하는 데 쓴다(앞 노드에서 이름·메일까지 설정한 그대로)
- 인터넷 — 패키지 네 개(tokenizers·huggingface-hub·regex·tiktoken)와 minbpe 저장소, Gemma 4 토크나이저 파일(tokenizer.json · 약 32MB · S5020)을 처음 한 번 받는 데만 쓴다. Gemma 4 저장소는 로그인·동의 절차 없이 받을 수 있다(S6303). 내 글은 PC 밖으로 보내지 않는다 — 토크나이저 파일만 받아 오고 자르기는 이 PC 의 파이썬 안에서 한다
- 내가 쓴 한국어 글 — 학습용 3만 자 이상과, 학습에 넣지 않을 다른 글 3천 자 이상(메모·일기·블로그·업무 문서에서 이름·연락처 같은 개인정보를 뺀 것). 모자라면 한국어 위키백과 문서 본문을 복사해 보태고 문서 이름을 적어 둔다 — 위키백과 글은 CC BY-SA 4.0·GFDL 로 공개된 글이다(S3529)
- 메모장 — 글을 UTF-8 로 저장하고 보고서를 쓰는 데 쓴다

## 들어 있는 파일
- `files/my_bpe.py`
- `files/check_roundtrip.py`
- `files/sweep.py`
- `files/longest_tokens.py`
- `files/gemma_cases.py`
- `files/hf_bpe.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.tokenizer_build` in the AI Atlas app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
