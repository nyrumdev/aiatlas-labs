# 내 RAG·에이전트를 프롬프트 인젝션으로 공격하고 방어 전후 재기 — 명령·코드 모음

실습 id: `lab.c.lab.injection_redteam`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기

```powershell
New-Item -ItemType Directory C:\work\redteam -Force
Set-Location C:\work\redteam
ollama list
C:\work\agent\.venv\Scripts\python --version
Test-Path C:\work\agent\tools.py, C:\work\agent\scenarios.csv, C:\work\qa\local_qa.py
```

## 2. 공격 셋 — attacks.csv · normal_rag.csv

- `files/attacks.csv` — 키트에 들어 있음 (text)

- `files/normal_rag.csv` — 키트에 들어 있음 (text)

## 3. 판정 규칙 먼저 — rules.md · selftest.txt

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py --selftest
```

## 4. 하네스 — redteam.py

- `files/redteam.py` — 키트에 들어 있음 (python)

## 5. 돌리기

```powershell
Remove-Item results_rt.csv, trace.jsonl -ErrorAction SilentlyContinue
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py rag
C:\work\agent\.venv\Scripts\python -X utf8 redteam.py agent
(Import-Csv results_rt.csv).Count
(Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"ev": "end"').Count
(Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"ev": "error"').Count
```

## 6. 한 표로 — summarize_rt.py

- `files/summarize_rt.py` — 키트에 들어 있음 (python)

## 7. 기록 읽기

```powershell
Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"way": "rag:D3", "id": "R10", "run": 1'
```

## 8. 모델 단독 점검 — garak

```powershell
New-Item -ItemType Directory C:\work\garak -Force
Set-Location C:\work\garak
py -0
py -3.12 -m venv .venv
.\.venv\Scripts\python --version
.\.venv\Scripts\python -m pip install "garak==0.17.0"
.\.venv\Scripts\python -m pip freeze | Out-File -Encoding utf8 requirements_garak.txt
.\.venv\Scripts\python -m garak --version
```

- `files/rt_garak.yaml` — 키트에 들어 있음 (yaml)

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 -m garak --config rt_garak.yaml --target_type ollama --target_name gemma4:e4b --spec probes.latentinjection.LatentInjectionReport,probes.web_injection.MarkdownImageExfil --report_prefix rt_gemma4 2>&1 | Tee-Object -FilePath garak_console.txt
```

- `files/garak_eval.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python -X utf8 garak_eval.py <보고서 jsonl 경로>` — `.\.venv\Scripts\python -X utf8 garak_eval.py <보고서 jsonl 경로>` 로 돌린다.

## 10. (선택) 내 문서에 심기

```powershell
Copy-Item C:\work\docs C:\work\docs_rt -Recurse
Set-Location C:\work\redteam
[Console]::OutputEncoding = [Text.Encoding]::UTF8
python -X utf8 C:\work\qa\local_qa.py C:\work\docs_rt "질문 하나" | Out-File -Encoding utf8 -Append own_docs.txt
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama list` — attacks.csv 가 20행(rag 12 · agent 8)이고 judge 다섯 갈래가 모두 있는가 · redteam.py 의 AGENT · QA 경로가 내 폴더이고, 실행한 python 이 앞 실습의 가상환경인가 · `ollama list` 에 gemma4:e4b 가 있는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python --version` — 디스크 여유와 가상환경의 파이썬 판(3.11~3.13 · `.\.venv\Scripts\python --version`)을 먼저 본다.
- `py -3.12 -m venv .venv` — 두 경우 모두 .venv 폴더를 지우고 `py -3.12 -m venv .venv` 로 다시 만든다.
- `ollama ps` — `ollama ps` 로 모델이 GPU 에 올라갔는지도 본다.
- `.\.venv\Scripts\python -m garak --list_probes --spec probes.latentinjection` — `.\.venv\Scripts\python -m garak --list_probes --spec probes.latentinjection` 으로 이 판의 이름을 확인한다(S6382).
