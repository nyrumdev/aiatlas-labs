# 추론 최적화 실험 + 벤치 리포트 — 명령·코드 모음

실습 id: `lab.c.lab.inference_opt_report`

앱 실습 화면의 절차와 같은 차례입니다.

## 2. 변수 축 결정

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama show --parameters <태그>` — 설정마다 `ollama show --parameters <태그>` 에 `draft_num_predict` 줄이 있는지 보고, 설정 표의 드래프터 상태 칸에 "있음·끔(0)" 이나 "없음" 처럼 적는다.

## 3. 장치에 들어가는 조합만 고른다

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama ps` — 설정마다 첫 실행 뒤 `ollama ps` 를 실행해 PROCESSOR 열을 설정 표에 적는다 — 한 실험의 모든 설정이 같은 값(전부 `100% GPU` 또는 전부 CPU)이어야 비교가 성립한다.

## 5. 측정 스크립트

```python
import csv, datetime, requests
URL = "http://127.0.0.1:11434/api/generate"  # 숫자 주소 — localhost 는 PC 에 따라 호출마다 시간이 붙는다
def now():  # nvidia-smi timestamp 칸과 같은 현지 시각·밀리초 꼴
    return datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f")[:-3]
# bench_raw.csv 열: 설정·프롬프트·회차·첫 토큰 시간(초)·프리필 tok/s·디코드 tok/s·입력·캐시·출력 토큰·적재(초)·시작·끝
# (최고 메모리 열은 7단계에서 시작~끝 사이 최대값으로 채운다)
def measure(cfg, p, rnd, writer):  # 요청 1회 → 1행 · 예외는 부르는 쪽이 잡아 bench_failures.csv 로(8단계)
    head = f"[회차 {rnd}]\n"  # 회차마다 다른 머리 — 캐시 함정 막기(6단계 · 워밍업은 회차 0)
    body = {"model": cfg["tag"], "prompt": head + p["prompt"], "stream": False,
            "options": {"num_ctx": cfg["num_ctx"], "temperature": 0, "seed": 42,
                        "num_predict": 256, "draft_num_predict": 0}}  # 생성 설정은 예시 값 — 환경 고정 절에 적은 값으로
    start = now()
    r = requests.post(URL, json=body, timeout=600).json()
    end = now()
    if "error" in r:
        raise RuntimeError(r["error"])
    n_in, n_out = r["prompt_eval_count"], r["eval_count"]
    cached = r.get("prompt_eval_cached_count", 0)  # 값이 없으면 칸이 빠진다 — 그때는 0
    pe = r["prompt_eval_duration"] / 1e9
    writer.writerow([cfg["id"], p["id"], rnd, round(pe, 4), round((n_in - cached) / pe, 2),
                     round(n_out / (r["eval_duration"] / 1e9), 2), n_in, cached, n_out,
                     round(r.get("load_duration", 0) / 1e9, 3), start, end])
```

## 6. 캐시 함정 막기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama stop` — 바퀴마다 `ollama stop` 으로 내리고 목록 밖 프롬프트로 워밍업을 다시 하는 방법도 실측에서 재사용 0 이었다.

## 7. 메모리 최고치

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `nvidia-smi --query-gpu=timestamp,memory.used --format=csv,noheader,nounits -lms 200 -f mem_log.csv` — NVIDIA GPU 라면 측정 동안 별도 창에서 `nvidia-smi --query-gpu=timestamp,memory.used --format=csv,noheader,nounits -lms 200 -f mem_log.csv` 를 돌려 0.2초마다 시각과 사용량(MiB)을 파일로 …
- `ollama ps` — `ollama ps` 의 SIZE 열은 판에 따라 가중치 일부를 빼고 셀 수 있어 참고로만 적는다 — 0.40.13 에서 e2b q8_0 의 SIZE 는 2.7GB 였지만 로그는 GPU 2,342MiB + 시스템 2,788MiB 였다.

## 8. 실행

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama stop <태그>` — 설정 사이에 모델을 내려 메모리를 비운다(`ollama stop <태그>`).

## 13. (선택) 스펙큘러티브 디코딩(S30·S103) 또는 Gemma 4 의 MTP 드래프터(S05)를 켜고 끄는 축을 추가한다.

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama show --parameters` — Ollama 에서는 드래프터가 든 q4_K_M 태그 하나로 `draft_num_predict` 0(끔)과 태그 기본값(켬 — `ollama show --parameters` 로 본 값)을 두 설정으로 잰다(S7800).
- `ollama -v` — 쓴 Ollama 버전(`ollama -v`)과 확인한 문서 주소·날짜를 남긴다.

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama ps` — `ollama ps` 의 PROCESSOR 가 설정마다 같은지 보고, 다르면 더 작은 모델의 양자화 쌍으로 바꾼다.
