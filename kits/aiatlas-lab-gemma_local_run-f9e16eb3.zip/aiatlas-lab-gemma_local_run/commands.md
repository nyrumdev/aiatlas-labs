# Gemma 4를 내 PC에서 돌리기 — 명령·코드 모음

실습 id: `lab.c.lab.gemma_local_run`

앱 실습 화면의 절차와 같은 차례입니다.

## 1. Ollama 설치(공식 사이트의 Windows 설치 파일, S361) → PowerShell에서 `ollama --version` (c1). 이 절차의 칸 이름과 숫자는 Ollama 0.40.13 에서 확인한 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama --version`

## 2. `ollama pull gemma4:e4b` 로 먼저 내려받는다(Windows PC 기준 6.6GB · S08). `ollama ps` 에 gemma4:e4b 가 보이면 `ollama stop …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama pull gemma4:e4b`
- `ollama ps`
- `ollama stop gemma4:e4b`
- `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits`
- `ollama run gemma4:e4b --verbose --think=false "토큰이 뭐야?"`
- `ollama run`

## 4. 답이 끝난 뒤에도 모델은 한동안 메모리에 남으므로(기본 5분 · S131) 곧바로 메모리를 잰다. 메모리 칸은 두 몫으로 나눠 채운다. GPU 몫 = 지금 `nvidia-smi …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits`
- `ollama serve`
- `Select-String -Path "$env:LOCALAPPDATA\Ollama\server.log" -Pattern "model buffer size" | Select-Object -Last 4`
- `ollama ps`
- `ollama list`

## 6. (선택) `ollama stop gemma4:e4b` 로 e4b 를 내리고 모델 없을 때의 GPU 사용량을 다시 잰 뒤 `ollama run gemma4:12b --verbose --think=false …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama stop gemma4:e4b`
- `ollama run gemma4:12b --verbose --think=false "토큰이 뭐야?"`
- `ollama show --verbose gemma4:e4b`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama list`
- `ollama ps`
- `ollama run gemma4:e4b --think=false`
- `ollama serve`
- `ollama stop`
- `ollama stop gemma4:e4b`
