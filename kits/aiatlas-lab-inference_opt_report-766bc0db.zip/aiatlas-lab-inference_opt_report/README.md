# 추론 최적화 실험 + 벤치 리포트

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.inference_opt_report`(L4 · 약 8시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
3. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 inference_opt_report.md 파일 하나를 제출(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c1:~c6: 줄 · 폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 폴더에 prompts_10.jsonl + bench_raw.csv + bench_failures.csv + bench_spread.csv + bench_graph.png + 측정 스크립트 + mem_log.csv.
4. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64(PC) — GPU 유무 무관(CPU 실행도 통과 조건 · 단 한 실험 안의 모든 설정은 같은 장치에서)
- Ollama 0.30.9 이상 설치(지금 q4_K_M 태그가 요구하는 판 · 이 절차의 기준 판은 Ollama 0.40.13 이다 — 판이 바뀌면 숫자·칸 이름을 `ollama --version` 과 실제 출력으로 다시 확인한다) + 같은 크기 gemma4 모델의 양자화 태그 2개 이상(예: gemma4:e2b-it-q4_K_M · gemma4:e2b-it-q8_0 — q4_K_M 태그에는 드래프터가 함께 들어 있어 절차 2 대로 끄고 잰다 · S08) 또는 llama.cpp 빌드 + 같은 모델의 GGUF 양자화 파일 2개 이상(S51)
- Python 3.11+ — pip install requests psutil pandas matplotlib(측정 요청 · CPU 실행의 메모리 조회 · 표 묶기 · 그래프)
- NVIDIA GPU 라면 nvidia-smi(드라이버에 포함) — 메모리 최고치 폴링용
- 실험 중 다른 무거운 프로그램을 끌 수 있는 시간대(측정 흩어짐을 줄이기 위해)
- lab.c.lab.gemma_local_run 통과 — 첫 토큰 시간·초당 토큰·메모리 읽는 법 숙지
- c.api.local_http(로컬 HTTP API 호출) 레슨 — Python requests 로 Ollama 에 JSON 요청을 보내고 응답의 prompt_eval_count·eval_count 를 읽는 법, 요청 options.num_ctx 로 창 크기를 정하는 법 숙지

## 들어 있는 파일
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.inference_opt_report` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
