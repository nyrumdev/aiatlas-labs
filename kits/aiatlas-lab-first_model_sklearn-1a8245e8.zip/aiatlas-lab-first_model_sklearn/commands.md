# 표데이터 첫 모델을 끝까지 — 기준선·파이프라인·교차검증·잠근 테스트·집단별 오류 — 명령·코드 모음

실습 id: `lab.c.lab.first_model_sklearn`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 판 맞추기

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install "scikit-learn==1.9.1" "pandas==3.0.6"
mkdir first_model
cd first_model
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -m pip freeze | Out-File -Encoding utf8 ..\requirements.lock.txt` — requirements.lock.txt 는 `python -m pip freeze | Out-File -Encoding utf8 ..\requirements.lock.txt` 로 다시 뽑는다.
- `pip freeze` — `pip freeze` 는 설치된 그대로를 요구사항 형식으로 적을 뿐이다(S3454).

## 3. 기준선과 5겹 교차검증

- `files/part1_baseline_cv.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python part1_baseline_cv.py` — 기준선과 5겹 교차검증 — 아래를 `part1_baseline_cv.py` 로 저장하고 `python part1_baseline_cv.py` 로 실행한다.

## 5. 누출 재현

- `files/part1_leakage.py` — 키트에 들어 있음 (python)

## 6. 1부 보고서와 커밋

```powershell
cd C:\work\ai-lab
git add first_model requirements.txt requirements.lock.txt
git commit -m "first_model 1부: 기준선·교차검증·문턱값·누출 재현"
git rev-parse HEAD
git status
```

```powershell
git add first_model\first_model_report.md
git commit -m "first_model 1부 보고서: 커밋 해시"
git status
```

## 7. 데이터를 판으로 받고, 모델보다 먼저 테스트를 잠근다

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
cd first_model
```

- `files/part2_common.py` — 키트에 들어 있음 (python)

- `files/part2_lock_split.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add first_model\part2_common.py first_model\part2_lock_split.py first_model\adult_lock.json first_model\adult_test_index.txt
git commit -m "first_model 2부: 테스트 행 잠금"
git rev-parse HEAD
cd first_model
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python part2_lock_split.py` — `python part2_lock_split.py` 로 한 번 실행한다.

## 8. 두 모델을 같은 폴드에서 비교

- `files/part2_compare.py` — 키트에 들어 있음 (python)

## 9. 탐색하고, 잠근 테스트에서 딱 한 번 잰다

- `files/part2_search_test.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add first_model\part2_common.py first_model\part2_compare.py first_model\part2_cv_compare.csv first_model\part2_search_test.py
git commit -m "first_model 2부: 측정 전 — 고른 모델과 탐색 범위"
git rev-parse HEAD
git status --short
```

```powershell
cd first_model
python part2_search_test.py
```

## 11. 2부 보고서와 커밋

```powershell
cd C:\work\ai-lab
git add first_model
git commit -m "first_model 2부: 비교·탐색·잠근 테스트·집단별 오류"
git rev-parse HEAD
git diff 잠금해시 HEAD -- first_model/adult_test_index.txt
git diff 측정전해시 HEAD -- first_model/part2_common.py first_model/part2_search_test.py
git log --oneline -- first_model/part2_test.json
```

```powershell
git add first_model\first_model_report.md
git commit -m "first_model 2부 보고서: 커밋 해시"
git status
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git log --format=%H` — … 줄이 1부 첫 출력의 판과 같고 맨 위에 색인 줄이 있는가 · c5 해시가 `git log --format=%H` 출력에 그대로 있는가(`git log --oneline` 은 해시를 앞부분만 줄여 찍으므로, 그 줄임 해시가 c5 해시의 앞부분과 같은지로 봐도 된다) …
- `git log --oneline` — … 줄이 1부 첫 출력의 판과 같고 맨 위에 색인 줄이 있는가 · c5 해시가 `git log --format=%H` 출력에 그대로 있는가(`git log --oneline` 은 해시를 앞부분만 줄여 찍으므로, 그 줄임 해시가 c5 해시의 앞부분과 같은지로 봐도 된다) …
- `git status` — … log --format=%H` 출력에 그대로 있는가(`git log --oneline` 은 해시를 앞부분만 줄여 찍으므로, 그 줄임 해시가 c5 해시의 앞부분과 같은지로 봐도 된다) · 보고서를 다시 커밋한 뒤 마지막 `git status

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cd C:\work\ai-lab` — `cd C:\work\ai-lab` 로 저장소 맨 위에 가서 `git checkout 잠금해시 -- first_model/adult_test_index.txt` 로 잠금 커밋의 판을 되돌리고, `cd first_model` 로 돌아온다(git 경로는 현재 폴더 기준이다).
- `git checkout 잠금해시 -- first_model/adult_test_index.txt` — `cd C:\work\ai-lab` 로 저장소 맨 위에 가서 `git checkout 잠금해시 -- first_model/adult_test_index.txt` 로 잠금 커밋의 판을 되돌리고, `cd first_model` 로 돌아온다(git 경로는 현재 폴더 기준이다).
- `cd first_model` — `cd C:\work\ai-lab` 로 저장소 맨 위에 가서 `git checkout 잠금해시 -- first_model/adult_test_index.txt` 로 잠금 커밋의 판을 되돌리고, `cd first_model` 로 돌아온다(git 경로는 현재 폴더 기준이다).
