# 한국어 BPE 토크나이저를 직접 짜고 Gemma 4 토크나이저와 비교하기 — 명령·코드 모음

실습 id: `lab.c.lab.tokenizer_build`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업 폴더와 판 고정

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
mkdir tokenizer_build
cd tokenizer_build
mkdir data
python -m pip install tokenizers==0.23.3 huggingface-hub==2.2.0 regex==2026.9.29 tiktoken==0.14.0
```

```powershell
git clone https://github.com/karpathy/minbpe.git C:\work\minbpe
git -C C:\work\minbpe checkout 1acefe89412b20245db5a22d2a02001e547dc602
git -C C:\work\minbpe rev-parse HEAD
```

## 3. BPE 를 직접 짠다

- `files/my_bpe.py` — 키트에 들어 있음 (python)

**풀이** — `files/my_bpe.py` 의 빈칸을 채운 판입니다(키트 파일은 빈칸 뼈대). 내가 채운 뒤 견줄 때 봅니다.

```python
"""my_bpe.py — 바이트 단위 BPE 를 처음부터 짠다(외부 패키지 없음).

학습: 글을 UTF-8 바이트(0~255)로 바꾼 뒤, 이웃한 두 토큰 쌍을 세어
가장 많은 쌍을 새 번호(256, 257, …) 하나로 바꾸는 일을 되풀이한다.
자르기: 배운 병합 가운데 가장 먼저 배운 것부터 적용한다.
되돌리기: 토큰 번호를 바이트 묶음으로 바꿔 이어 붙인 뒤 UTF-8 로 읽는다.
"""


def count_pairs(ids):
    """이웃한 두 번호 쌍의 등장 횟수. 사전은 처음 본 순서를 기억한다."""
    counts = {}
    for left, right in zip(ids, ids[1:]):
        counts[(left, right)] = counts.get((left, right), 0) + 1
    return counts


def replace_pair(ids, pair, new_id):
    """ids 안에서 왼쪽부터 pair 가 나올 때마다 new_id 하나로 바꾼 새 목록."""
    out = []
    i = 0
    while i < len(ids):
        if i + 1 < len(ids) and ids[i] == pair[0] and ids[i + 1] == pair[1]:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return out


class MyBPE:
    def __init__(self):
        self.merges = {}                                  # (왼쪽, 오른쪽) -> 새 번호
        self.vocab = {i: bytes([i]) for i in range(256)}  # 번호 -> 바이트 묶음

    def train(self, text, vocab_size):
        if vocab_size < 256:
            raise ValueError("어휘 크기는 바이트 256개보다 작을 수 없다")
        ids = list(text.encode("utf-8"))
        for step in range(vocab_size - 256):
            counts = count_pairs(ids)
            if not counts:
                break                                     # 글이 한 토큰으로 줄었다
            best = max(counts, key=counts.get)            # 같은 횟수면 먼저 본 쌍
            new_id = 256 + step
            ids = replace_pair(ids, best, new_id)
            self.merges[best] = new_id
            self.vocab[new_id] = self.vocab[best[0]] + self.vocab[best[1]]
        return ids                                        # 학습 글을 자른 결과

    def encode(self, text):
        ids = list(text.encode("utf-8"))
        while len(ids) >= 2:
            present = count_pairs(ids)
            pair = min(present, key=lambda p: self.merges.get(p, float("inf")))
            if pair not in self.merges:
                break                                     # 남은 쌍 중 배운 병합이 없다
            ids = replace_pair(ids, pair, self.merges[pair])
        return ids

    def decode(self, ids):
        raw = b"".join(self.vocab[i] for i in ids)
        return raw.decode("utf-8", errors="replace")


if __name__ == "__main__":
    bpe = MyBPE()
    bpe.train("김밥 김치 김치전 김밥 김치", 256 + 5)
    for pair, new_id in bpe.merges.items():
        print(new_id, pair, bpe.vocab[new_id])       # 배운 순서대로 — 새 번호 · 붙인 쌍 · 담은 바이트
    ids = bpe.encode("김치김밥")
    print(ids, bpe.decode(ids) == "김치김밥")
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python my_bpe.py` — 빈칸을 채웠으면 `python my_bpe.py` 로 맨 아래 작은 시험을 돌려 끝 줄이 True 인지 보고, 바로 4단계 check_roundtrip.py 로 minbpe 와 대조한다.

## 4. minbpe 와 대조하고 되돌리기를 시험한다

- `files/check_roundtrip.py` — 키트에 들어 있음 (python)

```powershell
python check_roundtrip.py --minbpe C:\work\minbpe --vocab 512
```

## 5. 어휘 크기를 훑고 Gemma 4 와 견준다

- `files/sweep.py` — 키트에 들어 있음 (python)

```powershell
python sweep.py --minbpe C:\work\minbpe
```

## 7. 어휘를 들여다본다

- `files/longest_tokens.py` — 키트에 들어 있음 (python)

```powershell
python longest_tokens.py C:\work\minbpe tok_4096.model
```

## 8. Gemma 4 와 사례별로 견준다

- `files/gemma_cases.py` — 키트에 들어 있음 (python)

```powershell
python gemma_cases.py --minbpe C:\work\minbpe --model tok_4096.model
```

## 10. (선택) 같은 글로 더 큰 어휘까지

- `files/hf_bpe.py` — 키트에 들어 있음 (python)

```powershell
python hf_bpe.py
```

## 11. (선택) 다른 갈래의 새 글

```powershell
python sweep.py --minbpe C:\work\minbpe --heldout data\heldout_other.txt --out sweep_other
```

## 12. 보고서와 커밋

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Add-Content C:\work\ai-lab\.gitignore "tokenizer_build/data/", "tokenizer_build/tok_*", "tokenizer_build/hf_bpe_*.json"` — 내 글이 개인적인 글이면 커밋하기 전에 `Add-Content C:\work\ai-lab\.gitignore "tokenizer_build/data/", "tokenizer_build/tok_*", "tokenizer_build/hf_bpe_*.json"` 로 글과 학습한 토크나이저 …
- `git add tokenizer_build` — 그다음 ai-lab 저장소에서 `git add tokenizer_build`, `git commit -m "BPE 토크나이저 실습"` 으로 올리고 `git status` 가 깨끗한지 본다.
- `git commit -m "BPE 토크나이저 실습"` — 그다음 ai-lab 저장소에서 `git add tokenizer_build`, `git commit -m "BPE 토크나이저 실습"` 으로 올리고 `git status` 가 깨끗한지 본다.
- `git status` — 그다음 ai-lab 저장소에서 `git add tokenizer_build`, `git commit -m "BPE 토크나이저 실습"` 으로 올리고 `git status` 가 깨끗한지 본다.

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Get-FileHash data\train.txt` — … sweep_info.json 의 두 파일 sha256 이 지금 data 폴더의 파일과 같은가(`Get-FileHash data\train.txt` · `Get-FileHash data\heldout.txt` 가 내는 Hash 값과 견준다 — 기본 알고리즘이 SHA256 …
- `Get-FileHash data\heldout.txt` — … sweep_info.json 의 두 파일 sha256 이 지금 data 폴더의 파일과 같은가(`Get-FileHash data\train.txt` · `Get-FileHash data\heldout.txt` 가 내는 Hash 값과 견준다 — 기본 알고리즘이 SHA256 …
- `python my_bpe.py` — check_roundtrip.py 출력에 '순서까지 같은가 True' 와 '어긋난 사례: 없음' 이 있고, roundtrip.csv 에서 False 는 마지막 행뿐인가 · errors 를 되돌려 놓은 뒤 `python my_bpe.py` 가 다시 True 를 내는가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -X utf8 스크립트.py` — 토큰 모양을 화면에 찍는 longest_tokens.py 나 직접 고친 코드에서 이 오류가 나면 `python -X utf8 스크립트.py` 로 돌린다(S6306 · S6309).
- `python gemma_cases.py --minbpe C:\work\minbpe --model tok_2048.model` — 이후 단계의 tok_4096 은 tok_2048 로 읽고, 8단계는 `python gemma_cases.py --minbpe C:\work\minbpe --model tok_2048.model` 로 돌린다.
- `git status` — `git status` 에 data 폴더의 글(또는 개인 글로 학습한 tok_* 파일)이 보인다 → .gitignore 보다 `git add` 가 먼저였다.
- `git add` — `git status` 에 data 폴더의 글(또는 개인 글로 학습한 tok_* 파일)이 보인다 → .gitignore 보다 `git add` 가 먼저였다.
- `git rm --cached -r tokenizer_build/data` — `git rm --cached -r tokenizer_build/data` 로 기록에서만 빼고(파일은 그대로 남는다), tok_* 파일도 같은 식으로 뺀 뒤 커밋한다(S763).
