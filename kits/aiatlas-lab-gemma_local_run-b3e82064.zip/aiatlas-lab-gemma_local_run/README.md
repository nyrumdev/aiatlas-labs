# Gemma 4를 내 PC에서 돌리기

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.gemma_local_run`(L2 · 약 90분) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — gemma_local_run_report.md + capture_version.png + capture_first_response.png.
3. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10(22H2 이상)·11 x64 · PowerShell(S361)
- 디스크 여유 — gemma4:e4b 꾸러미 6.6GB(Windows PC 기준 · S08)보다 넉넉히 · c5까지 하면 gemma4:12b 8.0GB가 더 필요(합 14.6GB) · 태그 목록의 'e4b 6.6GB - 9.5GB' 같은 범위 표기는 맥용(MLX) 판까지 함께 적은 것
- 메모리 — 받을 꾸러미 크기(e4b 6.6GB · S08)를 하한으로 어림한다(총 8B×4.89비트/8 ≈ 4.9GB 계산은 이 꾸러미보다 모자란다) · 메모리가 모자라면 gemma4:e2b(4.6GB)로 대체
- Ollama 0.30.9 이상(이 모델 패키지가 요구 · S08 · c1 의 `ollama --version` 으로 확인) — 이 절차의 기준 판은 Ollama 0.40.13 이다 · 판이 바뀌면 숫자·칸 이름을 `ollama --version` 과 실제 출력으로 다시 확인한다
- NVIDIA GPU 라면 nvidia-smi(드라이버에 포함) — 메모리 칸의 GPU 몫을 재는 데 쓴다
- 인터넷(모델 다운로드 1회)

## 들어 있는 파일
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.gemma_local_run` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
