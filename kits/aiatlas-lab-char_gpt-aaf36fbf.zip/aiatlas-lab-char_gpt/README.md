# 글자 단위 작은 GPT를 처음부터 짜서 내 GPU로 학습시키기

AI 아틀라스 앱의 실습 `lab.c.lab.char_gpt`(L3 · 약 6시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\work\ai-lab\char_gpt\chargpt_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 char_gpt 폴더에 loss_curve.png + samples.txt + results.md + prepare_text.py · chargpt.py · train_chargpt.py · prepare_kowiki.py · report.py + logs 폴더(nanoGPT 로그 · 걸린 초) + runs 폴더(실행마다 config.json · history.json · best.pt · samples.txt).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — GPU 가 없으면 점검(c2)·사다리(c3)·누출(c4)은 --device cpu 를 붙여 돌릴 수 있지만 nanogpt 설정(c5·c7)은 CPU 로는 너무 오래 걸린다. 그때는 8단계 끝의 'GPU 가 없으면' 대로 nanoGPT 와 내 GPT 에 같은 줄인 걸음 수를 주고(nanoGPT 에는 --device=cpu 와 --lr_decay_iters 도 함께) 표에 그 사실을 적는다
- 앞 실습 [실습] 첫 신경망을 GPU로 학습시키기(Fashion-MNIST · 진단 점검 포함)를 마친 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch·numpy·matplotlib 이 있고, 저장소의 .gitignore 에 data/ 와 *.pt 줄이 있다
- 인터넷 — 셰익스피어 글(약 1.1MB) · 한국어 위키백과 덤프 조각 하나(약 89MB)와 체크섬 목록 · nanoGPT 저장소 · requests·tiktoken 설치에만 쓴다
- 디스크 여유 — data 폴더(덤프 조각 · 뽑은 글 · 번호 파일)와 runs 폴더(실행마다 체크포인트 · nanogpt 설정은 ladder 설정보다 모델이 훨씬 커서 파일도 크다 — 실행 첫 줄의 파라미터 수로 어림한다)
- 시간 — 단계 사다리 7회와 nanogpt 설정 3회(nanoGPT 1 · 내 GPT 영어 1 · 한국어 1)를 GPU 로 돌린다(선택 단계는 사다리 크기 실행 몇 회씩 더). 실행마다 걸린 시간이 기록되니 처음 몇 회로 남은 시간을 어림한다

## 들어 있는 파일
- `files/prepare_text.py`
- `files/chargpt.py`
- `files/train_chargpt.py`
- `files/prepare_kowiki.py`
- `files/report.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.char_gpt` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
