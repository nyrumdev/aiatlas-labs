lab_id: lab.c.lab.char_gpt

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 출처 표기
(본문 절차가 이 절에 적으라고 한 것)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 영어 데이터 — prepare_text.py 출력 두 줄(글자 수 · 어휘 크기와 그중 한글 음절 · 학습/검증 글자 수 · 가장 흔한 글자) 붙여 넣기 + data\shakespeare.pt 가 있음 + nanoGPT prepare.py 가 같은 나눔을 쓴다는 1줄 -->
c1: 
<!-- c2(필수): 점검 먼저 — runs\shakespeare_ladder_layernorm_s0_onebatch\history.json 의 summary 에서 init_check 와 onebatch_check 가 둘 다 '통과' + 그 config.json 의 started_at 이 사다리 일곱 실행보다 앞 + 그동안 검증 손실이 어떻게 움직였는지 1줄 -->
c2: 
<!-- c3(필수): 단계 사다리 — results.md 의 표 1(bigram·head·multihead·mlp·deep·residual·layernorm 일곱 줄 · 모두 첫 검증 손실이 ln 65 근처) + 부품마다 검증 손실이 내려갔는지·올라갔는지 1줄씩 + 마지막 평가에서도 내려가는 중이던 단계가 있으면 그 사실 + bigram 줄을 '(참고) 셈 bigram' 줄과, deep 줄을 '(참고) 글자 빈도' 줄과 견준 1줄 + deep 과 residual 의 '초기화 직후 표준편차' 칸을 견주어 deep 의 결과에 '층을 쌓은 탓'과 '0.02 초기화 탓'이 섞여 있다고 적은 1줄 + 결론에 '학습률 1e-3·3000번에서' 단서 -->
c3: 
<!-- c4(필수): 누출 — results.md 의 표 2(마스크 있음·없음 두 줄) + 모든 자리 손실이 낮아진 까닭 1줄 + 맨 끝 자리 손실·표본으로 본 실제 실력과, 표본이 맨 끝 자리 손실보다도 망가진 까닭 1줄 -->
c4: 
<!-- c5(필수): 기준 대조 — logs\nanogpt_4070ti.txt · logs\nanogpt_seconds.txt · nanoGPT 커밋 해시 1줄 + results.md 의 표 3(README 기준값 · nanoGPT 내 PC · 내 chargpt 세 줄) + 두 구현이 다른 점 가운데 숫자 차이를 설명할 만한 것 2개 이상 -->
c5: 
<!-- c6(필수): 한국어 데이터 — data\kowiki_1m_pages.tsv 첫 줄(SHA-1 … 일치 · 문서 수 · 글자 수) + prepare_text.py 출력(어휘 크기 · 그중 한글 음절) + prepare_kowiki.py 를 담은 커밋 해시(= 한국어 두 실행 config.json 의 git_commit) + 보고서의 '출처 표기' 절(덤프 파일 이름 · 라이선스 · 고친 사실 · 문서 목록 파일) -->
c6: 
<!-- c7(필수): 영어 대 한국어 — results.md 의 표 4(두 줄) + 두 언어를 각자의 ln(어휘)·글자 빈도(셈)·셈 bigram 과 견준 1줄 + 학습한 bigram 과 셈 bigram 의 차이(어느 쪽이 얼마나 높은지) 1줄 + samples.txt 의 temperature 0.5·1.0·1.5 표본을 두 언어로 읽고 고른 차이 2줄 -->
c7: 
<!-- c8(필수): 기록 — chargpt_report.md(설정 · 파라미터 수 · 최저 검증 손실 · 최대 GPU 메모리가 표 1·3·4 에 있음) + loss_curve.png + samples.txt + requirements.lock.txt 다시 뽑음 · requirements.txt 의 requests·tiktoken 두 줄 + 커밋 해시 3줄(코드 커밋 = 사다리·영어 실행 config.json 의 git_commit · 한국어 데이터 커밋 = 한국어 실행의 git_commit · 결과 커밋) -->
c8: 
<!-- c9(선택): (선택) 내 글 — 권리가 확인된 내 글로 bigram·nanogpt 설정을 돌린 표 한 줄씩 + 위키백과 결과와 견준 1줄(글은 data 폴더에만 두고 저장소에 올리지 않는다) -->
c9: 
<!-- c10(선택): (선택) 시드 둘 더 — 사다리 일곱 단계를 --seed 1·2 로 더 돌린 기록 + 이웃 단계 사이의 차이가 시드 사이 흩어짐보다 컸는지 1줄 -->
c10: 
<!-- c11(선택): (선택) 학습률 후보 — bigram·deep·layernorm 을 학습률 3e-4·3e-3 으로 더 돌린 runs 폴더(꼬리표 lr3e-4·lr3e-3) + 단계마다 세 학습률 가운데 가장 좋은 검증 손실끼리 견준 작은 표 + 6단계 표와 순위가 달라졌는지 1줄 -->
c11: 
<!-- c12(선택): (선택) deep 의 초기화 바꾸기 — runs\shakespeare_ladder_deep_fanin_s0 의 history.json(init_block_std · 최저 검증 손실) + 6단계 deep·residual 과 견주어 deep 의 멈춤에서 초기화 몫과 잔차 몫을 가른 1줄 -->
c12: 
