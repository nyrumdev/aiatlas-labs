# 글자 단위 작은 GPT를 처음부터 짜서 내 GPU로 학습시키기 — 명령·코드 모음

실습 id: `lab.c.lab.char_gpt`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install "requests==2.34.2" "tiktoken==0.14.0"
python -c "import torch; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'GPU 없음')"
mkdir char_gpt
cd char_gpt
mkdir data
mkdir logs
curl.exe -L -o data\shakespeare.txt https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt
```

## 2. 글자 → 번호

- `files/prepare_text.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python prepare_text.py data\shakespeare.txt data\shakespeare.pt` — `python prepare_text.py data\shakespeare.txt data\shakespeare.pt` 로 실행한다.

## 3. 모델

- `files/chargpt.py` — 키트에 들어 있음 (python)

## 4. 학습 스크립트와 코드 커밋

- `files/train_chargpt.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add .
git commit -m "글자 GPT 실습 — 데이터·모델·학습 코드"
git rev-parse HEAD
cd char_gpt
```

## 5. 점검 먼저

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --one_batch --max_iters 500 --eval_interval 100 --tag onebatch
```

## 6. 단계 사다리

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage bigram
python train_chargpt.py --data data\shakespeare.pt --stage head
python train_chargpt.py --data data\shakespeare.pt --stage multihead
python train_chargpt.py --data data\shakespeare.pt --stage mlp
python train_chargpt.py --data data\shakespeare.pt --stage deep
python train_chargpt.py --data data\shakespeare.pt --stage residual
python train_chargpt.py --data data\shakespeare.pt --stage layernorm
```

## 7. 누출

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --no_mask
```

## 8. nanoGPT 를 커밋 고정으로

```powershell
cd C:\work
git clone https://github.com/karpathy/nanoGPT.git
cd nanoGPT
git checkout 3adf61e154c3fe3fca428ad6bc3818b27a3b8291
git rev-parse HEAD
python data\shakespeare_char\prepare.py
$sw = [Diagnostics.Stopwatch]::StartNew()
python -u train.py config\train_shakespeare_char.py --compile=False | Tee-Object -FilePath C:\work\ai-lab\char_gpt\logs\nanogpt_4070ti.txt
[int]$sw.Elapsed.TotalSeconds | Out-File -Encoding utf8 C:\work\ai-lab\char_gpt\logs\nanogpt_seconds.txt
python sample.py --out_dir=out-shakespeare-char --num_samples=1
cd C:\work\ai-lab\char_gpt
```

## 9. 내 GPT 를 같은 설정으로

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --preset nanogpt
```

## 10. 한국어 데이터

```powershell
curl.exe -L -o data\kowiki-20261001-pages-articles1.xml-p1p82407.bz2 https://dumps.wikimedia.org/kowiki/20261001/kowiki-20261001-pages-articles1.xml-p1p82407.bz2
curl.exe -L -o data\kowiki-20261001-sha1sums.txt https://dumps.wikimedia.org/kowiki/20261001/kowiki-20261001-sha1sums.txt
```

- `files/prepare_kowiki.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add char_gpt\prepare_kowiki.py
git commit -m "글자 GPT 실습 — 한국어 데이터 준비 스크립트"
git rev-parse HEAD
cd char_gpt
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python prepare_kowiki.py data\kowiki-20261001-pages-articles1.xml-p1p82407.bz2 data\kowiki-20261001-sha1sums.txt` — 이어서 `python prepare_kowiki.py data\kowiki-20261001-pages-articles1.xml-p1p82407.bz2 data\kowiki-20261001-sha1sums.txt` 로 실행하고, …
- `python prepare_text.py data\kowiki_1m.txt data\kowiki_1m.pt` — … data\kowiki-20261001-sha1sums.txt` 로 실행하고, `python prepare_text.py data\kowiki_1m.txt data\kowiki_1m.pt

## 11. 한국어 학습

```powershell
python train_chargpt.py --data data\kowiki_1m.pt --stage bigram
python train_chargpt.py --data data\kowiki_1m.pt --stage layernorm --preset nanogpt
```

## 12. 표·곡선·표본 모으기

- `files/report.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add char_gpt\report.py
git commit -m "글자 GPT 실습 — 결과 표 스크립트"
cd char_gpt
python report.py
```

## 14. 판 기록·결과 커밋·보고서

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

```powershell
git add char_gpt\chargpt_report.md
git commit -m "글자 GPT 실습 보고서 — 결과 커밋 해시"
git status
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 그 뒤 `git add .` 와 `git commit -m "글자 GPT 실습 — 결과 표·곡선·표본·보고서"` 를 친다.
- `git commit -m "글자 GPT 실습 — 결과 표·곡선·표본·보고서"` — 그 뒤 `git add .` 와 `git commit -m "글자 GPT 실습 — 결과 표·곡선·표본·보고서"` 를 친다.
- `git rev-parse HEAD` — `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다(S764).

## 15. (선택) 내 글

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python prepare_text.py data\mytext.txt data\mytext.pt` — 예를 들어 data\mytext.txt 라면 `python prepare_text.py data\mytext.txt data\mytext.pt` 뒤 11단계의 두 줄에서 데이터만 바꿔 돌린다.

## 16. (선택) 시드 둘 더

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage bigram --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage head --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage multihead --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage mlp --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage deep --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage residual --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --seed 1
python train_chargpt.py --data data\shakespeare.pt --stage bigram --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage head --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage multihead --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage mlp --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage deep --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage residual --seed 2
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --seed 2
```

## 17. (선택) 학습률 후보

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage bigram --lr 3e-4 --min_lr 3e-4 --tag lr3e-4
python train_chargpt.py --data data\shakespeare.pt --stage bigram --lr 3e-3 --min_lr 3e-3 --tag lr3e-3
python train_chargpt.py --data data\shakespeare.pt --stage deep --lr 3e-4 --min_lr 3e-4 --tag lr3e-4
python train_chargpt.py --data data\shakespeare.pt --stage deep --lr 3e-3 --min_lr 3e-3 --tag lr3e-3
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --lr 3e-4 --min_lr 3e-4 --tag lr3e-4
python train_chargpt.py --data data\shakespeare.pt --stage layernorm --lr 3e-3 --min_lr 3e-3 --tag lr3e-3
```

## 18. (선택) deep 의 초기화 바꾸기

```powershell
python train_chargpt.py --data data\shakespeare.pt --stage deep --init fanin
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git ls-tree -r --name-only <그 해시> char_gpt` — … 에 prepare_kowiki.py 가 들어 있는가(저장소 맨 위 C:\work\ai-lab 에서 `git ls-tree -r --name-only <그 해시> char_gpt` — 경로는 지금 폴더 기준이라, char_gpt 폴더에서 치면 아무것도 찍지 않고 오류 없이 끝난다)
- `git ls-files` — data\kowiki_1m_pages.tsv 가 있고 보고서 '출처 표기' 절에 덤프 파일 이름·라이선스·고친 사실·목록 파일이 있는가 · `git ls-files` 에 data 폴더와 .pt 파일이 없는가
- `git log --oneline` — … · loss_curve.png · samples.txt · results.md 가 있고 `git log --oneline` 에 코드·한국어 데이터·결과 표 스크립트·결과 커밋이 있는가 · chargpt_report.md 가 UTF-8 이고 64KiB 안이며 lab_id 줄로 …

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -u` — logs\nanogpt_4070ti.txt 가 비었거나 step 줄이 실행이 끝나서야 한꺼번에 생긴다 → `python -u` 를 빠뜨렸다.
