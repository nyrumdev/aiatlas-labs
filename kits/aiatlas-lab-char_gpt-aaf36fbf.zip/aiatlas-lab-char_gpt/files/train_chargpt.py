"""train_chargpt.py — 글자 단위 GPT 를 한 단계·한 설정으로 학습하고, 기록·가장 좋은 체크포인트·표본을 남긴다.

실행 예: python train_chargpt.py --data data\\shakespeare.pt --stage bigram
         python train_chargpt.py --data data\\shakespeare.pt --stage layernorm --preset nanogpt
만드는 폴더: runs\\<데이터>_<설정>_<단계>[_nomask][_fanin]_s<시드>[_<꼬리표>]\\ — config.json · history.json · best.pt · samples.txt
"""
import argparse
import json
import math
import platform
import subprocess
import time
from datetime import datetime
from pathlib import Path

import torch

from chargpt import STAGES, CharGPT, count_params

# 두 묶음의 기본값 — ladder = 단계 사다리용 작은 설정 · nanogpt = nanoGPT 의 config/train_shakespeare_char.py 와 같은 값
PRESETS = {
    "ladder": dict(n_layer=4, n_head=4, n_embd=128, block_size=128, batch_size=32, dropout=0.0,
                   lr=1e-3, min_lr=1e-3, warmup_iters=0, max_iters=3000, eval_interval=250, eval_iters=50),
    "nanogpt": dict(n_layer=6, n_head=6, n_embd=384, block_size=256, batch_size=64, dropout=0.2,
                    lr=1e-3, min_lr=1e-4, warmup_iters=100, max_iters=5000, eval_interval=250, eval_iters=200),
}
TEMPERATURES = (0.5, 1.0, 1.5)


def git_commit():
    """지금 코드의 커밋 해시와, 추적 중인 파일에 커밋하지 않은 수정이 있는지(앞 실습과 같은 방식)."""
    def run(*cmd):
        return subprocess.run(["git", *cmd], capture_output=True, text=True).stdout.strip()
    return run("rev-parse", "HEAD"), run("describe", "--always", "--dirty").endswith("-dirty")


def get_lr(it, c):
    """워밍업 뒤 코사인으로 min_lr 까지 내린다(nanoGPT train.py 의 get_lr 과 같은 식). ladder 는 lr = min_lr 이라 고정."""
    if it < c["warmup_iters"]:
        return c["lr"] * (it + 1) / (c["warmup_iters"] + 1)
    if it > c["max_iters"]:
        return c["min_lr"]
    ratio = (it - c["warmup_iters"]) / max(1, c["max_iters"] - c["warmup_iters"])
    return c["min_lr"] + 0.5 * (1.0 + math.cos(math.pi * ratio)) * (c["lr"] - c["min_lr"])


def batch_at(data, starts, block_size):
    """시작 자리들에서 block_size 글자를 잘라 입력 x 와, 한 칸 민 정답 y 를 만든다."""
    offsets = starts.unsqueeze(1) + torch.arange(block_size, device=data.device)
    return data[offsets], data[offsets + 1]


def sync(device):
    if device == "cuda":
        torch.cuda.synchronize()


@torch.no_grad()
def evaluate(model, data, starts, block_size, batch_size):
    """고정해 둔 시작 자리들로 손실을 잰다 — 모든 자리 평균과 맨 끝 자리만의 평균 둘."""
    model.eval()
    tot_all = tot_last = 0.0
    n = 0
    for i in range(0, len(starts), batch_size):
        x, y = batch_at(data, starts[i:i + batch_size], block_size)
        _, loss_all, loss_last = model(x, y)
        tot_all += loss_all.item()
        tot_last += loss_last.item()
        n += 1
    model.train()
    return tot_all / n, tot_last / n


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--stage", required=True, choices=STAGES)
    p.add_argument("--preset", default="ladder", choices=list(PRESETS))
    p.add_argument("--no_mask", action="store_true", help="인과 마스크를 뺀다(누출 실험)")
    p.add_argument("--one_batch", action="store_true", help="같은 묶음 하나만 되풀이해 외우게 한다(점검)")
    p.add_argument("--init", default="small", choices=["small", "fanin"],
                   help="첫 값 — small = 모두 표준편차 0.02(기본) · fanin = 몸통의 선형층만 1/√(입력 폭)(선택 실험)")
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--tag", default="")
    for k, v in PRESETS["ladder"].items():               # 묶음 값을 하나씩 덮어쓸 수 있게
        p.add_argument("--" + k, type=type(v), default=None)
    args = p.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA 를 쓸 수 없다 — 앞 실습의 env_report.json 부터 다시 본다")

    c = dict(PRESETS[args.preset])
    c.update({k: getattr(args, k) for k in PRESETS["ladder"] if getattr(args, k) is not None})
    d = torch.load(args.data, weights_only=True)
    vocab = len(d["chars"])
    name = (f"{Path(args.data).stem}_{args.preset}_{args.stage}{'_nomask' if args.no_mask else ''}"
            f"{'_fanin' if args.init == 'fanin' else ''}_s{args.seed}")
    run_dir = Path("runs") / (name + (f"_{args.tag}" if args.tag else ""))
    run_dir.mkdir(parents=True, exist_ok=True)

    cuda = args.device == "cuda"
    if cuda:
        torch.set_float32_matmul_precision("high")       # float32 행렬 곱에 TF32 를 허용(nanoGPT 도 TF32 를 켠다)
    torch.manual_seed(args.seed)
    model = CharGPT(vocab, args.stage, c["n_layer"], c["n_head"], c["n_embd"], c["block_size"],
                    c["dropout"], causal=not args.no_mask, init=args.init).to(args.device)
    # nanoGPT 처럼 2차원 이상 파라미터(행렬·임베딩)에만 가중치 감쇠를 건다
    decay = [p_ for p_ in model.parameters() if p_.dim() >= 2]
    no_decay = [p_ for p_ in model.parameters() if p_.dim() < 2]
    opt = torch.optim.AdamW([{"params": decay, "weight_decay": 0.1}, {"params": no_decay, "weight_decay": 0.0}],
                            lr=c["lr"], betas=(0.9, 0.99))

    commit, dirty = git_commit()
    config = {**vars(args), **c, "vocab_size": vocab, "params": count_params(model),
              "train_chars": len(d["train"]), "val_chars": len(d["val"]),
              "torch": str(torch.__version__), "python": platform.python_version(),   # str — weights_only 로 다시 읽히게
              "device_name": torch.cuda.get_device_name(0) if cuda else platform.processor(),
              "matmul_precision": torch.get_float32_matmul_precision(),
              "git_commit": commit, "git_dirty": dirty,
              "started_at": datetime.now().isoformat(timespec="seconds")}   # 실행 순서를 파일로 확인
    (run_dir / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{run_dir.name} · 어휘 {vocab:,} · 파라미터 {config['params']:,}개 · {config['device_name']}")

    train = d["train"].to(args.device)
    val = d["val"].to(args.device)
    T, B = c["block_size"], c["batch_size"]
    g_eval = torch.Generator().manual_seed(1234)          # 평가 자리는 실행마다 같게 — 단계끼리 같은 문제로 견준다
    eval_tr = torch.randint(len(train) - T, (c["eval_iters"] * B,), generator=g_eval).to(args.device)
    eval_va = torch.randint(len(val) - T, (c["eval_iters"] * B,), generator=g_eval).to(args.device)
    g_train = torch.Generator().manual_seed(args.seed)    # 학습 묶음을 뽑는 순서
    fixed = torch.randint(len(train) - T, (B,), generator=g_train).to(args.device)   # one_batch 점검용
    # 막 초기화한 모델에서 부품을 지날 때마다 출력의 표준편차를 잰다(평가 자리 첫 묶음으로)
    init_std = model.block_stds(batch_at(val, eval_va[:B], T)[0])
    if init_std:
        print("초기화 직후 표준편차(임베딩 합 → 부품마다): " + " → ".join(f"{v:.1e}" for v in init_std))

    history, best = [], {"val_loss": float("inf"), "iter": None}
    if cuda:
        torch.cuda.reset_peak_memory_stats()
    sync(args.device)
    start = time.perf_counter()
    eval_sec = 0.0
    batch_loss = None                                     # 아직 학습 걸음이 없다(JSON 에는 null 로)
    for it in range(c["max_iters"] + 1):
        if it % c["eval_interval"] == 0 or it == c["max_iters"]:
            sync(args.device)
            t_e = time.perf_counter()
            tr_all, _ = evaluate(model, train, eval_tr, T, B)
            va_all, va_last = evaluate(model, val, eval_va, T, B)
            sync(args.device)
            eval_sec += time.perf_counter() - t_e
            history.append({"iter": it, "train_loss": tr_all, "val_loss": va_all, "val_loss_last": va_last,
                            "batch_loss": batch_loss, "lr": get_lr(it, c),
                            "sec": time.perf_counter() - start})
            note = ""
            if va_all < best["val_loss"]:                 # 검증 손실이 나아졌을 때만 저장
                best = {"val_loss": va_all, "iter": it}
                torch.save({"iter": it, "model": model.state_dict(), "config": config}, run_dir / "best.pt")
                note = " · 저장"
            print(f"반복 {it:5d} | 학습 {tr_all:.4f} | 검증 {va_all:.4f} | 검증(맨 끝 자리) {va_last:.4f}{note}")
        if it == c["max_iters"]:
            break
        for g in opt.param_groups:
            g["lr"] = get_lr(it, c)
        starts = fixed if args.one_batch else torch.randint(len(train) - T, (B,), generator=g_train).to(args.device)
        x, y = batch_at(train, starts, T)
        _, loss, _ = model(x, y)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        batch_loss = loss.item()
    sync(args.device)
    total_sec = time.perf_counter() - start
    peak = torch.cuda.max_memory_allocated() / 2**20 if cuda else None

    # 가장 좋았던 검증 손실의 가중치로 temperature 셋의 표본을 뽑는다
    ckpt = torch.load(run_dir / "best.pt", weights_only=True)
    model.load_state_dict(ckpt["model"])
    model.eval()
    chars = d["chars"]
    start_id = chars.index("\n") if "\n" in chars else 0
    lines = []
    for temp in TEMPERATURES:
        gen = torch.Generator(device=args.device).manual_seed(args.seed)
        out = model.generate(torch.tensor([[start_id]], device=args.device), 300, temperature=temp, generator=gen)
        text = "".join(chars[i] for i in out[0].tolist()[1:])
        lines += [f"===== {run_dir.name} · temperature {temp} =====", text, ""]
    (run_dir / "samples.txt").write_text("\n".join(lines), encoding="utf-8")

    ln_v = math.log(vocab)
    ok = abs(history[0]["val_loss"] - ln_v) < 0.05 * ln_v                         # ln(어휘)의 5% 안
    onebatch_ok = batch_loss is not None and batch_loss < 0.05
    bl = "-" if batch_loss is None else f"{batch_loss:.4f}"
    summary = {"best_val_loss": best["val_loss"], "best_iter": best["iter"],
               "initial_val_loss": history[0]["val_loss"], "ln_vocab": ln_v,
               "init_check": "통과" if ok else "확인 필요",                        # 판정도 파일에 남긴다
               "onebatch_check": ("통과" if onebatch_ok else "확인 필요") if args.one_batch else None,
               "init_block_std": init_std,
               "final_batch_loss": batch_loss, "total_sec": total_sec, "eval_sec": eval_sec,
               "max_memory_allocated_mib": peak}
    (run_dir / "history.json").write_text(
        json.dumps({"config": config, "summary": summary, "history": history}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(f"첫 검증 손실 {summary['initial_val_loss']:.4f} · ln(어휘 {vocab}) = {ln_v:.4f} ({summary['init_check']})")
    if args.one_batch:
        print(f"한 묶음 외우기: 마지막 묶음 손실 {bl} ({summary['onebatch_check']})")
    print(f"최저 검증 손실 {best['val_loss']:.4f}(반복 {best['iter']}) · 마지막 묶음 손실 {bl} · "
          f"걸린 시간 {total_sec:.1f}초(평가 {eval_sec:.1f}초)"
          + (f" · 최대 GPU 메모리 {peak:.0f} MiB" if peak is not None else ""))
    print(f"저장: {run_dir}")


if __name__ == "__main__":
    main()
