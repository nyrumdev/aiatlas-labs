"""report.py — runs 폴더의 기록과 nanoGPT 로그를 모아 표(results.md)·곡선(loss_curve.png)·표본 모음(samples.txt)을 만든다.

실행: python report.py
읽는 것: runs\\*\\history.json · runs\\*\\samples.txt · logs\\nanogpt_4070ti.txt · logs\\nanogpt_seconds.txt
"""
import json
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import torch

from chargpt import STAGES

ADDED = {"bigram": "기준선(앞 글자 하나 → 다음 글자 표)", "head": "임베딩·위치 + 셀프 어텐션 헤드 1개",
         "multihead": "헤드 여러 개 + 섞는 선형층", "mlp": "+ MLP", "deep": "블록 여러 층(잔차·정규화 없음)",
         "residual": "+ 잔차 연결", "layernorm": "+ LayerNorm(완성형 GPT 블록)"}
README_ROW = "| nanoGPT README 기준값(A100 · torch.compile) | 같은 설정 | (README 에 없음) | 1.4697 | 약 3분 | (README 에 없음) |"
ALPHA = 0.01   # 셈 기준선의 덧셈 평활 — 학습 조각에 한 번도 없던 글자 짝도 확률이 0 이 되지 않게(이 실습이 정한 값)


def count_baselines(data_path):
    """학습 조각을 세기만 해서 만든 두 기준선의 검증 손실(글자당 교차 엔트로피).
    글자 빈도 = 앞 글자를 보지 않고 글자마다 나온 비율로 찍기 · 셈 bigram = 앞 글자마다 다음 글자가 나온 비율로 찍기."""
    d = torch.load(data_path, weights_only=True)
    tr, va, V = d["train"], d["val"], len(d["chars"])
    uni = torch.bincount(tr, minlength=V).double() + ALPHA
    uni_loss = -(uni / uni.sum()).log()[va].mean().item()
    pair = torch.bincount(tr[:-1] * V + tr[1:], minlength=V * V).double().view(V, V) + ALPHA
    prob = pair / pair.sum(dim=1, keepdim=True)                        # 줄(앞 글자)마다 합이 1
    bi_loss = -prob[va[:-1], va[1:]].log().mean().item()
    return uni_loss, bi_loss


def read_text_any(path):
    """PowerShell 이 만든 파일은 UTF-16 일 수도, UTF-8(BOM) 일 수도 있어 앞머리로 가려 읽는다."""
    raw = Path(path).read_bytes()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16")
    return raw.decode("utf-8-sig", errors="replace")


def load_runs():
    runs = {}
    for f in sorted(Path("runs").glob("*/history.json")):
        runs[f.parent.name] = json.loads(f.read_text(encoding="utf-8"))
    return runs


def pick(runs, data, preset, stage, nomask=False, seed=0):
    for name, r in runs.items():
        c = r["config"]
        if (Path(c["data"]).stem == data and c["preset"] == preset and c["stage"] == stage
                and c["no_mask"] == nomask and c["seed"] == seed and not c["one_batch"] and not c["tag"]
                and c.get("init", "small") == "small"):
            return name, r
    return None, None


def fmt_mem(s):
    return "-" if s["max_memory_allocated_mib"] is None else f"{s['max_memory_allocated_mib']:.0f}"


def fmt_std(s):
    """초기화 직후 표준편차 — 임베딩 합 → 마지막 부품(bigram 은 몸통이 없어 '-')."""
    v = s.get("init_block_std") or []
    return "-" if not v else f"{v[0]:.1e} → {v[-1]:.1e}"


def hangul_count(data):
    d = torch.load(f"data/{data}.pt", weights_only=True)
    return sum("가" <= c <= "힣" for c in d["chars"])


def nanogpt_row():
    log = Path("logs/nanogpt_4070ti.txt")
    if not log.exists():
        return None
    text = read_text_any(log)
    vals = [(int(s), float(v)) for s, v in re.findall(r"step (\d+): train loss [\d.]+, val loss ([\d.]+)", text)]
    params = re.search(r"number of parameters: ([\d.]+)M", text)
    sec_file = Path("logs/nanogpt_seconds.txt")
    sec = float(read_text_any(sec_file).strip()) if sec_file.exists() else None
    if not vals:
        return None
    step, best = min(vals, key=lambda t: t[1])
    p = f"{params.group(1)}M(위치 임베딩 뺀 수)" if params else "?"
    t = f"{sec / 60:.1f}분" if sec else "?"
    return f"| nanoGPT · 내 PC(--compile=False) | 같은 설정 | {p} | {best:.4f}(step {step}) | {t} | (재지 않음) |"


def main():
    runs = load_runs()
    L = ["# char_gpt 결과 표", ""]

    L += ["## 1. 단계 사다리(shakespeare · ladder 설정 · 시드 0)", "",
          "| 단계 | 더한 것 | 파라미터 | 첫 검증 손실 | 초기화 직후 표준편차(임베딩 합 → 끝 부품) | "
          "최저 검증 손실(반복) | 마지막 평가에서도 내려가는 중 | 시간(초) | 최대 GPU 메모리(MiB) |",
          "|---|---|---|---|---|---|---|---|---|"]
    for st in STAGES:
        name, r = pick(runs, "shakespeare", "ladder", st)
        if not r:
            continue
        s, h = r["summary"], r["history"]
        still = "예" if s["best_iter"] == h[-1]["iter"] else "아니오"
        L.append(f"| {st} | {ADDED[st]} | {r['config']['params']:,} | {s['initial_val_loss']:.4f} | {fmt_std(s)} | "
                 f"{s['best_val_loss']:.4f}({s['best_iter']}) | {still} | {s['total_sec']:.0f} | {fmt_mem(s)} |")
    base = {}                                                # 데이터 이름 → (글자 빈도, 셈 bigram)
    for data in ("shakespeare", "kowiki_1m"):
        if Path(f"data/{data}.pt").exists():
            base[data] = count_baselines(f"data/{data}.pt")
    if "shakespeare" in base:
        uni, bi = base["shakespeare"]
        L.append(f"| (참고) 글자 빈도 — 셈 | 앞 글자를 보지 않음 · 학습하지 않음 | - | - | - | {uni:.4f} | - | - | - |")
        L.append(f"| (참고) 셈 bigram | 앞 글자 하나 · 학습 조각을 세어 만든 표(평활 {ALPHA}) | - | - | - | {bi:.4f} | - | - | - |")

    L += ["", "## 2. 인과 마스크를 뺐을 때(shakespeare · ladder · layernorm)", "",
          "| 실행 | 최저 검증 손실(모든 자리) | 그때의 검증 손실(맨 끝 자리) |", "|---|---|---|"]
    for nm in (False, True):
        name, r = pick(runs, "shakespeare", "ladder", "layernorm", nomask=nm)
        if r:
            b = min(r["history"], key=lambda e: e["val_loss"])
            L.append(f"| {name} | {b['val_loss']:.4f} | {b['val_loss_last']:.4f} |")

    L += ["", "## 3. nanoGPT 와 같은 설정(shakespeare_char)", "",
          "| 실행 | 설정 | 파라미터 | 최저 검증 손실 | 걸린 시간 | 최대 GPU 메모리(MiB) |", "|---|---|---|---|---|---|",
          README_ROW]
    row = nanogpt_row()
    if row:
        L.append(row)
    name, r = pick(runs, "shakespeare", "nanogpt", "layernorm")
    if r:
        s = r["summary"]
        L.append(f"| 내 chargpt · 내 PC | nanogpt 설정 | {r['config']['params']:,}(모두 센 수) | "
                 f"{s['best_val_loss']:.4f}(반복 {s['best_iter']}) | {s['total_sec'] / 60:.1f}분 | {fmt_mem(s)} |")

    L += ["", "## 4. 영어 대 한국어(같은 설정 · 시드 0)", "",
          "| 데이터 | 학습+검증 글자 | 어휘 크기(그중 한글 음절) | ln(어휘) | 글자 빈도(셈) | 셈 bigram | "
          "학습한 bigram 최저 검증 | GPT(nanogpt 설정) 최저 검증 | GPT 파라미터 | GPT 최대 GPU 메모리(MiB) |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for data in ("shakespeare", "kowiki_1m"):
        _, rb = pick(runs, data, "ladder", "bigram")
        _, rg = pick(runs, data, "nanogpt", "layernorm")
        any_r = rg or rb
        if not any_r:
            continue
        c = any_r["config"]
        cnt = " | ".join(f"{v:.4f}" for v in base[data]) if data in base else "- | -"
        big = f"{rb['summary']['best_val_loss']:.4f}" if rb else "-"
        gpt = (f"{rg['summary']['best_val_loss']:.4f} | {rg['config']['params']:,} | {fmt_mem(rg['summary'])}"
               if rg else "- | - | -")
        hg = f"({hangul_count(data):,})" if Path(f"data/{data}.pt").exists() else ""
        L.append(f"| {data} | {c['train_chars'] + c['val_chars']:,} | {c['vocab_size']:,}{hg} | "
                 f"{math.log(c['vocab_size']):.3f} | {cnt} | {big} | {gpt} |")
    Path("results.md").write_text("\n".join(L) + "\n", encoding="utf-8")

    # 곡선: 왼쪽 = 사다리 단계별 검증 손실(+ 마스크를 뺀 실행의 모든 자리·맨 끝 자리)
    #       오른쪽 = nanogpt 설정의 영어·한국어 학습/검증 손실과 언어마다 자기 셈 bigram 가로줄
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 4.2))
    for st in STAGES:
        _, r = pick(runs, "shakespeare", "ladder", st)
        if r:
            a1.plot([e["iter"] for e in r["history"]], [e["val_loss"] for e in r["history"]], label=st)
    _, r = pick(runs, "shakespeare", "ladder", "layernorm", nomask=True)
    if r:
        its = [e["iter"] for e in r["history"]]
        a1.plot(its, [e["val_loss"] for e in r["history"]], "k:", label="no mask (all positions)")
        a1.plot(its, [e["val_loss_last"] for e in r["history"]], "k--", lw=1, label="no mask (last position)")
    if "shakespeare" in base:                                 # 셈 기준선 두 개를 가로줄로
        a1.axhline(base["shakespeare"][0], color="gray", ls="-.", lw=1, label="unigram (count)")
        a1.axhline(base["shakespeare"][1], color="gray", ls="--", lw=1, label="bigram (count)")
    a1.set_title("ladder (shakespeare) - val loss")
    a1.set_xlabel("iter")
    a1.set_ylabel("cross-entropy per char")
    a1.legend(fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=4)   # 범례는 그림 아래 — 곡선을 가리지 않게
    for data, color in (("shakespeare", "tab:blue"), ("kowiki_1m", "tab:red")):
        _, r = pick(runs, data, "nanogpt", "layernorm")
        if r:
            its = [e["iter"] for e in r["history"]]
            a2.plot(its, [e["train_loss"] for e in r["history"]], color=color, alpha=0.5, label=f"{data} train")
            a2.plot(its, [e["val_loss"] for e in r["history"]], color=color, label=f"{data} val")
            if data in base:                                    # 언어마다 자기 셈 bigram — 곡선은 같은 색 줄과 견준다
                a2.axhline(base[data][1], color=color, ls="--", lw=1, label=f"{data} bigram (count)")
    a2.set_title("nanogpt preset - compare each language to its own baseline")
    a2.set_xlabel("iter")
    a2.legend(fontsize=8)
    fig.savefig("loss_curve.png", dpi=120, bbox_inches="tight")

    # 표본 모음: nanogpt 설정의 영어·한국어 + 마스크를 뺀 실행
    parts = []
    for data, preset, st, nm in (("shakespeare", "nanogpt", "layernorm", False), ("kowiki_1m", "nanogpt", "layernorm", False),
                                 ("shakespeare", "ladder", "layernorm", True)):
        name, r = pick(runs, data, preset, st, nomask=nm)
        if r:
            parts.append((Path("runs") / name / "samples.txt").read_text(encoding="utf-8"))
    Path("samples.txt").write_text("\n".join(parts), encoding="utf-8")
    print(Path("results.md").read_text(encoding="utf-8"))
    print("저장: results.md · loss_curve.png · samples.txt")


if __name__ == "__main__":
    main()
