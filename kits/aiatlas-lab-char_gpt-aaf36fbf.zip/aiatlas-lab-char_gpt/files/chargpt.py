"""chargpt.py — 글자 단위 GPT 를 단계별로 조립한다. 단계(stage) 하나가 앞 단계에 부품 하나를 더한다.

bigram → head → multihead → mlp → deep → residual → layernorm(= GPT 블록을 쌓은 완성형)
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

STAGES = ("bigram", "head", "multihead", "mlp", "deep", "residual", "layernorm")


class Head(nn.Module):
    """셀프 어텐션 헤드 하나 — Q·K·V 를 만들고, 인과 마스크로 뒤 자리를 가린 뒤 V 를 가중합한다."""

    def __init__(self, n_embd, head_size, block_size, dropout, causal):
        super().__init__()
        self.query = nn.Linear(n_embd, head_size, bias=False)
        self.key = nn.Linear(n_embd, head_size, bias=False)
        self.value = nn.Linear(n_embd, head_size, bias=False)
        self.causal = causal
        # 아래 삼각형(대각선 포함)이 1 인 표 — 학습하는 값이 아니라 버퍼로 둔다
        self.register_buffer("tril", torch.tril(torch.ones(block_size, block_size)))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        B, T, C = x.shape
        q, k, v = self.query(x), self.key(x), self.value(x)          # 각각 (B, T, head_size)
        wei = q @ k.transpose(-2, -1) / math.sqrt(k.shape[-1])       # (B, T, T) 점수표
        if self.causal:
            wei = wei.masked_fill(self.tril[:T, :T] == 0, float("-inf"))   # 뒤 자리로 가는 칸을 지운다
        wei = F.softmax(wei, dim=-1)                                 # 줄마다 합이 1 인 가중치
        wei = self.dropout(wei)
        return wei @ v                                               # (B, T, head_size)


class MultiHead(nn.Module):
    """헤드 여러 개를 나란히 돌려 이어 붙이고, 선형층 하나로 섞는다."""

    def __init__(self, n_embd, n_head, block_size, dropout, causal):
        super().__init__()
        assert n_embd % n_head == 0, "n_embd 는 n_head 로 나누어떨어져야 한다"
        self.heads = nn.ModuleList(
            [Head(n_embd, n_embd // n_head, block_size, dropout, causal) for _ in range(n_head)])
        self.proj = nn.Linear(n_embd, n_embd)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        out = torch.cat([h(x) for h in self.heads], dim=-1)          # (B, T, n_embd)
        return self.dropout(self.proj(out))


class MLP(nn.Module):
    """자리마다 따로 도는 두 층 신경망 — 폭을 4배로 넓혔다가 되돌린다."""

    def __init__(self, n_embd, dropout):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_embd, 4 * n_embd), nn.ReLU(),
                                 nn.Linear(4 * n_embd, n_embd), nn.Dropout(dropout))

    def forward(self, x):
        return self.net(x)


class Block(nn.Module):
    """멀티헤드 어텐션 + MLP. residual 이면 각 부분의 출력을 입력에 더하고, layernorm 이면 그 앞에 LayerNorm."""

    def __init__(self, n_embd, n_head, block_size, dropout, causal, residual, layernorm):
        super().__init__()
        self.attn = MultiHead(n_embd, n_head, block_size, dropout, causal)
        self.mlp = MLP(n_embd, dropout)
        self.ln1 = nn.LayerNorm(n_embd) if layernorm else nn.Identity()
        self.ln2 = nn.LayerNorm(n_embd) if layernorm else nn.Identity()
        self.residual = residual

    def forward(self, x):
        if self.residual:
            x = x + self.attn(self.ln1(x))
            x = x + self.mlp(self.ln2(x))
        else:
            x = self.attn(self.ln1(x))
            x = self.mlp(self.ln2(x))
        return x


class CharGPT(nn.Module):
    def __init__(self, vocab_size, stage, n_layer, n_head, n_embd, block_size, dropout, causal=True, init="small"):
        super().__init__()
        assert stage in STAGES, f"모르는 단계: {stage}"
        assert init in ("small", "fanin"), f"모르는 초기화: {init}"
        self.stage, self.block_size = stage, block_size
        if stage == "bigram":
            # 앞 글자 하나로 다음 글자 점수를 바로 찾는 표(어휘 × 어휘)
            self.table = nn.Embedding(vocab_size, vocab_size)
        else:
            self.tok = nn.Embedding(vocab_size, n_embd)              # 글자 → 벡터
            self.pos = nn.Embedding(block_size, n_embd)              # 자리 번호 → 벡터
            if stage == "head":
                body = [Head(n_embd, n_embd, block_size, dropout, causal)]
            elif stage == "multihead":
                body = [MultiHead(n_embd, n_head, block_size, dropout, causal)]
            elif stage == "mlp":
                body = [MultiHead(n_embd, n_head, block_size, dropout, causal), MLP(n_embd, dropout)]
            else:   # deep · residual · layernorm — 블록 n_layer 개를 쌓는다
                residual = stage in ("residual", "layernorm")
                layernorm = stage == "layernorm"
                body = [Block(n_embd, n_head, block_size, dropout, causal, residual, layernorm)
                        for _ in range(n_layer)]
                if layernorm:
                    body.append(nn.LayerNorm(n_embd))                 # 마지막 LayerNorm
            self.body = nn.Sequential(*body)
            self.lm_head = nn.Linear(n_embd, vocab_size)             # 벡터 → 다음 글자 점수(로짓)
        self.apply(self._init_weights)
        if init == "fanin" and stage != "bigram":
            # (선택 실험) 출력층을 뺀 선형층만 표준편차 1/√(입력 폭)으로 — 층을 지나도 신호 크기가 덜 줄게
            for m in self.body.modules():
                if isinstance(m, nn.Linear):
                    nn.init.normal_(m.weight, mean=0.0, std=1.0 / math.sqrt(m.in_features))

    @staticmethod
    def _init_weights(m):
        # 작은 정규분포로 시작한다(nanoGPT 와 같은 표준편차 0.02) — 첫 손실이 ln(어휘 크기) 근처가 되게
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.zeros_(m.bias)

    @torch.no_grad()
    def block_stds(self, idx):
        """임베딩 합과 몸통의 부품마다 출력 벡터의 표준편차 — 신호가 층을 지나며 얼마나 줄거나 느는지 본다."""
        if self.stage == "bigram":
            return []
        was_training = self.training
        self.eval()
        x = self.tok(idx) + self.pos(torch.arange(idx.shape[1], device=idx.device))
        stds = [x.std().item()]
        for part in self.body:
            x = part(x)
            stds.append(x.std().item())
        self.train(was_training)
        return stds

    def forward(self, idx, targets=None):
        B, T = idx.shape
        if self.stage == "bigram":
            logits = self.table(idx)                                 # (B, T, 어휘)
        else:
            x = self.tok(idx) + self.pos(torch.arange(T, device=idx.device))
            logits = self.lm_head(self.body(x))                      # (B, T, 어휘)
        if targets is None:
            return logits, None, None
        loss_all = F.cross_entropy(logits.view(B * T, -1), targets.view(B * T))    # 모든 자리의 평균
        loss_last = F.cross_entropy(logits[:, -1, :], targets[:, -1])            # 맨 끝 자리만
        return logits, loss_all, loss_last

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, generator=None):
        """한 글자씩 이어 쓴다 — 마지막 자리의 점수를 temperature 로 나눠 확률로 바꾸고 하나를 뽑는다."""
        for _ in range(max_new_tokens):
            logits, _, _ = self(idx[:, -self.block_size:])
            probs = F.softmax(logits[:, -1, :] / temperature, dim=-1)
            nxt = torch.multinomial(probs, num_samples=1, generator=generator)
            idx = torch.cat([idx, nxt], dim=1)
        return idx


def count_params(model):
    return sum(p.numel() for p in model.parameters())
