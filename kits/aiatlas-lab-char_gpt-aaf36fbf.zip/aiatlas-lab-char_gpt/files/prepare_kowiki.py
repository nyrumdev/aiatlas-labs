"""prepare_kowiki.py — 한국어 위키백과 덤프 조각 하나에서 본문을 앞에서부터 뽑아, 셰익스피어 input.txt 와 같은 글자 수의 글을 만든다.

실행: python prepare_kowiki.py data\\kowiki-20261001-pages-articles1.xml-p1p82407.bz2 data\\kowiki-20261001-sha1sums.txt
만드는 파일: data\\kowiki_1m.txt(본문) · data\\kowiki_1m_pages.tsv(쓴 문서 목록 — 출처 표기용)
"""
import argparse
import bz2
import hashlib
import html
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

TARGET = 1_115_394          # 셰익스피어 input.txt 의 글자 수 — 두 언어를 같은 분량으로 견준다
MIN_CHARS = 200             # 다듬은 뒤 이보다 짧은 문서는 건너뛴다
SKIP_NS = ("파일:", "file:", "그림:", "image:", "분류:", "category:")
HANGUL = re.compile(r"[가-힣]")


def check_sha1(path, sums_path):
    """내려받은 파일의 SHA-1 을 덤프가 함께 낸 sha1sums 목록과 견준다."""
    want = None
    for line in Path(sums_path).read_text(encoding="utf-8").splitlines():
        h, _, fname = line.partition("  ")
        if fname.strip() == Path(path).name:
            want = h.strip()
    with open(path, "rb") as f:
        got = hashlib.file_digest(f, "sha1").hexdigest()
    if want != got:
        raise SystemExit(f"SHA-1 이 다르다 — 목록 {want} · 파일 {got}. 다시 내려받는다")
    print(f"SHA-1 일치: {got}")
    return got


def link(m):
    """[[대상|보이는 글]] → 보이는 글 · [[대상]] → 대상 · 파일·분류 링크 → 지움."""
    inner = m.group(1)
    if inner.lower().startswith(SKIP_NS):
        return ""
    return inner.split("|")[-1]


def clean(wikitext):
    """위키 문법을 거칠게 걷어 낸다 — 완벽한 변환이 아니라 '사람이 읽는 글'에 가깝게 만드는 정도."""
    t = re.sub(r"<!--.*?-->", "", wikitext, flags=re.S)
    t = re.sub(r"<ref[^>]*?/>", "", t)                             # 자기닫힘 각주 — 이름 속 '/'(예 tcp/ip)도 넘어가게
    t = re.sub(r"<(ref|math)[^>]*>.*?</\1>", "", t, flags=re.S)   # 각주·수식은 내용째 지운다
    for pat in (r"\{\{[^{}]*\}\}", r"\{\|[^{}]*?\|\}"):          # 틀·표: 안쪽부터 여러 번
        for _ in range(10):
            t, n = re.subn(pat, "", t, flags=re.S)
            if n == 0:
                break
    for _ in range(5):                                           # 링크: 안쪽부터(그림 설명 속 링크 먼저)
        t, n = re.subn(r"\[\[([^\[\]]*)\]\]", link, t)
        if n == 0:
            break
    t = re.sub(r"\[https?://[^\s\]]+ ([^\]]*)\]", r"\1", t)      # [주소 글] → 글
    t = re.sub(r"\[https?://[^\]]*\]", "", t)
    t = re.sub(r"<[^>]+>", "", t)                                # 남은 HTML 꼬리표
    t = html.unescape(t).replace("'''", "").replace("''", "")
    out = []
    for line in t.splitlines():
        line = line.strip().strip("=").strip()                   # == 제목 == → 제목
        line = line.lstrip("*#:;").strip()                       # 목록 기호
        if not line or line.startswith(("|", "!", "{", "}")) or not HANGUL.search(line):
            continue
        out.append(re.sub(r"[ \t]+", " ", line))
    return "\n".join(out)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("dump")
    p.add_argument("sha1sums")
    p.add_argument("--out", default="data/kowiki_1m.txt")
    args = p.parse_args()
    sha1 = check_sha1(args.dump, args.sha1sums)
    dump_name = Path(args.dump).name

    pieces, rows, total = [], [], 0
    with bz2.open(args.dump, "rb") as f:
        for _, elem in ET.iterparse(f):                          # 끝 꼬리표마다 하나씩 — 파일 전체를 메모리에 올리지 않는다
            if elem.tag.rsplit("}", 1)[-1] != "page":
                continue
            kids = {c.tag.rsplit("}", 1)[-1]: c for c in elem}
            rev = kids.get("revision")
            if kids["ns"].text == "0" and "redirect" not in kids and rev is not None:
                rk = {c.tag.rsplit("}", 1)[-1]: c for c in rev}
                body = clean(rk["text"].text or "")
                if len(body) >= MIN_CHARS:
                    body = body[:TARGET - total]                 # 마지막 문서는 목표 글자 수에서 자른다
                    pieces.append(body)
                    total += len(body) + 1                       # 문서 사이 줄바꿈 1글자
                    title = kids["title"].text
                    url = "https://ko.wikipedia.org/wiki/" + quote(title.replace(" ", "_"), safe="/:(),")   # ?·#·% 등은 %XX 로
                    rows.append([kids["id"].text, rk["id"].text, title, str(len(body)), url])
            elem.clear()                                         # 다 쓴 문서는 비워 메모리를 아낀다
            if total >= TARGET:
                break

    text = "\n".join(pieces)[:TARGET]
    Path(args.out).write_text(text, encoding="utf-8", newline="\n")
    tsv = Path(args.out).with_name(Path(args.out).stem + "_pages.tsv")
    with open(tsv, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# 원본: {dump_name} (Wikimedia dumps) · SHA-1 {sha1} 일치(sha1sums 목록과 견줌) · "
                f"문서 {len(rows):,}개 · 글자 {len(text):,}\n")
        f.write("# 본문 GFDL 및 CC BY-SA 4.0 · 위키 문법을 걷어 내고 앞부분만 잘라 바꾼 글\n")
        f.write("page_id\trev_id\ttitle\tchars\turl\n")
        for r in rows:
            f.write("\t".join(r) + "\n")
    print(f"문서 {len(rows):,}개 · 글자 {len(text):,} · 저장: {args.out} · {tsv}")


if __name__ == "__main__":
    main()
