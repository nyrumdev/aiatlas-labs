"""prepare_text.py — 글자 하나를 토큰 하나로 삼아 글을 정수 열로 바꾸고, 앞 90%(학습)·뒤 10%(검증)로 나눠 저장한다.

실행 예: python prepare_text.py data\\shakespeare.txt data\\shakespeare.pt
"""
import argparse
from collections import Counter

import torch


def main():
    p = argparse.ArgumentParser()
    p.add_argument("text_path")
    p.add_argument("out_path")
    args = p.parse_args()

    with open(args.text_path, encoding="utf-8") as f:
        text = f.read()
    chars = sorted(set(text))                          # 이 글에 나온 글자 전부 = 어휘
    stoi = {ch: i for i, ch in enumerate(chars)}
    ids = torch.tensor([stoi[c] for c in text], dtype=torch.long)
    n = int(0.9 * len(ids))                            # 앞 90% 학습 · 뒤 10% 검증
    torch.save({"train": ids[:n], "val": ids[n:], "chars": chars, "source": args.text_path},
               args.out_path)

    top = " ".join(repr(c) for c, _ in Counter(text).most_common(10))
    hangul = sum("가" <= c <= "힣" for c in chars)    # 어휘 가운데 한글 음절(나머지는 한자·영문·숫자·부호 등)
    print(f"글자 수 {len(text):,} · 어휘 크기 {len(chars):,}(그중 한글 음절 {hangul:,}) · "
          f"학습 {n:,} · 검증 {len(ids) - n:,}")
    print(f"가장 흔한 글자 10개: {top}")
    print(f"저장: {args.out_path}")


if __name__ == "__main__":
    main()
