# 논문 3편 요약 + 견해 1편

AI 아틀라스 앱의 실습 `lab.c.lab.paper_review`(L5 · 약 12시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰이나 PC)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 논문 리더 내보내기 폴더(paper_review)를 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 폴더에 paper_review_report.md(선정 표·출처 추가 제안 표·재현 시도 표) + summary_1.md + summary_2.md + summary_3.md + position.md + 재현 기록(코드 또는 재검산 스크립트 · 실행 로그).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- PC — 마크다운 편집기 + PDF 뷰어
- 출처 대장(sources) 열람 가능 — 인용은 대장 id 로만
- 논문 3편 원문 PDF(arXiv 등에서 내려받기)
- Python 3.11+ 또는 공개 수치 재검산 도구 — 실행 범위와 환경을 기록
- (선택) 로컬 Gemma 4(Ollama) — 초벌 요약·반론 브레인스토밍 보조용(판정 아님)

## 들어 있는 파일
- `files/c8_recheck.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.paper_review` in the AI Atlas app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
