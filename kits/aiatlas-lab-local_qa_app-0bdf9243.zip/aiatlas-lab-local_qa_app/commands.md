# 로컬 QA 앱 만들기 — 명령·코드 모음

실습 id: `lab.c.lab.local_qa_app`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다.

## 준비

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python local_qa.py …`
- `pip install`
- `ollama ps`

## 골격 코드 (local_qa.py)

- `files/local_qa.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python local_qa.py .\docs "연차는 다음 해로 넘어가나요"`
- `python local_qa.py .\docs eval_20.csv`

## 2. 골격 실행 — 위 코드를 `local_qa.py` 로 저장하고 질문 하나로 돌려 근거 id가 붙은 답이 나오는지 본다. `URLError`(연결 거부)가 나면 Ollama 서버가 떠 있지 않은 것이다. …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama list`

## 4. 검색 — 골격은 2-gram 키워드 검색(`search` 함수)이다. 그대로 써도 되고, 임베딩 검색으로 바꿔도 된다. 바꿀 때는 `ollama pull embeddinggemma` 로 모델을 받고 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama pull embeddinggemma`

## 6. 20문항 평가 — 문서 폴더에서 답을 찾을 수 있는 질문 20개와 정답·출처 문서를 먼저 손으로 적는다. 헤더는 `질문,정답,출처 문서,모델 답,정오` 로 하고 UTF-8로 저장한다(엑셀이라면 "CSV …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python local_qa.py .\docs eval_20.csv`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama ps`

## 추가 수행: 검색 실패와 답변 실패를 따로 남기기

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Copy-Item docs docs_minus -Recurse`
- `python local_qa.py .\docs_minus "<그 문서가 답인 질문>"`
