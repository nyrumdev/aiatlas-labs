# 로컬 QA 앱 만들기

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.local_qa_app`(L2 · 약 4시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — local_qa_report.md + eval_20.csv + 코드 저장소 경로.
4. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64(PC)
- Ollama 설치 + gemma4:e4b 받기 완료(앞 실습 [실습] Gemma 4를 내 PC에서 돌리기 통과)
- 파이썬 3 실습 환경 — 설치·가상환경(venv)·스크립트 실행은 파이썬 실습 환경 레슨으로 먼저 준비
- 내 문서 폴더 — UTF-8 마크다운 10~30개
- (임베딩 검색을 고를 때만) ollama pull embeddinggemma

## 들어 있는 파일
- `files/local_qa.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.local_qa_app` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
