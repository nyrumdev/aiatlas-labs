# 모델 내부 열어 보기 — 유도 헤드 끊기와 Gemma Scope 2 특징 개입 — 명령·코드 모음

실습 id: `lab.c.lab.interp_probe`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 가상환경 둘

```powershell
cd C:\work\ai-lab
mkdir interp_probe
cd interp_probe
mkdir env
py -V:3.14 -m venv .venv-tl
.\.venv-tl\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu132
python -m pip install "transformer-lens==4.2.0" "transformers==5.19.0" "matplotlib==3.11.2"
python -m pip check
@('--extra-index-url https://download.pytorch.org/whl/cu132') + (python -m pip freeze) | Out-File -Encoding utf8 env\tl.lock.txt
python -c "import torch; from importlib.metadata import version as v; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), v('transformer-lens'), v('transformers'))" | Out-File -Encoding utf8 env\tl_check.txt
Get-Content env\tl_check.txt
deactivate
py -V:3.14 -m venv .venv-sae
.\.venv-sae\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu132
python -m pip install "sae-lens==6.54.5" "transformer-lens==3.9.0" "transformers==5.19.0" "matplotlib==3.11.2"
python -m pip check
@('--extra-index-url https://download.pytorch.org/whl/cu132') + (python -m pip freeze) | Out-File -Encoding utf8 env\sae.lock.txt
python -c "import torch; from importlib.metadata import version as v; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), v('sae-lens'), v('transformer-lens'), v('transformers'))" | Out-File -Encoding utf8 env\sae_check.txt
Get-Content env\sae_check.txt
```

```powershell
Add-Content ..\.gitignore ".venv-tl/", ".venv-sae/"
git check-ignore -v .venv-tl .venv-sae
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `pip install -r` — CUDA 색인에서 받은 torch 는 freeze 에 `+cu132` 꼬리가 붙은 판으로 적히는데, 그 판은 PyPI 에 없어서 색인 줄이 없으면 `pip install -r` 이 torch 에서 멈춘다.

## 2. 판 고정과 게이트

```powershell
hf auth login
hf download openai-community/gpt2 config.json
hf download google/gemma-3-1b-pt
hf download google/gemma-scope-2-1b-pt resid_post/layer_13_width_65k_l0_medium/config.json resid_post/layer_13_width_65k_l0_medium/params.safetensors
```

## 3. A부 스크립트

- `files/a_induction.py` — 키트에 들어 있음 (python)

## 4. A부 실행과 히트맵

```powershell
python a_induction.py --revision <gpt2 커밋 40자>
```

## 6. B부 공용 코드

- `files/b_common.py` — 키트에 들어 있음 (python)

## 7. 글 파일 다섯 가운데 넷

```text
We cancelled the picnic because of the heavy rain
The roads were slippery after a night of rain
She stood by the window and listened to the rain
```

```text
We cancelled the picnic because of the heavy traffic
The roads were slippery after a night of frost
She stood by the window and listened to the music
```

```text
{"kind": "concept_in", "prompt": "The rain kept falling all afternoon, so she opened her", "target": " umbrella"}
{"kind": "concept_in", "prompt": "After an hour of heavy rain the streets were full of", "target": " puddles"}
{"kind": "concept_out", "prompt": "On the way home we were caught in a sudden", "target": " rain"}
{"kind": "concept_out", "prompt": "He forgot his umbrella and came home soaked from the", "target": " rain"}
{"kind": "neutral", "prompt": "She paid for the groceries with her credit", "target": " card"}
{"kind": "neutral", "prompt": "The capital of France is", "target": " Paris"}
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Out-File -Encoding utf8` — PowerShell 5.1 의 `Out-File -Encoding utf8` 로 만들어 맨 앞에 BOM 이 붙어도(S985) `read_lines` 가 지우고 읽는다.

## 8. SAE 점검

- `files/b_check_sae.py` — 키트에 들어 있음 (python)

```powershell
git add sae_criterion.txt
git commit -m "SAE 점검 기준"
python b_check_sae.py --revision <gemma-3-1b-pt 커밋 40자>
```

## 9. 후보 고르기

- `files/b_find_feature.py` — 키트에 들어 있음 (python)

```powershell
python b_find_feature.py --revision <커밋>
```

```powershell
python b_find_feature.py --revision <커밋> --feature <후보 번호>
```

## 10. 가설 사전 등록

```text
# 가설 — 특징 <번호> (gemma-scope-2-1b-pt · resid_post 13층 · 65k · L0 medium)
이름 가설: <예: 비가 오는 날씨를 말하는 낱말과 그 바로 앞뒤>
근거: candidates.csv 순위 <n> · 차이 <값> · 켜진 비율 개념 <값> / 짝 <값> / 말뭉치 <값> · 켜진 자리 요약 <두 줄> · Neuronpedia 위 로짓에 개념 낱말이 <있음/없음>
세기 목록: 0.25, 0.5, 1, 2 (특징 최댓값의 배수)
P0 시험 가능성: concept_in 프롬프트의 절반 이상에서 특징 <번호> 가 켜졌다(per_prompt.csv 의 fired_i > 0)
P1 끄기: ablate_feature 의 concept_in 변화 95% 구간 위끝 < 0, 그리고 concept_in 프롬프트 <예: 16개 중 13개 이상> 에서 내려감, 그리고 중립 변화 구간이 0 을 포함
P2 끄기 대조: ablate_feature − ablate_control_feature 의 concept_in 짝 차이 95% 구간 위끝 < 0(같은 프롬프트에서 특징 <번호> 를 끈 쪽이 대조 특징을 끈 쪽보다 확실히 더 내려감)
P4 부작용(세기마다): add_feature 의 부작용 손실 증가 < <예: 기준 손실의 5%> — 이를 지킨 양의 세기를 '읽는 세기'라 하고, 읽는 세기가 둘 이상이면 맞음
P3 키우기: P4 가 맞고, 읽는 세기 모두에서 add_feature 의 concept_out 변화가 add_random 다섯 줄의 최댓값보다 크며, 읽는 세기 안에서 세기를 키울수록 커진다
CAA 예측(판정에는 쓰지 않음): 같은 길이에서 <add_caa 와 add_feature 가운데 어느 쪽이 개념 변화가 클지 · 부작용이 클지>
판정 순서(위에서부터 처음 맞는 줄):
⓪ P0 틀림 → P1·P2 는 '시험되지 않음'으로 적는다. P3·P4 가 맞으면 '미는 손잡이는 되지만 끄기는 시험하지 못했다', 아니면 ④
① P1·P2·P3·P4 모두 → 가설 지지(이 층·이 프롬프트·이 세기에서)
② P3·P4 → 미는 손잡이는 되지만, 13층에서 이 특징을 끄는 것이 필요하다는 증거는 없다(P1 이 틀렸다면 앞 층이 이미 정보를 뒤 자리로 옮겼거나 다른 경로·오차 항이 같은 일을 했을 수 있고, P2 만 틀렸다면 개념과 무관한 특징을 꺼도 비슷하게 내려갔다)
③ P1·P2 → 쓰이지만 더해서 밀지는 못했다(이름이 넓거나, 세기가 모자라거나, 낱말을 읽는 입력 쪽 특징이라 다음 낱말로 그 낱말을 미는 효과가 없다 — 근거 줄의 위 로짓과 견준다)
④ 그 밖 → 이름 반박 또는 보류(어느 예측이 왜 틀렸는지 적는다)
```

```powershell
(Get-FileHash hypothesis.md -Algorithm SHA256).Hash | Out-File -Encoding ascii hypothesis.sha256.txt
git add hypothesis.md hypothesis.sha256.txt concept.txt control.txt side_texts.txt eval_prompts.jsonl
git commit -m "interp_probe 가설 사전 등록"
```

## 11. 개입

- `files/b_intervene.py` — 키트에 들어 있음 (python)

```powershell
python b_intervene.py --revision <커밋> --feature <번호> --prereg hypothesis.md
```

## 13. 보고서와 커밋

```text
lab_id: lab.c.lab.interp_probe

## 작업
(두 환경 · 세 커밋 · 실행한 명령 · 고른 개념과 특징 · 사전 등록 시각)

## 결과
(표 A · 표 B · 히트맵과 steer_compare.png 의 경로 · 판정 두 개)

## 검증
(세 묶음을 나눈 것 · 무작위 대조군 · 대조 특징 · 해시와 명령줄 값 대조 · P0 켜짐 기록 · SAE 점검 숫자 · 남은 한계)

c1: …
c2: …
(c8 까지 — 각 줄에 그 체크 항목을 확인한 실제 기록)
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git rev-parse HEAD` — 그다음 스크립트·글 파일·runs 폴더의 CSV·PNG·JSON·보고서를 커밋하고 `git rev-parse HEAD` 의 40자를 c8 줄에 적는다.
- `git status` — `git status` 로 .venv 폴더가 보이지 않는지 확인한다.

## 14. (선택) 한국어 짝

```powershell
python b_find_feature.py --revision <gemma-3-1b-pt 커밋 40자> --concept concept_ko.txt --control control_ko.txt --tag _ko
python b_find_feature.py --revision <gemma-3-1b-pt 커밋 40자> --concept concept_ko.txt --control control_ko.txt --tag _ko --feature <번호>
```

## 15. (선택) 사전 폭

```powershell
python b_find_feature.py --revision <gemma-3-1b-pt 커밋 40자> --tag _16k
python b_find_feature.py --revision <gemma-3-1b-pt 커밋 40자> --tag _262k
```

## 16. (선택) A부 씨앗

```powershell
python a_induction.py --revision <gpt2 커밋 40자> --seed 1 --out runs_a_s1
python a_induction.py --revision <gpt2 커밋 40자> --seed 2 --out runs_a_s2
```

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `pip install` — `pip install` 이 의존 충돌로 멈춘다 → 한 환경에 transformer-lens 4.x 와 sae-lens 를 함께 넣으려 했다(S6447).
- `pip check` — 1단계대로 환경 둘을 쓰고, 각 환경에서 `pip check` 를 다시 본다.
- `pip freeze` — `pip freeze` 로 transformer-lens 가 정말 4.2.0 인지부터 본다.
- `hf download google/gemma-3-1b-pt` — `hf download google/gemma-3-1b-pt` 나 B부 스크립트가 401·403 으로 멈춘다 → 게이트 동의를 안 했거나 로그인이 안 됐다.
- `hf auth whoami` — 모델 페이지에서 동의했는지와 `hf auth whoami` 를 본다(S162 · S6453).
