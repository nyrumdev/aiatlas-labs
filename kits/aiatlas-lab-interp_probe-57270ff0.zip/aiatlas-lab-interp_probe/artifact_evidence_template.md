lab_id: lab.c.lab.interp_probe

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): env/ — tl_check.txt(torch 판 · cuda True · GPU 이름 · transformer-lens 4.2.0 · transformers 5.19.0) + sae_check.txt(같은 칸 + sae-lens 6.54.5 · transformer-lens 3.9.0) + tl.lock.txt · sae.lock.txt(pip freeze) + 두 환경의 pip check 출력 + 환경을 둘로 나눈 까닭 1줄 + 커밋 40자 세 줄(openai-community/gpt2 · google/gemma-3-1b-pt · google/gemma-scope-2-1b-pt) -->
c1: 
<!-- c2(필수): runs_a/induction_scores.csv(144행 = 12층 × 12헤드) + induction_heatmap.png + top_head_pattern.png + 리포트에 상위 다섯 헤드(층.헤드 · 점수)와 그 헤드들이 놓인 층 1줄 + 0층 헤드가 상위에 있는지와 그 까닭 1줄 + 기준 손실 두 개(첫 절반 · 둘째 절반) -->
c2: 
<!-- c3(필수): runs_a/ablation.csv · random_controls.csv · run_meta.json + 리포트의 표 A(제거 방식 zero·mean 두 줄 × 상위 함께 끈 둘째·첫 절반 변화 · 하나씩의 합 · 무작위 둘째 절반 평균·최대 · 무작위 첫 절반 최대) + 목표 절의 A부 판정 규칙으로 고른 판정(zero·mean 각 1줄) + 하나씩의 합과 함께 끈 값이 다른 까닭 1줄 -->
c3: 
<!-- c4(필수): runs_b/sae_check.json(l0_mean · fvu_layer13 · fvu_layer12_wrong_hook · fvu_layer6_wrong_hook · manual_encode_max_abs_diff · loss_base · loss_spliced_recon) + sae_criterion.txt(실행 전에 적은 통과 기준 1줄 · 그 커밋이 sae_check.json 보다 앞) + 리포트에 그 기준과 커밋 해시 1줄 + 13층 FVU 를 12층·6층과 견준 판정 1줄 + 재구성으로 바꿔 넣었을 때 손실이 얼마나 올랐는지와 그것이 B부 결론에 주는 단서 1줄 -->
c4: 
<!-- c5(필수): concept.txt·control.txt(같은 줄 수의 짝 12줄 이상) · side_texts.txt(20줄 이상) · eval_prompts.jsonl(concept_in·concept_out·neutral 각 16행 이상 · 짝 문장과 겹치지 않음) + runs_b/candidates.csv + runs_b/feature_<번호>_tokens.tsv + hypothesis.md(특징 번호 · 이름 가설 · 근거 · 세기 목록 · 예측 P0~P4 · 판정 순서) + hypothesis.sha256.txt(만든 시각이 runs_b/intervene.csv 보다 앞) -->
c5: 
<!-- c6(필수): runs_b/intervene.csv · per_prompt.csv · steer_compare.png · samples.txt · intervene_meta.json(prereg_sha256 이 hypothesis.sha256.txt 의 값과 대소문자만 다르고 같음 · args.feature·args.coefs 가 hypothesis.md 와 같음 · n_fired_i·n_fired_j · removed_norm_i·removed_norm_j · p2_ablate_i_minus_j_concept_in) + per_prompt.csv 의 fired_i·fired_j 칸 + 리포트의 P0 줄(concept_in 에서 특징 i·j 가 켜진 프롬프트 수) + P2 줄(짝 차이 평균·95% 구간 · 빼는 크기 둘) + 표 B(끄기 두 줄의 concept_in 변화와 95% 구간·내려간 프롬프트 수 · 세기마다 특징·CAA 의 concept_out 변화와 95% 구간 · 무작위 다섯 줄의 평균·최댓값(구간은 최댓값 줄의 것) · 중립 변화 · 부작용 손실 변화) -->
c6: 
<!-- c7(필수): 리포트 '판정' 절 — hypothesis.md 의 순서대로 고른 판정 하나 + P0~P4 마다 맞음·틀림(P0 이 틀렸으면 P1·P2 는 시험되지 않음)과 그 숫자 + 읽는 세기 1줄 + 같은 길이에서 CAA 와 특징 방향의 효과·부작용을 견준 2줄 + 이 결과가 말하지 못하는 것 2줄(다른 층·다른 프롬프트·기제) -->
c7: 
<!-- c8(필수): interp_report.md(첫 줄 lab_id: lab.c.lab.interp_probe · ## 작업 · ## 결과 · ## 검증 · c1:~c8: 줄 · 64KiB 이하) + 스크립트·글 파일·결과를 담은 커밋 해시 1줄 -->
c8: 
<!-- c9(선택): (선택) 한국어 짝 — concept_ko.txt·control_ko.txt 로 b_find_feature.py 를 --tag _ko 로 다시 돌린 runs_b/candidates_ko.csv(영어 짝의 candidates.csv 는 그대로) + 고른 특징의 순위·켜진 비율을 영어 짝과 견준 표 한 줄 + 1줄 -->
c9: 
<!-- c10(선택): (선택) 사전 폭 — SAE_ID 를 layer_13_width_16k_l0_medium·layer_13_width_262k_l0_medium 으로 바꿔 같은 짝으로 다시 뽑은 runs_b/candidates_16k.csv · candidates_262k.csv + 개념이 특징 하나에 모이는지 여럿으로 갈리는지 1줄 -->
c10: 
<!-- c11(선택): (선택) A부 씨앗 — --seed 1·2 로 다시 돌린 run_meta.json 두 개 + 상위 다섯 헤드가 겹친 수와 A부 판정이 바뀌었는지 1줄 -->
c11: 
