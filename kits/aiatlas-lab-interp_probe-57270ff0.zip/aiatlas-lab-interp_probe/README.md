# 모델 내부 열어 보기 — 유도 헤드 끊기와 Gemma Scope 2 특징 개입

AI 아틀라스 앱의 실습 `lab.c.lab.interp_probe`(L5 · 약 8시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\work\ai-lab\interp_probe\interp_report.md 를 낸다(UTF-8 · 64KiB 이내) · 같은 폴더에 env\ · runs_a\ · runs_b\ · 스크립트 다섯(a_induction.py · b_common.py · b_check_sae.py · b_find_feature.py · b_intervene.py) · 글 파일 다섯(concept.txt · control.txt · side_texts.txt · eval_prompts.jsonl · hypothesis.md)과 sae_criterion.txt · hypothesis.sha256.txt.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 11 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — A부(GPT-2 small)는 --device cpu 로도 돈다. B부(Gemma 3 1B)는 GPU 에서 bf16 으로 불러 쓰도록 짰고, --device cpu 로 돌리면 float32 로 불러 훨씬 느리다
- 앞 실습 [실습] 글자 단위 작은 GPT를 처음부터 짜서 내 GPU로 학습시키기를 마친 작업대 C:\work\ai-lab — git 저장소와 파이썬 3.14(py -V:3.14 로 부를 수 있어야 한다), 그리고 작업대를 처음 꾸린 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 PyTorch 설치 선택기로 고른 CUDA 색인(예 cu132 · S3458)을 그대로 쓴다. 기억나지 않으면 앞 실습의 .venv 를 켜고 python -c "import torch; print(torch.version.cuda)" 로 CUDA 판(예 13.2 → cu132)을 확인한다
- 가상환경 두 개 — .venv-tl 에는 torch==2.14.1(CUDA 색인) · transformer-lens==4.2.0 · transformers==5.19.0 · matplotlib==3.11.2, .venv-sae 에는 torch==2.14.1(같은 색인) · sae-lens==6.54.5 · transformer-lens==3.9.0 · transformers==5.19.0 · matplotlib==3.11.2. sae-lens 6.54.5 가 transformer-lens 4 미만을 요구해서 한 환경에 둘 수 없다(S6447 · S6446)
- Hugging Face 계정과 읽기 토큰 — google/gemma-3-1b-pt 는 게이트 저장소라 모델 페이지에서 Google 사용 라이선스에 동의한 뒤 hf auth login 으로 받는다(S6453 · S162). GPT-2 와 Gemma Scope 2 저장소는 게이트가 없다(S6456 · S6452)
- 디스크 여유 — GPT-2 무게 파일 548,105,171 바이트(S6456), Gemma 3 1B BF16 무게(파라미터 999,885,952개 · S6453), SAE 무게 파일 604,509,056 바이트(S6452), 그리고 torch 가 두 번 깔리는 가상환경 둘. SAE 폴더에는 SAELens 가 쓰지 않는 examples.safetensors(1,721,339,768 바이트)도 있어, 2단계는 두 파일만 골라 받는다(S9293 · S9294)
- 앞 노드 해석가능성(회로 관점)의 직접 해 보기(induction_check.py)를 돌려 본 기록 — 없으면 A부가 그 실험을 넓혀 대신하되, 그 레슨의 '제거는 낯선 상태를 만든다'와 '백업 헤드' 두 단서를 먼저 읽고 온다

## 들어 있는 파일
- `files/a_induction.py`
- `files/b_common.py`
- `files/b_check_sae.py`
- `files/b_find_feature.py`
- `files/b_intervene.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.interp_probe` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
