"""b_find_feature.py — 개념 문장과 짝 문장의 특징 활성을 견줘 후보를 고르고, 고른 특징이 어디서 켜지는지 본다.

실행 예: python b_find_feature.py --revision <커밋> --concept concept.txt --control control.txt
         python b_find_feature.py --revision <커밋> --feature 12345
         python b_find_feature.py --revision <커밋> --concept concept_ko.txt --control control_ko.txt --tag _ko
만드는 파일: runs_b\\candidates<꼬리>.csv · runs_b\\feature_<번호><꼬리>_tokens.tsv
"""
import argparse
import csv
from pathlib import Path

import torch

from b_common import LAYER, NP_URL, capture, load, max_acts, read_lines


@torch.no_grad()
def top_tokens(model, tok, sae, texts, feature, device, n=30):
    """특징 하나가 가장 세게 켜진 토큰과 그 앞 글(<bos> 제외)."""
    handle, keep = capture(model, LAYER)
    found = []
    try:
        for t in texts:
            keep.clear()
            ids = tok(t, return_tensors="pt").input_ids.to(device)
            model(ids)
            a = sae.encode(keep[0][0])[:, feature].cpu()
            for pos in range(1, ids.shape[1]):
                if a[pos] > 0:
                    left = tok.decode(ids[0, max(1, pos - 8):pos])
                    found.append((a[pos].item(), tok.decode(ids[0, pos:pos + 1]), left, t))
    finally:
        handle.remove()
    return sorted(found, reverse=True)[:n], len(found)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--revision", required=True)
    p.add_argument("--concept", default="concept.txt")
    p.add_argument("--control", default="control.txt")
    p.add_argument("--corpus", default="side_texts.txt")
    p.add_argument("--feature", type=int, default=None, help="주면 후보 고르기 대신 이 특징의 켜진 자리를 본다")
    p.add_argument("--top", type=int, default=15)
    p.add_argument("--tag", default="", help="파일 이름 꼬리(예 _ko · _16k) — 영어 짝의 candidates.csv · feature_<번호>_tokens.tsv 를 덮어쓰지 않게")
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    out = Path("runs_b")
    out.mkdir(exist_ok=True)
    tok, model, sae = load(args.revision, args.device)
    concept, control, corpus = read_lines(args.concept), read_lines(args.control), read_lines(args.corpus)

    if args.feature is not None:
        texts = concept + control + corpus
        rows, n_fired = top_tokens(model, tok, sae, texts, args.feature, args.device)
        path = out / f"feature_{args.feature}{args.tag}_tokens.tsv"
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter="\t")
            w.writerow(["activation", "token", "left_context", "line"])
            for a, token, left, line in rows:
                w.writerow([f"{a:.3f}", repr(token), repr(left), line])
        print(f"특징 {args.feature} · 켜진 토큰 {n_fired}개 · 상위 {len(rows)}개를 {path} 에 저장 · {NP_URL.format(args.feature)}")
        return

    if len(concept) != len(control):
        raise SystemExit("concept.txt 와 control.txt 는 같은 줄 수의 짝이어야 한다")
    a_con = max_acts(model, tok, sae, concept, args.device)          # [짝 수, 특징 수]
    a_ctl = max_acts(model, tok, sae, control, args.device)
    a_cor = max_acts(model, tok, sae, corpus, args.device)
    diff = a_con.mean(0) - a_ctl.mean(0)
    fire_con, fire_ctl = (a_con > 0).float().mean(0), (a_ctl > 0).float().mean(0)
    fire_cor = (a_cor > 0).float().mean(0)
    order = torch.argsort(diff, descending=True)
    cand_path = out / f"candidates{args.tag}.csv"
    with open(cand_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rank", "feature", "mean_max_concept", "mean_max_control", "diff",
                    "fire_concept", "fire_control", "fire_corpus", "neuronpedia"])
        for r, i in enumerate(order[:200].tolist(), 1):
            w.writerow([r, i, f"{a_con[:, i].mean():.3f}", f"{a_ctl[:, i].mean():.3f}", f"{diff[i]:.3f}",
                        f"{fire_con[i]:.2f}", f"{fire_ctl[i]:.2f}", f"{fire_cor[i]:.2f}", NP_URL.format(i)])
            if r <= args.top:
                print(f"{r:2d}. 특징 {i:5d} | 차이 {diff[i]:6.2f} | 켜진 비율 개념 {fire_con[i]:.2f}"
                      f" · 짝 {fire_ctl[i]:.2f} · 말뭉치 {fire_cor[i]:.2f}")
    print(f"저장: {cand_path.resolve()} (상위 200줄)")


if __name__ == "__main__":
    main()
