"""a_induction.py — GPT-2 small 의 헤드마다 유도 점수를 재어 히트맵으로 그리고, 상위 헤드 제거를 무작위 헤드 제거와 견준다.

실행 예: python a_induction.py --revision <gpt2 커밋 40자>
만드는 파일(runs_a 폴더): induction_scores.csv · induction_heatmap.png · top_head_pattern.png
                          ablation.csv · random_controls.csv · run_meta.json
"""
import argparse
import csv
import json
import platform
import random
from datetime import datetime
from importlib.metadata import version
from pathlib import Path

import matplotlib

matplotlib.use("Agg")                                   # 창을 띄우지 않고 파일로만 그린다
import matplotlib.pyplot as plt
import torch
from transformer_lens.model_bridge import TransformerBridge


def random_tokens(batch, seq_len, seed, device, repeat):
    """[무작위 seq_len 개][같은 seq_len 개]. repeat=False 면 뒤 절반도 새로 뽑는다(평균 제거의 기준 묶음)."""
    g = torch.Generator().manual_seed(seed)
    first = torch.randint(1000, 10000, (batch, seq_len), generator=g)
    second = first if repeat else torch.randint(1000, 10000, (batch, seq_len), generator=g)
    return torch.cat([first, second], dim=1).to(device)


def induction_scores(model, tokens, seq_len):
    """헤드마다, 둘째 절반의 각 자리가 '같은 토큰이 앞에 나왔던 자리의 바로 다음 자리'에 준 주의의 평균."""
    n_layers, n_heads = model.cfg.n_layers, model.cfg.n_heads
    scores = torch.zeros(n_layers, n_heads)

    def make_hook(layer):
        def hook(pattern, hook):
            # pattern 모양 = [묶음, 헤드, 받는 자리(query), 보는 자리(key)]
            assert pattern.dim() == 4 and pattern.shape[1] == n_heads, f"pattern 모양 {tuple(pattern.shape)}"
            dest = torch.arange(seq_len, 2 * seq_len, device=pattern.device)   # 둘째 절반의 자리
            src = dest - seq_len + 1                                          # 앞선 같은 토큰의 다음 자리
            stripe = pattern[:, :, dest, src]                                 # [묶음, 헤드, seq_len]
            scores[layer] = stripe.float().mean(dim=(0, 2)).cpu()
        return hook

    hooks = [(f"blocks.{layer}.attn.hook_pattern", make_hook(layer)) for layer in range(n_layers)]
    model.run_with_hooks(tokens, return_type=None, fwd_hooks=hooks)
    return scores


def head_pattern(model, tokens, layer, head):
    """헤드 하나의 주의 패턴(첫 줄 하나) — 그림용."""
    keep = {}

    def hook(pattern, hook):
        keep["p"] = pattern[0, head].float().cpu()
    model.run_with_hooks(tokens[:1], return_type=None, fwd_hooks=[(f"blocks.{layer}.attn.hook_pattern", hook)])
    return keep["p"]


def mean_z(model, tokens):
    """층·헤드마다 hook_z(헤드 출력 직전 값)의 평균 — 평균 제거에 쓴다. 모양 [층, 헤드, d_head]."""
    n_layers, n_heads = model.cfg.n_layers, model.cfg.n_heads
    store = [None] * n_layers

    def make_hook(layer):
        def hook(z, hook):
            # z 모양 = [묶음, 자리, 헤드, d_head]
            assert z.dim() == 4 and z.shape[2] == n_heads, f"hook_z 모양 {tuple(z.shape)}"
            store[layer] = z.float().mean(dim=(0, 1)).clone()
        return hook

    hooks = [(f"blocks.{layer}.attn.hook_z", make_hook(layer)) for layer in range(n_layers)]
    model.run_with_hooks(tokens, return_type=None, fwd_hooks=hooks)
    return torch.stack(store)


def ablation_hooks(heads, mode, means):
    """heads = [(층, 헤드), …] 를 0(zero) 또는 기준 묶음의 평균(mean)으로 바꾸는 훅 목록."""
    by_layer = {}
    for layer, head in heads:
        by_layer.setdefault(layer, []).append(head)

    def make_hook(layer, hs):
        def hook(z, hook):
            for h in hs:
                if mode == "zero":
                    z[:, :, h, :] = 0.0
                else:
                    z[:, :, h, :] = means[layer, h].to(z.dtype)     # [d_head] 가 [묶음, 자리, d_head] 로 브로드캐스팅
            return z
        return hook

    return [(f"blocks.{layer}.attn.hook_z", make_hook(layer, hs)) for layer, hs in by_layer.items()]


def half_losses(model, tokens, seq_len, hooks=()):
    """첫 절반(단서 없음)과 둘째 절반(앞에서 본 짝을 이어 붙이면 맞힘)의 평균 손실."""
    logits = model.run_with_hooks(tokens, return_type="logits", fwd_hooks=list(hooks))
    per_tok = model.loss_fn(logits, tokens, per_token=True)      # [묶음, 2·seq_len − 1] · 자리 p 가 토큰 p+1 을 맞힌다
    first = per_tok[:, : seq_len - 1].float().mean().item()       # 토큰 1 … seq_len−1
    second = per_tok[:, seq_len:].float().mean().item()           # 토큰 seq_len+1 … 끝
    return first, second


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="openai-community/gpt2")
    p.add_argument("--revision", required=True, help="hf download 로 확인한 커밋 40자")
    p.add_argument("--seq_len", type=int, default=50)
    p.add_argument("--batch", type=int, default=20)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--top_k", type=int, default=5)
    p.add_argument("--n_random", type=int, default=20)
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    p.add_argument("--out", default="runs_a")
    args = p.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA 를 쓸 수 없다 — --device cpu 로 돌리거나 torch 설치 줄을 다시 본다")
    torch.set_grad_enabled(False)
    out = Path(args.out)
    out.mkdir(exist_ok=True)

    model = TransformerBridge.boot_transformers(args.model, device=args.device, revision=args.revision)
    model.enable_compatibility_mode(disable_warnings=True)    # 옛 HookedTransformer 와 같은 수치·훅 이름
    n_layers, n_heads, L = model.cfg.n_layers, model.cfg.n_heads, args.seq_len

    # 세 묶음은 씨앗이 다르다 — 고르는 데 쓴 묶음으로 효과를 재지 않는다
    score_toks = random_tokens(args.batch, L, args.seed, args.device, repeat=True)
    eval_toks = random_tokens(args.batch, L, args.seed + 1000, args.device, repeat=True)
    ref_toks = random_tokens(args.batch, L, args.seed + 2000, args.device, repeat=False)

    scores = induction_scores(model, score_toks, L)
    ranked = sorted(((scores[a, b].item(), a, b) for a in range(n_layers) for b in range(n_heads)), reverse=True)
    top = [(a, b) for _, a, b in ranked[: args.top_k]]
    with open(out / "induction_scores.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rank", "layer", "head", "induction_score"])
        for r, (s, a, b) in enumerate(ranked, 1):
            w.writerow([r, a, b, f"{s:.4f}"])

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(scores.numpy(), cmap="viridis", vmin=0.0, vmax=1.0)   # 주의 값은 0~1
    for a, b in top:
        ax.text(b, a, "*", ha="center", va="center", color="white", fontsize=14)
    ax.set_xlabel("head")
    ax.set_ylabel("layer")
    ax.set_title(f"induction score (seq_len {L}, batch {args.batch}, seed {args.seed})")
    fig.colorbar(im, ax=ax, label="mean attention to the token after the earlier copy")
    fig.savefig(out / "induction_heatmap.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    a0, b0 = top[0]
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.imshow(head_pattern(model, eval_toks, a0, b0).numpy(), cmap="viridis", vmin=0.0, vmax=1.0)
    ax.set_xlabel("key position (attended)")
    ax.set_ylabel("query position")
    ax.set_title(f"layer {a0} head {b0} on one repeated sequence")
    fig.savefig(out / "top_head_pattern.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    means = mean_z(model, ref_toks)
    base_first, base_second = half_losses(model, eval_toks, L)
    print(f"기준: 첫 절반 손실 {base_first:.3f} · 둘째 절반 손실 {base_second:.3f}")

    rows = []

    def record(name, heads, mode):
        f1, f2 = half_losses(model, eval_toks, L, ablation_hooks(heads, mode, means))
        rows.append({"condition": name, "mode": mode, "heads": " ".join(f"{a}.{b}" for a, b in heads),
                     "first_loss": f1, "second_loss": f2,
                     "d_first": f1 - base_first, "d_second": f2 - base_second})
        return f1 - base_first, f2 - base_second

    rng = random.Random(args.seed)
    others = [(a, b) for a in range(n_layers) for b in range(n_heads) if (a, b) not in top]
    random_sets = [rng.sample(others, args.top_k) for _ in range(args.n_random)]
    summary = {}
    for mode in ("zero", "mean"):
        top_first, top_second = record(f"top{args.top_k}", top, mode)
        singles = [record("single", [h], mode)[1] for h in top]
        rand = [record("random", hs, mode) for hs in random_sets]
        summary[mode] = {"top_d_second": top_second, "top_d_first": top_first, "sum_of_singles_d_second": sum(singles),
                         "random_d_second_mean": sum(r[1] for r in rand) / len(rand),
                         "random_d_second_max": max(r[1] for r in rand),
                         "random_d_first_max": max(r[0] for r in rand)}
        s = summary[mode]
        print(f"[{mode}] 상위 {args.top_k}개 함께 제거: 둘째 절반 {top_second:+.3f} · 첫 절반 {top_first:+.3f}"
              f" · 하나씩의 합 {sum(singles):+.3f} · 무작위 {args.n_random}회 둘째 절반 평균"
              f" {s['random_d_second_mean']:+.3f} · 최대 {s['random_d_second_max']:+.3f}"
              f" · 무작위 첫 절반 최대 {s['random_d_first_max']:+.3f}")

    fields = ["condition", "mode", "heads", "first_loss", "second_loss", "d_first", "d_second"]
    for name, keep in (("ablation.csv", lambda r: r["condition"] != "random"),
                       ("random_controls.csv", lambda r: r["condition"] == "random")):
        with open(out / name, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                if keep(r):
                    w.writerow({k: (f"{v:.4f}" if isinstance(v, float) else v) for k, v in r.items()})

    meta = {"args": vars(args), "top_heads": [f"{a}.{b}" for a, b in top], "base_first": base_first,
            "base_second": base_second, "summary": summary,
            "versions": {k: version(k) for k in ("transformer-lens", "transformers", "torch")},
            "python": platform.python_version(),
            "device_name": torch.cuda.get_device_name(0) if args.device == "cuda" else platform.processor(),
            "finished_at": datetime.now().isoformat(timespec="seconds")}
    (out / "run_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"저장: {out.resolve()}")


if __name__ == "__main__":
    main()
