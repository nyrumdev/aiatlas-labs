"""b_check_sae.py — 받은 SAE 가 이 모델의 13층 출력에 맞는지 먼저 잰다(특징을 해석하기 전의 점검).

실행 예: python b_check_sae.py --revision <gemma-3-1b-pt 커밋 40자> --texts side_texts.txt
만드는 파일: runs_b\\sae_check.json
"""
import argparse
import json
from datetime import datetime
from importlib.metadata import version
from pathlib import Path

import torch

from b_common import LAYER, MODEL_ID, RELEASE, SAE_ID, capture, edit_layer, load, read_lines, splice_recon, text_loss


@torch.no_grad()
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--revision", required=True)
    p.add_argument("--texts", default="side_texts.txt")
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    out = Path("runs_b")
    out.mkdir(exist_ok=True)
    tok, model, sae = load(args.revision, args.device)
    texts = read_lines(args.texts)
    first_id = tok(texts[0]).input_ids[0]
    if first_id != tok.bos_token_id:                                  # b_*.py 는 0번 자리를 <bos> 로 보고 건너뛴다
        raise SystemExit(f"토큰화한 첫 토큰이 <bos> 가 아니다(id {first_id}) — 토크나이저 판을 확인한다")

    # 13층(맞는 자리)과 12층·6층(일부러 틀린 자리)의 출력을 모은다 — <bos> 자리는 뺀다
    h13, keep13 = capture(model, LAYER)
    h12, keep12 = capture(model, LAYER - 1)                          # 바로 앞 층 — 잔차 연결 때문에 13층과 비슷하기 쉽다
    h6, keep6 = capture(model, LAYER - 7)                            # 멀리 떨어진 층
    try:
        for t in texts:
            model(tok(t, return_tensors="pt").input_ids.to(args.device))
    finally:
        for h in (h13, h12, h6):
            h.remove()
    x13 = torch.cat([k[0, 1:] for k in keep13])                      # [토큰 수, d_model]
    x12 = torch.cat([k[0, 1:] for k in keep12])
    x6 = torch.cat([k[0, 1:] for k in keep6])

    def fvu(x):
        """설명되지 않은 분산의 비율 = 재구성 오차 제곱합 ÷ 평균에서 잰 제곱합."""
        x_hat = sae.decode(sae.encode(x))
        return (((x - x_hat) ** 2).sum() / ((x - x.mean(dim=0)) ** 2).sum()).item()

    acts = sae.encode(x13)
    l0 = (acts > 0).float().sum(dim=-1)                              # 토큰마다 켜진 특징 수
    pre = x13 @ sae.W_enc + sae.b_enc                                 # 손으로 쓴 JumpReLU
    manual = torch.relu(pre) * (pre > sae.threshold).float()
    alive = (acts > 0).any(dim=0)

    base = text_loss(model, tok, texts, args.device)
    handle = edit_layer(model, LAYER, splice_recon(sae))
    try:
        spliced = text_loss(model, tok, texts, args.device)
    finally:
        handle.remove()

    report = {
        "model": MODEL_ID, "revision": args.revision, "release": RELEASE, "sae_id": SAE_ID,
        "d_in": int(sae.W_enc.shape[0]), "d_sae": int(sae.W_enc.shape[1]),
        "n_texts": len(texts), "n_tokens": int(x13.shape[0]),
        "l0_mean": l0.mean().item(), "l0_median": l0.median().item(),
        "fvu_layer13": fvu(x13), "fvu_layer12_wrong_hook": fvu(x12), "fvu_layer6_wrong_hook": fvu(x6),
        "manual_encode_max_abs_diff": (manual - acts).abs().max().item(),
        "features_seen_alive": int(alive.sum().item()),
        "loss_base": base, "loss_spliced_recon": spliced, "loss_increase": spliced - base,
        "versions": {k: version(k) for k in ("sae-lens", "transformer-lens", "transformers", "torch")},
        "finished_at": datetime.now().isoformat(timespec="seconds"),
    }
    (out / "sae_check.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    for k in ("n_tokens", "l0_mean", "fvu_layer13", "fvu_layer12_wrong_hook", "fvu_layer6_wrong_hook",
              "manual_encode_max_abs_diff",
              "loss_base", "loss_spliced_recon"):
        print(f"{k}: {report[k]}")


if __name__ == "__main__":
    main()
