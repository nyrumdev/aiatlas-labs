"""b_intervene.py — 특징 하나를 끄고 키운 효과를, 같은 크기의 CAA 방향·무작위 방향·대조 특징과 나란히 잰다.

실행 예: python b_intervene.py --revision <커밋> --feature 12345 --prereg hypothesis.md
만드는 파일: runs_b\\intervene.csv · runs_b\\per_prompt.csv · runs_b\\steer_compare.png · runs_b\\samples.txt · runs_b\\intervene_meta.json
"""
import argparse
import csv
import hashlib
import json
import random
import re
from datetime import datetime
from importlib.metadata import version
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from b_common import (LAYER, ablate_feature, add_vector, capture, edit_layer, load, max_acts, read_lines,
                      target_logprob, text_loss)

OPEN_PROMPTS = ["Yesterday afternoon I", "The report says that", "My favourite thing about the city is"]


def paired_ci(deltas, iters=2000, seed=0):
    """짝 차이의 평균과 부트스트랩 95% 구간(프롬프트를 다시 뽑는다)."""
    d = torch.tensor(deltas, dtype=torch.float64)
    g = torch.Generator().manual_seed(seed)
    means = d[torch.randint(0, len(d), (iters, len(d)), generator=g)].mean(dim=1)
    return d.mean().item(), torch.quantile(means, 0.025).item(), torch.quantile(means, 0.975).item()


@torch.no_grad()
def last_token_mean(model, tok, texts, device):
    """줄마다 마지막 토큰 자리의 13층 출력을 모아 평균 — CAA 의 재료."""
    handle, keep = capture(model, LAYER)
    try:
        for t in texts:
            model(tok(t, return_tensors="pt").input_ids.to(device))
    finally:
        handle.remove()
    return torch.stack([k[0, -1] for k in keep]).mean(dim=0)


@torch.no_grad()
def prompt_fires(model, tok, sae, prompt, target, feats, device):
    """평가 글(프롬프트 + 표적의 마지막 토큰 앞까지 · <bos> 제외)에서 특징마다 켜진 자리 수 — 끌 것이 있었는지 본다.
    표적의 마지막 토큰 자리는 잰 로그확률에 들어가지 않으므로 뺀다."""
    handle, keep = capture(model, LAYER)
    try:
        model(tok(prompt + target, return_tensors="pt").input_ids.to(device))
    finally:
        handle.remove()
    a = sae.encode(keep[0][0, 1:-1])[:, feats]                       # [자리 수, 특징 수]
    return (a > 0).sum(dim=0).tolist()


@torch.no_grad()
def removed_norm(model, tok, sae, texts, device):
    """특징마다 끄기가 빼는 벡터의 길이 f·‖d‖ 를 켜진 자리(<bos> 제외)끼리 평균 — [특징 수]."""
    handle, keep = capture(model, LAYER)
    total = torch.zeros(sae.W_dec.shape[0], device=sae.W_dec.device)
    count = torch.zeros_like(total)
    try:
        for t in texts:
            keep.clear()
            model(tok(t, return_tensors="pt").input_ids.to(device))
            a = sae.encode(keep[0][0, 1:])                           # [자리, 특징]
            total += a.sum(dim=0)
            count += (a > 0).float().sum(dim=0)
    finally:
        handle.remove()
    return (total / count.clamp(min=1) * sae.W_dec.norm(dim=1)).cpu()


def check_prereg(text, feature, coefs):
    """hypothesis.md 의 첫 줄 특징 번호와 '세기 목록' 줄이 명령줄 값과 같은지 본다."""
    lines = [ln.strip() for ln in text.splitlines()]
    if not lines or not re.search(rf"특징 {feature}(?!\d)", lines[0]):
        raise SystemExit(f"hypothesis.md 첫 줄에 '특징 {feature}' 가 없다 — 사전 등록한 특징으로 돌린다")
    row = next((ln for ln in lines if ln.startswith("세기 목록:")), None)
    if row is None:
        raise SystemExit("hypothesis.md 에 '세기 목록:' 줄이 없다")
    listed = [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", row.split(":", 1)[1].split("(")[0])]
    if listed != coefs:
        raise SystemExit(f"--coefs {coefs} 가 사전 등록한 세기 목록 {listed} 와 다르다 — 바꿨다면 새 사전 등록으로 한다")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--revision", required=True)
    p.add_argument("--feature", type=int, required=True)
    p.add_argument("--prereg", required=True, help="개입 전에 적어 둔 hypothesis.md")
    p.add_argument("--concept", default="concept.txt")
    p.add_argument("--control", default="control.txt")
    p.add_argument("--corpus", default="side_texts.txt")
    p.add_argument("--evals", default="eval_prompts.jsonl")
    p.add_argument("--coefs", default="0.25,0.5,1,2", help="특징 최댓값의 몇 배를 더하나 — hypothesis.md 의 '세기 목록' 과 같아야 한다")
    p.add_argument("--n_random", type=int, default=5)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    torch.set_grad_enabled(False)
    out = Path("runs_b")
    out.mkdir(exist_ok=True)
    prereg_bytes = Path(args.prereg).read_bytes()
    prereg_sha = hashlib.sha256(prereg_bytes).hexdigest()
    coef_list = [float(x) for x in args.coefs.split(",")]
    check_prereg(prereg_bytes.decode("utf-8-sig"), args.feature, coef_list)
    tok, model, sae = load(args.revision, args.device)
    i = args.feature
    concept, control, corpus = read_lines(args.concept), read_lines(args.control), read_lines(args.corpus)
    evals = [json.loads(ln) for ln in read_lines(args.evals)]
    KINDS = ("concept_in", "concept_out", "neutral")
    if sorted({e["kind"] for e in evals}) != sorted(KINDS):
        raise SystemExit("eval_prompts.jsonl 의 kind 는 concept_in · concept_out · neutral 세 가지여야 한다")
    prompts_in = [e["prompt"] for e in evals if e["kind"] == "concept_in"]

    # 세기의 단위 = 개념 문장에서 본 특징 i 의 최댓값 × 사전 방향의 길이
    a_con = max_acts(model, tok, sae, concept, args.device)
    a_ctl = max_acts(model, tok, sae, control, args.device)
    a_max = a_con[:, i].max().item()
    if a_max <= 0:
        raise SystemExit(f"특징 {i} 가 개념 문장에서 한 번도 켜지지 않았다 — b_find_feature.py 결과를 다시 본다")
    d_i = sae.W_dec[i].detach().float()
    unit_norm = a_max * d_i.norm().item()

    # 대조 특징 j: 개념 줄에서 켜지는 비율이 i 와 비슷하되(절반~두 배) 짝 줄에서도 그 절반 이상 켜지는
    # — 곧 이 문장들에서 켜지지만 개념과는 무관한 — 다른 특징 하나를 씨앗으로 고른다.
    # 끌 것이 있어야 대조가 되므로, concept_in 프롬프트의 절반 이상에서 켜지는 특징만 후보로 둔다.
    # 끄기가 빼는 크기(켜진 자리의 f·‖d‖ 평균)도 i 의 절반~두 배로 맞춘다 — 크기가 다르면 대조가 아니라 세기 비교가 된다
    fc, fl = (a_con > 0).float().mean(0), (a_ctl > 0).float().mean(0)
    f_in = (max_acts(model, tok, sae, prompts_in, args.device) > 0).float().mean(0)
    rn = removed_norm(model, tok, sae, concept + prompts_in, args.device)
    ok = ((fc >= fc[i] / 2) & (fc <= min(1.0, fc[i].item() * 2)) & (fl >= fc / 2) & (fc > 0) & (f_in >= 0.5)
          & (rn >= rn[i] / 2) & (rn <= rn[i] * 2))
    near = [j for j in torch.nonzero(ok).flatten().tolist() if j != i]
    if not near:
        raise SystemExit("조건에 맞는 대조 특징이 없다 — 짝 문장이나 concept_in 프롬프트를 늘린다")
    j = random.Random(args.seed).choice(near)
    fires = [prompt_fires(model, tok, sae, e["prompt"], e["target"], [i, j], args.device) for e in evals]

    caa = last_token_mean(model, tok, concept, args.device) - last_token_mean(model, tok, control, args.device)
    caa_unit = caa / caa.norm()
    feat_unit = d_i / d_i.norm()
    g = torch.Generator().manual_seed(args.seed)
    rand_units = []
    for _ in range(args.n_random):
        r = torch.randn(d_i.shape[0], generator=g).to(d_i.device)
        rand_units.append(r / r.norm())

    def measure(fn):
        handle = edit_layer(model, LAYER, fn) if fn is not None else None
        try:
            logps = [target_logprob(model, tok, e["prompt"], e["target"], args.device) for e in evals]
            side = text_loss(model, tok, corpus, args.device)
        finally:
            if handle is not None:
                handle.remove()
        return logps, side

    def sample(fn):
        handle = edit_layer(model, LAYER, fn) if fn is not None else None
        texts = []
        try:
            for q in OPEN_PROMPTS:
                ids = tok(q, return_tensors="pt").input_ids.to(args.device)
                gen = model.generate(ids, max_new_tokens=30, do_sample=False)
                texts.append(q + " ▶ " + tok.decode(gen[0, ids.shape[1]:], skip_special_tokens=True))
        finally:
            if handle is not None:
                handle.remove()
        return texts

    conditions = [("ablate_feature", 0.0, -1, ablate_feature(sae, i)),
                  ("ablate_control_feature", 0.0, -1, ablate_feature(sae, j))]
    for c in coef_list:
        norm = c * unit_norm                                           # 세 방향 모두 같은 길이를 더한다
        conditions.append(("add_feature", c, -1, add_vector(norm * feat_unit)))
        conditions.append(("add_caa", c, -1, add_vector(norm * caa_unit)))
        for s, u in enumerate(rand_units):
            conditions.append(("add_random", c, s, add_vector(norm * u)))

    base_logps, base_side = measure(None)
    rows, per_prompt, ablated = [], [], {}
    for name, c, s, fn in conditions:
        logps, side = measure(fn)
        if name.startswith("ablate_"):
            ablated[name] = logps
        row = {"condition": name, "coef": c, "seed": s, "added_norm": c * unit_norm,
               "side_loss": side, "d_side_loss": side - base_side}
        for kind in KINDS:
            deltas = [lp - b for lp, b, e in zip(logps, base_logps, evals) if e["kind"] == kind]
            m, lo, hi = paired_ci(deltas, seed=args.seed)
            row.update({f"d_{kind}": m, f"d_{kind}_lo": lo, f"d_{kind}_hi": hi,
                        f"n_{kind}_down": sum(x < 0 for x in deltas), f"n_{kind}": len(deltas)})
        rows.append(row)
        for e, lp, b, fr in zip(evals, logps, base_logps, fires):
            per_prompt.append({"condition": name, "coef": c, "seed": s, "kind": e["kind"],
                               "prompt": e["prompt"], "target": e["target"], "base_logp": b, "logp": lp,
                               "fired_i": fr[0], "fired_j": fr[1]})
        print(f"{name:24s} c={c:<4g} s={s:<2d} | 안 {row['d_concept_in']:+.3f} [{row['d_concept_in_lo']:+.3f}, "
              f"{row['d_concept_in_hi']:+.3f}] | 밖 {row['d_concept_out']:+.3f} [{row['d_concept_out_lo']:+.3f}, "
              f"{row['d_concept_out_hi']:+.3f}] | 중립 {row['d_neutral']:+.3f} | 부작용 손실 {row['d_side_loss']:+.4f}")

    # P2 재료: 같은 concept_in 프롬프트에서 (i 를 끈 로그확률) − (j 를 끈 로그확률) 의 짝 차이
    diff_ij = [a - b for a, b, e in zip(ablated["ablate_feature"], ablated["ablate_control_feature"], evals)
               if e["kind"] == "concept_in"]
    p2_mean, p2_lo, p2_hi = paired_ci(diff_ij, seed=args.seed)

    for name, data in (("intervene.csv", rows), ("per_prompt.csv", per_prompt)):
        with open(out / name, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            w.writeheader()
            for r in data:
                w.writerow({k: (f"{v:.4f}" if isinstance(v, float) else v) for k, v in r.items()})

    c_top = max(coef_list)
    lines = []
    for name, fn in (("base", None), ("ablate_feature", ablate_feature(sae, i)),
                     (f"add_feature c={c_top:g}", add_vector(c_top * unit_norm * feat_unit)),
                     (f"add_caa c={c_top:g}", add_vector(c_top * unit_norm * caa_unit)),
                     (f"add_random s=0 c={c_top:g}", add_vector(c_top * unit_norm * rand_units[0]))):
        lines.append(f"===== {name} =====")
        lines += sample(fn)
        lines.append("")
    (out / "samples.txt").write_text("\n".join(lines), encoding="utf-8")

    coefs = sorted({r["coef"] for r in rows if r["condition"].startswith("add_")})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    for key, ax, label in (("d_concept_out", axes[0], "change in concept_out target log-prob"),
                           ("d_side_loss", axes[1], "change in side-text loss")):
        for name, style in (("add_feature", "o-"), ("add_caa", "s-")):
            ax.plot(coefs, [next(r[key] for r in rows if r["condition"] == name and r["coef"] == c) for c in coefs],
                    style, label=name)
        rnd = [[r[key] for r in rows if r["condition"] == "add_random" and r["coef"] == c] for c in coefs]
        ax.plot(coefs, [sum(v) / len(v) for v in rnd], "x--", label="add_random (mean)")
        ax.fill_between(coefs, [min(v) for v in rnd], [max(v) for v in rnd], alpha=0.2, label="add_random (min-max)")
        ax.axhline(0.0, color="gray", linewidth=0.8)
        ax.set_xlabel(f"coefficient (x feature max {a_max:.1f})")
        ax.set_ylabel(label)
        ax.legend(fontsize=8)
    fig.savefig(out / "steer_compare.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    meta = {"args": vars(args), "prereg_sha256": prereg_sha, "feature": i, "control_feature": j,
            "a_max": a_max, "decoder_norm": d_i.norm().item(), "unit_norm": unit_norm,
            "caa_norm": caa.norm().item(), "cos_caa_feature": torch.dot(caa_unit, feat_unit).item(),
            "removed_norm_i": rn[i].item(), "removed_norm_j": rn[j].item(),
            "p2_ablate_i_minus_j_concept_in": {"mean": p2_mean, "lo": p2_lo, "hi": p2_hi,
                                               "n_i_lower": sum(x < 0 for x in diff_ij), "n": len(diff_ij)},
            "base_side_loss": base_side, "n_eval": len(evals),
            "n_fired_i": {k: sum(fr[0] > 0 for fr, e in zip(fires, evals) if e["kind"] == k) for k in KINDS},
            "n_fired_j": {k: sum(fr[1] > 0 for fr, e in zip(fires, evals) if e["kind"] == k) for k in KINDS},
            "n_by_kind": {k: sum(e["kind"] == k for e in evals) for k in KINDS},
            "versions": {k: version(k) for k in ("sae-lens", "transformer-lens", "transformers", "torch")},
            "finished_at": datetime.now().isoformat(timespec="seconds")}
    (out / "intervene_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"대조 특징 {j} · CAA 와 특징 방향의 코사인 {meta['cos_caa_feature']:+.3f} · prereg sha256 {prereg_sha[:12]}…")
    print(f"concept_in 에서 특징 {i} 가 켜진 프롬프트 {meta['n_fired_i']['concept_in']}/{meta['n_by_kind']['concept_in']}"
          f" · 대조 특징 {j} {meta['n_fired_j']['concept_in']}/{meta['n_by_kind']['concept_in']} (P0 은 이 줄로 판정)")
    print(f"P2 짝 차이(i 끄기 − j 끄기, concept_in) {p2_mean:+.3f} [{p2_lo:+.3f}, {p2_hi:+.3f}]"
          f" · 빼는 크기 i {meta['removed_norm_i']:.2f} · j {meta['removed_norm_j']:.2f}")


if __name__ == "__main__":
    main()
