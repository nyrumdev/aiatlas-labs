"""b_common.py — Gemma 3 1B(사전학습판)와 Gemma Scope 2 잔차 SAE 를 불러오고, 13층 출력에 손을 대는 도구(b_*.py 가 함께 쓴다)."""
from pathlib import Path

import torch
from sae_lens import SAE
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_ID = "google/gemma-3-1b-pt"
RELEASE = "gemma-scope-2-1b-pt-res"            # SAELens 의 릴리스 이름 → google/gemma-scope-2-1b-pt
SAE_ID = "layer_13_width_65k_l0_medium"         # → resid_post/layer_13_width_65k_l0_medium
LAYER = 13                                      # SAE 가 읽는 곳 = model.layers.13.output(13층 출력 잔차)
NP_URL = "https://www.neuronpedia.org/gemma-3-1b/13-gemmascope-2-res-65k/{}"


def load(revision, device):
    tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=revision)
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID, revision=revision, dtype=dtype).to(device).eval()
    sae = SAE.from_pretrained(RELEASE, SAE_ID, device=device)    # v6 부터 SAE 하나만 돌려준다
    return tok, model, sae


def read_lines(path):
    lines = [ln.strip() for ln in Path(path).read_text(encoding="utf-8-sig").splitlines()]   # 맨 앞 BOM 은 지운다
    return [ln for ln in lines if ln and not ln.startswith("#")]


def start(h):
    """한 번에 여러 자리를 계산할 때는 0번(<bos>)을 건너뛴다. 생성 중 한 토큰씩 올 때는 0부터."""
    return 1 if h.shape[1] > 1 else 0


def edit_layer(model, layer, fn):
    """layer 층 출력(잔차)을 fn(h) 로 바꾸는 훅을 건다. 돌려받은 손잡이로 .remove() 한다."""
    def hook(module, args, output):
        h = output[0] if isinstance(output, tuple) else output       # 판에 따라 텐서 또는 튜플
        h = fn(h)
        return (h,) + tuple(output[1:]) if isinstance(output, tuple) else h
    return model.model.layers[layer].register_forward_hook(hook)


def capture(model, layer):
    """layer 층 출력을 복사해 두는 훅. 돌려받은 목록에 실행마다 하나씩 쌓인다."""
    keep = []

    def fn(h):
        keep.append(h.detach().float().clone())
        return h
    return edit_layer(model, layer, fn), keep


def ablate_feature(sae, i):
    """특징 i 의 몫만 뺀다: h ← h − f_i(h)·d_i. 재구성되지 않은 오차 몫은 그대로 둔다."""
    d = sae.W_dec[i]                                                 # [d_model] 사전의 한 줄 = 특징 방향

    def fn(h):
        a = sae.encode(h.float())[..., i:i + 1]                      # [묶음, 자리, 1]
        a[:, : start(h)] = 0.0
        return (h.float() - a * d).to(h.dtype)
    return fn


def add_vector(vec):
    """모든 자리(<bos> 제외)에 vec 를 더한다 — 특징 키우기·CAA·무작위 방향이 모두 이 꼴."""
    def fn(h):
        h = h.clone()
        s = start(h)
        h[:, s:] = (h[:, s:].float() + vec).to(h.dtype)             # [d_model] 가 [묶음, 자리, d_model] 로 브로드캐스팅
        return h
    return fn


def splice_recon(sae):
    """13층 출력을 SAE 재구성으로 바꿔 넣는다(<bos> 자리는 그대로)."""
    def fn(h):
        h = h.clone()
        s = start(h)
        h[:, s:] = sae.decode(sae.encode(h[:, s:].float())).to(h.dtype)
        return h
    return fn


@torch.no_grad()
def target_logprob(model, tok, prompt, target, device):
    """prompt 다음에 target 이 올 로그확률(토큰들의 합)."""
    p_ids = tok(prompt, return_tensors="pt").input_ids.to(device)              # 맨 앞 <bos>(b_check_sae.py 가 확인)
    full = tok(prompt + target, return_tensors="pt").input_ids.to(device)
    n_p = p_ids.shape[1]
    if full.shape[1] <= n_p or not torch.equal(full[0, :n_p], p_ids[0]):
        raise SystemExit(f"경계에서 토큰이 합쳐졌다 — target 을 공백으로 시작하게 고친다: {prompt!r} + {target!r}")
    logp = torch.log_softmax(model(full).logits[0, :-1].float(), dim=-1)    # 줄 k 가 토큰 k+1 을 맞힌다
    tgt = full[0, n_p:]
    return logp[n_p - 1:].gather(1, tgt[:, None]).sum().item()


@torch.no_grad()
def text_loss(model, tok, texts, device):
    """글 여러 줄의 토큰당 평균 손실 — 부작용 지표."""
    total, n = 0.0, 0
    for t in texts:
        ids = tok(t, return_tensors="pt").input_ids.to(device)
        k = ids.shape[1] - 1
        total += model(ids, labels=ids).loss.item() * k
        n += k
    return total / n


@torch.no_grad()
def max_acts(model, tok, sae, texts, device):
    """줄마다 특징별 최댓값(<bos> 제외) — [줄 수, 특징 수]."""
    handle, keep = capture(model, LAYER)
    rows = []
    try:
        for t in texts:
            keep.clear()
            model(tok(t, return_tensors="pt").input_ids.to(device))
            rows.append(sae.encode(keep[0][:, 1:]).amax(dim=1)[0].cpu())
    finally:
        handle.remove()
    return torch.stack(rows)
