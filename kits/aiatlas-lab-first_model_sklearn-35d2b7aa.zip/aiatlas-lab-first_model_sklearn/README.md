# 표데이터 첫 모델을 끝까지 — 기준선·파이프라인·교차검증·잠근 테스트·집단별 오류

AI 아틀라스 앱의 실습 `lab.c.lab.first_model_sklearn`(L2 · 약 4시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰이나 PC)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱 제출 = first_model_report.md 파일 하나 · 같은 C:\work\ai-lab\first_model 폴더에 part1_baseline_cv.py · part1_leakage.py · part1_cv.csv · part1_thresholds.csv · part1_leakage.json (2부를 하면 + part2_common.py · part2_lock_split.py · part2_compare.py · part2_search_test.py · adult_lock.json · adult_test_index.txt · part2_cv_compare.csv · part2_test.json · part2_groups.csv).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — GPU 는 쓰지 않는다(전부 CPU)
- 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 만든 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 scikit-learn 이 이미 있고, git 저장소와 requirements.txt·requirements.lock.txt 가 있다
- 인터넷 — 1단계에서 scikit-learn 1.9.1·pandas 3.0.6 판을 맞출 때와 2부 7단계에서 OpenML 의 Adult 표를 처음 받을 때만 쓴다(1부의 데이터는 내려받지 않는다)
- 메모장 등 글 편집기 — 코드 파일과 보고서 first_model_report.md 를 쓴다

## 들어 있는 파일
- `files/part1_baseline_cv.py`
- `files/part1_leakage.py`
- `files/part2_common.py`
- `files/part2_lock_split.py`
- `files/part2_compare.py`
- `files/part2_search_test.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.first_model_sklearn` in the AI Atlas app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
