# 파인튜닝 1회 + 평가 리포트 — 명령·코드 모음

실습 id: `lab.c.lab.finetune_report`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 2. 실행 환경과 판 고정

```powershell
wsl --install            # 관리자 PowerShell · 끝나면 재시작
wsl -l -v                # 재시작 뒤 — Ubuntu 줄의 VERSION 이 2 인지 본다
```

```bash
sudo apt update && sudo apt install -y python3-venv python3-dev build-essential git
mkdir -p ~/ft-lab/env ~/ft-lab/runs && cd ~/ft-lab
python3 --version                      # 3.11~3.14 여야 한다(trl 1.15.0 은 3.11 이상 · torch 의 Triton 은 3.15 미만)
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132
python -m pip install "trl[peft]==1.15.0" "transformers==5.19.0" "peft==0.21.2" "datasets==5.1.0" "accelerate==1.15.0" "matplotlib==3.11.2" "bitsandbytes==0.50.2" "pyyaml==6.0.3"
python -c "import torch, trl, bitsandbytes, trl.trainer.utils as u; c = torch.cuda.is_available(); print(torch.__version__, c, torch.cuda.get_device_name(0) if c else None, torch.cuda.is_bf16_supported() if c else None, trl.__version__, bitsandbytes.__version__, u._ChunkedLogProbFunction)" | tee env/env_check.txt
```

```bash
{ echo "--extra-index-url https://download.pytorch.org/whl/cu132"; python -m pip freeze; } > env/requirements.lock.txt
grep -E "^(torch|torchvision|transformers|peft|trl|bitsandbytes|accelerate|datasets)==" env/requirements.lock.txt
git init && git config user.name "내 이름" && git config user.email "내 메일"
printf ".venv/\nruns/\n__pycache__/\n" > .gitignore
explorer.exe .
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `pip install transformers` — transformers 는 torchvision 을 선택 묶음(vision)에만 적어 `pip install transformers` 로는 깔리지 않는다(S9286).
- `hf download google/gemma-4-E4B-it` — `hf download google/gemma-4-E4B-it` 로 WSL 의 기본 캐시에 받는다(S162).
- `cd ~/ft-lab && source .venv/bin/activate` — Ubuntu 창을 새로 열 때마다 먼저 `cd ~/ft-lab && source .venv/bin/activate` 를 치고, 프롬프트 앞에 (.venv) 가 보이는지 확인한다.

## 3. 데이터

```bash
python -c "import json; t={json.dumps(json.loads(l)['prompt'],ensure_ascii=False) for l in open('train_data.jsonl',encoding='utf-8')}; v=[json.dumps(json.loads(l)['prompt'],ensure_ascii=False) for l in open('val_data.jsonl',encoding='utf-8')]; print(len(t), len(v), sum(x in t for x in v))"
```

## 6. 설정 파일과 학습 스크립트

- `files/qlora_config.yaml` — 키트에 들어 있음 (yaml)

- `files/train_qlora.py` — 키트에 들어 있음 (python)

## 7. 예행 학습

- `files/reload_check.py` — 키트에 들어 있음 (python)

- `files/plot_loss.py` — 키트에 들어 있음 (python)

```bash
git add reload_check.py plot_loss.py && git commit -m "예행 점검 스크립트"
sed -e "s/^train_rows: null.*/train_rows: 20/" -e "s/^output_dir: runs\/main/output_dir: runs\/rehearsal/" -e "s/^  max_steps: -1.*/  max_steps: 50/" qlora_config.yaml > qlora_config_rehearsal.yaml
diff qlora_config.yaml qlora_config_rehearsal.yaml
git add qlora_config_rehearsal.yaml && git commit -m "예행 설정"
python train_qlora.py --config qlora_config_rehearsal.yaml --show-example
python record_run.py runs/rehearsal
python train_qlora.py --config qlora_config_rehearsal.yaml
ls runs/rehearsal runs/rehearsal/adapter
python plot_loss.py runs/rehearsal/trainer_state.json --out runs/rehearsal/loss_curve.png
python reload_check.py --config qlora_config_rehearsal.yaml --adapter runs/rehearsal/adapter --question "내 평가 문항 하나" --out runs/rehearsal/reload_check.json
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `mv runs/rehearsal runs/rehearsal_e4b` — E4B 예행 폴더는 `mv runs/rehearsal runs/rehearsal_e4b` 로 이름을 바꿔 변종을 고른 근거로 남긴다.
- `hf download google/gemma-4-E2B-it` — 그다음 `hf download google/gemma-4-E2B-it` 로 원본을 받고(S162), 위 sed 줄로 예행 설정을 다시 만든 뒤 …
- `git add qlora_config.yaml qlora_config_rehearsal.yaml && git commit -m "E2B 로 전환"` — … 로 원본을 받고(S162), 위 sed 줄로 예행 설정을 다시 만든 뒤 `git add qlora_config.yaml qlora_config_rehearsal.yaml && git commit -m "E2B 로 전환"` 으로 두 파일을 함께 커밋하고 예행부터 …

## 9. 학습과 손실 곡선

```bash
python -m pip freeze | diff <(grep -v "^--" env/requirements.lock.txt) - && echo "lock 과 같음"
python record_run.py runs/main
python train_qlora.py --config qlora_config.yaml
python plot_loss.py runs/main/trainer_state.json --out runs/main/loss_curve.png
```

## 13. (선택) 어댑터를 16비트 원본에 병합하고, llama.cpp 의 convert_hf_to_gguf.py 와 llama-quantize 로 GGUF 를 만든 뒤(S51) Modelfile 의 FROM 줄에 …

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama create` — … llama.cpp 의 convert_hf_to_gguf.py 와 llama-quantize 로 GGUF 를 만든 뒤(S51) Modelfile 의 FROM 줄에 적어 `ollama create` 로 등록한다(S137) — 앞 노드 Gemma 4 파인튜닝 경로의 마지막 단계다.
- `wsl --shutdown` — … 파일의 `[wsl2]` 칸에 `memory=` 를 늘려 적고(가이드의 E2B 값보다 넉넉하되 PC 메모리 안에서 · 값 끝에 GB 를 붙인다), PowerShell 에서 `wsl --shutdown` 으로 WSL 을 완전히 내린 뒤 다시 연다(S7662).
- `explorer.exe .` — 만든 GGUF 는 Windows 쪽 Ollama 가 읽을 수 있게 `explorer.exe .` 로 연 탐색기에서 Windows 폴더로 복사한다(S3599).

## 15. 리포트

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cp finetune_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/` — 다 쓰면 `cp finetune_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/` 로 Windows 쪽에 복사해(WSL 안에서 Windows 의 C 드라이브는 /mnt/c 다 · S3599) 앱에서 그 파일을 고른다.

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -m pip install torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132` — 가상환경을 켠 채 `python -m pip install torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132`(cu126 을 골랐다면 그 주소)로 넣는다.
- `wsl -l -v` — PowerShell 의 `wsl -l -v` 에서 VERSION 이 2 인지(S3594), WSL 안에 리눅스용 드라이버를 깔지 않았는지(S3593) 본다.
- `wsl --shutdown` — Windows 쪽 NVIDIA 드라이버를 최신으로 올린 뒤(S3593) `wsl --shutdown` 하고 다시 연다.

## 추가 수행: 데이터 계보와 실패 주입 확인

```bash
python -c "import json; print(sum(not ''.join(m['content'] for m in json.loads(l)['completion']).strip() for l in open('train_data.jsonl',encoding='utf-8')))"
```
