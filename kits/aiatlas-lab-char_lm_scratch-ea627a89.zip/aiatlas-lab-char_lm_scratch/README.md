# 글자 단위 언어 모델 — 세어서 만든 bigram → 신경망 bigram → 작은 MLP(CPU)

AI 아틀라스 앱의 실습 `lab.c.lab.char_lm_scratch`(L2 · 약 3시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰이나 PC)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱 제출 = C:\work\char-lm\char_lm_report.md 파일 하나 · 같은 폴더에 스크립트 일곱 개(common.py · prepare_names.py · count_bigram.py · neural_bigram.py · mlp_lm.py · make_table.py · test_once.py) + data\split.json + results 폴더(count_bigram.json · neural_bigram.json · row_diff.md · mlp.json · table.md · test_once.json) + versions.txt · requirements.txt · requirements.lock.txt.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — GPU 는 쓰지 않는다(세 모델 모두 CPU 에서 돈다)
- 파이썬 3.14 — PyTorch 설치 안내가 적은 Windows 지원 범위(3.10~3.14) 안의 판이다(S481). 가상환경 만들기·활성화·`python -m pip` 는 파이썬 실습 환경 레슨에서 익힌 그대로 쓴다(S160 · S161)
- 인터넷 — 이름 목록 파일 하나(GitHub 표시 223 KB · S6281)를 받고 torch 를 설치할 때만 쓴다
- (이미 했다면) [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)의 작업대 C:\work\ai-lab 과 그 .venv 를 그대로 써도 된다 — CUDA 판 torch 가 들어 있어도 이 실습 코드는 텐서를 GPU 로 옮기지 않으므로 CPU 에서 돈다
- 메모장 등 글 편집기 — 코드 파일을 UTF-8 로 저장한다
- (선택) Karpathy 강좌의 makemore 1·2편 영상(영어) — 이 실습과 같은 순서를 손으로 짜 보인다(S12)

## 들어 있는 파일
- `files/common.py`
- `files/prepare_names.py`
- `files/count_bigram.py`
- `files/neural_bigram.py`
- `files/mlp_lm.py`
- `files/make_table.py`
- `files/test_once.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.char_lm_scratch` in the AI Atlas app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
