# 논문 3편 요약 + 견해 1편 — 명령·코드 모음

실습 id: `lab.c.lab.paper_review`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 10. 재현 시도

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install numpy
.\.venv\Scripts\python.exe c8_recheck.py
```

- `files/c8_recheck.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `py -m venv .venv` — 아래 코드를 작업 폴더에 `c8_recheck.py` 로 UTF-8 저장하고 PowerShell 에서 친다(`python` 이 없다고 나오면 첫 줄을 `py -m venv .venv` 로).
