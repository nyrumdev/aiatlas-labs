# 소형 모델 GRPO 강화학습 + Pass@k/Maj@k 로 새 능력인지 가리기 — 명령·코드 모음

실습 id: `lab.c.lab.grpo_reasoning`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 실행 환경

```powershell
wsl --install            # 관리자 PowerShell · 끝나면 재시작
wsl -l -v                # 재시작 뒤 — Ubuntu 줄의 VERSION 이 2 인지 본다
```

```bash
sudo apt update && sudo apt install -y python3-venv python3-dev build-essential
mkdir -p ~/grpo-lab/env ~/grpo-lab/configs ~/grpo-lab/baseline && cd ~/grpo-lab
python3 --version                      # 3.11~3.14 여야 한다(trl 1.15.0 은 3.11 이상 · torch 의 Triton 은 3.15 미만)
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu130
python -m pip install "trl[peft]==1.15.0" "transformers==5.19.0" "peft==0.21.2" "datasets==5.1.0" "accelerate==1.15.0" "matplotlib==3.11.2"
python -m pip freeze > env/requirements.lock.txt
python -c "import torch, trl, trl.trainer.utils as u; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), torch.cuda.is_bf16_supported(), trl.__version__, u._ChunkedLogProbFunction)" | tee env/wsl_check.txt
python -c "import torch; f = torch.compile(lambda x: x * 2); print(f(torch.ones(4, device='cuda')))" | tee -a env/wsl_check.txt
explorer.exe .
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -c "import trl, trl.trainer.utils as u; print(trl.__version__, u._ChunkedLogProbFunction)"` — Windows 가상환경이 따로 있다면 거기서 `python -c "import trl, trl.trainer.utils as u; print(trl.__version__, u._ChunkedLogProbFunction)"` 를 쳐 보고, 찍힌 판과 맨 끝 값을 리포트에 1줄 …
- `cd ~/grpo-lab && source .venv/bin/activate` — Ubuntu 창을 새로 열 때마다 먼저 `cd ~/grpo-lab && source .venv/bin/activate` 를 치고, 프롬프트 앞에 (.venv) 가 보이는지 확인한다. (c2)

## 3. 모델·데이터를 받고 판을 고정한다

```bash
hf download Qwen/Qwen2.5-0.5B-Instruct            # 마지막 줄 경로의 snapshots/ 다음 40자가 모델 커밋
hf download openai/gsm8k --repo-type dataset      # 같은 방식으로 데이터 커밋
```

- `files/grpo_common.py` — 키트에 들어 있음 (python)

- `files/make_splits.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python make_splits.py <데이터 커밋>` — `python make_splits.py <데이터 커밋>` 의 출력(행 수 · 겹침 셋 · gold None)을 리포트에 붙인다.

## 4. 학습 스크립트

- `files/train_grpo.py` — 키트에 들어 있음 (python)

- `files/configs/R0.json` — 키트에 들어 있음 (json)

## 5. 시운전 → 기반 모델 dev 확인 → 사전 등록 → 학습

- `files/derive.py` — 키트에 들어 있음 (python)

```bash
python derive.py R0_smoke max_steps 2
python train_grpo.py configs/R0_smoke.json
```

```bash
time python sample_eval.py --split splits/dev200.jsonl --n 8 --out samples/base_dev.jsonl
python score.py samples/base_dev.jsonl --out results/base_dev
```

```bash
sha256sum prereg.md configs/R0.json | tee env/prereg.sha256
python train_grpo.py configs/R0.json
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git init -q && git add prereg.md configs/R0.json && git -c user.name=me -c user.email=me@localhost commit -qm prereg` — 따로 기록을 남기고 싶으면 test200 을 재기 전에 `git init -q && git add prereg.md configs/R0.json && git -c user.name=me -c user.email=me@localhost commit -qm prereg` 로 커밋해 …
- `sudo apt install -y git` — … configs/R0.json && git -c user.name=me -c user.email=me@localhost commit -qm prereg` 로 커밋해 둔다(선택 · git 이 없으면 `sudo apt install -y git

## 6. 표본을 뽑아 채점한다

- `files/sample_eval.py` — 키트에 들어 있음 (python)

- `files/score.py` — 키트에 들어 있음 (python)

```bash
python sample_eval.py --split splits/test200.jsonl --n 8 --out samples/base_test.jsonl
python sample_eval.py --adapter runs/R0/final --split splits/test200.jsonl --n 8 --out samples/R0_test.jsonl
python score.py samples/base_test.jsonl samples/R0_test.jsonl --out results/test200
```

## 7. 손잡이를 하나씩

```bash
python derive.py R0s1 seed 1
python derive.py R1 num_generations 4
python derive.py R2 num_generations 16
python derive.py R3 beta 0.04
for r in R0s1 R1 R2 R3; do echo "== $r"; python -c "import json,sys; a,b=(json.load(open(p,encoding='utf-8')) for p in sys.argv[1:3]); [print(k, a.get(k), '->', b.get(k)) for k in dict.fromkeys([*a, *b]) if a.get(k) != b.get(k)]" configs/R0.json configs/$r.json; done
for r in R0s1 R1 R2 R3; do python train_grpo.py configs/$r.json; done
for r in R0 R0s1 R1 R2 R3; do
  python sample_eval.py --adapter runs/$r/final --split splits/dev200.jsonl --n 8 --out samples/${r}_dev.jsonl
  python score.py samples/${r}_dev.jsonl --out results/${r}_dev
done
for r in R0s1 R1 R2 R3; do
  python score.py samples/R0_dev.jsonl samples/${r}_dev.jsonl --out results/pair_R0_${r}_dev
done
```

## 8. 보상 해킹 구간

- `files/plot_run.py` — 키트에 들어 있음 (python)

```bash
python sample_eval.py --split splits/dev200.jsonl --n 4 --out samples/R0_ckpt/checkpoint-0_dev.jsonl
for d in runs/R0/checkpoint-*; do
  python sample_eval.py --adapter "$d" --split splits/dev200.jsonl --n 4 --out "samples/R0_ckpt/$(basename "$d")_dev.jsonl"
done
python plot_run.py runs/R0 samples/R0_ckpt
```

## 9. 새 능력인가

```bash
if grep -q . results/test200_to_recheck.txt; then
  python sample_eval.py --split splits/test200.jsonl --only results/test200_to_recheck.txt --n 64 --batch_questions 1 --seed 1 --out samples/base_recheck64.jsonl
  python sample_eval.py --adapter runs/R0/final --split splits/test200.jsonl --only results/test200_to_recheck.txt --n 64 --batch_questions 1 --seed 1 --out samples/R0_recheck64.jsonl
  python score.py samples/base_recheck64.jsonl samples/R0_recheck64.jsonl --out results/recheck64 --recheck
else
  echo "재검사 대상 0개 — 9단계를 건너뛴다 (test200_to_recheck.txt 의 줄 수 $(grep -c . results/test200_to_recheck.txt))"
fi
```

## 10. 리포트

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `cp grpo_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/` — 다 쓰면 `cp grpo_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/` 로 Windows 쪽에 복사해(WSL 안에서 Windows 의 C 드라이브는 /mnt/c 다 · S3599) 앱에서 그 파일을 고른다.

## 11. (선택) Gemma 3 1B

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python derive.py G0 model_id '"google/gemma-3-1b-it"'` — (선택) Gemma 3 1B — `python derive.py G0 model_id '"google/gemma-3-1b-it"'` 로 설정을 만든 뒤, G0.json 의 model_revision 을 그 저장소 커밋으로 바꾼다.

## 12. (선택) 형식 보상만 키우기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python derive.py R5 reward_weights "[1.0, 2.0]"` — (선택) 형식 보상만 키우기 — `python derive.py R5 reward_weights "[1.0, 2.0]"` 로 R5 를 학습하고 8단계를 되풀이해 R0 그림과 나란히 놓는다.

## 13. (선택) 큰 k 곡선

- `files/passk_curve.py` — 키트에 들어 있음 (python)

```bash
head -n 50 splits/test200.jsonl > splits/test50.jsonl
python sample_eval.py --split splits/test50.jsonl --n 64 --batch_questions 1 --out samples/base_k64.jsonl
python sample_eval.py --adapter runs/R0/final --split splits/test50.jsonl --n 64 --batch_questions 1 --out samples/R0_k64.jsonl
python passk_curve.py samples/base_k64.jsonl samples/R0_k64.jsonl
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git log -1 --format=%ci -- prereg.md` — … 에서 해시 파일이 먼저이고, `sha256sum -c env/prereg.sha256` 이 두 파일 모두 OK 인가 · (선택) 커밋했다면 `git log -1 --format=%ci -- prereg.md` 의 시각이 samples/base_test.jsonl 보다 이른가 …

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `wsl -l -v` — `wsl -l -v` 로 WSL 2 인지도 본다(S3594).
- `cd ~/grpo-lab && source .venv/bin/activate` — `cd ~/grpo-lab && source .venv/bin/activate` 를 치고 다시 실행한다.
