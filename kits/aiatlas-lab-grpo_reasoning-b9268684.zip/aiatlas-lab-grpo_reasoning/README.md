# 소형 모델 GRPO 강화학습 + Pass@k/Maj@k 로 새 능력인지 가리기

AI 아틀라스 앱의 실습 `lab.c.lab.grpo_reasoning`(L5 · 약 10시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — grpo_report.md(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c1:~c8: 줄 · 64KiB 이하) + prereg.md + baseline/ + env/ + splits/ + configs/ + runs/R0/ + samples/ + results/ — 모두 WSL 의 ~/grpo-lab 안(앱에 낼 grpo_report.md 는 Windows 쪽으로 복사).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 11 · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) 와 Windows 쪽 NVIDIA 드라이버 — WSL 2 안에는 리눅스용 디스플레이 드라이버를 설치하지 않는다(S3593)
- WSL 2 + Ubuntu(관리자 PowerShell 에서 wsl --install 후 재시작 · S3594) — TRL 1.15.0 의 GRPOTrainer 는 학습 걸음마다 Triton 커널을 거치는데 Windows 용 PyTorch 에는 Triton 이 함께 설치되지 않아, Windows 파이썬에서는 첫 걸음에서 멈춘다(S3595·S3596·S3597). 그래서 학습과 평가는 모두 WSL 안에서 한다
- WSL 안의 Python 3.11~3.14 가상환경 · C 컴파일러와 파이썬 헤더(apt 의 build-essential · python3-dev — Triton 이 커널용 모듈을 빌드할 때 쓴다 · S3598) · CUDA 판 torch==2.14.1(설치 선택기 S481 · S3597) · trl[peft]==1.15.0 · transformers==5.19.0 · peft==0.21.2 · datasets==5.1.0 · accelerate==1.15.0 · matplotlib==3.11.2(S3588) — 설치한 판 전체는 pip freeze 로 남긴다(S985)
- 앞 노드 검증 가능한 보상 강화학습(RLVR)과 GRPO 레슨의 직접 해 보기(엄격한 확인기 대 허술한 확인기) 결과 — 아직 없으면 1단계 환경에서 먼저 돌린다
- 앞 노드 [실습] 파인튜닝 1회 + 평가 리포트의 리포트 — 전후 표와 회귀 절의 짜임을 그대로 가져온다
- (선택 과제 c9 용) Hugging Face 계정과 읽기 토큰 — google/gemma-3-1b-it 는 게이트 저장소라 모델 페이지에서 조건에 동의한 뒤 hf auth login 으로 받는다(S3586·S162)
- 디스크 여유 — 모델·데이터 캐시, 체크포인트, 표본 파일이 쌓인다

## 들어 있는 파일
- `files/grpo_common.py`
- `files/make_splits.py`
- `files/train_grpo.py`
- `files/configs/R0.json`
- `files/derive.py`
- `files/sample_eval.py`
- `files/score.py`
- `files/plot_run.py`
- `files/passk_curve.py`
- `files/baseline/grpo_mini.py`
- `files/baseline/eval_mini.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.grpo_reasoning` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
