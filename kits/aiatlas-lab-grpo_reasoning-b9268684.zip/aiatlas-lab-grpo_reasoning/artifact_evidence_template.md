lab_id: lab.c.lab.grpo_reasoning

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): baseline/ — 앞 노드 GRPO 레슨 직접 해 보기의 strict·loose 두 실행 기록(trainer_state.json 두 개 또는 reward 곡선 그림) + 엄격 평가 세 줄 표(기반·strict·loose 의 정답 수/50) + 그때 쓴 trl 판 1줄 + 학습 보상과 엄격 평가가 벌어졌는지 1줄 -->
c1: 
<!-- c2(필수): env/ — wsl_check.txt(torch 판 · cuda True · GPU 이름 · bf16 지원 · trl 1.15.0 · 첫 줄 끝 값이 None 이 아님 · 둘째 줄에 커널 빌드 점검의 tensor 출력) + requirements.lock.txt(pip freeze) + 리포트에 붙인 wsl -l -v 출력(VERSION 2) -->
c2: 
<!-- c3(필수): splits/ — train_pool·dev200·test200 세 jsonl(행마다 qid·question·gold) + make_splits.py 출력 붙여 넣기(행 수 · 세 겹침 0 · gold None 0) + 모델 커밋과 GSM8K 커밋 40자 두 줄(configs/R0.json 의 model_revision·dataset_revision 과 같음) -->
c3: 
<!-- c4(필수): results/base_dev_summary.csv(본 학습 전에 잰 기반 모델 dev 지표 · format_fail_rate) + prereg.md(test200 을 재기 전에 적은 R0 설정 전체 · 순서 판정 규칙 · 시간 어림 · loss_type dapo · beta 0.0 · num_generations 8 · 걸음당 질문 4개) + env/prereg.sha256(prereg.md·configs/R0.json 해시 — samples/base_test.jsonl 보다 먼저 생김) + runs/R0/ — run_config.json · run_meta.json(판·GPU·메모리 정점·학습 초) · trainer_state.json · final/adapter_model.safetensors -->
c4: 
<!-- c5(필수): results/test200_summary.csv(기반·R0 의 Pass@1·Pass@8·Maj@8 과 95% 구간 · 느슨한 추출 Pass@1·Pass@8 · format_fail_rate · truncated_rate + diff 다섯 줄) + test200_per_question.csv + 두 표본 파일의 .meta.json(n 8 · 온도 0.7 · top_p 1.0 · top_k 0 · max_new_tokens 512 가 같음) + 리포트에 전후 표 1개(형식 실패율 전후 포함) -->
c5: 
<!-- c6(필수): results/ablation.csv — R0·R0s1(씨앗만 1)·R1(num_generations 4)·R2(num_generations 16)·R3(beta 0.04) 다섯 줄 × dev200 의 Pass@1·Pass@8·Maj@8(구간 포함) · R0 대비 짝 차이와 95% 구간(results/pair_R0_<실행>_dev_summary.csv 의 diff 줄 · R0 줄은 비움) · 걸음당 질문 수 · 메모리 정점 · kl 기록 여부 + 줄마다 R0 대 R0s1 짝 차이와 견준 해석 1문장 + 표 아래 비교 횟수 9 + 학습 씨앗은 한 쌍·평가 씨앗은 하나(0)로만 쟀다는 한계 1줄 -->
c6: 
<!-- c7(필수): runs/R0/hacking.png(형식 보상·정답 보상·dev Pass@1·평균 길이·frac_reward_zero_std·correct_zero_std_frac 이 같은 걸음 축) + runs/R0/dev_curve.csv + 리포트에 표시한 해킹 구간(걸음 범위 · 8단계 세 조건이 함께 맞는 곳)과 그 구간 samples_train.jsonl 답을 5개까지 읽은 표(모자라면 남은 만큼과 그 사실) — 구간이 없으면 없다고 본 근거 -->
c7: 
<!-- c8(필수): 리포트 '판정' 절 — prereg.md 의 순서 규칙으로 고른 새 능력(후보) / 확률이 모였다 / 형식을 배웠다 / 판단 보류 가운데 하나 + 근거(느슨한·엄격 Pass@1·Pass@8 짝 차이 구간 · 형식 실패율 전후와 형식만 고쳐진 문항 수(test200_format_only.txt) · results/recheck64_per_question.csv 와 recheck64_candidates.txt · 재검사한 문항 수 — 재검사 대상이 0개였다면 test200_to_recheck.txt 가 비었다는 사실(grep -c . 이 0 · 9단계 블록이 찍은 건너뜀 줄) · 잃은 문항 수) + 이 결론이 말하지 못하는 것 1줄 -->
c8: 
<!-- c9(선택): (선택) google/gemma-3-1b-it 로 R0 를 되풀이 — model_id·model_revision 만 바꾼 configs/G0.json 과 test200 전후 표 + 문서 예가 아니어서 생긴 문제와 해결 기록 -->
c9: 
<!-- c10(선택): (선택) 형식 보상 비중만 키운 R5(reward_weights [1.0, 2.0])의 hacking.png 와 R0 그림의 차이 3줄 -->
c10: 
<!-- c11(선택): (선택) test200 앞 50문항에서 기반·R0 를 64번씩 뽑은 Pass@k 곡선(passk_curve.py 출력 · k 1~64) + 두 곡선이 만나거나 뒤집히는지 1줄 -->
c11: 
