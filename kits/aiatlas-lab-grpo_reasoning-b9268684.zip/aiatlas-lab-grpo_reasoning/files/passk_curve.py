"""passk_curve.py — python passk_curve.py samples/base_k64.jsonl samples/R0_k64.jsonl"""
import sys
from collections import defaultdict

import grpo_common as common

for path in sys.argv[1:]:
    n, c = defaultdict(int), defaultdict(int)
    for r in common.read_jsonl(path):
        n[r["qid"]] += 1
        c[r["qid"]] += r["correct"]
    ks = [k for k in (1, 2, 4, 8, 16, 32, 64) if k <= min(n.values())]
    vals = [sum(common.pass_at_k(n[q], c[q], k) for q in n) / len(n) for k in ks]
    print(path, " ".join(f"k={k}:{v:.3f}" for k, v in zip(ks, vals)))
