"""make_splits.py — python make_splits.py <GSM8K 데이터 커밋>"""
import random
import sys
from pathlib import Path

from datasets import load_dataset

import grpo_common as common

REV = sys.argv[1]
Path("splits").mkdir(exist_ok=True)
train = load_dataset("openai/gsm8k", "main", split="train", revision=REV)
test = load_dataset("openai/gsm8k", "main", split="test", revision=REV)


def rows(ds, prefix):
    return [{"qid": f"{prefix}{i:04d}", "question": r["question"], "gold": common.gold_of(r["answer"])}
            for i, r in enumerate(ds)]


tr, te = rows(train, "tr"), rows(test, "te")
random.Random(1234).shuffle(tr)
dev200, pool = tr[:200], tr[200:]
test200 = random.Random(5678).sample(te, 200)

# 보류 문항과 글자까지 같은 질문은 학습 풀에서 뺀다
held = {r["question"].strip() for r in dev200 + test200}
before = len(pool)
pool = [r for r in pool if r["question"].strip() not in held]

for name, part in [("train_pool", pool), ("dev200", dev200), ("test200", test200)]:
    common.write_jsonl(f"splits/{name}.jsonl", part)

q = {name: {r["question"].strip() for r in part}
     for name, part in [("pool", pool), ("dev", dev200), ("test", test200)]}
print("rows  pool", len(pool), " dev", len(dev200), " test", len(test200), " removed", before - len(pool))
print("overlap  pool-dev", len(q["pool"] & q["dev"]), " pool-test", len(q["pool"] & q["test"]),
      " dev-test", len(q["dev"] & q["test"]))
print("gold None", sum(r["gold"] is None for r in pool + dev200 + test200))
