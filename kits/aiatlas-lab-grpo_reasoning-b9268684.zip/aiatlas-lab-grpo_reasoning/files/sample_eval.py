"""sample_eval.py — 문항마다 n 번 뽑아 답과 정오를 jsonl 로 남긴다.
python sample_eval.py --split splits/test200.jsonl --n 8 --out samples/base_test.jsonl
python sample_eval.py --adapter runs/R0/final --split splits/test200.jsonl --n 8 --out samples/R0_test.jsonl
"""
import argparse
import json
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, set_seed

import grpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("--config", default="configs/R0.json")    # 모델 id·커밋을 학습과 같은 파일에서 읽는다
ap.add_argument("--adapter", default=None)                 # 없으면 기반 모델
ap.add_argument("--split", required=True)
ap.add_argument("--only", default=None)                    # qid 목록 파일(재검사용)
ap.add_argument("--n", type=int, default=8)
ap.add_argument("--temperature", type=float, default=0.7)
ap.add_argument("--max_new_tokens", type=int, default=512)
ap.add_argument("--batch_questions", type=int, default=4)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--out", required=True)
a = ap.parse_args()

cfg = json.loads(Path(a.config).read_text(encoding="utf-8"))
set_seed(a.seed)
tok = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg["model_revision"])
tok.padding_side = "left"
if tok.pad_token is None:
    tok.pad_token = tok.eos_token
model = AutoModelForCausalLM.from_pretrained(cfg["model_id"], revision=cfg["model_revision"],
                                             dtype=cfg["dtype"]).to("cuda")
if a.adapter:
    model = PeftModel.from_pretrained(model, a.adapter)
model.eval()
eos = model.generation_config.eos_token_id
eos = set(eos if isinstance(eos, list) else [eos])
# 모델 저장소의 generation_config.json 값이 끼어들지 않게 생성 설정을 모두 적는다
gen = dict(do_sample=True, temperature=a.temperature, top_p=1.0, top_k=0, repetition_penalty=1.0,
           max_new_tokens=a.max_new_tokens, num_return_sequences=a.n, pad_token_id=tok.pad_token_id)

rows = common.read_jsonl(a.split)
if a.only:
    keep = set(Path(a.only).read_text(encoding="utf-8").split())
    rows = [r for r in rows if r["qid"] in keep]
out = []
for s in range(0, len(rows), a.batch_questions):
    part = rows[s:s + a.batch_questions]
    texts = [tok.apply_chat_template([{"role": "user", "content": r["question"] + "\n\n" + common.SUFFIX}],
                                     tokenize=False, add_generation_prompt=True) for r in part]
    enc = tok(texts, return_tensors="pt", padding=True).to("cuda")
    with torch.no_grad():
        seqs = model.generate(**enc, **gen)
    for j, ids in enumerate(seqs[:, enc["input_ids"].shape[1]:].tolist()):
        r = part[j // a.n]                             # 한 문항의 n 개가 이어서 나온다
        text = tok.decode(ids, skip_special_tokens=True)
        pred = common.extract(text)                 # 엄격 — 보상과 같은 규칙
        loose = common.loose_extract(text)          # 느슨 — 형식 실패와 내용 실패를 가르는 보조 칸
        out.append({"qid": r["qid"], "k": j % a.n, "gold": r["gold"], "pred": pred,
                    "correct": int(pred == r["gold"]), "fmt_ok": int(pred is not None),
                    "loose_pred": loose, "loose_correct": int(loose == r["gold"]),
                    "truncated": int(not eos & set(ids)), "text": text})
    print(f"{min(s + a.batch_questions, len(rows))}/{len(rows)}", flush=True)

Path(a.out).parent.mkdir(parents=True, exist_ok=True)
common.write_jsonl(a.out, out)
meta = {"args": vars(a), "model_id": cfg["model_id"], "model_revision": cfg["model_revision"],
        "generation": {k: v for k, v in gen.items() if k != "pad_token_id"}}
Path(a.out + ".meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
