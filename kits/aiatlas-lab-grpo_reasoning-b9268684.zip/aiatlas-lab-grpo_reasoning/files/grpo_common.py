"""grpo_common.py — 답 뽑기·보상·Pass@k 를 학습과 평가가 함께 쓴다."""
import json
import re
from decimal import Decimal, InvalidOperation

SUFFIX = ("Solve the problem step by step. "
          "On the last line, write only 'Answer: <number>'.")
ANSWER_LINE = re.compile(r"^\s*Answer:\s*\$?\s*(-?[\d,]*\.?\d+)\s*\.?\s*$")
NUMBER = re.compile(r"-?[\d,]*\.?\d+")


def to_number(text):
    """'1,234'·'72.0' 같은 표기를 한 꼴의 글자로 맞춘다. 숫자가 아니면 None."""
    try:
        d = Decimal(text.replace(",", "").strip())
    except InvalidOperation:
        return None
    return format(d.normalize(), "f")


def gold_of(gsm8k_answer):
    """GSM8K answer 칸의 '#### 72' 뒤 숫자."""
    return to_number(gsm8k_answer.split("####")[-1])


def extract(completion):
    """빈 줄을 뺀 마지막 줄이 'Answer: 숫자' 꼴일 때만 그 숫자를 돌려준다."""
    lines = [ln for ln in completion.strip().splitlines() if ln.strip()]
    if not lines:
        return None
    m = ANSWER_LINE.match(lines[-1])
    return to_number(m.group(1)) if m else None


def loose_extract(completion):
    """평가 보조 전용(보상에는 쓰지 않는다) — 꼴과 상관없이 글에 나온 마지막 숫자를 답으로 본다."""
    nums = NUMBER.findall(completion)
    return to_number(nums[-1]) if nums else None


def text_of(completion):
    """대화형 완성([{'role': .., 'content': ..}])과 문자열 완성을 모두 받는다."""
    return completion[0]["content"] if isinstance(completion, list) else completion


def correct_reward(completions, gold, **kwargs):
    return [1.0 if extract(text_of(c)) == g else 0.0 for c, g in zip(completions, gold)]


def format_reward(completions, **kwargs):
    return [0.0 if extract(text_of(c)) is None else 1.0 for c in completions]


def pass_at_k(n, c, k):
    """n 번 뽑아 c 번 맞았을 때 Pass@k 의 편향 없는 추정(1 - C(n-c,k)/C(n,k))."""
    if n - c < k:
        return 1.0
    prod = 1.0
    for i in range(n - c + 1, n + 1):
        prod *= 1.0 - k / i
    return 1.0 - prod


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
