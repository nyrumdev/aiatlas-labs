"""derive.py — python derive.py R1 num_generations 4   (R0.json 에서 한 칸만 바꾼 설정을 만든다)"""
import json
import sys
from pathlib import Path

name, key, raw = sys.argv[1:4]
cfg = json.loads(Path("configs/R0.json").read_text(encoding="utf-8"))
assert key in cfg, f"R0.json 에 없는 칸: {key}"
cfg[key] = json.loads(raw)
cfg["run"], cfg["output_dir"] = name, f"runs/{name}"
Path(f"configs/{name}.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
print(name, key, "=", cfg[key])
