"""score.py — 문항별로 모아 Pass@1·Pass@k·Maj@k 와 부트스트랩 95% 구간을 낸다.
한 파일:  python score.py samples/R0_dev.jsonl --out results/R0_dev
전후 짝:  python score.py samples/base_test.jsonl samples/R0_test.jsonl --out results/test200
재검사 짝: python score.py samples/base_recheck64.jsonl samples/R0_recheck64.jsonl --out results/recheck64 --recheck
"""
import argparse
import csv
import random
from collections import Counter, defaultdict
from math import comb
from pathlib import Path

import grpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("files", nargs="+")
ap.add_argument("--out", required=True)
ap.add_argument("--R", type=int, default=10000)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--recheck", action="store_true")      # 재검사 짝이면 새 능력 후보 목록을 쓴다(9단계)
a = ap.parse_args()
rng = random.Random(a.seed)


def per_question(path):
    by = defaultdict(list)
    for r in common.read_jsonl(path):
        by[r["qid"]].append(r)
    q = {}
    for qid, rs in by.items():
        votes = Counter(r["pred"] for r in rs if r["pred"] is not None)
        top = votes.most_common(1)[0][0] if votes else None   # 동률이면 먼저 나온 답
        q[qid] = {"n": len(rs), "c": sum(r["correct"] for r in rs), "maj": int(top == rs[0]["gold"]),
                  "lc": sum(r["loose_correct"] for r in rs),      # 느슨한 추출로 맞은 수
                  "nofmt": sum(1 - r["fmt_ok"] for r in rs),     # 마지막 줄 꼴을 못 지킨 수
                  "trunc": sum(r["truncated"] for r in rs)}
    return q


def scores(q, qids):
    ns = {q[i]["n"] for i in qids}
    assert len(ns) == 1, f"문항마다 뽑은 수가 다르다: {ns}"
    k = ns.pop()
    return k, {"Pass@1": [common.pass_at_k(q[i]["n"], q[i]["c"], 1) for i in qids],
               f"Pass@{k}": [common.pass_at_k(q[i]["n"], q[i]["c"], k) for i in qids],
               f"Maj@{k}": [q[i]["maj"] for i in qids],
               "loose_Pass@1": [common.pass_at_k(q[i]["n"], q[i]["lc"], 1) for i in qids],
               f"loose_Pass@{k}": [common.pass_at_k(q[i]["n"], q[i]["lc"], k) for i in qids]}


def ci(vals):
    m = len(vals)
    boots = sorted(sum(rng.choices(vals, k=m)) / m for _ in range(a.R))
    return boots[int(0.025 * a.R)], boots[int(0.975 * a.R) - 1]


def rate(q, qids, key):
    return sum(q[i][key] for i in qids) / sum(q[i]["n"] for i in qids)


def fisher_greater(tc, tn, bc, bn):
    """한쪽 피셔 정확 검정 p: 맞은 수 합을 고정할 때 학습 후 쪽이 tc 번 이상 맞을 확률(초기하 분포)."""
    K, N = tc + bc, tn + bn
    return sum(comb(tn, x) * comb(bn, K - x) for x in range(tc, min(K, tn) + 1)) / comb(N, K)


qs = [per_question(f) for f in a.files]
qids = sorted(qs[0])
if not qids:                                           # 빈 표본 파일 — 9단계라면 재검사 대상이 0개다
    raise SystemExit("문항이 0개다: 재검사 대상이 0개면 9단계를 건너뛰고 그 사실을 적는다")
assert all(sorted(q) == qids for q in qs), "파일마다 문항 id 묶음이 다르다"
Path(a.out).parent.mkdir(parents=True, exist_ok=True)
table = []
all_scores = []
for f, q in zip(a.files, qs):
    k, sc = scores(q, qids)
    all_scores.append(sc)
    for name, vals in sc.items():
        lo, hi = ci(vals)
        table.append([Path(f).stem, name, sum(vals) / len(vals), lo, hi])
    table.append([Path(f).stem, "format_fail_rate", rate(q, qids, "nofmt"), "", ""])
    table.append([Path(f).stem, "truncated_rate", rate(q, qids, "trunc"), "", ""])
if len(qs) == 2:                                       # 짝 비교: 문항 id 를 다시 뽑는 것 = 문항별 차이를 다시 뽑는 것
    for name in all_scores[0]:
        d = [y - x for x, y in zip(all_scores[0][name], all_scores[1][name])]
        lo, hi = ci(d)
        table.append(["diff(after-before)", name, sum(d) / len(d), lo, hi])
    b, t = qs
    newly = [i for i in qids if b[i]["c"] == 0 and t[i]["c"] > 0]
    lost = [i for i in qids if b[i]["c"] > 0 and t[i]["c"] == 0]
    fmt_only = [i for i in newly if b[i]["lc"] > 0]     # 전에도 정답 숫자는 냈다 — 형식만 고쳐진 문항
    to_recheck = [i for i in newly if b[i]["lc"] == 0]  # 9단계 재검사 대상
    for name, ids in [("newly_solved", newly), ("lost", lost), ("format_only", fmt_only), ("to_recheck", to_recheck)]:
        Path(f"{a.out}_{name}.txt").write_text("".join(i + "\n" for i in ids), encoding="utf-8")  # 0개면 빈 파일
    with open(a.out + "_per_question.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["qid", "n_before", "n_after", "c_before", "c_after", "lc_before", "lc_after",
                    "nofmt_before", "nofmt_after", "maj_before", "maj_after"])
        for i in qids:
            w.writerow([i, b[i]["n"], t[i]["n"], b[i]["c"], t[i]["c"], b[i]["lc"], t[i]["lc"],
                        b[i]["nofmt"], t[i]["nofmt"], b[i]["maj"], t[i]["maj"]])
    print(f"newly solved {len(newly)} (format only {len(fmt_only)}) / lost {len(lost)}")
    if a.recheck:
        # 기반 모델이 엄격·느슨 모두 0/n 이고, 한쪽 피셔 정확 검정(학습 후가 더 자주 맞는가)의 p 가
        # 0.05 를 재검사 문항 수로 나눈 값보다 작은 문항만 새 능력 후보로 남긴다(n=64·문항 1개면 5번 이상).
        m = max(len(qids), 1)
        cand = [i for i in qids if b[i]["c"] == 0 and b[i]["lc"] == 0
                and fisher_greater(t[i]["c"], t[i]["n"], b[i]["c"], b[i]["n"]) < 0.05 / m]
        Path(a.out + "_candidates.txt").write_text("".join(i + "\n" for i in cand), encoding="utf-8")
        print(f"new-ability candidates {len(cand)} / rechecked {m} (alpha {0.05 / m:.4g} each)")
else:                                                  # 한 파일: 문항별 맞은 수만 남긴다
    with open(a.out + "_per_question.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["qid", "n", "c", "lc", "nofmt", "maj"])
        for i in qids:
            r = qs[0][i]
            w.writerow([i, r["n"], r["c"], r["lc"], r["nofmt"], r["maj"]])

with open(a.out + "_summary.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["model", "metric", "mean", "ci_low", "ci_high"])
    for row in table:
        w.writerow([row[0], row[1]] + [f"{v:.4f}" if isinstance(v, float) else v for v in row[2:]])
for row in table:
    print(row[0], row[1], *[f"{v:.3f}" if isinstance(v, float) else v for v in row[2:]])
