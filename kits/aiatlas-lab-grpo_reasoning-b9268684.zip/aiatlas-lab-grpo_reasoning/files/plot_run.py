"""plot_run.py — 학습 기록과 체크포인트별 dev Pass@1 을 같은 걸음 축에 그린다.
python plot_run.py runs/R0 samples/R0_ckpt --zone 150 300
"""
import argparse
import csv
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import grpo_common as common

ap = argparse.ArgumentParser()
ap.add_argument("run")
ap.add_argument("ckpt_samples")
ap.add_argument("--zone", type=int, nargs=2, default=None)   # 보상 해킹으로 표시할 걸음 범위
a = ap.parse_args()

run = Path(a.run)
hist = json.loads((run / "trainer_state.json").read_text(encoding="utf-8"))["log_history"]


def series(key):
    pts = [(h["step"], h[key]) for h in hist if key in h]
    return [p[0] for p in pts], [p[1] for p in pts]


dev = []
for f in Path(a.ckpt_samples).glob("checkpoint-*_dev.jsonl"):
    step = int(re.search(r"checkpoint-(\d+)", f.name).group(1))
    rs = common.read_jsonl(f)
    dev.append((step, sum(r["correct"] for r in rs) / len(rs)))
dev.sort()
with open(run / "dev_curve.csv", "w", newline="", encoding="utf-8") as fh:
    csv.writer(fh).writerows([["step", "dev_pass1"]] + dev)

fig, ax = plt.subplots(3, 1, figsize=(9, 9), sharex=True)
ax[0].plot(*series("rewards/format_reward/mean"), label="format reward (train)")
ax[0].plot(*series("rewards/correct_reward/mean"), label="correct reward (train)")
if dev:
    ax[0].plot([d[0] for d in dev], [d[1] for d in dev], "o-", label="dev Pass@1 (checkpoints)")
ax[0].set_ylabel("rate")
ax[1].plot(*series("completions/mean_length"), label="mean completion length")
ax[1].set_ylabel("tokens")
ax[2].plot(*series("frac_reward_zero_std"), label="frac_reward_zero_std (weighted sum)")
ax[2].plot(*series("correct_zero_std_frac"), label="correct_zero_std_frac (correct reward only)")
ax[2].plot(*series("completions/clipped_ratio"), label="clipped_ratio")
ax[2].set_xlabel("step")
for x in ax:
    if a.zone:
        x.axvspan(a.zone[0], a.zone[1], alpha=0.15, color="red")
    x.legend(loc="best")
fig.tight_layout()
fig.savefig(run / "hacking.png", dpi=120)
print("saved", run / "hacking.png", "and", run / "dev_curve.csv")
