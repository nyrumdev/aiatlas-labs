"""train_grpo.py — python train_grpo.py configs/R0.json"""
import json
import sys
import time
from pathlib import Path

import datasets
import peft
import torch
import transformers
import trl
from datasets import Dataset
from peft import LoraConfig
from trl import GRPOConfig, GRPOTrainer

import grpo_common as common

cfg = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
out = Path(cfg["output_dir"])
out.mkdir(parents=True, exist_ok=True)
(out / "run_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

train = Dataset.from_list([
    {"prompt": [{"role": "user", "content": r["question"] + "\n\n" + common.SUFFIX}],
     "gold": r["gold"], "qid": r["qid"]}
    for r in common.read_jsonl(cfg["train_file"])
])
log_file = open(out / "samples_train.jsonl", "w", encoding="utf-8")   # 다시 돌리면 새로 쓴다


def correct_reward(completions, gold, trainer_state=None, log_metric=None, **kwargs):
    rewards = common.correct_reward(completions, gold)
    if log_metric is not None:                   # 질문 하나의 답 묶음 안에서 정답 보상이 모두 같은 묶음의 비율
        g = cfg["num_generations"]               # (frac_reward_zero_std 는 두 보상의 가중합 기준이다)
        groups = [rewards[i:i + g] for i in range(0, len(rewards), g)]
        log_metric("correct_zero_std_frac", sum(len(set(x)) == 1 for x in groups) / len(groups))
    # 보상은 갱신 전에 매기므로 +1 = 이 답으로 갱신한 뒤 log_history·checkpoint 에 붙는 걸음
    step = trainer_state.global_step + 1 if trainer_state is not None else -1
    if step % cfg["sample_every"] == 0:          # 정해 둔 걸음마다 답 4개를 파일로 남긴다
        for c, g, r in list(zip(completions, gold, rewards))[:4]:
            log_file.write(json.dumps({"step": step, "gold": g, "reward": r,
                                       "text": common.text_of(c)}, ensure_ascii=False) + "\n")
        log_file.flush()
    return rewards


args = GRPOConfig(
    output_dir=str(out), seed=cfg["seed"],
    num_generations=cfg["num_generations"], beta=cfg["beta"], loss_type=cfg["loss_type"],
    learning_rate=cfg["learning_rate"], max_steps=cfg["max_steps"],
    per_device_train_batch_size=cfg["per_device_train_batch_size"],
    gradient_accumulation_steps=cfg["gradient_accumulation_steps"],
    max_completion_length=cfg["max_completion_length"], temperature=cfg["temperature"],
    reward_weights=cfg["reward_weights"], logging_steps=cfg["logging_steps"],
    save_steps=cfg["save_steps"], bf16=cfg["bf16"],
    model_init_kwargs={"dtype": cfg["dtype"], "revision": cfg["model_revision"]},
)
lora = LoraConfig(r=cfg["lora_r"], lora_alpha=cfg["lora_alpha"], lora_dropout=cfg["lora_dropout"],
                  bias="none", task_type="CAUSAL_LM", target_modules=cfg["lora_target_modules"])
trainer = GRPOTrainer(model=cfg["model_id"], reward_funcs=[correct_reward, common.format_reward],
                      args=args, train_dataset=train, peft_config=lora)

torch.cuda.reset_peak_memory_stats()
t0 = time.perf_counter()
trainer.train()
trainer.save_state()                               # runs/<이름>/trainer_state.json (log_history)
trainer.save_model(str(out / "final"))             # 어댑터만 저장된다
meta = {
    "versions": {"torch": torch.__version__, "transformers": transformers.__version__, "trl": trl.__version__,
                 "peft": peft.__version__, "datasets": datasets.__version__},
    "gpu": torch.cuda.get_device_name(0), "bf16_supported": torch.cuda.is_bf16_supported(),
    "peak_mem_mib": round(torch.cuda.max_memory_allocated() / 2**20),
    "train_seconds": round(time.perf_counter() - t0),
    "resolved_args": json.loads(args.to_json_string()),
}
(out / "run_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
