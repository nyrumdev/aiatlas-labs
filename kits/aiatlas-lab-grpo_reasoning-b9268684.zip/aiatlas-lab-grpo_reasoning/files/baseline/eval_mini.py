# eval_mini.py — python eval_mini.py out/grpo_strict   (out/grpo_loose, Qwen/Qwen2.5-0.5B-Instruct 도)
import random, re, sys
from transformers import pipeline

gen = pipeline("text-generation", model=sys.argv[1], device_map="auto")
rng, ok, n = random.Random(1), 0, 50
for _ in range(n):
    a, b, c = rng.randint(11, 99), rng.randint(11, 99), rng.randint(11, 99)
    msg = [{"role": "user", "content": f"Compute {a} * {b} + {c}. Show your work, then end with a line 'Answer: <integer>'."}]
    text = gen(msg, max_new_tokens=256, do_sample=False)[0]["generated_text"][-1]["content"]
    found = re.findall(r"Answer:\s*(-?\d+)", text)
    ok += bool(found) and found[-1] == str(a * b + c)
print(ok, "/", n)
