# grpo_mini.py — python grpo_mini.py strict   (또는 loose)
import random, re, sys
from datasets import Dataset
from trl import GRPOConfig, GRPOTrainer

MODE, rng = sys.argv[1], random.Random(0)

def make(n):
    rows = []
    for _ in range(n):
        a, b, c = rng.randint(11, 99), rng.randint(11, 99), rng.randint(11, 99)
        q = f"Compute {a} * {b} + {c}. Show your work, then end with a line 'Answer: <integer>'."
        rows.append({"prompt": [{"role": "user", "content": q}], "answer": str(a * b + c)})
    return Dataset.from_list(rows)

def strict(completions, answer, **kwargs):      # 마지막 Answer: 줄의 숫자만 본다
    out = []
    for comp, ans in zip(completions, answer):
        found = re.findall(r"Answer:\s*(-?\d+)", comp[0]["content"])
        out.append(1.0 if found and found[-1] == ans else 0.0)
    return out

def loose(completions, answer, **kwargs):       # 정답 숫자가 어디든 있으면 통과 — 일부러 허술하게
    return [1.0 if ans in comp[0]["content"] else 0.0 for comp, ans in zip(completions, answer)]

cfg = GRPOConfig(output_dir=f"out/grpo_{MODE}", num_generations=8, per_device_train_batch_size=8,
                 max_completion_length=256, max_steps=60, logging_steps=5, seed=0, bf16=True)
trainer = GRPOTrainer(model="Qwen/Qwen2.5-0.5B-Instruct", args=cfg, train_dataset=make(60),
                      reward_funcs=strict if MODE == "strict" else loose)
trainer.train()
trainer.save_state()                              # out/grpo_<MODE>/trainer_state.json 에 기록(log_history)을 남긴다
trainer.save_model(f"out/grpo_{MODE}")
