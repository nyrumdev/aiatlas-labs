# 글자 단위 언어 모델 — 세어서 만든 bigram → 신경망 bigram → 작은 MLP(CPU) — 명령·코드 모음

실습 id: `lab.c.lab.char_lm_scratch`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업 폴더와 가상환경

```powershell
py list
py install 3.14
mkdir C:\work\char-lm
cd C:\work\char-lm
py -V:3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install torch
python -c "import sys, torch; print(sys.version); print(torch.__version__)" | Out-File -Encoding utf8 versions.txt
Get-Content versions.txt
mkdir data
```

## 2. 데이터 받기

```powershell
curl.exe -L -o data\names.txt https://raw.githubusercontent.com/karpathy/makemore/master/names.txt
Get-Content data\names.txt -TotalCount 5
(Get-Content data\names.txt).Count
```

## 3. 공통 도구

- `files/common.py` — 키트에 들어 있음 (python)

## 4. 이름 단위 분할

- `files/prepare_names.py` — 키트에 들어 있음 (python)

```powershell
python prepare_names.py
```

## 5. 셈 bigram

- `files/count_bigram.py` — 키트에 들어 있음 (python)

```powershell
python count_bigram.py
```

## 7. 신경망 bigram

- `files/neural_bigram.py` — 키트에 들어 있음 (python)

```powershell
python neural_bigram.py
```

## 8. 두 bigram 견주기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python neural_bigram.py --steps 2000 --tag s2000` — 마지막 기록에서도 검증 NLL 이 내려가는 중이었다면(`still_falling_at_end` 가 true) 걸음을 늘려 한 번 더 돌린다 — `python neural_bigram.py --steps 2000 --tag s2000`.

## 9. 작은 MLP

- `files/mlp_lm.py` — 키트에 들어 있음 (python)

```powershell
python mlp_lm.py
```

## 10. (선택) 평활과 정규화

```powershell
python count_bigram.py --alpha 0.1 --tag a0.1
python count_bigram.py --alpha 10 --tag a10
python neural_bigram.py --reg 0.01 --tag reg0.01
```

## 11. (선택) MLP 설정 하나 바꾸기

```powershell
python mlp_lm.py --block 5 --tag block5
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python mlp_lm.py --emb 2 --tag emb2` — (또는 `python mlp_lm.py --emb 2 --tag emb2`.) 두 개를 한꺼번에 바꾸면 무엇 때문에 달라졌는지 가를 수 없다.

## 12. 비교표

- `files/make_table.py` — 키트에 들어 있음 (python)

```powershell
python make_table.py
```

## 13. 테스트 한 번

- `files/test_once.py` — 키트에 들어 있음 (python)

```powershell
# 고른 모델이 MLP 기본 설정일 때의 두 줄 — 꼬리표 모델(예: block5)이면 끝에 --tag block5 를 붙여 친다 · 첫 줄을 치면 다른 모델로 다시 잴 수 없다(아래 설명)
python test_once.py --model mlp
python test_once.py --model mlp
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python test_once.py --model mlp --tag block5` — 셈 bigram 이면 `--model count`, 꼬리표 모델이면 꼬리표를 붙인다 — 11단계의 block5 가 검증 NLL 이 더 낮았다면 `python test_once.py --model mlp --tag block5` 를 두 번 친다.

## 14. 판 기록

```powershell
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
Get-Content requirements.lock.txt
```

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Get-Content data\names.txt -TotalCount 5` — `Get-Content data\names.txt -TotalCount 5` 로 첫 줄들을 보고, 2단계의 raw.githubusercontent.com 주소로 다시 받는다.
- `pip install torch` — 1단계 `pip install torch` 가 맞는 파일을 찾지 못한다 → 가상환경이 3.14 가 아닌 판(예: 3.15)으로 만들어졌다.
- `python -V` — `python -V` 로 확인하고, .venv 폴더를 지운 뒤 `py -V:3.14 -m venv .venv` 로 다시 만든다(S3449).
- `py -V:3.14 -m venv .venv` — `python -V` 로 확인하고, .venv 폴더를 지운 뒤 `py -V:3.14 -m venv .venv` 로 다시 만든다(S3449).
- `cd C:\work\char-lm` — `cd C:\work\char-lm` 에서 4 → 5 → 7 → 9 단계 순서로 돌린다.
- `python test_once.py` — `python test_once.py` 가 '이미 테스트를 쟀다'로 멈춘다 → 정상 동작이다.
