# 기울기를 손으로 — 순수 파이썬 경사하강·기울기 검사에서 작은 자동미분 엔진(micrograd)까지

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.gradients_by_hand`(L2 · 약 4시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 gradients_by_hand\gd_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 C:\work\ai-lab\gradients_by_hand 폴더에 logreg_by_hand.py + gradcheck_table.md + lr_sweep.json + lr_sweep.png + moons_pred.png + autograd 폴더(engine.py · engine_overwrite.py · nn.py · reuse_demo.py · test_engine.py · test_log.txt · train_moons.py · train_log.txt).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — GPU 는 쓰지 않는다(이 실습은 전부 CPU 에서 도는 순수 파이썬)
- 앞 실습 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 만든 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 matplotlib·scikit-learn 이 이미 들어 있고, git 저장소와 requirements.txt·requirements.lock.txt 가 있다
- pytest — 이 실습 1단계에서 같은 가상환경에 더 넣는다(인터넷은 이때만 쓴다)
- 메모장 등 글 편집기 — 코드 파일을 UTF-8 로 저장한다
- (선택) 앞 노드 역전파가 소개한 Karpathy 의 micrograd 편 영상 — 같은 엔진을 짜는 과정을 영어로 보여 준다(S12)

## 들어 있는 파일
- `files/logreg_by_hand.py`
- `files/engine.py`
- `files/test_engine.py`
- `files/reuse_demo.py`
- `files/nn.py`
- `files/train_moons.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.gradients_by_hand` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
