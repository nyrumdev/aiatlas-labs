# 한국어 BPE 토크나이저를 직접 짜고 Gemma 4 토크나이저와 비교하기 — 명령·코드 모음

실습 id: `lab.c.lab.tokenizer_build`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업 폴더와 판 고정 — 앞 노드 AI 실습 PC 세우기에서 만든 저장소에서 가상환경을 켜고, 이 실습의 폴더를 만든다. 쓰는 패키지는 판을 박아 설치한다. tokenizers 0.23.3 은 Hub 에서 …

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
mkdir tokenizer_build
cd tokenizer_build
mkdir data
python -m pip install tokenizers==0.23.3 huggingface-hub==2.2.0 regex==2026.9.29 tiktoken==0.14.0
```

```powershell
git clone https://github.com/karpathy/minbpe.git C:\work\minbpe
git -C C:\work\minbpe checkout 1acefe89412b20245db5a22d2a02001e547dc602
git -C C:\work\minbpe rev-parse HEAD
```

## 3. BPE 를 직접 짠다 — 아래 뼈대를 `my_bpe.py` 로 저장하고 빈칸 두 곳을 내가 채운다. 이웃 쌍 세기(count_pairs)·쌍 바꾸기(replace_pair)·되돌리기(decode)는 짜 …

- `files/my_bpe.py` — 키트에 들어 있음 (python)

**풀이** — `files/my_bpe.py` 의 빈칸을 채운 판입니다(키트 파일은 빈칸 뼈대). 내가 채운 뒤 견줄 때 봅니다.

```python
"""my_bpe.py — 바이트 단위 BPE 를 처음부터 짠다(외부 패키지 없음).

학습: 글을 UTF-8 바이트(0~255)로 바꾼 뒤, 이웃한 두 토큰 쌍을 세어
가장 많은 쌍을 새 번호(256, 257, …) 하나로 바꾸는 일을 되풀이한다.
자르기: 배운 병합 가운데 가장 먼저 배운 것부터 적용한다.
되돌리기: 토큰 번호를 바이트 묶음으로 바꿔 이어 붙인 뒤 UTF-8 로 읽는다.
"""


def count_pairs(ids):
    """이웃한 두 번호 쌍의 등장 횟수. 사전은 처음 본 순서를 기억한다."""
    counts = {}
    for left, right in zip(ids, ids[1:]):
        counts[(left, right)] = counts.get((left, right), 0) + 1
    return counts


def replace_pair(ids, pair, new_id):
    """ids 안에서 왼쪽부터 pair 가 나올 때마다 new_id 하나로 바꾼 새 목록."""
    out = []
    i = 0
    while i < len(ids):
        if i + 1 < len(ids) and ids[i] == pair[0] and ids[i + 1] == pair[1]:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return out


class MyBPE:
    def __init__(self):
        self.merges = {}                                  # (왼쪽, 오른쪽) -> 새 번호
        self.vocab = {i: bytes([i]) for i in range(256)}  # 번호 -> 바이트 묶음

    def train(self, text, vocab_size):
        if vocab_size < 256:
            raise ValueError("어휘 크기는 바이트 256개보다 작을 수 없다")
        ids = list(text.encode("utf-8"))
        for step in range(vocab_size - 256):
            counts = count_pairs(ids)
            if not counts:
                break                                     # 글이 한 토큰으로 줄었다
            best = max(counts, key=counts.get)            # 같은 횟수면 먼저 본 쌍
            new_id = 256 + step
            ids = replace_pair(ids, best, new_id)
            self.merges[best] = new_id
            self.vocab[new_id] = self.vocab[best[0]] + self.vocab[best[1]]
        return ids                                        # 학습 글을 자른 결과

    def encode(self, text):
        ids = list(text.encode("utf-8"))
        while len(ids) >= 2:
            present = count_pairs(ids)
            pair = min(present, key=lambda p: self.merges.get(p, float("inf")))
            if pair not in self.merges:
                break                                     # 남은 쌍 중 배운 병합이 없다
            ids = replace_pair(ids, pair, self.merges[pair])
        return ids

    def decode(self, ids):
        raw = b"".join(self.vocab[i] for i in ids)
        return raw.decode("utf-8", errors="replace")


if __name__ == "__main__":
    bpe = MyBPE()
    bpe.train("김밥 김치 김치전 김밥 김치", 256 + 5)
    for pair, new_id in bpe.merges.items():
        print(new_id, pair, bpe.vocab[new_id])       # 배운 순서대로 — 새 번호 · 붙인 쌍 · 담은 바이트
    ids = bpe.encode("김치김밥")
    print(ids, bpe.decode(ids) == "김치김밥")
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python my_bpe.py`

## 4. minbpe 와 대조하고 되돌리기를 시험한다 — 아래 코드를 `check_roundtrip.py` 로 저장한다. 같은 학습 글·같은 어휘(512)로 내 것과 minbpe 를 각각 학습한 뒤, 병합 목록이 …

- `files/check_roundtrip.py` — 키트에 들어 있음 (python)

```powershell
python check_roundtrip.py --minbpe C:\work\minbpe --vocab 512
```

## 5. 어휘 크기를 훑고 Gemma 4 와 견준다 — 아래 코드를 `sweep.py` 로 저장한다. 여기서부터는 minbpe 의 BasicTokenizer 를 쓴다. 4단계에서 내 것과 같다는 것을 확인했고, 학습한 …

- `files/sweep.py` — 키트에 들어 있음 (python)

```powershell
python sweep.py --minbpe C:\work\minbpe
```

## 7. 어휘를 들여다본다 — tok_4096.vocab 을 메모장으로 연다. 첫 256줄은 바이트 하나짜리 토큰이고, 그 뒤로 `[왼쪽][오른쪽] -> [합친 것] 번호` 꼴의 병합이 배운 순서대로 …

- `files/longest_tokens.py` — 키트에 들어 있음 (python)

```powershell
python longest_tokens.py C:\work\minbpe tok_4096.model
```

## 8. Gemma 4 와 사례별로 견준다 — 아래 코드를 `gemma_cases.py` 로 저장한다. 4단계의 시험 사례를 5단계에서 저장한 내 토크나이저(tok_4096.model)와 Gemma 4 토크나이저에 …

- `files/gemma_cases.py` — 키트에 들어 있음 (python)

```powershell
python gemma_cases.py --minbpe C:\work\minbpe --model tok_4096.model
```

## 10. (선택) 같은 글로 더 큰 어휘까지 — 순수 파이썬 학습은 어휘가 커질수록 오래 걸린다. Hugging Face Tokenizers 로도 바이트 단위 BPE 를 학습할 수 있다(S6301). 순수 파이썬보다 …

- `files/hf_bpe.py` — 키트에 들어 있음 (python)

```powershell
python hf_bpe.py
```

## 11. (선택) 다른 갈래의 새 글 — 영어 글이나 내 코드처럼 학습 글과 갈래가 다른 글을 `data\heldout_other.txt` 로 저장하고, 결과 이름을 바꿔 다시 돈다. CS336 과제가 한 데이터로 …

```powershell
python sweep.py --minbpe C:\work\minbpe --heldout data\heldout_other.txt --out sweep_other
```

## 12. 보고서와 커밋 — tokenizer_report.md 를 앱의 실습 화면이 안내하는 증거 문서 형식에 맞춘다. 첫 부분에 `lab_id: lab.c.lab.tokenizer_build` 한 줄을 쓰고 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Add-Content C:\work\ai-lab\.gitignore "tokenizer_build/data/", "tokenizer_build/tok_*", "tokenizer_build/hf_bpe_*.json"`
- `git add tokenizer_build`
- `git commit -m "BPE 토크나이저 실습"`
- `git status`

## 검증(자가)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Get-FileHash data\train.txt`
- `Get-FileHash data\heldout.txt`
- `python my_bpe.py`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python -X utf8 스크립트.py`
- `python gemma_cases.py --minbpe C:\work\minbpe --model tok_2048.model`
- `git status`
- `git add`
- `git rm --cached -r tokenizer_build/data`
