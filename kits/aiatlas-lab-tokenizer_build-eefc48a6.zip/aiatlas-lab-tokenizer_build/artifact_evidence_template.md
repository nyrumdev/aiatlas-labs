lab_id: lab.c.lab.tokenizer_build

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): data\train.txt · data\heldout.txt(둘 다 UTF-8) + 보고서에 두 글의 출처(내 글의 갈래 · 위키백과 문서 이름)와 '새 글은 학습 글에 들어 있지 않은 다른 글'이라는 1줄 + 보고서 맨 위 측정 전 예상 2줄(어휘를 4096 까지 키우면 새 글 토큰이 어떻게 변할지 · Gemma 4 와 견주면 어느 쪽이 적을지) -->
c1: 
<!-- c2(필수): my_bpe.py(빈칸 두 곳을 내가 채운 코드) + 처음 돌린 check_roundtrip.py 의 '순서까지 같은가' 결과(True/False) 1줄과, False 였다면 고친 곳 1줄 + 마지막으로 돌린 check_roundtrip.py 실행 출력 붙여 넣기 — '순서까지 같은가 True' 줄과 '어긋난 사례: 없음' 줄 + roundtrip.csv 의 same_ids·my_roundtrip·minbpe_roundtrip 열이 마지막 행을 빼고 모두 True -->
c2: 
<!-- c3(필수): roundtrip.csv 마지막 행(토큰 하나만 되돌리기)이 False 인 까닭 1줄 + decode 가 errors="replace" 를 쓰는 까닭 1줄 + errors 를 지우고 같은 행을 다시 돌렸을 때 난 오류 이름 1줄 -->
c3: 
<!-- c4(필수): sweep.csv + sweep.png + sweep_info.json — sweep_info.json 의 minbpe_commit 이 1acefe8 로 시작하고 gemma_revision 이 3e22461 로 시작하며 packages 에 tokenizers 0.23.3 · huggingface-hub 2.2.0 이 적혀 있다는 1줄 + gemma_special_tokens_added_by_default 값 1줄 -->
c4: 
<!-- c5(필수): 바이트로 확인 3줄 — ① sweep.csv 어휘 256 행의 heldout_tokens 와 sweep_info.json 의 heldout_file.utf8_bytes 가 같은가 ② utf8_bytes = 3 × hangul_syllables + ascii_chars + other_bytes 를 손으로 계산한 식과 결과 ③ sweep.csv 어휘 512 행의 heldout_tokens 와 roundtrip.csv '새 글(held-out)' 행의 minbpe_tokens 가 같은가와 그 까닭 -->
c5: 
<!-- c6(필수): 어휘 들여다보기 — tok_4096.vocab 에서 한글 음절을 하나 이상 통째로 담은 토큰 5개(번호·모양) · �가 섞인 토큰 1개와 그 까닭 1줄 · 내 글에서 가장 길게 합쳐진 토큰 1개(longest_tokens.py 출력 첫 줄의 번호·바이트 수)와 그것이 내 글의 어떤 말인지 1줄(개인 글이면 '개인 글이라 생략 · 길이 N바이트') -->
c6: 
<!-- c7(필수): gemma_cases.csv + Gemma 4 에서 gemma_roundtrip 이 False 인 사례마다 원인 1줄(gemma_pieces 열의 조각을 인용) + 같은 사례가 내 토크나이저에서는 왜 True 인지 1줄 -->
c7: 
<!-- c8(필수): 결론 3문장 — ① 어휘를 두 배로 키울 때마다 새 글 토큰이 줄어든 폭이 어떻게 변했나(sweep.csv 인용) ② 같은 어휘에서 학습 글과 새 글의 토큰당 글자 차이와 그 까닭(sweep.csv 인용) ③ 같은 새 글에서 Gemma 4 와 내 가장 큰 어휘의 토큰 수 비교와 해석(어휘 크기·학습 글의 양) — 맨 끝에 c1 의 예상과 맞았는지 1줄 -->
c8: 
<!-- c9(선택): (선택) hf_bpe.py 로 만든 hf_sweep.csv — 요청한 어휘와 실제 어휘(actual_vocab_size)가 다른 행이 있으면 그 까닭 추정 1줄 + 어휘 4096 에서 minbpe(sweep.csv)와 새 글 토큰 수를 견준 1줄 -->
c9: 
<!-- c10(선택): (선택) 다른 갈래의 새 글(영어 글·코드 등) data\heldout_other.txt 로 만든 sweep_other.csv — sweep.csv 와 heldout_bytes_per_token 을 어휘별로 견준 1줄 + Gemma 4 와의 차이가 어떻게 바뀌었는지 1줄 -->
c10: 
