"""my_bpe.py — 바이트 단위 BPE 를 처음부터 짠다(외부 패키지 없음) · 빈칸 ①② 를 채운다.

학습: 글을 UTF-8 바이트(0~255)로 바꾼 뒤, 이웃한 두 토큰 쌍을 세어
가장 많은 쌍을 새 번호(256, 257, …) 하나로 바꾸는 일을 되풀이한다.
자르기: 배운 병합 가운데 가장 먼저 배운 것부터 적용한다.
되돌리기: 토큰 번호를 바이트 묶음으로 바꿔 이어 붙인 뒤 UTF-8 로 읽는다.
"""


def count_pairs(ids):
    """이웃한 두 번호 쌍의 등장 횟수. 사전은 처음 본 순서를 기억한다."""
    counts = {}
    for left, right in zip(ids, ids[1:]):
        counts[(left, right)] = counts.get((left, right), 0) + 1
    return counts


def replace_pair(ids, pair, new_id):
    """ids 안에서 왼쪽부터 pair 가 나올 때마다 new_id 하나로 바꾼 새 목록."""
    out = []
    i = 0
    while i < len(ids):
        if i + 1 < len(ids) and ids[i] == pair[0] and ids[i + 1] == pair[1]:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return out


class MyBPE:
    def __init__(self):
        self.merges = {}                                  # (왼쪽, 오른쪽) -> 새 번호
        self.vocab = {i: bytes([i]) for i in range(256)}  # 번호 -> 바이트 묶음

    def train(self, text, vocab_size):
        if vocab_size < 256:
            raise ValueError("어휘 크기는 바이트 256개보다 작을 수 없다")
        ids = list(text.encode("utf-8"))
        for step in range(vocab_size - 256):
            counts = count_pairs(ids)
            if not counts:
                break                                     # 글이 한 토큰으로 줄었다
            # 빈칸 ① (5줄 안팎) — 아래 raise 줄을 지우고 채운다
            #   ㉠ counts 에서 가장 많이 나온 쌍을 best 로 고른다(횟수가 같으면 글에서 먼저 본 쌍 · max 와 key)
            #   ㉡ 새 번호 new_id 를 정한다 — 첫 병합이 256, 그다음이 257, …
            #   ㉢ ids 안의 best 를 new_id 하나로 바꾼다(replace_pair)
            #   ㉣ self.merges 에 best -> new_id 를 적는다
            #   ㉤ self.vocab 에 new_id -> (best 왼쪽의 바이트 묶음 + 오른쪽의 바이트 묶음) 을 적는다
            raise NotImplementedError("빈칸 ① 을 채운다")
        return ids                                        # 학습 글을 자른 결과

    def encode(self, text):
        ids = list(text.encode("utf-8"))
        while len(ids) >= 2:
            present = count_pairs(ids)
            # 빈칸 ② (4줄 안팎) — 아래 raise 줄을 지우고 채운다
            #   ㉠ present 의 쌍 가운데 가장 먼저 배운 병합(self.merges 의 번호가 가장 작은 쌍)을 pair 로 고른다
            #      — 배운 적 없는 쌍은 번호를 무한대 float("inf") 로 쳐서 뽑히지 않게 한다(min 과 key)
            #   ㉡ pair 가 배운 병합이 아니면 더 붙일 쌍이 없으니 멈춘다(break)
            #   ㉢ ids 안의 pair 를 그 병합의 번호로 바꾼다
            raise NotImplementedError("빈칸 ② 를 채운다")
        return ids

    def decode(self, ids):
        raw = b"".join(self.vocab[i] for i in ids)
        return raw.decode("utf-8", errors="replace")


if __name__ == "__main__":
    bpe = MyBPE()
    bpe.train("김밥 김치 김치전 김밥 김치", 256 + 5)
    for pair, new_id in bpe.merges.items():
        print(new_id, pair, bpe.vocab[new_id])       # 배운 순서대로 — 새 번호 · 붙인 쌍 · 담은 바이트
    ids = bpe.encode("김치김밥")
    print(ids, bpe.decode(ids) == "김치김밥")
