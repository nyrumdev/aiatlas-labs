"""check_roundtrip.py — 내 BPE(my_bpe.py)와 minbpe BasicTokenizer 를 같은 글·같은 어휘 크기로 학습해
① 병합 목록이 같은지 ② 같은 글을 같은 번호로 자르는지 ③ decode(encode(x)) == x 가 지켜지는지 본다.

실행 예:
    python check_roundtrip.py --minbpe C:\\work\\minbpe --vocab 512
결과: roundtrip.csv(사례마다 한 줄) · 화면에 요약
"""
import argparse
import csv
import sys
import time
from pathlib import Path

from my_bpe import MyBPE

# 학습 글에 없을 법한 것까지 일부러 섞은 시험 사례 — 이름, 글
CASES = [
    ("빈 글", ""),
    ("한 글자", "가"),
    ("띄어쓰기 여러 칸", "토큰   세기\t탭\n줄바꿈"),
    ("영어와 숫자", "Gemma 4 tokenizer, 2026-10-16 v0.23.3"),
    ("이모지", "좋아요 👍🏽 ❤️"),
    ("옛한글 자모", "ᄒᆞᆫ글"),
    ("한자와 일본어", "漢字 かな カナ"),
    ("드문 음절", "똠얌꿍 뷁"),
    ("공백 기호가 든 글", "SentencePiece 는 공백을 ▁ 로 적는다"),
    ("특수 토큰처럼 생긴 글", "<bos> 라는 글자"),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--minbpe", required=True, help="minbpe 저장소를 내려받은 폴더")
    parser.add_argument("--vocab", type=int, default=512, help="두 토크나이저의 어휘 크기")
    parser.add_argument("--train", default="data/train.txt")
    parser.add_argument("--heldout", default="data/heldout.txt")
    args = parser.parse_args()

    sys.path.insert(0, args.minbpe)            # 내려받은 minbpe 폴더를 불러올 수 있게
    from minbpe import BasicTokenizer

    train_text = Path(args.train).read_text(encoding="utf-8-sig")
    heldout_text = Path(args.heldout).read_text(encoding="utf-8-sig")

    mine = MyBPE()
    start = time.perf_counter()
    mine.train(train_text, args.vocab)
    my_sec = time.perf_counter() - start

    ref = BasicTokenizer()
    start = time.perf_counter()
    ref.train(train_text, args.vocab)
    ref_sec = time.perf_counter() - start

    same_merges = list(mine.merges.items()) == list(ref.merges.items())
    print(f"병합 수: 내 것 {len(mine.merges)} · minbpe {len(ref.merges)} · 순서까지 같은가 {same_merges}")
    print(f"학습 시간(초): 내 것 {my_sec:.1f} · minbpe {ref_sec:.1f}")

    rows = []
    for name, text in [("학습 글", train_text), ("새 글(held-out)", heldout_text)] + CASES:
        my_ids = mine.encode(text)
        ref_ids = ref.encode(text)
        rows.append({
            "case": name,
            "chars": len(text),
            "utf8_bytes": len(text.encode("utf-8")),
            "my_tokens": len(my_ids),
            "minbpe_tokens": len(ref_ids),
            "same_ids": my_ids == ref_ids,
            "my_roundtrip": mine.decode(my_ids) == text,
            "minbpe_roundtrip": ref.decode(ref_ids) == text,
        })

    # 토큰 하나만 되돌리면? — 한글 한 음절의 첫 바이트만 담은 토큰은 홀로 글자가 되지 못한다
    first_byte = list("가".encode("utf-8"))[:1]
    piece = mine.decode(first_byte)
    rows.append({
        "case": "토큰 하나만 되돌리기('가'의 첫 바이트)",
        "chars": 1, "utf8_bytes": 3,
        "my_tokens": 1, "minbpe_tokens": 1,
        "same_ids": True,
        "my_roundtrip": piece == "가",
        "minbpe_roundtrip": ref.decode(first_byte) == "가",
    })

    with open("roundtrip.csv", "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    broken = [r["case"] for r in rows[:-1] if not (r["my_roundtrip"] and r["minbpe_roundtrip"] and r["same_ids"])]
    print(f"사례 {len(rows) - 1}개 중 어긋난 사례: {broken if broken else '없음'}")
    print("토큰 하나만 되돌린 결과가 대체 문자(U+FFFD)인가:", piece == "\ufffd")
    return 0 if same_merges and not broken else 1


if __name__ == "__main__":
    sys.exit(main())
