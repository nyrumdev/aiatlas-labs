"""sweep.py — minbpe BasicTokenizer 를 내 글로 한 번 학습하고, 어휘 크기별로 학습 글·새 글의 토큰 수를 센 뒤
같은 글을 Gemma 4 토크나이저로도 세어 한 표(sweep.csv)와 그림(sweep.png)으로 남긴다.

실행 예:
    python sweep.py --minbpe C:\\work\\minbpe --sizes 256 512 1024 2048 4096
    python sweep.py --minbpe C:\\work\\minbpe --heldout data\\heldout_other.txt --out sweep_other
결과: <out>.csv · <out>.png · <out>_info.json(기본 out = sweep) · tok_<가장 큰 크기>.model / .vocab
"""
import argparse
import csv
import hashlib
import json
import subprocess
import sys
import time
from importlib.metadata import version
from pathlib import Path

GEMMA_ID = "google/gemma-4-E2B-it"
GEMMA_REVISION = "3e22461f65e89153144f8adb70e3b8c2cc9845a7"   # 저장소 커밋을 고정한다(main 은 바뀔 수 있다)


def char_mix(text):
    """한글 음절(가~힣) · ASCII · 그 밖의 글자 수와, 그 밖의 글자가 차지한 UTF-8 바이트 수."""
    hangul = sum(1 for ch in text if "\uac00" <= ch <= "\ud7a3")
    ascii_ = sum(1 for ch in text if ord(ch) < 128)
    others = [ch for ch in text if not ("\uac00" <= ch <= "\ud7a3" or ord(ch) < 128)]
    return {"hangul_syllables": hangul, "ascii_chars": ascii_, "other_chars": len(others),
            "other_bytes": sum(len(ch.encode("utf-8")) for ch in others)}


def sha256_of(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--minbpe", required=True, help="minbpe 저장소를 내려받은 폴더")
    parser.add_argument("--sizes", type=int, nargs="+", default=[256, 512, 1024, 2048, 4096])
    parser.add_argument("--train", default="data/train.txt")
    parser.add_argument("--heldout", default="data/heldout.txt")
    parser.add_argument("--out", default="sweep", help="결과 파일 이름 앞부분")
    args = parser.parse_args()
    sizes = sorted(set(args.sizes))

    sys.path.insert(0, args.minbpe)
    from minbpe import BasicTokenizer
    from tokenizers import Tokenizer

    train_text = Path(args.train).read_text(encoding="utf-8-sig")
    heldout_text = Path(args.heldout).read_text(encoding="utf-8-sig")

    # 1) 가장 큰 크기로 한 번만 학습한다 — 병합은 앞에서부터 쌓이므로 앞 k개만 쓰면 어휘 256+k 로 학습한 것과 같다
    full = BasicTokenizer()
    start = time.perf_counter()
    full.train(train_text, sizes[-1])
    train_sec = round(time.perf_counter() - start, 1)
    full.save(f"tok_{sizes[-1]}")
    ordered = sorted(full.merges.items(), key=lambda kv: kv[1])   # 배운 순서(새 번호 순)

    rows = []
    for size in sizes:
        tok = BasicTokenizer()
        tok.merges = dict(ordered[: size - 256])
        tok.vocab = tok._build_vocab()        # 병합에서 어휘(번호 -> 바이트)를 다시 만든다
        n_train = len(tok.encode(train_text))
        heldout_ids = tok.encode(heldout_text)
        rows.append({
            "tokenizer": f"minbpe_basic_{size}",
            "vocab_size": size,
            "train_tokens": n_train,
            "train_chars_per_token": round(len(train_text) / n_train, 3),
            "heldout_tokens": len(heldout_ids),
            "heldout_chars_per_token": round(len(heldout_text) / len(heldout_ids), 3),
            "heldout_bytes_per_token": round(len(heldout_text.encode("utf-8")) / len(heldout_ids), 3),
            "heldout_roundtrip": tok.decode(heldout_ids) == heldout_text,
        })
        print(f"어휘 {size}: 새 글 토큰 {len(heldout_ids)}")

    # 2) 같은 글을 Gemma 4 토크나이저로 센다(특수 토큰은 붙이지 않고 본문만)
    gemma = Tokenizer.from_pretrained(GEMMA_ID, revision=GEMMA_REVISION)
    g_train = gemma.encode(train_text, add_special_tokens=False).ids
    g_heldout = gemma.encode(heldout_text, add_special_tokens=False).ids
    rows.append({
        "tokenizer": "gemma4",
        "vocab_size": gemma.get_vocab_size(),
        "train_tokens": len(g_train),
        "train_chars_per_token": round(len(train_text) / len(g_train), 3),
        "heldout_tokens": len(g_heldout),
        "heldout_chars_per_token": round(len(heldout_text) / len(g_heldout), 3),
        "heldout_bytes_per_token": round(len(heldout_text.encode("utf-8")) / len(g_heldout), 3),
        "heldout_roundtrip": gemma.decode(g_heldout) == heldout_text,
    })

    with open(f"{args.out}.csv", "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    minbpe_commit = subprocess.run(["git", "-C", args.minbpe, "rev-parse", "HEAD"],
                                   capture_output=True, text=True).stdout.strip()
    info = {
        "python_version": sys.version,
        "packages": {name: version(name) for name in ["tokenizers", "huggingface-hub", "regex", "tiktoken", "matplotlib"]},
        "minbpe_commit": minbpe_commit,
        "gemma_id": GEMMA_ID,
        "gemma_revision": GEMMA_REVISION,
        "gemma_special_tokens_added_by_default": gemma.num_special_tokens_to_add(False),
        "train_file": {"path": args.train, "chars": len(train_text),
                       "utf8_bytes": len(train_text.encode("utf-8")), "sha256": sha256_of(args.train)},
        "heldout_file": {"path": args.heldout, "chars": len(heldout_text),
                         "utf8_bytes": len(heldout_text.encode("utf-8")), "sha256": sha256_of(args.heldout),
                         **char_mix(heldout_text)},
        "train_seconds_for_largest": train_sec,
    }
    Path(f"{args.out}_info.json").write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # 3) 그림 — 가로 = 어휘 크기(로그 눈금), 세로 = 토큰 하나가 담은 글자 수(클수록 토큰이 적다), 점선 = Gemma 4
    import matplotlib.pyplot as plt
    mine = [r for r in rows if r["tokenizer"] != "gemma4"]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot([r["vocab_size"] for r in mine], [r["heldout_chars_per_token"] for r in mine], "o-", label="my BPE, held-out text")
    ax.plot([r["vocab_size"] for r in mine], [r["train_chars_per_token"] for r in mine], "s--", label="my BPE, training text")
    ax.axhline(rows[-1]["heldout_chars_per_token"], color="gray", linestyle=":", label="Gemma 4, held-out text")
    ax.set_xscale("log", base=2)
    ax.set_xlabel("vocabulary size")
    ax.set_ylabel("characters per token")
    ax.legend()
    fig.savefig(f"{args.out}.png", dpi=120, bbox_inches="tight")
    print(f"{args.out}.csv · {args.out}.png · {args.out}_info.json 을 썼다")
    return 0


if __name__ == "__main__":
    sys.exit(main())
