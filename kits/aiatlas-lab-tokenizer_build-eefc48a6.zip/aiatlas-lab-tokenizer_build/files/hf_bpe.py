"""hf_bpe.py — (선택) 같은 학습 글로 Hugging Face Tokenizers 의 바이트 단위 BPE 를 더 큰 어휘까지 학습해
sweep.csv 와 같은 칸으로 새 글의 토큰 수를 센다.

실행 예:
    python hf_bpe.py --sizes 4096 8192 16384
결과: hf_sweep.csv · hf_bpe_<가장 큰 크기>.json
"""
import argparse
import csv
import sys
from pathlib import Path

from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers


def build(train_text, size):
    tok = Tokenizer(models.BPE())
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=size,
        show_progress=False,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),   # 바이트 256개를 처음부터 다 넣는다
    )
    tok.train_from_iterator([train_text], trainer=trainer)
    return tok


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", type=int, nargs="+", default=[4096, 8192, 16384])
    parser.add_argument("--train", default="data/train.txt")
    parser.add_argument("--heldout", default="data/heldout.txt")
    args = parser.parse_args()

    train_text = Path(args.train).read_text(encoding="utf-8-sig")
    heldout_text = Path(args.heldout).read_text(encoding="utf-8-sig")
    rows = []
    for size in sorted(set(args.sizes)):
        tok = build(train_text, size)
        ids = tok.encode(heldout_text).ids
        rows.append({
            "tokenizer": f"hf_bytelevel_bpe_{size}",
            "requested_vocab_size": size,
            "actual_vocab_size": tok.get_vocab_size(),
            "train_tokens": len(tok.encode(train_text).ids),
            "heldout_tokens": len(ids),
            "heldout_bytes_per_token": round(len(heldout_text.encode("utf-8")) / len(ids), 3),
            "heldout_roundtrip": tok.decode(ids) == heldout_text,
        })
        print(f"요청 {size} · 실제 어휘 {tok.get_vocab_size()} · 새 글 토큰 {len(ids)}")
    tok.save(f"hf_bpe_{rows[-1]['requested_vocab_size']}.json")
    with open("hf_sweep.csv", "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())
