"""gemma_cases.py — check_roundtrip.py 의 시험 사례를 내 BPE(sweep.py 가 저장한 tok_4096.model)와
Gemma 4 토크나이저에 똑같이 넣어, 토큰 수·조각·되돌리기 결과를 나란히 적는다.

실행 예:
    python gemma_cases.py --minbpe C:\\work\\minbpe --model tok_4096.model
결과: gemma_cases.csv
"""
import argparse
import csv
import sys

from check_roundtrip import CASES
from sweep import GEMMA_ID, GEMMA_REVISION


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--minbpe", required=True, help="minbpe 저장소를 내려받은 폴더")
    parser.add_argument("--model", default="tok_4096.model", help="sweep.py 가 저장한 내 토크나이저")
    args = parser.parse_args()

    sys.path.insert(0, args.minbpe)
    from minbpe import BasicTokenizer
    from tokenizers import Tokenizer

    mine = BasicTokenizer()
    mine.load(args.model)
    gemma = Tokenizer.from_pretrained(GEMMA_ID, revision=GEMMA_REVISION)

    rows = []
    for name, text in CASES:
        my_ids = mine.encode(text)
        enc = gemma.encode(text, add_special_tokens=False)
        rows.append({
            "case": name,
            "chars": len(text),
            "my_tokens": len(my_ids),
            "my_roundtrip": mine.decode(my_ids) == text,
            "gemma_tokens": len(enc.ids),
            "gemma_roundtrip": gemma.decode(enc.ids) == text,
            "gemma_roundtrip_keep_special": gemma.decode(enc.ids, skip_special_tokens=False) == text,
            "gemma_pieces": " | ".join(enc.tokens),
        })

    with open("gemma_cases.csv", "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    failed = [r["case"] for r in rows if not r["gemma_roundtrip"]]
    print(f"사례 {len(rows)}개 · Gemma 4 에서 되돌리기가 어긋난 사례: {failed if failed else '없음'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
