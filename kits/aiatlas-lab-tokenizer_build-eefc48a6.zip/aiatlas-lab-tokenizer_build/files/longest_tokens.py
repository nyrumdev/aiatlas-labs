"""longest_tokens.py — 저장한 minbpe 토크나이저(.model)에서 바이트로 가장 긴 토큰 다섯 개를 찍는다."""
import sys

sys.path.insert(0, sys.argv[1])            # 내려받은 minbpe 폴더
from minbpe import BasicTokenizer

tok = BasicTokenizer()
tok.load(sys.argv[2])                      # 예: tok_4096.model
longest = sorted(tok.vocab.items(), key=lambda kv: len(kv[1]), reverse=True)[:5]
for idx, raw in longest:
    print(idx, len(raw), repr(raw.decode("utf-8", errors="replace")))
