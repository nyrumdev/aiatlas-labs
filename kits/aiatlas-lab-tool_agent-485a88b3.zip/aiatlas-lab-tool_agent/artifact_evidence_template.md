lab_id: lab.c.lab.tool_agent

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 레슨 넷 묶기 — agent/lessons 폴더에 agent_demo.py · tool_wrapper.py · agent_eval_grade.py · taint_gate.py(레슨 예제 원문 · 세 파일은 실행부만 main 가드 아래로) + lessons/RESULTS.md(레슨마다 직접 해 보기에서 적은 결과를 옮기고, 이 실습의 어느 파일이 그 장치를 쓰는지 1줄) + main 가드로 옮긴 뒤 agent_eval_grade.py 를 직접 돌려 남긴 lessons/grade_check.txt 의 마지막 세 줄이 레슨과 같은 pass@k·pass^k 세 줄 -->
c1: 
<!-- c2(필수): 환경 — check_env.py 가 남긴 env_check.txt(두 주소의 걸린 초 · gemma4:e4b 가 이 PC 라는 줄 · 같은 요청 두 번의 입력·캐시 토큰) + requirements.txt(pip freeze 출력) + ways.py 의 MODEL 이 gemma4:e4b 이고 URL 이 127.0.0.1 이라는 확인과 토큰 칸을 바꿨는지 1줄 -->
c2: 
<!-- c3(필수): scenarios.csv — 17행 이상 · kind 에 해야 · 하지 말 것 · 대조군 2행 이상 · 장애 2행 이상 · 인젝션 2행 이상 · 모든 행에 expect · budget 채움 + run.py --selftest 가 남긴 selftest.txt 다섯 줄이 모두 기대대로 -->
c3: 
<!-- c4(필수): trace.jsonl + results.csv — 세 안(single · workflow · agent) × 시나리오 × 3회 행(17개면 153행)이 두 파일을 지운 뒤 이어 쌓은 것(한 번에든 안별로 나눠서든 · 그 사이 코드·시나리오·모델을 바꾸지 않음 · 선택 c8 의 agent+think 행은 그 뒤에 더해진다) · results.csv 의 llm · tokens · sec · stopped 칸이 모든 행에 있음 + trace.jsonl 의 error 줄 수 1줄(형식 실패만 — Ollama 오류·연결 끊김으로 멈춘 묶음은 지우고 다시 쌓은 것) -->
c4: 
<!-- c5(필수): compare_table.md — 안별 지표 표(성공률 · 회차별 성공률 · 보류 없는 시도의 성공률 · pass@3 · pass^3 · 평균 모델 호출 · 평균 도구 호출 · 잘못된 호출률 · 문지기 보류 · 코드 멈춤 · 공격 시도/실행 · 평균 토큰 · 평균 초)와 종류별 성공 수 표를 리포트에 그대로 붙임 -->
c5: 
<!-- c6(필수): 실패 읽기 표 — 떨어진 시도 6개 이상(안마다 2개 이상 · 떨어진 시도가 그보다 적은 안은 있는 만큼 전부): 안 · 시나리오 · 회차 · why · trace.jsonl 에서 찾은 원인 1줄 · 실패 이름(무한 루프 · 잘못된 인자 · 환각된 도구 · 거짓 완료 보고 · 알리지 않은 실패 · 형식 오류 · 분류 오류 · 인젝션 따르기 · 문지기 보류 · 시나리오 쪽 결함 중 하나) -->
c6: 
<!-- c7(필수): tool_agent_report.md 와 결론 5문장 — 리포트 다섯 부분(환경 · 시나리오 수정 기록 · 두 표 · 실패 읽기 표 · 결론) · 결론은 이 과제에 셋 중 무엇을 쓸지와 그 근거 · 문장마다 compare_table.md 의 숫자 하나 이상 인용 · 안을 가른 문장은 그 성공률 차이가 회차별 성공률의 폭과 시나리오 하나가 뒤집히는 크기보다 큰지 함께 적음 · 시나리오 수와 결과를 보고 고친 것이 있는지를 한계로 적은 문장 1개 · 인젝션 시나리오에서 모델이 써 낸 공격 호출과 실제로 실행된 공격 호출을 나눠 말한 문장 1개 포함 -->
c7: 
<!-- c8(선택): (선택) 생각 켜기 — run.py agent+think 뒤 summarize.py 를 다시 돌려 compare_table.md 에 agent+think 행이 생김 + 원래 agent 행과 다른 칸 2개를 짚은 1줄 -->
c8: 
<!-- c9(선택): (선택) MCP — requirements.txt 에 mcp==2.3.0(pip freeze 는 [cli] 를 적지 않는다) · server.py · mcp_check.py 가 남긴 mcp_check.txt(도구 넷 · lend 두 번 · 목록 밖 인자 한 번) + mcp dev 로 연 Inspector 화면 캡처(도구 목록과 호출 한 번) -->
c9: 
