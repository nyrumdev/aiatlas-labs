import csv
from collections import defaultdict
from math import comb
with open("results.csv", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
by = defaultdict(list)
for r in rows:
    by[r["way"]].append(r)
ORDER = ["single", "workflow", "agent", "agent+think"]  # 표의 줄 순서 — 안을 돌린 순서와 상관없이 고정
ways = [w for w in ORDER if w in by] + [w for w in by if w not in ORDER]
def pass_k(rs, k):  # 에이전트 평가 레슨의 식 — 시나리오마다 구해 평균한다
    per = defaultdict(list)
    for r in rs:
        per[r["id"]].append(int(r["ok"]))
    nc = [(len(v), sum(v)) for v in per.values()]
    at = sum(1 - comb(n - c, k) / comb(n, k) for n, c in nc) / len(nc)
    hat = sum(comb(c, k) / comb(n, k) for n, c in nc) / len(nc)
    return at, hat
total = lambda rs, col: sum(float(r[col]) for r in rs)
out = ["| 안 | 시도 | 성공률 | 회차별 성공률(0/1/2) | 보류 없는 시도의 성공률 | pass@3 | pass^3 | 평균 모델 호출 | 평균 도구 호출 | "
       "잘못된 호출률 | 문지기 보류 | 코드 멈춤 | 공격 시도/실행 | 평균 토큰 | 평균 초 |",
       "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
for way in ways:
    rs = by[way]
    n, tools = len(rs), total(rs, "tools")
    at, hat = pass_k(rs, 3)
    bad = f"{total(rs, 'bad') / tools:.2f}" if tools else "-"
    free = [r for r in rs if r["blocked"] == "0"]  # 문지기가 한 번도 보류하지 않은 시도
    ok_free = f"{total(free, 'ok') / len(free):.2f} ({len(free)})" if free else "-"
    one = [[r for r in rs if r["run"] == str(k)] for k in range(3)]  # 회차별로 나눈 시도 — 같은 안의 흔들림
    per_run = "/".join(f"{total(x, 'ok') / len(x):.2f}" if x else "-" for x in one)
    out.append(f"| {way} | {n} | {total(rs, 'ok') / n:.2f} | {per_run} | {ok_free} | {at:.2f} | {hat:.2f} | "
               f"{total(rs, 'llm') / n:.1f} | {tools / n:.1f} | {bad} | {total(rs, 'blocked'):.0f} | {total(rs, 'stopped'):.0f} | "
               f"{total(rs, 'attack_tried'):.0f}/{total(rs, 'attack_done'):.0f} | {total(rs, 'tokens') / n:.0f} | {total(rs, 'sec') / n:.1f} |")
kinds = sorted({r["kind"] for r in rows})
out += ["", "| 안 | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
for way in ways:
    rs = by[way]
    cell = lambda k: f"{sum(int(r['ok']) for r in rs if r['kind'] == k)}/{sum(r['kind'] == k for r in rs)}"
    out.append(f"| {way} | " + " | ".join(cell(k) for k in kinds) + " |")
with open("compare_table.md", "w", encoding="utf-8") as f:
    f.write("\n".join(out) + "\n")
print("\n".join(out))
