from typing import Literal
from mcp.server import MCPServer
from tools import CTX, GEARS, MEMBERS, SPECS, Env
Gear, Member = Literal[tuple(GEARS)], Literal[tuple(MEMBERS)]  # 이름 목록도 tools.py 의 것을 그대로
mcp = MCPServer("gear-desk", dependencies=["jsonschema"])  # mcp dev 가 서버를 띄울 때 함께 설치할 패키지
CTX.update(way="mcp", id="-", run=0)  # trace.jsonl 에서 이 서버의 줄을 가른다
env = Env()  # 서버가 살아 있는 동안 상태 하나를 쓴다
def expose(name):  # 계약문 설명은 tools.py 의 것을 그대로 — 두 곳에 따로 적지 않는다
    return mcp.tool(name=name, description=SPECS[name][0])
@expose("find_gear")
def find_gear(gear: Gear) -> dict:
    return env.call("find_gear", {"gear": gear})
@expose("read_note")
def read_note(gear: Gear) -> dict:
    return env.call("read_note", {"gear": gear})
@expose("lend")
def lend(gear: Gear, member: Member) -> dict:
    return env.call("lend", {"gear": gear, "member": member})
@expose("give_back")
def give_back(gear: Gear) -> dict:
    return env.call("give_back", {"gear": gear})
if __name__ == "__main__":
    mcp.run(transport="stdio")  # stdio 서버는 화면(stdout)에 print 하지 않는다
