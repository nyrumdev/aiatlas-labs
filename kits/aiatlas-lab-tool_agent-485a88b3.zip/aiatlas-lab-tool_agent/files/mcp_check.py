import asyncio, sys
from mcp import Client, StdioServerParameters
log = open("mcp_check.txt", "w", encoding="utf-8")  # 화면에 찍은 줄을 파일에도 남긴다(c9)
def say(*a):
    print(*a)
    print(*a, file=log, flush=True)
async def main():
    async with Client(StdioServerParameters(command=sys.executable, args=["server.py"])) as c:
        tools = await c.list_tools()
        for t in tools.tools:
            props = t.input_schema.get("properties", {})
            say(t.name, "|", t.description[:20], "|", {k: v.get("enum") for k, v in props.items()})
        r = await c.call_tool("lend", {"gear": "버너", "member": "M2"})
        say("lend:", r.is_error, [getattr(b, "text", b) for b in r.content])
        r = await c.call_tool("lend", {"gear": "버너", "member": "M3"})
        say("lend again:", r.is_error, [getattr(b, "text", b) for b in r.content])
        r = await c.call_tool("find_gear", {"gear": "캠핑 의자"})
        say("bad arg:", r.is_error, [getattr(b, "text", b)[:80] for b in r.content])
asyncio.run(main())
