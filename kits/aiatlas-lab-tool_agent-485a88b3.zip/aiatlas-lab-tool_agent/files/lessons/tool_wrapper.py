from jsonschema import Draft202012Validator  # pip install jsonschema

def user_approved(name, args):  # 되돌릴 수 없는 행동은 사람이 확인
    return input(f"{name} {args} 실행? (y/n) ") == "y"

def validate(args, schema):  # 스키마를 벗어난 곳을 문장으로 모은다
    return "; ".join(e.message for e in Draft202012Validator(schema).iter_errors(args))

def as_is(out, args):  # 이미 계약 모양이면 그대로, 아니면 감싼다
    return out if isinstance(out, dict) and "ok" in out else {"ok": True, "result": out}

def call_tool(name, args):
    if name not in TOOL_SPECS:  # 목록에 없는 도구도 실패 응답으로
        return {"ok": False, "reason": f"없는 도구: {name}",
                "hint": f"쓸 수 있는 도구: {sorted(TOOL_SPECS)}", "retryable": True}
    spec = TOOL_SPECS[name]
    bad = validate(args, spec["parameters"])  # 스키마 검사는 코드가 한다
    if bad:
        return {"ok": False, "reason": f"인자 오류: {bad}",
                "hint": spec["arg_example"], "retryable": True}
    if spec["writes"] and not user_approved(name, args):
        return {"ok": False, "reason": "사용자 확인이 없어 실행하지 않았다",
                "hint": "같은 요청을 다시 하지 말고 사용자에게 알린다", "retryable": False}
    try:
        out = spec["fn"](**args)
    except TimeoutError:
        return {"ok": False, "reason": "도구가 제때 응답하지 않았다",
                "hint": "잠시 뒤 같은 인자로 한 번만 다시 시도한다", "retryable": True}
    except Exception as e:  # 그 밖의 예외도 실패 응답으로
        return {"ok": False, "reason": f"도구 오류: {type(e).__name__}",
                "hint": "이 도구는 더 부르지 말고 사용자에게 알린다", "retryable": False}
    return spec.get("shape", as_is)(out, args)  # 도구마다 반환 모양을 맞춘다

def shape_notes(rows, args):  # search_meeting_notes 전용 — 네 필드만 남기고 자른다
    cut = rows[: args.get("max_results", 5)]
    keep = ("note_id", "title", "excerpt", "date")
    return {"ok": True, "results": [{k: r.get(k) for k in keep} for r in cut],
            "truncated": len(cut) < len(rows)}
