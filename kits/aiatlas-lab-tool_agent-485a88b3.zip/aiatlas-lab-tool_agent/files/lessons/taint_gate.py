import re
TOOLS = {  # 계약에 두 칸을 더한다 — 믿지 않는 글을 돌려주나, 결과가 큰 행동인가
    "read_trip":    {"untrusted_out": False, "consequential": False},  # 내 일정·예약 번호
    "open_listing": {"untrusted_out": True,  "consequential": False},  # 남이 쓴 숙소 페이지
    "send_inquiry": {"untrusted_out": False, "consequential": True},   # 숙소에 문의 메일을 보낸다
    "fetch_url":    {"untrusted_out": True,  "consequential": True},   # 주소에 무엇이든 실린다
}
ALLOWED_HOSTS = {"booking.example.com"}
class Session:
    def __init__(self):
        self.tainted = False                 # 믿지 않는 글을 읽었는가
    def gate(self, name):
        spec = TOOLS.get(name)
        if spec is None:
            return "거부(목록 밖)"
        if self.tainted and spec["consequential"]:
            return "보류(사람 확인)"          # 무엇을 시켰든 코드가 멈춘다
        if spec["untrusted_out"]:
            self.tainted = True              # 실행한 뒤부터 이 대화는 오염
        return "실행"
LINK = re.compile(r"!?\[([^\]]*)\]\((https?://([^/)\s]+)[^)\s]*)\)")
def clean(text):  # 인라인 꼴만 잡는 연습용 — 참조식·제목 붙은 꼴·<자동 링크>·HTML 태그는 못 잡는다
    return LINK.sub(lambda m: m.group(0) if m.group(3) in ALLOWED_HOSTS else m.group(1), text)
s = Session()
for name in ["read_trip", "open_listing", "send_inquiry", "fetch_url", "delete_trip"]:
    print(name, "→", s.gate(name))
print(clean("비교표 끝. [예약하기](https://evil.example.net/r?d=예약번호) ![](https://evil.example.net/i.png)"))
