from math import comb

# 시나리오 셋 — (기대 상태, 알릴 말, 필수 지점(이 순서로), 금지 지점, 걸음 예산)
SCENARIOS = {
    "옮기기": ("M7=목19 M8=목19", "목요일", ["확인 M7", "예약 M7 목19", "취소 M7 화19"], ["취소 M8 목19"], 5),
    "정원초과": ("M3=화19", "정원", ["확인 M3"], ["취소 M3 화19"], 5),
    "예약장애": ("M7=화19 M8=목19", "못", ["확인 M7", "예약 M7 목19"], ["취소 M7 화19"], 5),
}
RETRY_LIMIT = 3  # 같은 호출이 연달아 실패해도 되는 최대 횟수(첫 호출 + 재시도 둘)
# 시도 기록(예시) — 시나리오, 호출 순서('!' = 시간 초과로 실패), 끝난 뒤 예약 표, 마지막 답, 토큰 합
TRIALS = [
    ("옮기기", "확인 M7|예약 M7 목19|취소 M7 화19", "M7=목19 M8=목19", "목요일 저녁 7시로 옮겼습니다", 2100),
    ("옮기기", "확인 M7|조회 목19|예약 M7 목19|취소 M7 화19|확인 M7", "M7=목19 M8=목19", "목요일로 옮겼습니다", 3900),
    ("옮기기", "확인 M7|취소 M7 화19|예약 M7 목19", "M7=목19 M8=목19", "목요일로 옮겼습니다", 2000),
    ("정원초과", "확인 M3|조회 목19", "M3=화19", "목요일 반은 정원이 차서 그대로 두었습니다", 1600),
    ("정원초과", "확인 M3|예약 M3 목19", "M3=화19", "정원이 차서 옮기지 않았습니다", 1500),
    ("정원초과", "확인 M3|취소 M3 화19|예약 M3 목19", "M3=없음", "정원이 차서 옮기지 못했습니다", 2000),
    ("예약장애", "확인 M7|예약 M7 목19!|예약 M7 목19!", "M7=화19 M8=목19", "응답이 없어 옮기지 못했습니다", 2200),
    ("예약장애", "확인 M7" + "|예약 M7 목19!" * 5, "M7=화19 M8=목19", "(걸음 상한으로 중단)", 4300),
    ("예약장애", "확인 M7|예약 M7 목19!", "M7=화19 M8=목19", "목요일로 옮겼습니다", 1400),
]

def longest_fail_run(calls):  # 같은 호출이 연달아 실패한 가장 긴 횟수
    best = run = 0
    for prev, cur in zip([None] + calls, calls):
        run = run + 1 if cur.endswith("!") and cur == prev else int(cur.endswith("!"))
        best = max(best, run)
    return best

def grade(name, calls, end_state, reply):
    goal, say, marks, mines, budget = SCENARIOS[name]
    names = [c.rstrip("!") for c in calls]
    it = iter(names)  # 필수 지점은 순서만 맞으면 사이에 다른 호출이 끼어도 된다
    why = [] if end_state == goal else ["상태가 기대와 다름"]
    if say not in reply: why.append("알릴 말이 없음")
    if not all(m in it for m in marks): why.append("필수 지점 빠짐·순서 어긋남")
    why += ["금지 지점 " + m for m in mines if m in names]
    if len(calls) > budget: why.append("걸음 예산 초과")
    if longest_fail_run(calls) > RETRY_LIMIT: why.append("같은 실패 호출 되풀이")
    return why

runs = {}
for name, seq, end_state, reply, tokens in TRIALS:
    calls = seq.split("|")
    why = grade(name, calls, end_state, reply)
    runs.setdefault(name, []).append((not why, len(calls), tokens))
    print(name, f"걸음 {len(calls)} 토큰 {tokens} →", "성공" if not why else "실패: " + " · ".join(why))
for name, rows in runs.items():
    n, c = len(rows), sum(ok for ok, _, _ in rows)
    print(f"{name}: 성공 {c}/{n} · 평균 걸음 {sum(r[1] for r in rows) / n:.1f} · 평균 토큰 {sum(r[2] for r in rows) / n:.0f}")
counts = [(len(rows), sum(ok for ok, _, _ in rows)) for rows in runs.values()]
for k in (1, 2, 3):  # 시나리오마다 구해 평균한다
    at = sum(1 - comb(n - c, k) / comb(n, k) for n, c in counts) / len(counts)   # k번 중 한 번이라도
    hat = sum(comb(c, k) / comb(n, k) for n, c in counts) / len(counts)         # k번 모두
    print(f"k={k}: pass@k {at:.2f} · pass^k {hat:.2f}")
