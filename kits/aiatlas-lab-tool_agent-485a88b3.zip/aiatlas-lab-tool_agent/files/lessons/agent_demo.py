import json, re, requests
from collections import Counter
from pathlib import Path

URL, MODEL = "http://127.0.0.1:11434/api/chat", "gemma4:e4b"  # localhost 는 호출마다 늦을 수 있다
BASE = Path("sandbox").resolve()                 # 에이전트가 만질 수 있는 유일한 폴더
MAX_STEPS, MAX_REPEAT = 8, 2                     # 단계 상한·같은 호출 허용 횟수는 코드가 쥔다

def list_files(ext):                             # 읽기 도구 — 확인 없이 실행
    if not re.fullmatch(r"[A-Za-z0-9]+", str(ext).strip(".")):
        return {"ok": False, "error": "확장자는 영문·숫자만 받는다. 예: pdf"}
    return {"ok": True, "files": sorted(p.name for p in BASE.glob("*." + str(ext).strip(".")))}

def move_file(name, to):                         # 쓰기 도구 — 경로 검사 + 사람 확인
    src, dst = (BASE / name).resolve(), (BASE / to).resolve()
    if src.parent != BASE or dst.parent != BASE or not src.is_file():
        return {"ok": False, "error": "작업 폴더 안의 파일 이름과 하위 폴더 이름만 받는다"}
    if input(f"{name} → {to} 폴더로 옮길까요? (y/n) ").strip() != "y":
        return {"ok": False, "error": "사용자가 거절했다. 같은 이동을 다시 요청하지 말 것"}
    dst.mkdir(exist_ok=True)
    src.rename(dst / src.name)
    return {"ok": True, "moved": name, "to": to}

def spec(tool, desc, **props):                   # 모든 인자가 문자열인 도구 명세를 만든다
    return {"type": "function", "function": {"name": tool, "description": desc, "parameters": {
        "type": "object", "required": list(props),
        "properties": {k: {"type": "string", "description": v} for k, v in props.items()}}}}

TOOLS = {"list_files": list_files, "move_file": move_file}       # 여기 없는 이름은 실행되지 않는다
SPECS = [spec("list_files", "작업 폴더에서 확장자가 ext 인 파일 이름 목록을 돌려준다", ext="확장자. 예: pdf"),
         spec("move_file", "작업 폴더의 파일 하나를 하위 폴더로 옮긴다. 실행 전에 사람이 확인한다",
              name="파일 이름", to="하위 폴더 이름. 예: bills")]

def run(task):                                   # (답 또는 멈춘 이유, 대화 기록, 성공한 이동 목록)을 돌려준다
    messages, seen, done = [{"role": "user", "content": task}], Counter(), []
    for _ in range(MAX_STEPS):
        msg = requests.post(URL, json={"model": MODEL, "messages": messages, "tools": SPECS,
                                       "stream": False}, timeout=300).json()["message"]
        messages.append(msg)
        if not msg.get("tool_calls"):                            # 호출 없이 답하면 자연 종료
            return msg.get("content", ""), messages, done
        for c in msg["tool_calls"]:
            name, args = c["function"]["name"], c["function"]["arguments"]
            key = name + json.dumps(args, sort_keys=True, ensure_ascii=False)
            seen[key] += 1
            if seen[key] > MAX_REPEAT:                           # 같은 호출의 되풀이(없는 도구 포함)
                return ("같은 호출이 되풀이되어 멈췄다 — sandbox 폴더를 직접 확인할 것"
                        f" — 성공한 이동: {done}"), messages, done
            elif name not in TOOLS:                              # 환각된 도구
                result = {"ok": False, "error": f"없는 도구다. 쓸 수 있는 도구: {sorted(TOOLS)}"}
            else:
                try:
                    result = TOOLS[name](**args)
                except Exception as e:                           # 잘못된 인자도 결과로 돌려준다
                    result = {"ok": False, "error": f"인자 오류: {e}"}
            if name == "move_file" and result.get("ok"):         # 실제로 성공한 이동만 적어 둔다
                done.append(f"{result['moved']} → {result['to']}")
            messages.append({"role": "tool", "tool_name": name,
                             "content": json.dumps(result, ensure_ascii=False)})
    return ("단계 상한에 닿아 멈췄다 — sandbox 폴더를 직접 확인할 것"
            f" — 성공한 이동: {done}"), messages, done

answer, messages, done = run("sandbox 폴더의 pdf 중 이름에 '청구서'가 들어간 파일만 bills 폴더로 옮겨 줘")
print(answer)
