import time, requests
log = open("env_check.txt", "w", encoding="utf-8")  # 화면에 찍은 줄을 파일에도 남긴다(c2)
def say(*a):
    print(*a)
    print(*a, file=log, flush=True)
for base in ("http://localhost:11434", "http://127.0.0.1:11434"):  # 같은 서버를 두 주소로 한 번씩
    t = time.time()
    models = requests.get(base + "/api/tags", timeout=30).json()["models"]
    say(base, round(time.time() - t, 2), "초")
for m in models:
    if m["name"].startswith("gemma4"):
        where = "원격(remote_host " + m["remote_host"] + ")" if m.get("remote_host") else "이 PC"
        say(m["name"], "—", where, "—", m["details"].get("quantization_level", ""))
body = {"model": "gemma4:e4b", "stream": False, "think": False, "options": {"seed": 0},
        "messages": [{"role": "user", "content": "장비 대여함 점검 문장이다. " * 60 + "'네' 한 글자로만 답하라."}]}
for i in (1, 2):  # 같은 요청 두 번 — 둘째에 입력 토큰이 줄면 입력 칸은 캐시분을 빼고 센다
    r = requests.post("http://127.0.0.1:11434/api/chat", json=body, timeout=300).json()
    say("같은 요청", i, "번째 — 입력", r.get("prompt_eval_count"), "· 캐시", r.get("prompt_eval_cached_count", 0), r.get("error", ""))
