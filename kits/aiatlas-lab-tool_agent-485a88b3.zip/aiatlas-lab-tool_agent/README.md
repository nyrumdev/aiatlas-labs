# 단일 호출 vs 워크플로 vs 에이전트 — 같은 시나리오 셋으로 견주기(에이전트 레슨 4편 직접 해 보기 통합)

AI 아틀라스 앱의 실습 `lab.c.lab.tool_agent`(L3 · 약 5시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — tool_agent_report.md + agent/ 폴더(lessons/ · tools.py · ways.py · run.py · summarize.py · check_env.py · env_check.txt · scenarios.csv · selftest.txt · requirements.txt · trace.jsonl · results.csv · compare_table.md · 선택 c9 의 server.py · mcp_check.py · mcp_check.txt).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell — 이 과정의 기준 PC 는 RTX 4070 Ti 12GB 이지만 CPU 로 돌아도 이 실습은 끝까지 간다(느린 숫자도 표의 값이다)
- Ollama 와 gemma4:e4b — [실습] Gemma 4를 내 PC에서 돌리기에서 받은 그대로(S08). 이 실습은 이 한 태그만 쓴다. 이름에 cloud 가 붙은 태그는 남의 서버에서 돌므로 쓰지 않는다
- Python 3.10 이상과 가상환경 — requests·jsonschema 두 패키지만 쓴다(선택 과제 c9 의 MCP Python SDK 는 저장소 README 기준 3.11 이상 · S3540)
- 앞 레슨 네 편의 예제 코드와 직접 해 보기 기록 — 에이전트 기초(도구 사용 루프) · 도구 설계와 계약 · 에이전트 평가 · 간접 프롬프트 인젝션. 직접 해 보기를 하지 않았다면 그 사실을 RESULTS.md 에 적고 진행한다(여기서 다시 하지 않는다)
- (선택 c9 만) MCP Python SDK 2.3.0 · uv · Node.js(mcp dev 가 npx 로 받는 Inspector 배포판이 22.19.0 이상을 요구 · S3545)

## 들어 있는 파일
- `files/check_env.py`
- `files/tools.py`
- `files/ways.py`
- `files/scenarios.csv`
- `files/run.py`
- `files/summarize.py`
- `files/server.py`
- `files/mcp_check.py`
- `files/lessons/agent_demo.py`
- `files/lessons/tool_wrapper.py`
- `files/lessons/agent_eval_grade.py`
- `files/lessons/taint_gate.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.tool_agent` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
