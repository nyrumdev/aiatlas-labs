# 단일 호출 vs 워크플로 vs 에이전트 — 같은 시나리오 셋으로 견주기(에이전트 레슨 4편 직접 해 보기 통합) — 명령·코드 모음

실습 id: `lab.c.lab.tool_agent`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기 — 폴더 하나에 가상환경을 만들고 두 패키지만 넣는다. 활성화 스크립트가 실행 정책에 막히는 PC 가 있으므로 가상환경의 python 을 경로로 부른다. 설치한 판은 pip freeze 로 …

```powershell
New-Item -ItemType Directory C:\work\agent\lessons -Force
Set-Location C:\work\agent
python -m venv .venv
.\.venv\Scripts\python -m pip install requests jsonschema
.\.venv\Scripts\python -m pip freeze | Out-File -Encoding utf8 requirements.txt
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `py -m venv .venv`
- `py --version`

## 2. 레슨 넷 가져오기 — 레슨 본문의 예제 코드를 원문 그대로 lessons 폴더에 저장하고, 결과를 한 파일에 모은다. 실습 키트를 받았다면 키트의 files/lessons/ 에 네 파일이 레슨 원문 그대로 …

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 lessons\agent_eval_grade.py | Out-File -Encoding utf8 lessons\grade_check.txt
```

## 3. 모델과 주소 확인 — Ollama 를 켠 채 아래를 check_env.py 로 저장하고, 코드 칸 다음의 명령으로 돌린다. 화면에 찍힌 줄은 env_check.txt 에도 그대로 남는다. 모델 …

- `files/check_env.py` — 키트에 들어 있음 (python)

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
.\.venv\Scripts\python -X utf8 check_env.py
```

## 4. 환경과 도구 — tools.py — 세 안이 모두 같은 장비 대여함, 같은 도구, 같은 실행기를 쓰게 한다. 표의 차이가 구조의 차이가 되려면 이것이 먼저다. 도구는 여섯 개다. find_gear(상태 조회) …

- `files/tools.py` — 키트에 들어 있음 (python)

## 5. 세 안 — ways.py — 모델 호출은 모두 llm() 하나를 지난다. 보낸 메시지 · 받은 메시지 · 걸린 초 · 입력 토큰(prompt_eval_count) · 캐시에서 다시 읽은 …

- `files/ways.py` — 키트에 들어 있음 (python)

## 6. 시나리오 셋 — scenarios.csv — 앞 노드 에이전트 평가의 시나리오 한 줄을 그대로 열로 옮겼다. expect 는 끝난 뒤 기대 상태(장비 넷과 문자를 받은 회원), say 는 답에 꼭 들어갈 말 …

- `files/scenarios.csv` — 키트에 들어 있음 (text)

## 7. 채점기 먼저, 그다음 돌리기 — run.py — run.py 는 앞 노드 에이전트 평가의 채점기를 불러 그 SCENARIOS 를 이 실습의 시나리오로 바꿔 끼운다. 판정 규칙은 레슨 그대로다. 상태가 기대와 …

- `files/run.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python -X utf8 run.py --selftest`
- `.\.venv\Scripts\python -X utf8 run.py`

## 8. 한 표로 — summarize.py — results.csv 를 읽어 compare_table.md 에 표 두 개를 쓴다. 칸의 뜻은 이렇다. 성공률은 성공한 시도 ÷ 전체 시도다. 회차별 성공률은 회차 …

- `files/summarize.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python -X utf8 summarize.py
```

## 9. 실패 읽기 — 떨어진 시도마다 why 칸은 무엇이 틀렸는지만 말한다. 왜 틀렸는지는 trace.jsonl 에 있다. 줄마다 way·id·run 이 앞에 붙으므로 `Select-String -Path …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `Select-String -Path trace.jsonl -Encoding utf8 -Pattern '"way": "agent", "id": "T09", "run": 1'`

## 11. (선택) 생각 켜기 — Gemma 4 함수 호출 안내는 생각 모드가 함수 호출의 정확도를 높인다고 적는다(S04). 이 말을 내 시나리오로 잰다. 파일을 옮기거나 코드를 고치지 않는다. …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python -X utf8 run.py agent+think`

## 12. (선택) 도구 서버를 MCP 로 — 도구를 MCP 서버로 옮기면 다른 호스트 앱도 같은 계약으로 부를 수 있다. MCP 는 도구 목록·호출을 앱 밖의 서버로 꺼내 여러 호스트 앱이 같은 형식으로 부르게 하는 …

- `files/server.py` — 키트에 들어 있음 (python)

- `files/mcp_check.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python -X utf8 mcp_check.py
```

```powershell
$env:Path = (Resolve-Path .\.venv\Scripts).Path + ";" + $env:Path
.\.venv\Scripts\mcp dev server.py
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `.\.venv\Scripts\python -m pip install "mcp[cli]==2.3.0" uv`
- `uv run --with mcp… mcp run server.py`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama ps`
- `ollama list`
- `ollama pull gemma4:e4b`
- `ollama serve`
- `mcp dev`
