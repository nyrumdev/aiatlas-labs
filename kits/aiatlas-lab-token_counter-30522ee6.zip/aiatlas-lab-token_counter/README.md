# 같은 문장의 토큰 수 세어 보기 — 한국어·영어, 토크나이저 두 개

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.token_counter`(L0 · 약 60분) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\token_lab\token_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 C:\token_lab 폴더에 sentences.txt + capture_tokenizers.png + capture_split.png.
3. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 PC · 데스크톱 Chrome 또는 Edge — 창 두 개를 나란히 놓을 수 있는 화면
- 인터넷 — 도구 페이지와 토크나이저 파일을 받는 데 쓰인다. Gemma 4 토크나이저 파일(tokenizer.json)은 약 32MB 라(S5020) 처음 한 번은 받는 데 시간이 걸린다 · 계정·로그인·설치·코드 없음 · 토큰 나누기는 화면 부제대로 브라우저 안에서 한다(S6260)
- 메모장(문장 파일·보고서) · Windows 계산기 — Excel 이나 무료 LibreOffice Calc 가 있으면 나눗셈을 칸 수식으로 해도 된다(선택)
- 토큰 레슨(c.llm.token)의 직접 해 보기에서 종이로 조각을 나눠 본 경험 — 이 실습은 그 어림을 실제 숫자로 바꾼다

## 들어 있는 파일
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.token_counter` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
