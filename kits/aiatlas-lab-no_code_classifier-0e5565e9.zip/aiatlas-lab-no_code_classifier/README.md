# 코드 없이 분류기 학습시키고 일부러 망가뜨리기

AI 아틀라스 프리미엄 앱의 실습 `lab.c.lab.no_code_classifier`(L0 · 약 3시간) 키트입니다. 절차 설명은 앱의 실습 화면에 있고, 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\tm_lab\no_code_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 C:\tm_lab 폴더에 capture_start.png + capture_wrong_preview.png (선택 capture_classes.png) · 사진 폴더는 지우지 않고 보관.
3. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 PC · 데스크톱 Chrome(권장) — 도구는 데스크톱에서 Chrome 계열·Safari·Firefox 로 알아본 브라우저에서만 열리고, 휴대폰 브라우저에서는 '지원하지 않는다'는 안내만 뜬다(S3401)
- 사진을 찍을 휴대폰 카메라(또는 웹캠)와 사진을 PC 로 옮길 방법 — 사진 형식은 JPG 또는 PNG
- 집 안 물건 3개 — 모양이 서로 다른 것(예 머그컵·리모컨·안경집) + 눈에 띄는 배경 하나(예 무늬 있는 수건 — 기준 학습 사진에는 한 장도 나오지 않게 하고, 덫 시험 사진 2장과 조건 B 의 머그컵 사진에만 쓴다)
- 인터넷은 도구 페이지와 도구가 쓰는 미리 학습된 신경망(학습 화면을 열 때 내려받는다)을 받는 데 쓰인다 · 내 사진은 Drive 에 저장하지 않는 한 어떤 서버로도 가지 않는다 · 페이지는 학습 시작 같은 사용 통계(클래스 수·샘플 수)를 Google 에 보내지만 사진은 보내지 않는다 · 계정·로그인·설치·코드 없음(S3402·S3401)

## 들어 있는 파일
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.no_code_classifier` in the AI Atlas Premium app. The step-by-step instructions are in the app; this kit holds what you use on a PC and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
