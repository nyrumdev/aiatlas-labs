# 내 평가 하네스 만들기(Inspect + lm-eval, 로컬 모델) — 명령·코드 모음

실습 id: `lab.c.lab.eval_harness`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대 세우기 — 폴더 하나에 Python 3.13 가상환경을 만든다(가상환경은 지우고 다시 만들 수 있는 일회용이고, 재현 수단은 꾸러미 목록 파일이다 · S161). inspect-ai 는 3.11 이상을 …

```powershell
New-Item -ItemType Directory C:\work\evalh\data, C:\work\evalh\tasks\lm_eval, C:\work\evalh\tools, C:\work\evalh\results -Force
Set-Location C:\work\evalh
py install 3.13
py -V:3.13 -m venv .venv
.\.venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cu128
.\.venv\Scripts\python -m pip install "inspect-ai==0.3.281" openai "lm-eval[hf]==0.4.13"
"--extra-index-url https://download.pytorch.org/whl/cu128" | Out-File -Encoding utf8 requirements.lock.txt
.\.venv\Scripts\python -m pip freeze | Out-File -Append -Encoding utf8 requirements.lock.txt
```

```powershell
ollama list
py -V:3.13 --version | Out-File -Encoding utf8 results\env.md
ollama --version | Out-File -Append -Encoding utf8 results\env.md
.\.venv\Scripts\python -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())" | Out-File -Append -Encoding utf8 results\env.md
.\.venv\Scripts\python -m pip show inspect-ai lm-eval | Select-String '^(Name|Version)' | Out-File -Append -Encoding utf8 results\env.md
ollama show gemma4:e4b | Out-File -Append -Encoding utf8 results\env.md
```

```powershell
$env:OLLAMA_BASE_URL = "http://127.0.0.1:11434/v1"
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `pip install -r requirements.lock.txt`
- `ollama pull gemma4:e4b`

## 2. 평가셋 쓰기 — 지금까지 이 앱에서 읽은 레슨의 노트로 30문항을 쓴다. 용어 문항(kind term) 20개는 답이 짧은 명사구인 것, 계산 문항(kind calc) 10개는 두세 단계를 거쳐 숫자 하나가 …

```json
{"id": "t01", "kind": "term", "q": "평가 하네스에서 지난 실행과 이번 실행을 문항 id 로 맞대어 뒤집힌 문항을 뽑는 부품은?", "a": "리포터", "alias": ["reporter"], "wrong": ["로더", "실행기", "채점기"]}
{"id": "c01", "kind": "calc", "q": "사람과 심판이 30문항 가운데 24문항에서 같은 판정을 냈다. 일치율은 몇 퍼센트인가? 숫자만.", "a": "80", "alias": ["80%"]}
```

- `files/tools/check_data.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\check_data.py
```

## 3. 과제 파일 — 아래를 tasks\notes.py 로 저장한다. 과제 셋은 한 파일에 두고, 명령에서 `파일@과제` 로 하나씩 고른다(S3652). 로더는 FieldSpec 으로 칸을 잇는다(S3647). 틀의 …

- `files/tasks/notes.py` — 키트에 들어 있음 (python)

- `files/tasks/judge.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `inspect log dump`
- `ollama show gemma4:e4b`
- `ollama show`

## 4. 리포터 공통 부분과 시험 실행 — 표를 만드는 도구들이 같이 쓰는 로그 읽기를 tools\loglib.py 로 저장한다. Inspect 로그의 기본 형식은 .eval 이고, 파일 이름이 시각으로 시작해 …

- `files/tools/loglib.py` — 키트에 들어 있음 (python)

- `files/tools/peek.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --limit 2 --log-dir logs\smoke
.\.venv\Scripts\python tools\peek.py logs\smoke results\env.md
Get-Content -Encoding utf8 results\env.md
```

## 5. 첫 실행과 사람 채점 — 같은 명령을 그대로 두 번 쓸 것이므로 동시 요청을 1로 고정한다. Inspect 는 기본으로 연결 수를 스스로 조절하며 여럿을 동시에 연다(S3651). 재현 확인에서는 바뀌는 …

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\direct_run1
```

- `files/tools/export_sheet.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\export_sheet.py logs\direct_run1
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `inspect view`

## 6. 같은 설정 두 번 — 사람 채점을 마쳤으면 같은 명령을 로그 폴더만 바꿔 한 번 더 돌린다. 아래를 tools\compare_runs.py 로 저장해 두 실행을 문항 id 로 맞댄다. 답 글자까지 같은 문항 …

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_direct --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\direct_run2
```

- `files/tools/compare_runs.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\compare_runs.py logs\direct_run1 logs\direct_run2
```

## 7. 심판으로 다시 채점하고 일치율 재기 — 모델을 다시 돌리지 않는다. 이미 돈 첫 실행의 로그를 `inspect score` 에 judge.py 의 채점기를 붙여 다시 채점한다. 파일 안의 채점기 하나는 …

```powershell
$run1 = (Get-ChildItem logs\direct_run1\*.eval | Where-Object Name -NotLike "*-scored*" | Sort-Object Name | Select-Object -Last 1).FullName
$scored = $run1 -replace '\.eval$', '-scored.eval'
.\.venv\Scripts\inspect score $run1 --scorer tasks\judge.py@note_judge --action append --output-file $scored --overwrite
```

- `files/tools/agree.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\agree.py logs\direct_run1
```

## 8. few-shot 예시 순서 다섯 가지 — 예시 넷을 돌려 놓은 네 순서(ABCD · BCDA · CDAB · DABC — 넷이 저마다 한 번씩 맨 끝에 온다)와 뒤집은 순서(DCBA)를 같은 설정으로 돌린다. …

```powershell
foreach ($o in "ABCD", "BCDA", "CDAB", "DABC", "DCBA") {
    .\.venv\Scripts\inspect eval tasks\notes.py@notes_fewshot -T order=$o --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\fewshot_$o
}
.\.venv\Scripts\inspect eval tasks\notes.py@notes_fewshot -T order=ABCD --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\fewshot_ABCD_again
```

- `files/tools/order_table.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\compare_runs.py logs\fewshot_ABCD logs\fewshot_ABCD_again repro_fewshot.md
.\.venv\Scripts\python tools\order_table.py
```

## 9. 자기 일관성 — 표본 수 1·3·5·8 — notes_sc 는 풀이를 쓰게 하는 틀로 문항마다 여덟 번 뽑는다. 온도는 0.7 로 고정하고, 다른 값을 쓰려면 `-T temperature=값` 으로 바꿔 …

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_sc --model ollama/gemma4:e4b --max-connections 1 --log-dir logs\sc
```

- `files/tools/sc_table.py` — 키트에 들어 있음 (python)

```powershell
.\.venv\Scripts\python tools\sc_table.py logs\sc
```

```powershell
.\.venv\Scripts\python tools\peek.py logs\sc results\sc_peek.md
(Select-String -Path results\sc_peek.md -Encoding utf8 -SimpleMatch '출력 토큰 1024 ').Count
```

## 10. 가능도 과제는 lm-eval 의 HF 경로로 — 지금까지는 모델에게 답 글자를 *생성*하게 하고 그 글자를 채점했다. 객관식에는 다른 재는 법이 있다. 질문 뒤에 보기 넷을 하나씩 이어 붙여, 모델이 각 …

- `files/tools/make_mc.py` — 키트에 들어 있음 (python)

- `files/tasks/lm_eval/notes_mc.yaml` — 키트에 들어 있음 (yaml)

```powershell
.\.venv\Scripts\python tools\make_mc.py
.\.venv\Scripts\lm-eval run --model hf --model_args pretrained=Qwen/Qwen2.5-0.5B-Instruct,dtype=bfloat16 --tasks notes_mc --include_path tasks\lm_eval --device cuda:0 --batch_size 8 --output_path results\lm_eval --log_samples
```

## 12. (선택) 같은 객관식을 생성 방식으로 — notes_mc_gen 은 같은 20문항을 Inspect 의 객관식 풀이기(multiple_choice)로 '보기 글자를 골라 답하게' 하고 choice 채점기로 …

```powershell
.\.venv\Scripts\inspect eval tasks\notes.py@notes_mc_gen --model hf/Qwen/Qwen2.5-0.5B-Instruct -M do_sample=False --log-dir logs\mc_gen
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `inspect view`

## 13. (선택) 다른 심판 — [실습] Gemma 4를 내 PC에서 돌리기의 선택 과제로 gemma4:12b 를 받아 두었다면, 같은 첫 실행 로그를 그 모델로 다시 채점한다. 채점기 인자는 `-S` 로 …

```powershell
New-Item -ItemType Directory logs\judge_12b -Force
$orig = (Get-ChildItem logs\direct_run1\*.eval | Where-Object Name -NotLike "*-scored*" | Sort-Object Name | Select-Object -Last 1).FullName
Copy-Item $orig logs\judge_12b\
$copy = (Get-ChildItem logs\judge_12b\*.eval | Where-Object Name -NotLike "*-scored*" | Select-Object -First 1).FullName
$copy_scored = $copy -replace '\.eval$', '-scored.eval'
.\.venv\Scripts\inspect score $copy --scorer tasks\judge.py@note_judge -S judge=ollama/gemma4:12b --action append --output-file $copy_scored --overwrite
.\.venv\Scripts\python tools\agree.py logs\judge_12b _12b
```

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `py install 3.13`
- `inspect eval`
- `inspect score`
- `ollama list`
- `inspect log dump`
- `inspect view`
