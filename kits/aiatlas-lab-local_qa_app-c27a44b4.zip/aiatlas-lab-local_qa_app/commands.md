# 로컬 QA 앱 만들기 — 명령·코드 모음

실습 id: `lab.c.lab.local_qa_app`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다.

## 준비

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `.\.venv\Scripts\python local_qa.py …` — 활성화 스크립트가 실행 정책에 막히면 켜지 않은 채 `.\.venv\Scripts\python local_qa.py …` 처럼 가상환경의 python 을 경로로 불러도 같다(아래 명령의 `python` 자리).
- `pip install` — 아래 골격은 파이썬 표준 라이브러리만 쓰므로 `pip install` 할 것이 없다.
- `ollama ps` — Ollama가 떠 있는지 `ollama ps` 로 확인한다(목록이 비어 있어도 명령이 답하면 서버는 떠 있다).

## 골격 코드 (local_qa.py)

- `files/local_qa.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python local_qa.py .\docs "연차는 다음 해로 넘어가나요"` — 실행(PowerShell): `python local_qa.py .\docs "연차는 다음 해로 넘어가나요"` — 청크 수, 근거 후보 id, 답, 입력 토큰 수가 찍힌다.
- `python local_qa.py .\docs eval_20.csv` — `python local_qa.py .\docs eval_20.csv` 로 주면 CSV의 `질문` 열을 차례로 물어 `eval_20_answered.csv` 에 `모델 답`·`근거 id` 를 채운다.

## 2. 골격 실행

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama list` — `Ollama 오류 404:` 뒤에 `model '…' not found` 가 찍히면 서버는 떠 있지만 그 태그의 모델이 없는 것이니(S1384), `ollama list` 로 받은 태그를 확인해 `MODEL` 과 맞춘다.

## 4. 검색

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama pull embeddinggemma` — 바꿀 때는 `ollama pull embeddinggemma` 로 모델을 받고 `/api/embed` 에 청크들과 질문을 보내 벡터를 받은 뒤(S165), 코사인 유사도로 상위 k개를 고른다.

## 6. 20문항 평가

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python local_qa.py .\docs eval_20.csv` — `python local_qa.py .\docs eval_20.csv` 로 모델 답을 채운 뒤(`eval_20_answered.csv`) 정오를 내가 1/0으로 매기고, 이 파일을 제출용 eval_20.csv 로 둔다.

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama ps` — 실제로 열린 창은 `ollama ps` 의 CONTEXT 열로 확인한다.

## 추가 수행: 검색 실패와 답변 실패를 따로 남기기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `Copy-Item docs docs_minus -Recurse` — `Copy-Item docs docs_minus -Recurse` 로 사본 폴더를 만들고 사본에서만 정답 문서 하나를 지운 뒤(`Remove-Item docs_minus\<그 문서>.md`), `python local_qa.py .\docs_minus "<그 문서가 답인 질문>"` 으로 …
- `python local_qa.py .\docs_minus "<그 문서가 답인 질문>"` — … docs_minus -Recurse` 로 사본 폴더를 만들고 사본에서만 정답 문서 하나를 지운 뒤(`Remove-Item docs_minus\<그 문서>.md`), `python local_qa.py .\docs_minus "<그 문서가 답인 질문>"
