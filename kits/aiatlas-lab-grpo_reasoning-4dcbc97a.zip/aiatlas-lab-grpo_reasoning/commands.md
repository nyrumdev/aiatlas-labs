# 소형 모델 GRPO 강화학습 + Pass@k/Maj@k 로 새 능력인지 가리기 — 명령·코드 모음

실습 id: `lab.c.lab.grpo_reasoning`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 실행 환경 — WSL 2 를 쓰는 이유부터 확인한다. TRL 1.15.0 의 GRPOTrainer 는 만들 때 정책 모델에 '융합 LM 머리'를 조건 없이 덧씌우고, 학습 걸음마다 그 머리로 토큰별 로그확률을 …

```powershell
wsl --install            # 관리자 PowerShell · 끝나면 재시작
wsl -l -v                # 재시작 뒤 — Ubuntu 줄의 VERSION 이 2 인지 본다
```

```bash
sudo apt update && sudo apt install -y python3-venv python3-dev build-essential
mkdir -p ~/grpo-lab/env ~/grpo-lab/configs ~/grpo-lab/baseline && cd ~/grpo-lab
python3 --version                      # 3.11~3.14 여야 한다(trl 1.15.0 은 3.11 이상 · torch 의 Triton 은 3.15 미만)
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu130
python -m pip install "trl[peft]==1.15.0" "transformers==5.19.0" "peft==0.21.2" "datasets==5.1.0" "accelerate==1.15.0" "matplotlib==3.11.2"
python -m pip freeze > env/requirements.lock.txt
python -c "import torch, trl, trl.trainer.utils as u; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), torch.cuda.is_bf16_supported(), trl.__version__, u._ChunkedLogProbFunction)" | tee env/wsl_check.txt
python -c "import torch; f = torch.compile(lambda x: x * 2); print(f(torch.ones(4, device='cuda')))" | tee -a env/wsl_check.txt
explorer.exe .
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python -c "import trl, trl.trainer.utils as u; print(trl.__version__, u._ChunkedLogProbFunction)"`
- `cd ~/grpo-lab && source .venv/bin/activate`

## 3. 모델·데이터를 받고 판을 고정한다 — 앞 노드 Hugging Face Hub와 모델 카드에서 한 대로, 받은 저장소의 커밋을 적어야 '같은 모델'이라고 말할 수 있다(S162). 기본 모델 …

```bash
hf download Qwen/Qwen2.5-0.5B-Instruct            # 마지막 줄 경로의 snapshots/ 다음 40자가 모델 커밋
hf download openai/gsm8k --repo-type dataset      # 같은 방식으로 데이터 커밋
```

- `files/grpo_common.py` — 키트에 들어 있음 (python)

- `files/make_splits.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python make_splits.py <데이터 커밋>`

## 4. 학습 스크립트 — 보상은 둘이다. `correct_reward` 는 마지막 줄의 답이 정답과 같을 때 1, `format_reward` 는 답이 맞든 틀리든 마지막 줄이 `Answer: 숫자` 꼴이면 1 …

- `files/train_grpo.py` — 키트에 들어 있음 (python)

- `files/configs/R0.json` — 키트에 들어 있음 (json)

## 5. 시운전 → 기반 모델 dev 확인 → 사전 등록 → 학습 — 먼저 두 걸음짜리 시운전으로 걸음당 시간을 잰다. `derive.py` 는 R0.json 에서 한 칸만 바꾼 설정을 만든다. 이후 모든 비교 실행도 …

- `files/derive.py` — 키트에 들어 있음 (python)

```bash
python derive.py R0_smoke max_steps 2
python train_grpo.py configs/R0_smoke.json
```

```bash
time python sample_eval.py --split splits/dev200.jsonl --n 8 --out samples/base_dev.jsonl
python score.py samples/base_dev.jsonl --out results/base_dev
```

```bash
sha256sum prereg.md configs/R0.json | tee env/prereg.sha256
python train_grpo.py configs/R0.json
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git init -q && git add prereg.md configs/R0.json && git -c user.name=me -c user.email=me@localhost commit -qm prereg`
- `sudo apt install -y git`

## 6. 표본을 뽑아 채점한다 — 평가는 학습과 같은 프롬프트(질문 + 마지막 줄 지시)로 문항마다 8번 뽑는다. 생성 설정은 모두 직접 적는다. transformers 는 온도·top_k·top_p 를 주지 않으면 …

- `files/sample_eval.py` — 키트에 들어 있음 (python)

- `files/score.py` — 키트에 들어 있음 (python)

```bash
python sample_eval.py --split splits/test200.jsonl --n 8 --out samples/base_test.jsonl
python sample_eval.py --adapter runs/R0/final --split splits/test200.jsonl --n 8 --out samples/R0_test.jsonl
python score.py samples/base_test.jsonl samples/R0_test.jsonl --out results/test200
```

## 7. 손잡이를 하나씩 — R0 에서 한 칸만 바꾼 실행 넷을 만들고, 모두 dev200 으로만 잰다. 아래 루프는 몇 시간 걸린다. 끝날 때까지 Ubuntu 창을 닫지 않고, Windows 가 절전에 들어가지 않게 …

```bash
python derive.py R0s1 seed 1
python derive.py R1 num_generations 4
python derive.py R2 num_generations 16
python derive.py R3 beta 0.04
for r in R0s1 R1 R2 R3; do echo "== $r"; python -c "import json,sys; a,b=(json.load(open(p,encoding='utf-8')) for p in sys.argv[1:3]); [print(k, a.get(k), '->', b.get(k)) for k in dict.fromkeys([*a, *b]) if a.get(k) != b.get(k)]" configs/R0.json configs/$r.json; done
for r in R0s1 R1 R2 R3; do python train_grpo.py configs/$r.json; done
for r in R0 R0s1 R1 R2 R3; do
  python sample_eval.py --adapter runs/$r/final --split splits/dev200.jsonl --n 8 --out samples/${r}_dev.jsonl
  python score.py samples/${r}_dev.jsonl --out results/${r}_dev
done
for r in R0s1 R1 R2 R3; do
  python score.py samples/R0_dev.jsonl samples/${r}_dev.jsonl --out results/pair_R0_${r}_dev
done
```

## 8. 보상 해킹 구간 — 학습 보상만 봐서는 그 상승이 해킹인지 알 수 없다. 체크포인트마다 dev200 을 4번씩 뽑아, 학습 기록과 같은 걸음 축에 올린다.

- `files/plot_run.py` — 키트에 들어 있음 (python)

```bash
python sample_eval.py --split splits/dev200.jsonl --n 4 --out samples/R0_ckpt/checkpoint-0_dev.jsonl
for d in runs/R0/checkpoint-*; do
  python sample_eval.py --adapter "$d" --split splits/dev200.jsonl --n 4 --out "samples/R0_ckpt/$(basename "$d")_dev.jsonl"
done
python plot_run.py runs/R0 samples/R0_ckpt
```

## 9. 새 능력인가 — 6단계의 test200_newly_solved.txt 는 기반 모델이 8번 모두 틀렸는데 학습 후 모델은 한 번 이상 맞힌 문항이다. 그 가운데 기반 모델의 8개 답에 느슨한 추출로는 정답 …

```bash
if grep -q . results/test200_to_recheck.txt; then
  python sample_eval.py --split splits/test200.jsonl --only results/test200_to_recheck.txt --n 64 --batch_questions 1 --seed 1 --out samples/base_recheck64.jsonl
  python sample_eval.py --adapter runs/R0/final --split splits/test200.jsonl --only results/test200_to_recheck.txt --n 64 --batch_questions 1 --seed 1 --out samples/R0_recheck64.jsonl
  python score.py samples/base_recheck64.jsonl samples/R0_recheck64.jsonl --out results/recheck64 --recheck
else
  echo "재검사 대상 0개 — 9단계를 건너뛴다 (test200_to_recheck.txt 의 줄 수 $(grep -c . results/test200_to_recheck.txt))"
fi
```

## 10. 리포트 — grpo_report.md 의 첫 줄 근처에 `lab_id: lab.c.lab.grpo_reasoning` 를 적는다. 절은 `## 작업`(무엇을 어떤 순서로 돌렸나 · 명령 1줄씩) · `## …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `cp grpo_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/`

## 11. (선택) Gemma 3 1B — `python derive.py G0 model_id '"google/gemma-3-1b-it"'` 로 설정을 만든 뒤, G0.json 의 model_revision 을 그 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python derive.py G0 model_id '"google/gemma-3-1b-it"'`

## 12. (선택) 형식 보상만 키우기 — `python derive.py R5 reward_weights "[1.0, 2.0]"` 로 R5 를 학습하고 8단계를 되풀이해 R0 그림과 나란히 놓는다. 형식 보상이 정답 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python derive.py R5 reward_weights "[1.0, 2.0]"`

## 13. (선택) 큰 k 곡선 — test200 앞 50문항에서 기반 모델과 R0 를 64번씩 뽑아 k 1~64 의 Pass@k 를 그린다.

- `files/passk_curve.py` — 키트에 들어 있음 (python)

```bash
head -n 50 splits/test200.jsonl > splits/test50.jsonl
python sample_eval.py --split splits/test50.jsonl --n 64 --batch_questions 1 --out samples/base_k64.jsonl
python sample_eval.py --adapter runs/R0/final --split splits/test50.jsonl --n 64 --batch_questions 1 --out samples/R0_k64.jsonl
python passk_curve.py samples/base_k64.jsonl samples/R0_k64.jsonl
```

## 검증(자가)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git log -1 --format=%ci -- prereg.md`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `wsl -l -v`
- `cd ~/grpo-lab && source .venv/bin/activate`
