# Gemma 4를 내 PC에서 돌리기 — 명령·코드 모음

실습 id: `lab.c.lab.gemma_local_run`

앱 실습 화면의 절차와 같은 차례입니다.

## 1. Ollama 설치(공식 사이트의 Windows 설치 파일, S361) → PowerShell에서 `ollama --version` (c1).

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama --version` — Ollama 설치(공식 사이트의 Windows 설치 파일, S361) → PowerShell에서 `ollama --version` (c1).

## 2. `ollama pull gemma4:e4b` 로 먼저 내려받는다(Windows PC 기준 6.6GB · S08).

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama pull gemma4:e4b` — `ollama pull gemma4:e4b` 로 먼저 내려받는다(Windows PC 기준 6.6GB · S08).
- `ollama ps` — `ollama ps` 에 gemma4:e4b 가 보이면 `ollama stop gemma4:e4b` 로 내려(S131) 모델이 메모리에 없는 상태에서 시작한다.
- `ollama stop gemma4:e4b` — `ollama ps` 에 gemma4:e4b 가 보이면 `ollama stop gemma4:e4b` 로 내려(S131) 모델이 메모리에 없는 상태에서 시작한다.
- `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits` — NVIDIA GPU 라면 이때(목록이 빈 상태) `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits` 를 한 번 쳐서 모델 없을 때의 GPU 사용량(MiB)을 적어 둔다 — 4단계의 메모리 칸에 쓴다.
- `ollama run gemma4:e4b --verbose --think=false "토큰이 뭐야?"` — 그다음 질문을 명령 끝에 붙여 `ollama run gemma4:e4b --verbose --think=false "토큰이 뭐야?"` 를 실행한다 — 답을 한 번 내고 끝나는 실행이라 `/bye` 가 필요 없다.
- `ollama run` — 질문 없이 `ollama run` 으로 대화 창(`>>>`)을 열면 창이 뜨기 전에 모델을 미리 올리므로(S362), 첫 답의 통계에 적재 시간이 거의 남지 않는다.

## 4. 답이 끝난 뒤에도 모델은 한동안 메모리에 남으므로(기본 5분 · S131) 곧바로 메모리를 잰다.

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits` — GPU 몫 = 지금 `nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits` 값에서 2단계에 적은 모델 없을 때 값을 뺀 것(MiB) — 모델 가중치·KV 캐시·계산 버퍼가 다 들어간다.
- `ollama serve` — 설치판의 서버 로그는 `%LOCALAPPDATA%\Ollama\server.log` 이고, `ollama serve` 를 창에서 직접 띄웠다면 그 창에 찍힌다(S536).
- `Select-String -Path "$env:LOCALAPPDATA\Ollama\server.log" -Pattern "model buffer size" | Select-Object -Last 4` — 설치판이라면 `Select-String -Path "$env:LOCALAPPDATA\Ollama\server.log" -Pattern "model buffer size" | Select-Object -Last 4` 로 방금 적재한 줄만 본다.
- `ollama ps` — 이어서 `ollama ps` 를 친다.
- `ollama list` — `ollama list` 로 파일 크기도 적는다.

## 6. (선택) `ollama stop gemma4:e4b` 로 e4b 를 내리고 모델 없을 때의 GPU 사용량을 다시 잰 뒤 …

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama stop gemma4:e4b` — (선택) `ollama stop gemma4:e4b` 로 e4b 를 내리고 모델 없을 때의 GPU 사용량을 다시 잰 뒤 `ollama run gemma4:12b --verbose --think=false "토큰이 뭐야?"` 로 같은 표에 1행(메모리 칸은 4단계와 같은 방법).
- `ollama run gemma4:12b --verbose --think=false "토큰이 뭐야?"` — (선택) `ollama stop gemma4:e4b` 로 e4b 를 내리고 모델 없을 때의 GPU 사용량을 다시 잰 뒤 `ollama run gemma4:12b --verbose --think=false "토큰이 뭐야?"` 로 같은 표에 1행(메모리 칸은 4단계와 같은 방법).
- `ollama show --verbose gemma4:e4b` — 내 PC에 받은 파일은 `ollama show --verbose gemma4:e4b` 의 텐서 목록에서 per_layer_token_embd 줄의 형식으로 확인한다(S362).

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `ollama list` — 표에는 내 `ollama list` 값을 그대로 적는다.
- `ollama ps` — GPU를 안 쓰는 것 같음 → `ollama ps` 의 PROCESSOR가 100% CPU인지, GPU와 CPU로 나뉘었는지 확인한다.
- `ollama run gemma4:e4b --think=false` — 창을 넓혀 보려면 `ollama run gemma4:e4b --think=false` 로 대화 창을 열어 `/set parameter num_ctx 8192` 처럼 바꾼 뒤(S131) GPU 사용량(nvidia-smi)과 서버 로그의 `KV buffer size` 줄이 얼마나 커지는지도 …
- `ollama serve` — 설치판은 `%LOCALAPPDATA%\Ollama\server.log`(가장 최근 기록 · 이전 기록은 server-#.log 처럼 번호가 붙음), 창에서 직접 띄운 `ollama serve` 는 그 창이다(S536).
- `ollama stop` — … eval duration 이 수 초~수십 초로 큼(질문 14토큰에 29초 등) → 받은 직후 처음 돌린 묶음에서 한 번 관찰된 일이고, `ollama stop` 뒤 다시 잰 묶음과 서버를 새로 띄워 잰 묶음에서는 1회차가 0.17~0.22초였다(0.40.13 · 원인 미확정).
- `ollama stop gemma4:e4b` — `ollama stop gemma4:e4b` 뒤 3회를 다시 재고 그 묶음을 표에 쓴다.
