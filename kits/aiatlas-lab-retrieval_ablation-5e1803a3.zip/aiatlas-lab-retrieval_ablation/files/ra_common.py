# ra_common.py — 앞 실습(semantic_search)의 데이터·지표 코드를 그대로 가져오고, 이 실습의 설정을 한곳에 둔다
import json
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEM = ROOT.parent / "semantic_search"  # 앞 실습 폴더 — 잠근 data 와 지표 코드를 여기서 읽는다
sys.path.insert(0, str(SEM))
from common import KINDS, MODEL, REVISION, first_rank, grams, load, metrics  # 앞 실습의 common.py

RESULTS = ROOT / "results"
RERANKER = "BAAI/bge-reranker-v2-m3"
RERANKER_REVISION = None  # env_check.py 가 찍어 준 리랭커 커밋 해시 40자리를 따옴표 안에 넣는다
RERANK_MAX_LEN = 512      # 리랭커 입력 상한 — 모델 카드의 transformers 예와 같은 값
RRF_K = 60                # 역순위 융합 상수
POOL = 20                 # 리랭커에게 넘길 하이브리드 후보 수
DEPTH = 100               # 실행마다 남기는 순위 목록의 길이


def rrf(lists, k=RRF_K):
    """lists = 위에서부터 늘어선 문서 id 목록들. 문서마다 목록별 1/(k + 순위)를 더해 큰 순서로(같으면 id 순)."""
    point = {}
    for lst in lists:
        for r, doc in enumerate(lst, start=1):
            point[doc] = point.get(doc, 0.0) + 1.0 / (k + r)
    return sorted(point, key=lambda d: (-point[d], d))


def save_run(name, info, ranked_by_q, queries, ms_by_q):
    """앞 실습과 같은 꼴의 run 파일에 질문당 지연(밀리초)을 더해 남긴다."""
    RESULTS.mkdir(exist_ok=True)
    ms = [ms_by_q[q["id"]] for q in queries]
    info = dict(info, name=name, n_queries=len(queries),
                metrics=metrics(ranked_by_q, queries),
                latency_ms={"median": statistics.median(ms), "max": max(ms)},
                ranks={q["id"]: first_rank(ranked_by_q[q["id"]], set(q["rel"])) for q in queries},
                top1={q["id"]: (ranked_by_q[q["id"]] or [None])[0] for q in queries},
                ms=ms_by_q)
    path = RESULTS / f"run_{name}.json"
    path.write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{name:<22}", " · ".join(f"{k} {v:.3f}" for k, v in info["metrics"].items()),
          f"· 지연 중앙값 {info['latency_ms']['median']:.1f}ms · 최댓값 {info['latency_ms']['max']:.1f}ms")
    return info
