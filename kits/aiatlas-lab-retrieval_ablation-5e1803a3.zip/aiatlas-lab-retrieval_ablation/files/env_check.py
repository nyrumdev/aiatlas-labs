# env_check.py — 판·장치·두 모델의 커밋·리랭커의 입력 상한과 점수 변환을 results/env.md 에 남긴다
import platform
from importlib.metadata import version

import torch
from huggingface_hub import model_info
from sentence_transformers import CrossEncoder

from ra_common import MODEL, RERANK_MAX_LEN, RERANKER, RERANKER_REVISION, RESULTS, REVISION

if REVISION is None:
    raise SystemExit("앞 실습 common.py 의 REVISION 이 비어 있다 — 앞 실습의 3단계부터 끝낸다")
sha = RERANKER_REVISION or model_info(RERANKER).sha  # 고정했으면 그 커밋을, 처음이면 지금 최신 커밋을
ce = CrossEncoder(RERANKER, revision=sha, max_length=RERANK_MAX_LEN)
gpu = f" · {torch.cuda.get_device_name(0)}" if torch.cuda.is_available() else ""
lines = [
    "# 환경", "",
    f"- python {platform.python_version()} · torch {torch.__version__} · cuda {torch.cuda.is_available()}{gpu}",
    f"- sentence-transformers {version('sentence-transformers')} · transformers {version('transformers')}"
    f" · bm25s {version('bm25s')}",
    f"- 임베딩 {MODEL} · 커밋 {REVISION}(앞 실습 common.py)",
    f"- 리랭커 {RERANKER} · 커밋 {sha} · 장치 {ce.device}",
    f"- 리랭커 입력 상한 max_seq_length {ce.max_seq_length} · num_labels {ce.num_labels} · 점수 변환 {ce.activation_fn}",
]
RESULTS.mkdir(exist_ok=True)
(RESULTS / "env.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
if RERANKER_REVISION is None:
    print(f'\nra_common.py 의 RERANKER_REVISION 줄을 이렇게 고친다 → RERANKER_REVISION = "{sha}"')
