# failures.py — 리랭커 실행에서 5위 밖에 남은 문항을 '후보 밖(리랭커가 고칠 수 없음)'과 '후보 안에서 밀림'으로 나눠 센다
import argparse
import json

from ra_common import POOL, RESULTS, RRF_K, first_rank, load

ap = argparse.ArgumentParser()
ap.add_argument("--pool", type=int, default=POOL)
ap.add_argument("--rrf-k", type=int, default=RRF_K)
a = ap.parse_args()
if a.pool < 5:
    raise SystemExit("--pool 은 5 이상이어야 한다 — 그보다 작으면 후보 밖 정답도 5위 안에 남아 '후보 밖' 분류와 천장 줄이 뜻을 잃는다")
hyb_name, rr_name = f"hybrid_rrf{a.rrf_k}", f"rerank_rrf{a.rrf_k}_p{a.pool}"
corpus, queries = load()


def read(name):
    p = RESULTS / name
    if not p.exists():
        raise SystemExit(f"{name} 가 없다 — run_all.py 를 같은 --pool·--rrf-k 로 먼저 돌린다")
    return json.loads(p.read_text(encoding="utf-8"))


hyb, rr = read(f"run_{hyb_name}.json"), read(f"run_{rr_name}.json")
bm, e5 = read("run_bm25s_char2.json"), read("run_e5small_prefix.json")
pools = read(f"pools_rrf{a.rrf_k}_p{a.pool}.json")


def miss(rank):
    return rank is None or rank > 5


reach = sum(first_rank(pools[q["id"]]["ids"], set(q["rel"])) is not None for q in queries)
fixed = [q["id"] for q in queries if miss(hyb["ranks"][q["id"]]) and not miss(rr["ranks"][q["id"]])]
broke = [q["id"] for q in queries if not miss(hyb["ranks"][q["id"]]) and miss(rr["ranks"][q["id"]])]
rows, outside, inside = [], 0, 0
for q in queries:
    qid, rel = q["id"], set(q["rel"])
    if not miss(rr["ranks"][qid]):
        continue
    pool, scores = pools[qid]["ids"], pools[qid]["scores"]
    if first_rank(pool, rel) is None:
        outside += 1
        kind, gold = "후보 밖(리랭커가 고칠 수 없음)", "-"
    else:
        inside += 1
        kind, gold = "후보 안에서 밀림", f"{max(scores[d] for d in rel if d in scores):.4f}"
    top = rr["top1"][qid]
    rows.append(f"| {qid} | {q['kind']} | {kind} | {rr['ranks'][qid] or '없음'} | {hyb['ranks'][qid] or '없음'} | "
                f"{bm['ranks'][qid] or '없음'} | {e5['ranks'][qid] or '없음'} | {top} ({scores.get(top, 0):.4f}) | {gold} |  |")

n = len(queries)
lines = [f"# 리랭커 뒤에도 5위 밖에 남은 문항 — {rr_name}", "",
         f"- 후보 {a.pool}개 안에 정답이 하나라도 든 문항 {reach}/{n} ← 리랭커가 닿을 수 있는 천장(5위 안 문항 비율의 상한 {reach / n:.3f})",
         f"- 5위 밖 {outside + inside}개 = 후보 밖(리랭커가 고칠 수 없음) {outside} + 후보 안에서 밀림 {inside}",
         f"- 리랭커가 고친 문항(하이브리드 5위 밖 → 5위 안) {len(fixed)}개: {', '.join(fixed) or '없음'}",
         f"- 리랭커가 망친 문항(하이브리드 5위 안 → 5위 밖) {len(broke)}개: {', '.join(broke) or '없음'}", "",
         "| 문항 | 갈래 | 실패 갈래 | 리랭커 뒤 순위 | 하이브리드 | bm25s | e5 | 리랭커 1위 문서(점수) | 정답 문서 점수 | 원인 추정(손으로) |",
         "|---|---|---|---|---|---|---|---|---|---|"] + rows
(RESULTS / f"failures_rrf{a.rrf_k}_p{a.pool}.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
