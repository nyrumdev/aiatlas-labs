# run_all.py — 네 설정(bm25s · e5 · RRF 하이브리드 · 리랭커)을 같은 질문으로 돌려 순위와 질문당 지연을 남긴다
import argparse
import json
import statistics
import time

import bm25s
from sentence_transformers import CrossEncoder, SentenceTransformer

from ra_common import (DEPTH, MODEL, POOL, RERANK_MAX_LEN, RERANKER, RERANKER_REVISION, RESULTS, REVISION,
                       RRF_K, SEM, grams, load, rrf, save_run)

ap = argparse.ArgumentParser(description="검색 갈래 비교 — 네 설정을 같은 30문항으로")
ap.add_argument("--pool", type=int, default=POOL, help="리랭커에게 넘길 하이브리드 후보 수")
ap.add_argument("--rrf-k", type=int, default=RRF_K, help="역순위 융합 상수 k")
a = ap.parse_args()
if a.pool < 5:
    raise SystemExit("--pool 은 5 이상이어야 한다 — 그보다 작으면 후보 밖 정답도 5위 안에 남아 '후보 밖' 분류와 천장 줄이 뜻을 잃는다")
if REVISION is None or RERANKER_REVISION is None:
    raise SystemExit("모델 커밋 해시가 비어 있다 — 앞 실습 common.py 의 REVISION 과 ra_common.py 의 RERANKER_REVISION 을 채운다")
base = a.pool == POOL and a.rrf_k == RRF_K  # 설정 잠금 그대로인 실행인가

corpus, queries = load()
ids = sorted(corpus)
texts = [corpus[i] for i in ids]

# 준비 — 질문이 오기 전에 한 번만 한다(지연에 넣지 않는다)
t = time.perf_counter()
lex_index = bm25s.BM25(k1=1.5, b=0.75, method="lucene")  # 0.3.13 의 기본값을 그대로 적어 둔다
lex_index.index([grams(x) for x in texts], show_progress=False)  # 앞 실습과 같은 글자 2-gram 조각 목록
dense = SentenceTransformer(MODEL, revision=REVISION)
doc_vecs = dense.encode_document(texts, prompt="passage: ")
ce = CrossEncoder(RERANKER, revision=RERANKER_REVISION, max_length=RERANK_MAX_LEN)
print(f"준비 {time.perf_counter() - t:.1f}초 · 문서 {len(ids)}개 · 장치 e5 {dense.device} · 리랭커 {ce.device}")


def lexical(text):
    s = lex_index.get_scores(grams(text))  # 문서 순서대로 점수 · 색인에 없는 조각은 건너뛴다
    order = sorted(range(len(ids)), key=lambda j: (-s[j], ids[j]))
    return [ids[j] for j in order if s[j] > 0][:DEPTH]  # 점수 0 = 겹치는 조각 없음 → 찾지 못한 것


def semantic(text):
    v = dense.encode_query([text], prompt="query: ")
    s = dense.similarity(v, doc_vecs)[0].tolist()
    order = sorted(range(len(ids)), key=lambda j: (-s[j], ids[j]))  # 평가기와 같은 줄 세우기
    return [ids[j] for j in order][:DEPTH]


def rerank(text, cand):
    s = ce.predict([(text, corpus[d]) for d in cand])  # 질문·문서 쌍을 함께 읽은 점수(0~1)
    order = sorted(range(len(cand)), key=lambda j: (-float(s[j]), cand[j]))
    return [cand[j] for j in order], {cand[j]: round(float(s[j]), 6) for j in range(len(cand))}


def clock(fn, *args):
    t0 = time.perf_counter()
    out = fn(*args)
    return out, (time.perf_counter() - t0) * 1000


def pipeline(text):
    lex, t_lex = clock(lexical, text)
    sem, t_sem = clock(semantic, text)
    hyb, t_fuse = clock(rrf, [lex, sem], a.rrf_k)
    (top, scores), t_rr = clock(rerank, text, hyb[:a.pool])
    return {"bm25s": (lex, t_lex), "e5": (sem, t_sem),
            "hybrid": (hyb[:DEPTH], t_lex + t_sem + t_fuse),
            "rerank": ((top + hyb[a.pool:])[:DEPTH], t_lex + t_sem + t_fuse + t_rr)}, hyb[:a.pool], scores, t_rr


pipeline(queries[0]["text"])  # 몸풀기 — 첫 호출의 준비 시간을 재지 않으려고 한 번 돌려 버린다
got = {k: ({}, {}) for k in ("bm25s", "e5", "hybrid", "rerank")}
pools = {}
for q in queries:
    out, pool, scores, t_rr = pipeline(q["text"])
    for k, (ranked, ms) in out.items():
        got[k][0][q["id"]], got[k][1][q["id"]] = ranked, ms
    pools[q["id"]] = {"ids": pool, "scores": scores, "rerank_only_ms": t_rr}
rr_only = statistics.median(p["rerank_only_ms"] for p in pools.values())

names = {"bm25s": "bm25s_char2", "e5": "e5small_prefix",
         "hybrid": f"hybrid_rrf{a.rrf_k}", "rerank": f"rerank_rrf{a.rrf_k}_p{a.pool}"}
about = {"bm25s": {"model": "bm25s BM25(method=lucene, k1=1.5, b=0.75) · 글자 2-gram"},
         "e5": {"model": MODEL, "revision": REVISION, "query_prompt": "query: ", "doc_prompt": "passage: "},
         "hybrid": {"model": f"RRF(k={a.rrf_k}) · bm25s_char2 + e5small_prefix"},
         "rerank": {"model": RERANKER, "revision": RERANKER_REVISION, "pool": a.pool, "rrf_k": a.rrf_k,
                    "max_seq_length": ce.max_seq_length, "rerank_only_ms_median": rr_only}}
devices = {"bm25s": "cpu", "e5": str(dense.device), "hybrid": f"cpu + {dense.device}",
           "rerank": f"cpu + {dense.device} + {ce.device}"}
saved = {}
for k, name in names.items():
    if k in ("bm25s", "e5") and not base:
        continue  # 선택 실행은 설정 잠금 실행의 두 단독 행을 덮어쓰지 않는다
    if k == "hybrid" and not base and a.rrf_k == RRF_K:
        continue  # 후보 폭만 바꾼 실행의 하이브리드는 설정 잠금 실행과 같은 순위다 — 그 행도 덮어쓰지 않는다
    saved[name] = save_run(name, dict(about[k], device=devices[k]), got[k][0], queries, got[k][1])
(RESULTS / f"pools_rrf{a.rrf_k}_p{a.pool}.json").write_text(
    json.dumps(pools, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

# 앞 실습과 맞대기 — 같은 질문에서 처음 나온 정답의 순위가 같은 문항 수
for mine, theirs in (("e5small_prefix", "e5small_prefix"), ("bm25s_char2", "bm25_char2")):
    p = SEM / "results" / f"run_{theirs}.json"
    if mine in saved and p.exists():
        old, new = json.loads(p.read_text(encoding="utf-8"))["ranks"], saved[mine]["ranks"]
        diff = [q["id"] for q in queries if old[q["id"]] != new[q["id"]]]
        print(f"앞 실습 {theirs} 와 순위가 같은 문항 {len(queries) - len(diff)}/{len(queries)}"
              + (f" · 다른 문항 {', '.join(diff)}" if diff else ""))
        if mine != "e5small_prefix":
            continue
        for q in (x for x in queries if x["id"] in diff):  # 정답 문서와 그 바로 위·아래 문서의 오늘 점수
            s = dense.similarity(dense.encode_query([q["text"]], prompt="query: "), doc_vecs)[0].tolist()
            order = sorted(range(len(ids)), key=lambda j: (-s[j], ids[j]))
            r = new[q["id"]] or len(order)
            near = order[max(0, r - 2):r + 1]
            print(f"  {q['id']} 앞 실습 {old[q['id']] or '없음'}위 · 오늘 {new[q['id']] or '없음'}위 · "
                  + " · ".join(f"{i}위 {ids[j]} {s[j]:.6f}" for i, j in enumerate(near, start=max(1, r - 1))))
