# report.py — run_*.json 을 한 표(성적 + 지연)로 · 문항별 순위 표 · 같은 질문끼리 짝 비교를 만든다
import csv
import json
import sys

from ra_common import KINDS, POOL, RESULTS, RRF_K, load

corpus, queries = load()
runs = {}
for p in sorted(RESULTS.glob("run_*.json")):
    r = json.loads(p.read_text(encoding="utf-8"))
    runs[r["name"]] = r
if not runs:
    sys.exit("results 에 run_*.json 이 없다 — run_all.py 를 먼저 돌린다")
HYB, RR = f"hybrid_rrf{RRF_K}", f"rerank_rrf{RRF_K}_p{POOL}"
first = [x for x in ("bm25s_char2", "e5small_prefix", HYB, RR) if x in runs]
names = first + sorted(x for x in runs if x not in first)
n = len(queries)
by_kind = {k: [q for q in queries if q["kind"] == k] for k in KINDS}


def hit(rank, k):
    return rank is not None and rank <= k


head = ["실행", "Recall@5", "MRR@10", "Recall@1", "Recall@10"] + [f"{k} 5위 안" for k in KINDS] + ["지연 중앙값 ms", "지연 최댓값 ms"]
lines = ["# 검색 갈래 비교 — 같은 질문 · 같은 자", "", "| " + " | ".join(head) + " |", "|---" * len(head) + "|"]
for name in names:
    m, rk, lat = runs[name]["metrics"], runs[name]["ranks"], runs[name]["latency_ms"]
    cells = [name, f"{m['recall@5']:.3f}", f"{m['mrr@10']:.3f}", f"{m['recall@1']:.3f}", f"{m['recall@10']:.3f}"]
    cells += [f"{sum(hit(rk[q['id']], 5) for q in qs)}/{len(qs)}" for qs in by_kind.values()]
    cells += [f"{lat['median']:.1f}", f"{lat['max']:.1f}"]
    lines.append("| " + " | ".join(cells) + " |")
lines += ["", f"- 질문 {n}개 · 문서 {len(corpus)}개 · 질문 하나의 몫 {1 / n:.3f}",
          "- 지연 = 질문 하나를 넣고 순위 목록을 받기까지(준비 제외 · 몸풀기 1회 뒤) · 하이브리드 = bm25s + e5 + 합치기를 차례로 돌린 합 · 리랭커 = 하이브리드 + 다시 줄 세우기",
          "- 지연은 같은 run_all.py 실행에서 잰 행끼리만 견준다(선택 실행의 행은 따로 돌려 잰 것)",
          "- 장치: " + " · ".join(f"{x} {runs[x].get('device', '?')}" for x in names)]
(RESULTS / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

with open(RESULTS / "per_query.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "kind", "query", "rel"] + [f"rank_{x}" for x in names] + [f"top1_{x}" for x in names])
    for q in queries:
        w.writerow([q["id"], q["kind"], q["text"], " ".join(q["rel"])]
                   + [runs[x]["ranks"][q["id"]] or "" for x in names]
                   + [runs[x]["top1"][q["id"]] or "" for x in names])

# 짝 비교 — 같은 질문에서 처음 나온 정답의 순위가 어느 쪽이 더 위인가(찾지 못함은 맨 아래로 친다)
default = [(HYB, "e5small_prefix"), (HYB, "bm25s_char2"), (RR, HYB), ("e5small_prefix", "bm25s_char2")]
default += [(x, HYB) for x in names if x.startswith("hybrid_rrf") and x != HYB]  # 선택 실행(다른 k)은 기본 하이브리드와
default += [(x, RR) for x in names if x.startswith("rerank_rrf") and x != RR]    # 선택 실행(다른 폭·k)은 기본 리랭커와
pairs = [tuple(x.split(",")) for x in sys.argv[1:]] or [p for p in default if p[0] in runs and p[1] in runs]
pairs_path = RESULTS / ("pairs_custom.md" if sys.argv[1:] else "pairs.md")  # 인자로 고른 쌍은 따로 — pairs.md 는 그대로
out = ["# 짝 비교(같은 질문끼리)", ""]
for a, b in pairs:
    if a not in runs or b not in runs:
        sys.exit(f"없는 실행 이름: {a} 또는 {b} — 있는 이름 {names}")
    big = len(corpus) + 1
    sa = {q["id"]: runs[a]["ranks"][q["id"]] or big for q in queries}
    sb = {q["id"]: runs[b]["ranks"][q["id"]] or big for q in queries}
    a_up = [q["id"] for q in queries if sa[q["id"]] < sb[q["id"]]]
    b_up = [q["id"] for q in queries if sb[q["id"]] < sa[q["id"]]]
    only_a = [q["id"] for q in queries if sa[q["id"]] <= 5 < sb[q["id"]]]
    only_b = [q["id"] for q in queries if sb[q["id"]] <= 5 < sa[q["id"]]]
    out += [f"## {a} 대 {b}",
            f"- {a} 가 더 위: {len(a_up)} · {b} 가 더 위: {len(b_up)} · 같음: {n - len(a_up) - len(b_up)}"]
    for kind, qs in by_kind.items():  # 같은 셈을 갈래마다 — 앞 실습 compare.py 와 같은 줄
        ka = sum(sa[q["id"]] < sb[q["id"]] for q in qs)
        kb = sum(sb[q["id"]] < sa[q["id"]] for q in qs)
        out.append(f"  - {kind} {len(qs)}문항: {a} 가 더 위 {ka} · {b} 가 더 위 {kb} · 같음 {len(qs) - ka - kb}")
    out += [f"- {a} 만 5위 안: {', '.join(only_a) or '없음'}",
            f"- {b} 만 5위 안: {', '.join(only_b) or '없음'}", ""]
pairs_path.write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
