# 검색 갈래 비교 — bm25s·e5·RRF 하이브리드·bge-reranker-v2-m3 를 같은 30문항과 같은 자로 — 명령·코드 모음

실습 id: `lab.c.lab.retrieval_ablation`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대와 설치

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install bm25s==0.3.13
python -c "import torch, bm25s, sentence_transformers; print(torch.__version__, torch.cuda.is_available(), bm25s.__version__, sentence_transformers.__version__)"
mkdir retrieval_ablation
```

```powershell
git log -1 --format="%H %ci" -- semantic_search/data
git ls-files semantic_search/data
git status --short semantic_search
cd retrieval_ablation
```

## 2. 공용 코드

- `files/ra_common.py` — 키트에 들어 있음 (python)

## 3. 환경과 리랭커 고정

- `files/env_check.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python env_check.py` — 환경과 리랭커 고정 — 아래를 `env_check.py` 로 저장하고 `python env_check.py` 로 실행한다.

## 4. 설정 잠금

```powershell
cd C:\work\ai-lab
git add retrieval_ablation/ra_common.py retrieval_ablation/env_check.py
git commit -m "검색 갈래 비교 — 설정 잠금(후보 20 · RRF k 60 · Recall@5·MRR@10 · 지연 중앙값)"
git rev-parse HEAD
cd retrieval_ablation
```

## 5. 네 설정 돌리기

- `files/run_all.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_all.py` — 네 설정 돌리기 — 아래를 `run_all.py` 로 저장하고 `python run_all.py` 로 실행한다.

## 6. 한 표와 짝 비교

- `files/report.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python report.py` — 한 표와 짝 비교 — 아래를 `report.py` 로 저장하고 `python report.py` 로 실행한다.
- `python report.py hybrid_rrf60,bm25s_char2` — 다른 쌍만 보고 싶으면 `python report.py hybrid_rrf60,bm25s_char2` 처럼 '이름,이름' 을 준다.

## 8. 리랭커가 고칠 수 없었던 실패

- `files/failures.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python failures.py` — 리랭커가 고칠 수 없었던 실패 — 아래를 `failures.py` 로 저장하고 `python failures.py` 로 실행한다.

## 9. (선택) 후보 폭 바꾸기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_all.py --pool 10` — `python run_all.py --pool 10` 과 `python run_all.py --pool 50` 을 돌리고, 각각 `python failures.py --pool 10` · `python failures.py --pool 50` 을 돌린 뒤 …
- `python run_all.py --pool 50` — `python run_all.py --pool 10` 과 `python run_all.py --pool 50` 을 돌리고, 각각 `python failures.py --pool 10` · `python failures.py --pool 50` 을 돌린 뒤 …
- `python failures.py --pool 10` — `python run_all.py --pool 10` 과 `python run_all.py --pool 50` 을 돌리고, 각각 `python failures.py --pool 10` · `python failures.py --pool 50` 을 돌린 뒤 …
- `python failures.py --pool 50` — … --pool 10` 과 `python run_all.py --pool 50` 을 돌리고, 각각 `python failures.py --pool 10` · `python failures.py --pool 50` 을 돌린 뒤 `python report.py
- `python report.py` — … --pool 10` 과 `python run_all.py --pool 50` 을 돌리고, 각각 `python failures.py --pool 10` · `python failures.py --pool 50` 을 돌린 뒤 `python report.py

## 10. (선택) RRF 상수 바꾸기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python run_all.py --rrf-k 10` — (선택) RRF 상수 바꾸기 — `python run_all.py --rrf-k 10` 처럼 60 이 아닌 값 하나로 돌린다.
- `python report.py` — `python report.py` 를 다시 돌리면 pairs.md 에 hybrid_rrf10 대 hybrid_rrf60 줄과 rerank_rrf10_p20 대 rerank_rrf60_p20 줄이 더해진다.

## 12. 판 기록과 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

```powershell
git add requirements.txt requirements.lock.txt retrieval_ablation
git commit -m "검색 갈래 비교 — bm25s·e5·RRF·리랭커 한 표와 실패 분류"
git rev-parse HEAD
```

```powershell
git add retrieval_ablation/ablation_report.md
git commit -m "검색 갈래 비교 보고서 — c7 커밋 해시"
git status
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git status --short semantic_search` — 1단계의 `git status --short semantic_search` 가 빈 출력이었고, 설정 잠금 커밋(`git show --stat <해시>`)에 ra_common.py 가 들어 있으며, 그 커밋 시각(`git log -1 --format=%ci <해시>`)이 results …
- `git show --stat <해시>` — 1단계의 `git status --short semantic_search` 가 빈 출력이었고, 설정 잠금 커밋(`git show --stat <해시>`)에 ra_common.py 가 들어 있으며, 그 커밋 시각(`git log -1 --format=%ci <해시>`)이 results …
- `git log -1 --format=%ci <해시>` — … 가 빈 출력이었고, 설정 잠금 커밋(`git show --stat <해시>`)에 ra_common.py 가 들어 있으며, 그 커밋 시각(`git log -1 --format=%ci <해시>`)이 results 폴더의 모든 run 파일의 수정 시각보다 앞서는가
- `git status` — requirements.txt 에 bm25s==0.3.13 이 있고, lock 의 torch 줄에 +cu 꼬리표가 있으며, c7 해시를 적은 보고서를 다시 올린 뒤 마지막 `git status` 가 깨끗한가

## 흔한 실패

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python -c "import torch; print(torch.cuda.is_available())"` — 리랭커 장치가 cpu 로 찍힌다 → `python -c "import torch; print(torch.cuda.is_available())"` 가 False 면 torch 판부터 본다.
