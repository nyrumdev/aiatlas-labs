# 검색 갈래 비교 — bm25s·e5·RRF 하이브리드·bge-reranker-v2-m3 를 같은 30문항과 같은 자로

AI 아틀라스 앱의 실습 `lab.c.lab.retrieval_ablation`(L3 · 약 3시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 retrieval_ablation\ablation_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다) · 같은 C:\work\ai-lab\retrieval_ablation 폴더에 파이썬 파일 5개(ra_common · env_check · run_all · report · failures) + results 폴더.
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · 앞 실습 [실습] 한국어 의미 검색 만들고 Recall@k 로 재기를 끝낸 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch·sentence-transformers·rank-bm25 가 들어 있고, semantic_search 폴더에 잠근 data(corpus.jsonl · queries.jsonl)와 REVISION 을 채운 common.py, results\run_e5small_prefix.json · run_bm25_char2.json 이 있다 · 마지막 git status 가 깨끗하다
- GPU — 리랭커는 파라미터 약 5억 6,800만 개의 F32 가중치(약 2.3GB)를 올린다. RTX 4070 Ti 12GB 에 넉넉히 들어가고, GPU 가 없어도 CPU 로 끝까지 돌지만 지연 열의 숫자가 크게 달라진다
- 인터넷 — bm25s 설치와 리랭커 모델 파일 내려받기에만 쓴다(model.safetensors 한 파일이 2,271,071,852바이트 · S6362) · Hugging Face 계정·토큰은 필요 없다
- 메모장 등 글 편집기 — 파이썬 파일을 UTF-8 로 저장한다

## 들어 있는 파일
- `files/ra_common.py`
- `files/env_check.py`
- `files/run_all.py`
- `files/report.py`
- `files/failures.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.retrieval_ablation` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
