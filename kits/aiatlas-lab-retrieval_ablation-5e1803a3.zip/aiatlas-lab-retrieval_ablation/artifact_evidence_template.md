lab_id: lab.c.lab.retrieval_ablation

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 두 잠금 — 앞 실습 data 의 마지막 커밋(git log -1 --format='%H %ci' -- semantic_search/data 출력 1줄)과 git status --short semantic_search 가 빈 출력이라는 1줄 + 이 실습의 설정(후보 20 · RRF k 60 · 지표 Recall@5·MRR@10 · 지연 중앙값)을 담은 ra_common.py 를 첫 실행 전에 올린 설정 잠금 커밋 해시 40자리 1줄 -->
c1: 
<!-- c2(필수): 환경 — results\env.md(판 · 장치 · bm25s 판 · e5 커밋 · 리랭커 커밋 · 리랭커 max_seq_length·num_labels·점수 변환) + ra_common.py 의 RERANKER_REVISION 이 env.md 의 리랭커 커밋과 같다는 1줄 -->
c2: 
<!-- c3(필수): 네 실행 — results\run_bm25s_char2.json · run_e5small_prefix.json · run_hybrid_rrf60.json · run_rerank_rrf60_p20.json · pools_rrf60_p20.json + run_all.py 출력의 '앞 실습 … 같은 문항' 두 줄(e5 줄은 30/30 이어야 하고, 아니면 run_all.py 가 그 문항마다 찍은 정답 문서와 이웃 문서의 점수 차를 적는다 · bm25s 줄은 다른 문항 수와 그 까닭 1줄) -->
c3: 
<!-- c4(필수): 한 표 — results\summary.md(네 실행 × Recall@5·MRR@10·Recall@1·Recall@10·갈래별 5위 안·지연 중앙값·최댓값 · 장치 줄) + results\pairs.md + results\per_query.csv -->
c4: 
<!-- c5(필수): 결론 3문장 — ① 하이브리드 대 두 단독 검색 ② 리랭커 대 하이브리드 ③ 리랭커가 얹은 지연의 값 — ①②는 summary.md 의 숫자와 pairs.md 의 '더 위' 문항 수·갈래별 줄을, ③은 summary.md 의 하이브리드·리랭커 두 행의 지연과 run 파일의 rerank_only_ms_median 을 인용하고, 두 칸을 따로 판정해 '더 위' 수의 차가 2 이하인 짝은 순서 쪽을, '만 5위 안' 문항 수의 차가 2 이하인 짝은 5위 안 쪽을 '이 묶음으로는 가르지 못한다'로 쓴다 -->
c5: 
<!-- c6(필수): 리랭커가 고칠 수 없었던 실패 — results\failures_rrf60_p20.md 의 '후보 20개 안에 정답이 하나라도 든 문항' 줄 · 5위 밖 문항 수 = 후보 밖 + 후보 안에서 밀림 줄 · 고친 문항·망친 문항 줄 + 보고서에 붙인 failures 표의 모든 행에 손으로 쓴 원인 추정 1줄 -->
c6: 
<!-- c7(필수): 판 기록과 커밋 — requirements.txt 의 bm25s==0.3.13 줄 + 다시 뽑은 requirements.lock.txt 맨 위 색인 줄과 torch 줄의 +cu 꼬리표 + 실습 파일·결과·보고서를 올린 커밋 해시 1줄(이 줄만 고친 보고서는 다음 커밋으로 다시 올린다) -->
c7: 
<!-- c8(선택): (선택) 후보 폭 바꾸기 — --pool 10 과 --pool 50 실행의 run 파일 둘 + summary.md 의 두 행 + 두 폭의 failures_rrf60_p10.md · failures_rrf60_p50.md 와 기본 폭 20 의 failures_rrf60_p20.md 에서 '후보 밖' 개수와 세 run 파일의 rerank_only_ms_median 이 어떻게 움직였는지 1줄(pairs.md 의 rerank_rrf60_p10 대 rerank_rrf60_p20 · rerank_rrf60_p50 대 rerank_rrf60_p20 줄도 함께) -->
c8: 
<!-- c9(선택): (선택) RRF 상수 바꾸기 — --rrf-k 를 60 이 아닌 값 하나로 돌린 run 파일 둘(hybrid · rerank) + summary.md 의 행 + pairs.md 의 그 하이브리드 대 hybrid_rrf60 줄 + 해석 1줄 -->
c9: 
