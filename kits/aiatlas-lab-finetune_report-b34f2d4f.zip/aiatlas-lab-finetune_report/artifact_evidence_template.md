lab_id: lab.c.lab.finetune_report

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c9(필수): env/ — requirements.lock.txt(pip freeze 출력 · 맨 위 --extra-index-url 줄 · torch·torchvision·transformers·peft·trl·bitsandbytes·accelerate·datasets 여덟 줄이 == 로 적힘) + env_check.txt(torch 판 · cuda True · GPU 이름 · bf16 지원 · trl 1.15.0 · 맨 끝 값이 None 이 아님) + 리포트에 붙인 wsl -l -v 출력(VERSION 2) + 9단계 직전에 다시 뽑은 freeze 와 lock 의 대조 1줄(같음, 또는 달라진 줄과 lock 을 갱신한 사실) + runs/main/run_info.json(본 학습 직전에 record_run.py 로 남긴 commit 40자리 · dirty false) -->
c9: 
<!-- c1(필수): train_data.jsonl — 대화형 프롬프트·완성 쌍 200개 이상 + 리포트에 데이터 형식 명시(열 이름·손실을 거는 구간·출처·행 수) -->
c1: 
<!-- c2(필수): qlora_config.yaml — 튜닝할 모델 id·양자화 설정·LoRA 붙일 자리(비웠다면 그 사실과 기본값 = 언어 모델 q_proj·v_proj)·랭크·학습률·에폭·시퀀스 길이·옵티마이저·검증 데이터 경로·기록 간격(logging_steps·eval_steps) 항목이 값과 함께 들어 있는 설정 파일 1개 + 학습 스크립트가 이 파일 하나만 읽는다는 확인 1줄 -->
c2: 
<!-- c10(필수): runs/rehearsal/ — qlora_config_rehearsal.yaml 과 본 설정의 diff 출력(train_rows 20 · max_steps 50 · output_dir 세 줄만 다름) + run_summary.json(global_step 50 · train_rows 20 · train_runtime · peak_mem_mib · peak_reserved_mib) + adapter/ 의 adapter_config.json·adapter_model.safetensors + reload_check.json(load ok · generate ok · 답 1개) + 리포트 '예행' 줄에 본 학습 시간 어림 1줄과 고른 변종(E4B 또는 E2B)·그 근거(peak_reserved_mib 인용) 1줄 -->
c10: 
<!-- c3(필수): 어댑터 폴더 경로 — runs/main/adapter 에 adapter_config.json + adapter_model.safetensors 존재 + 리포트 상단에 학습 스크립트 경로와 실행 명령 1줄 -->
c3: 
<!-- c11(필수): runs/main/loss_curve.png(학습 손실과 검증 손실이 같은 걸음 축) + loss_points.csv + trainer_state.json + val_data.jsonl(학습 쌍과 같은 형식 20행 이상 · 학습 데이터와 프롬프트가 같은 행 0 — 대조 출력 붙여 넣기) + 그림 아래 해석 2줄(검증 손실이 가장 낮았던 걸음 · 끝으로 가며 오르는지 내리는지) -->
c11: 
<!-- c4(필수): eval_before_after.csv — 문항 id·질문·기대 답·튜닝 전 답·튜닝 후 답·전 정오(1/0)·후 정오(1/0) 20행 이상 + 리포트에 전후 정답 수 표(정답 수/문항 수) -->
c4: 
<!-- c5(필수): 리포트 '회귀' 절 — 회귀를 찾은 절차(어느 문항 묶음을 전후로 대조했는지)와 결과: 나빠진 항목마다 문항 id·전 답·후 답·원인 추정 1문장, 찾지 못했다면 일반 문항을 늘려 다시 찾은 뒤 대조한 문항 목록과 함께 그 사실 -->
c5: 
<!-- c6(필수): safety_10.csv — 안전 시나리오 10행(시나리오 id·갈래·프롬프트·기대 행동·전 응답 요약·후 응답 요약·전 판정·후 판정 — 정상으로 답해야 하는 대조군 2행 이상 포함) + 리포트에 전후 통과 수 표(통과 수/10) -->
c6: 
<!-- c7(선택): (선택) 어댑터를 16비트 원본에 병합해 GGUF 로 변환·양자화하고 Ollama Modelfile 로 등록 — Modelfile 경로와 `ollama run` 첫 응답 캡처 — 등록한 모델로 평가 문항을 다시 돌린 결과를 eval_before_after.csv 에 '변환 후' 열로 추가 -->
c7: 
<!-- c8(선택): (선택) 랭크·데이터 양·에폭 가운데 하나만 바꿔 1회 더 학습하고 c4 표에 열 추가 -->
c8: 
