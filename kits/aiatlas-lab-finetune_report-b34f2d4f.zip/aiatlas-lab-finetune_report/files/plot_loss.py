r"""plot_loss.py — trainer_state.json 의 기록(log_history)에서 학습 손실과 검증 손실을 꺼내
같은 걸음 축의 그림 한 장(loss_curve.png)과 점 목록(loss_points.csv)으로 남긴다.

실행 예:
    python plot_loss.py runs/main/trainer_state.json --out runs/main/loss_curve.png
"""
import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # 창을 띄우지 않고 파일로만 그린다
import matplotlib.pyplot as plt


def read_points(state_path):
    """log_history 에서 (걸음, 학습 손실) 과 (걸음, 검증 손실) 목록을 뽑는다."""
    history = json.loads(Path(state_path).read_text(encoding="utf-8"))["log_history"]
    train = [(h["step"], h["loss"]) for h in history if "loss" in h]
    val = [(h["step"], h["eval_loss"]) for h in history if "eval_loss" in h]
    return train, val


def main():
    parser = argparse.ArgumentParser(description="학습·검증 손실 곡선을 그린다")
    parser.add_argument("state", help="trainer_state.json 경로")
    parser.add_argument("--out", default="loss_curve.png", help="저장할 그림 파일")
    args = parser.parse_args()

    train, val = read_points(args.state)
    if not train or not val:
        print("학습 손실 또는 검증 손실 기록이 없다 — logging_steps · eval_strategy · 검증 데이터를 확인한다",
              file=sys.stderr)
        return 1

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot([s for s, _ in train], [v for _, v in train], label="train loss")
    ax.plot([s for s, _ in val], [v for _, v in val], marker="o", label="validation loss")
    ax.set_xlabel("step")
    ax.set_ylabel("loss")
    ax.legend()
    fig.savefig(args.out, dpi=120, bbox_inches="tight")

    csv_path = Path(args.out).with_name("loss_points.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["kind", "step", "loss"])
        writer.writerows(("train", s, v) for s, v in train)
        writer.writerows(("validation", s, v) for s, v in val)
    print(f"학습 점 {len(train)}개 · 검증 점 {len(val)}개 → {args.out} · {csv_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
