"""train_qlora.py — 설정 파일 하나(qlora_config.yaml)만 읽어 QLoRA 학습을 돌리고, 어댑터·손실 기록·요약을 남긴다.

실행 예:
    python train_qlora.py --config qlora_config.yaml --show-example   # 첫 행이 펴진 모양과 손실 구간만 보고 끝낸다
    python train_qlora.py --config qlora_config.yaml
"""
import argparse
import json
import sys
from pathlib import Path

import torch
import yaml
from datasets import load_dataset
from peft import LoraConfig
from transformers import AutoModelForMultimodalLM, AutoProcessor, BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer


def load_base(cfg):
    """설정대로 원 모델(4비트)과 프로세서를 부른다 — 학습 · 전후 측정 · 재적재 점검이 모두 이 함수를 쓴다."""
    q = cfg["quantization"]
    dtype = getattr(torch, q["compute_dtype"])
    bnb = BitsAndBytesConfig(
        load_in_4bit=q["load_in_4bit"],
        bnb_4bit_quant_type=q["bnb_4bit_quant_type"],
        bnb_4bit_use_double_quant=q["bnb_4bit_use_double_quant"],
        bnb_4bit_compute_dtype=dtype,
        bnb_4bit_quant_storage=dtype,
    )
    model = AutoModelForMultimodalLM.from_pretrained(cfg["model_id"], dtype=dtype, device_map="auto",
                                                     quantization_config=bnb)
    processor = AutoProcessor.from_pretrained(cfg["processor_id"])
    return model, processor


def main():
    parser = argparse.ArgumentParser(description="설정 파일 하나만 읽어 QLoRA 학습을 돌린다")
    parser.add_argument("--config", required=True)
    parser.add_argument("--show-example", action="store_true", help="첫 행이 템플릿으로 펴진 모양과 손실 구간만 찍고 끝낸다")
    args = parser.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    out_dir = Path(cfg["output_dir"])

    data = load_dataset("json", data_files={"train": cfg["train_file"], "validation": cfg["val_file"]})
    train_ds = data["train"]
    if cfg.get("train_rows"):
        train_ds = train_ds.select(range(cfg["train_rows"]))

    model, processor = load_base(cfg)
    lora = LoraConfig(task_type="CAUSAL_LM", **cfg["lora"])
    sft_args = SFTConfig(output_dir=str(out_dir), **cfg["train"])
    trainer = SFTTrainer(model=model, args=sft_args, train_dataset=train_ds, eval_dataset=data["validation"],
                         processing_class=processor, peft_config=lora)
    if args.show_example:
        row = trainer.train_dataset[0]
        print(sorted(row.keys()))
        print(processor.decode(row["input_ids"]))
        print("--- 손실이 걸리는 토큰(labels 가 -100 이 아닌 자리):")
        print(processor.decode([i for i, lab in zip(row["input_ids"], row["labels"]) if lab != -100]))
        return 0
    result = trainer.train()
    trainer.save_model(str(out_dir / "adapter"))  # 어댑터 파일 두 개
    trainer.save_state()                          # out_dir/trainer_state.json — 손실 기록(log_history)

    cuda = torch.cuda.is_available()
    summary = dict(result.metrics, global_step=result.global_step, train_rows=len(train_ds),
                   peak_mem_mib=round(torch.cuda.max_memory_allocated() / 2**20, 1) if cuda else None,
                   peak_reserved_mib=round(torch.cuda.max_memory_reserved() / 2**20, 1) if cuda else None)
    (out_dir / "run_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
