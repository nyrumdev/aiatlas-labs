r"""reload_check.py — 새 프로세스에서 원 모델과 저장한 어댑터를 다시 불러와 질문 하나에 답하게 하고,
'불러오기'와 '답하기'를 나눠 JSON 으로 남긴다.

실행 예:
    python reload_check.py --config qlora_config_rehearsal.yaml --adapter runs/rehearsal/adapter --question "환불은 며칠 안에 되나요?"
"""
import argparse
import json
import sys
import traceback
from pathlib import Path

import yaml
from peft import PeftModel

from train_qlora import load_base  # 학습·전후 측정과 같은 적재 함수를 그대로 쓴다


def main():
    parser = argparse.ArgumentParser(description="저장한 어댑터를 새 프로세스에서 다시 불러와 한 문항에 답하게 한다")
    parser.add_argument("--config", required=True, help="학습에 쓴 설정 파일")
    parser.add_argument("--adapter", required=True, help="어댑터 폴더(adapter_config.json 이 있는 곳)")
    parser.add_argument("--question", required=True, help="물어볼 문항 하나")
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--out", default="reload_check.json")
    args = parser.parse_args()

    record = {"config": args.config, "adapter": args.adapter, "question": args.question,
              "max_new_tokens": args.max_new_tokens, "load": "not_run", "generate": "not_run"}
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))

    try:
        model, processor = load_base(cfg)
        model = PeftModel.from_pretrained(model, args.adapter)
        model.eval()
        record["load"] = "ok"
    except Exception:
        record["load"] = "fail"
        record["error"] = traceback.format_exc(limit=2)

    if record["load"] == "ok":
        try:
            messages = [{"role": "user", "content": args.question}]
            inputs = processor.apply_chat_template(messages, add_generation_prompt=True, tokenize=True,
                                                   return_dict=True, return_tensors="pt").to(model.device)
            out = model.generate(**inputs, max_new_tokens=args.max_new_tokens, do_sample=False)
            answer = processor.decode(out[0][inputs["input_ids"].shape[-1]:], skip_special_tokens=True)
            record["answer"] = answer
            record["generate"] = "ok" if answer.strip() else "empty"
        except Exception:
            record["generate"] = "fail"
            record["error"] = traceback.format_exc(limit=2)

    Path(args.out).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"불러오기 {record['load']} · 답하기 {record['generate']} → {args.out}")
    return 0 if record["generate"] == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
