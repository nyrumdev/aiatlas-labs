# record_run.py — 이번 실행이 어느 코드 판에서 돌았는지 그 실행의 결과 폴더에 남긴다
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

def git(*args):
    done = subprocess.run(["git", *args], capture_output=True, text=True, encoding="utf-8", check=True)
    return done.stdout

changes = git("status", "--porcelain").rstrip("\n")  # 줄 앞의 두 칸 상태는 살려 둔다
record = {
    "commit": git("rev-parse", "HEAD").strip(),
    "describe": git("describe", "--always", "--dirty").strip(),
    "dirty": bool(changes),
    "recorded_at": datetime.now().isoformat(timespec="seconds"),
}
out = Path(sys.argv[1] if len(sys.argv) > 1 else "out")  # 실행마다 결과 폴더를 넘긴다
out.mkdir(parents=True, exist_ok=True)
(out / "run_info.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print("코드 판:", record["describe"])
if changes:
    print("경고: 커밋하지 않은 변경이 있다. 이 커밋 이름이 이번 코드를 가리킨다고 장담할 수 없다")
    print(changes)
