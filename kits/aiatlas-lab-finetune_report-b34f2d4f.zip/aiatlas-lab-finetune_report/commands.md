# 파인튜닝 1회 + 평가 리포트 — 명령·코드 모음

실습 id: `lab.c.lab.finetune_report`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 2. 실행 환경과 판 고정 — 학습 데이터를 만들기 전에 환경부터 세운다. 먼저 WSL 을 쓰는 이유다. TRL 1.15.0 의 SFTTrainer 는 만들 때 모델에 '융합 LM 머리'를 조건 없이 덧씌우고 …

```powershell
wsl --install            # 관리자 PowerShell · 끝나면 재시작
wsl -l -v                # 재시작 뒤 — Ubuntu 줄의 VERSION 이 2 인지 본다
```

```bash
sudo apt update && sudo apt install -y python3-venv python3-dev build-essential git
mkdir -p ~/ft-lab/env ~/ft-lab/runs && cd ~/ft-lab
python3 --version                      # 3.11~3.14 여야 한다(trl 1.15.0 은 3.11 이상 · torch 의 Triton 은 3.15 미만)
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch==2.14.1 torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132
python -m pip install "trl[peft]==1.15.0" "transformers==5.19.0" "peft==0.21.2" "datasets==5.1.0" "accelerate==1.15.0" "matplotlib==3.11.2" "bitsandbytes==0.50.2" "pyyaml==6.0.3"
python -c "import torch, trl, bitsandbytes, trl.trainer.utils as u; c = torch.cuda.is_available(); print(torch.__version__, c, torch.cuda.get_device_name(0) if c else None, torch.cuda.is_bf16_supported() if c else None, trl.__version__, bitsandbytes.__version__, u._ChunkedLogProbFunction)" | tee env/env_check.txt
```

```bash
{ echo "--extra-index-url https://download.pytorch.org/whl/cu132"; python -m pip freeze; } > env/requirements.lock.txt
grep -E "^(torch|torchvision|transformers|peft|trl|bitsandbytes|accelerate|datasets)==" env/requirements.lock.txt
git init && git config user.name "내 이름" && git config user.email "내 메일"
printf ".venv/\nruns/\n__pycache__/\n" > .gitignore
explorer.exe .
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `pip install transformers`
- `hf download google/gemma-4-E4B-it`
- `cd ~/ft-lab && source .venv/bin/activate`

## 3. 데이터 — 대화형 프롬프트·완성 쌍을 200개 이상 만들어 train_data.jsonl 에 저장한다. 한 행은 `prompt`(사용자 턴 목록)와 `completion`(어시스턴트 턴 목록) 두 열로 적는다 …

```bash
python -c "import json; t={json.dumps(json.loads(l)['prompt'],ensure_ascii=False) for l in open('train_data.jsonl',encoding='utf-8')}; v=[json.dumps(json.loads(l)['prompt'],ensure_ascii=False) for l in open('val_data.jsonl',encoding='utf-8')]; print(len(t), len(v), sum(x in t for x in v))"
```

## 6. 설정 파일과 학습 스크립트 — 튜닝할 모델 id·양자화 설정(S108)·LoRA 붙일 자리·랭크·학습률·에폭·시퀀스 길이·옵티마이저·검증 데이터·기록 간격을 qlora_config.yaml 에 값과 함께 …

- `files/qlora_config.yaml` — 키트에 들어 있음 (yaml)

- `files/train_qlora.py` — 키트에 들어 있음 (python)

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `git add . && git commit -m "설정·스크립트·판 기록"`

## 7. 예행 학습 — 본 학습 전에 데이터 20행·50걸음으로 끝에서 끝까지 한 번 돌린다. 목적은 품질이 아니라 관이 끝까지 통하는지다. 4비트 적재 → 학습 → 저장 → 새 프로세스에서 재적재 → 답 생성, 이 …

- `files/reload_check.py` — 키트에 들어 있음 (python)

- `files/plot_loss.py` — 키트에 들어 있음 (python)

```bash
git add reload_check.py plot_loss.py && git commit -m "예행 점검 스크립트"
sed -e "s/^train_rows: null.*/train_rows: 20/" -e "s/^output_dir: runs\/main/output_dir: runs\/rehearsal/" -e "s/^  max_steps: -1.*/  max_steps: 50/" qlora_config.yaml > qlora_config_rehearsal.yaml
diff qlora_config.yaml qlora_config_rehearsal.yaml
git add qlora_config_rehearsal.yaml && git commit -m "예행 설정"
python train_qlora.py --config qlora_config_rehearsal.yaml --show-example
python record_run.py runs/rehearsal
python train_qlora.py --config qlora_config_rehearsal.yaml
ls runs/rehearsal runs/rehearsal/adapter
python plot_loss.py runs/rehearsal/trainer_state.json --out runs/rehearsal/loss_curve.png
python reload_check.py --config qlora_config_rehearsal.yaml --adapter runs/rehearsal/adapter --question "내 평가 문항 하나" --out runs/rehearsal/reload_check.json
```

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `mv runs/rehearsal runs/rehearsal_e4b`
- `hf download google/gemma-4-E2B-it`
- `git add qlora_config.yaml qlora_config_rehearsal.yaml && git commit -m "E2B 로 전환"`

## 9. 학습과 손실 곡선 — 시작하기 직전에 판이 그대로인지 본다. 예행 뒤에 꾸러미를 더 넣었다면 lock 과 어긋난다. 8단계에서 만든 측정 스크립트와 표도 커밋해 둔다. 그래야 실행 기록의 dirty 가 …

```bash
python -m pip freeze | diff <(grep -v "^--" env/requirements.lock.txt) - && echo "lock 과 같음"
python record_run.py runs/main
python train_qlora.py --config qlora_config.yaml
python plot_loss.py runs/main/trainer_state.json --out runs/main/loss_curve.png
```

## 13. (선택) 어댑터를 16비트 원본에 병합하고, llama.cpp 의 convert_hf_to_gguf.py 와 llama-quantize 로 GGUF 를 만든 뒤(S51) Modelfile 의 FROM 줄에 …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `ollama create`
- `wsl --shutdown`
- `explorer.exe .`

## 15. 리포트 — finetune_report.md 첫 부분에 `lab_id: lab.c.lab.finetune_report` 한 줄을 적는다. 절은 `## 작업`(무엇을 어떤 순서로 돌렸나 · 명령 1줄씩) …

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `cp finetune_report.md /mnt/c/Users/<Windows 사용자 이름>/Documents/`

## 흔한 실패

본문 글 속 명령(앞뒤 설명은 앱 실습 화면):

- `python -m pip install torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132`
- `wsl -l -v`
- `wsl --shutdown`

## 추가 수행: 데이터 계보와 실패 주입 확인

```bash
python -c "import json; print(sum(not ''.join(m['content'] for m in json.loads(l)['completion']).strip() for l in open('train_data.jsonl',encoding='utf-8')))"
```
