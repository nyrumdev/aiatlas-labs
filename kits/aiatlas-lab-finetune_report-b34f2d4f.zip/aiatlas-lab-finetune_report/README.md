# 파인튜닝 1회 + 평가 리포트

AI 아틀라스 앱의 실습 `lab.c.lab.finetune_report`(L3 · 약 9시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — finetune_report.md(lab_id 줄 · ## 작업 · ## 결과 · ## 검증 · c9·c1·c2·c10·c3·c11·c4·c5·c6: 줄 · 64KiB 이하) + env/(requirements.lock.txt · env_check.txt) + train_data.jsonl + val_data.jsonl + qlora_config.yaml + qlora_config_rehearsal.yaml + train_qlora.py · plot_loss.py · reload_check.py · record_run.py + runs/rehearsal/ + runs/main/(adapter/ · trainer_state.json · loss_curve.png · loss_points.csv · run_summary.json · run_info.json) + eval_before_after.csv + safety_10.csv — 모두 WSL 의 ~/ft-lab 안(앱에 낼 finetune_report.md 는 15단계대로 Windows 쪽으로 복사).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 11 · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB · S426) 와 Windows 쪽 NVIDIA 드라이버 — 예를 들어 VRAM 12GB 라면 E4B 로 4비트 적재와 7단계 예행이 도는지 먼저 보고, 메모리가 모자라면 E2B 로 바꿔 끝까지 간다(E4B 는 4비트로 불러도 임베딩 표가 줄지 않는다 — 4비트 적재는 선형층만 4비트로 바꾸고 임베딩 층은 그대로 두는데(S6467), E4B 의 임베딩 표는 주 임베더 670M 과 층별 임베딩 2,820M 이라(S42) 이 약 35억 개가 16비트(하나에 2바이트 · S09)로 남아 그것만 7GB 안팎이다. 같은 VRAM 을 Windows 화면도 쓰므로 빠듯하다). 실측 예: RTX 4070 Ti 12GB 에서 E4B 4비트 예행과 본 학습(200행 · 600걸음)이 메모리 부족 없이 끝까지 돌았다 — 두 실행 모두 peak_reserved_mib 9048 · 그동안 nvidia-smi 가 본 GPU 전체 사용은 최고 10,773 MiB(12,282 MiB 가운데 · 화면 몫 포함). GPU 가 없거나 모자라면 클라우드 노트북 1개(공식 가이드의 기준 장비는 T4 16GB, S135)
- WSL 2 + Ubuntu(관리자 PowerShell 에서 wsl --install 후 재시작 · S3594) — 이 실습이 고정한 TRL 1.15.0 의 SFTTrainer 는 학습 걸음마다 Triton 커널을 거치는데 Windows 용 PyTorch 에는 Triton 이 함께 설치되지 않아, Windows 파이썬에서는 첫 걸음에서 멈춘다(S6461·S3595·S3597 · 1.16.0 은 Triton 이 없으면 같은 계산을 PyTorch 연산으로 대신한다 · S8920·S8921). 이 실습은 저작자가 점검한 1.15.0 조합을 고정하므로 학습·전후 측정은 모두 WSL 안에서 한다. WSL 안에는 리눅스용 디스플레이 드라이버를 설치하지 않는다(S3593)
- WSL 안의 파이썬 3.11~3.14 가상환경 — 판은 torch 2.14.1(CUDA 판) · torchvision 0.29.1(torch 와 같은 색인 · Gemma 4 프로세서가 부른다 · S9286·S9287) · trl 1.15.0 · transformers 5.19.0 · peft 0.21.2 · datasets 5.1.0 · accelerate 1.15.0 · matplotlib 3.11.2 · bitsandbytes 0.50.2 · PyYAML 6.0.3 으로 고정한다(S3588·S6465·S6466 · bitsandbytes 의 요구 사항은 S483). 설치·venv·pip·판 고정 습관은 앞 노드 파이썬 실습 환경과 [실습] AI 실습 PC 세우기(파이썬·가상환경·Jupyter·PyTorch GPU 확인·판 고정)에서 익힌 그대로 쓴다
- 모델 google/gemma-4-E4B-it 원본 가중치 — Apache 2.0 이라 별도 사용 승인 없이 WSL 안에서 `hf download` 로 받는다(S09·S162). 파일은 16비트 한 덩어리로 약 16GB 이고(S09), WSL 의 리눅스 디스크는 C 드라이브 위의 파일이라(S6471) C 드라이브에 그만큼과 선택 과제 c7 의 병합본·GGUF 몫을 남겨 둔다. 튜닝·평가·병합·변환을 끝까지 이 한 변종으로 한다(7단계에서 E2B 로 바꿨다면 그 변종으로)
- git — WSL 안에서 이름·메일을 다시 설정한다(앞 노드 git 기초에서 Windows 쪽에 한 설정은 WSL 로 넘어오지 않는다)
- (선택 과제 c7 용) Windows 쪽 Ollama 설치 + `ollama run` 실행 경험 — Ollama로 실행 레슨 수준이면 되고, [실습] Gemma 4를 내 PC에서 돌리기를 해 두었다면 그 환경을 그대로 쓴다
- 내 도메인 텍스트 원천(문서·FAQ·대화 기록 등) — 학습 200쌍과 검증 20쌍을 만들 만큼

## 들어 있는 파일
- `files/qlora_config.yaml`
- `files/train_qlora.py`
- `files/reload_check.py`
- `files/plot_loss.py`
- `files/record_run.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.finetune_report` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
