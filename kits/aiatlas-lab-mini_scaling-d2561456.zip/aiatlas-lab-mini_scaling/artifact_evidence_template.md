lab_id: lab.c.lab.mini_scaling

<!-- 이 틀을 채워 앱에 냅니다(파일 이름은 README '쓰는 법' 4). 폰 앱에서는 실습 화면 '결과 문서 붙여넣기'에 전체를 붙여 넣습니다.
     앱은 문서의 구조(lab_id · 세 절 · 필수 항목 줄)와 체크리스트 자가 보고만 검사합니다. 내용이 참인지·코드가 실제로 돌았는지는 검증하지 않습니다. -->

## 작업
(무엇을 어떤 환경·판으로 했는지 — 40자 이상)

## 결과
(관찰한 숫자·출력·파일 — 40자 이상)

## Chinchilla 와 견주기
(본문 절차가 이 절에 적으라고 한 것)

## 출처 표기
(본문 절차가 이 절에 적으라고 한 것)

## 검증
(어떻게 확인했는지와 남은 한계 — 40자 이상)

## 체크리스트 기록
<!-- 항목마다 'cN: ' 뒤에 그 조건을 확인한 실제 기록을 20자 이상 씁니다. 앱에서 체크한 항목과 같아야 합니다. -->
<!-- c1(필수): 통제 체크리스트 먼저 — control_checklist.md 의 '정한 값' 칸 열네 줄이 모두 채워진 채, 첫 학습 실행(runs 폴더의 가장 이른 config.json)보다 먼저 코드와 함께 커밋되어 있음(git log 시각) + fit_summary.md 0절이 '같은 코드: 예(커밋 1종)'이고 그 커밋이 control_checklist.md 를 처음 넣은 커밋과 같음 + 끝난 뒤 '지켰나' 칸에 fit_summary.md 0절과 config.json 을 근거로 한 줄씩 -->
c1: 
<!-- c2(필수): 데이터 — prepare_tinystories.py 출력(SHA-256 일치 두 줄 · 어휘 크기 · train·val_select·val_final 의 이야기·토큰·바이트) 붙여 넣기 + data\meta.json 이 있음 + '한 바퀴 = 학습 토큰 수' 1줄 + git status 에 data 폴더가 보이지 않음 -->
c2: 
<!-- c3(필수): 시간 먼저 — probe.csv(크기 아홉 × bf16·off 열여덟 줄 — bf16 을 하드웨어로 지원하지 않는 GPU 면 off 아홉 줄과 그 사실 1줄) + plan.md(범위 밖 칸 표시 · 예산마다 범위 안 크기 수와 이웃 N 비 · 어림 합계) + 실제로 돌릴 범위를 정한 1줄(줄였다면 무엇을 왜) -->
c3: 
<!-- c4(필수): 학습률 — lr_choice.json(크기 아홉 · 모두 edge false) + pick_lr.py 출력의 크기별 탐색 줄 + 최선 학습률이 크기에 따라 옮겨 갔는지 1줄 -->
c4: 
<!-- c5(필수): 사다리 — scaling_runs.csv 의 ladder 열 줄(크기 다섯 × 시드 0·1) + fit_summary.md 1절 + '마지막 10% 하락'을 칸끼리, 그리고 같은 칸의 시드 흩어짐과 견준 1줄 -->
c5: 
<!-- c6(필수): 직선과 예측 — fit_summary.md 2절(맨 윗칸을 뺀 직선 · 맨 윗칸 예측 · 차이와 그 부호 · 견줄 잣대 · 세 갈래 판정) + scaling_fit.png 왼쪽 + '이 직선을 바깥으로 연장할 자격이 있는가' 판정 1줄 -->
c6: 
<!-- c7(필수): 등연산 — scaling_runs.csv 의 iso 줄 + 돌리지 않은 칸과 그 까닭 목록 + fit_summary.md 3절(예산 셋 · 범위 안 점 수 · 바닥 · D*/N* · 측정 최저 칸의 두 기준 D/N · 칸 걸음 ÷ 탐색 걸음) + scaling_fit.png 오른쪽 + 예산이 커질 때 바닥이 어느 쪽으로 움직였는지 1줄 + 바닥 근처 칸들이 탐색보다 몇 배 길게 돌았는지 1줄 -->
c7: 
<!-- c8(필수): 정밀도 — fit_summary.md 4절(크기마다 bf16 켬·끔의 초당 토큰과 최대 GPU 메모리) + 두 값이 어느 쪽으로 달랐는지 재어 본 그대로 1줄(bf16 을 하드웨어로 지원하지 않는 GPU 면 off 값과 'bf16 은 재지 못함' 1줄) -->
c8: 
<!-- c9(필수): 보고 — mini_scaling_report.md(Chinchilla 의 주장과 내 결과 5문장 · 규모 한계 포함 · '출처 표기' 절) + scaling_runs.csv · scaling_fit.png · fit_summary.md · requirements.lock.txt 다시 뽑음 + 코드 커밋 해시와 결과 커밋 해시 2줄 -->
c9: 
<!-- c10(선택): (선택) nanochat — 리눅스(WSL2 의 Ubuntu 포함)에서 커밋 92d63d4 를 --depth 를 줄이고 한 시간 안에 끝나는 걸음 수로 한 번 돌린 로그의 'Tokens : Scaling params ratio' · 'Total training FLOPs estimate' · 'Peak memory usage' · 'Total training time' · 'Minimum validation bpb' 다섯 줄 + 그 숫자를 내 사다리와 같은 그림에 올리지 않는 까닭 1줄 -->
c10: 
