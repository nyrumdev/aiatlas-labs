# 작은 GPT 사전학습으로 미니 스케일링 사다리 그리기

AI 아틀라스 앱의 실습 `lab.c.lab.mini_scaling`(L4 · 약 10시간) 키트입니다. 실습은 앱 안 구매 '실습 패키지'로 열리고, 절차 설명은 앱의 실습 화면에 있습니다. 이 키트에는 PC 에서 그대로 쓰는 파일만 담았습니다.

## 쓰는 법
1. 앱(폰)에서 이 실습의 절차를 읽습니다.
2. PC 에서 절차가 정한 작업 폴더에 `files/` 안의 파일을 같은 이름·같은 하위 폴더로 복사합니다.
3. 명령·코드는 `commands.md` 에 절차 순서대로 있습니다.
4. 끝나면 `artifact_evidence_template.md` 의 구조(lab_id · 작업/결과/검증 절 · 체크리스트 줄)대로 결과 문서를 씁니다. 앱에 내는 문서는 실습 본문의 제출 안내를 따릅니다 — 앱에는 C:\work\ai-lab\mini_scaling\mini_scaling_report.md 파일을 제출(폴더를 내면 앱은 그 안의 artifact_evidence.md 만 읽는다 · UTF-8 · 64KiB 이내) · 같은 mini_scaling 폴더에 control_checklist.md + scaling_runs.csv + scaling_fit.png + fit_summary.md + plan.md + probe.csv + lr_choice.json + prepare_tinystories.py · train_scaling.py · pick_lr.py · plan.py · fit_report.py + runs 폴더(실행마다 config.json · history.json · result.json · 사다리는 samples.txt).
5. 폰에서 학습한다면 그 문서를 메신저·메일로 폰에 보내고, 앱 실습 화면의 '결과 문서 붙여넣기'에 전체를 붙여 넣어 등록합니다.

## 준비물(앱의 실습 화면과 같음)
- Windows 10/11 x64 · PowerShell · NVIDIA GPU(이 과정의 기준 PC 는 RTX 4070 Ti 12GB) — 이 실습은 GPU 를 전제로 한다. bf16 끔(--amp off)으로도 돌지만 처리량이 다르니 probe 로 먼저 잰다 — bf16 을 하드웨어로 지원하지 않는 GPU 면 2단계에서 ⑭ 줄을 off 로 고쳐 적고, 학습 명령마다 --amp off 를 붙인다(그때 probe.csv 에는 off 줄 아홉만 생긴다)
- 앞 실습 [실습] 글자 단위 작은 GPT를 처음부터 짜서 내 GPU로 학습시키기를 마친 작업대 C:\work\ai-lab — 파이썬 3.14 가상환경(.venv)에 CUDA 판 torch·numpy·matplotlib 이 있고, char_gpt\chargpt.py 가 커밋되어 있으며, 저장소의 .gitignore 에 data/ 와 *.pt 줄이 있다
- 인터넷 — TinyStories 두 파일(학습 1,924,281,556바이트 · 검증 19,447,282바이트)과 tokenizers 설치에만 쓴다
- 디스크 여유 — 내려받은 글(약 1.9GB)과 토큰 번호 파일(토큰 수 × 2바이트) · runs 폴더는 기록만 남기고 가중치는 저장하지 않는다
- 시간 — 학습률 탐색(크기 9) · 사다리(크기 5 × 시드 2) · 등연산 칸들(예산 3 × 범위 안 크기들)을 GPU 로 돌린다. 실행 칸마다 기록이 따로 남으니 plan.md 의 어림 시간을 보고 여러 날에 나눠 돌려도 된다

## 들어 있는 파일
- `files/control_checklist.md`
- `files/prepare_tinystories.py`
- `files/train_scaling.py`
- `files/pick_lr.py`
- `files/plan.py`
- `files/fit_report.py`
- `commands.md`
- `artifact_evidence_template.md`
- `LICENSE`

모델 가중치·데이터셋은 키트에 넣지 않았습니다. 절차대로 원래 배포처에서 받으며, 각 배포처의 약관을 따릅니다.

## English
Lab kit for `lab.c.lab.mini_scaling` in the AI Atlas app. Labs are unlocked by the in-app Practice Pack, and the step-by-step instructions are in the app; this kit holds what you use on a PC: code under `files/`, every command in `commands.md` (in step order) and `artifact_evidence_template.md` (the structure of the evidence document). Paste the filled evidence document into the lab screen of the app to record the lab. Model weights and datasets are not included — download them from their original sources as the steps describe.

문의: nyrum@nyrumlabs.com · https://github.com/nyrumdev/aiatlas-labs
