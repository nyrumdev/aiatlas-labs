"""pick_lr.py — 학습률 탐색 결과에서 크기마다 '고르기용 검증 손실'이 가장 낮은 학습률을 골라 lr_choice.json 에 쓴다.

실행: python pick_lr.py
읽는 것: scaling_runs.csv 의 phase = search 줄 · 만드는 것: lr_choice.json · 화면에 크기별 표
"""
import csv
import json
import math
from collections import defaultdict
from pathlib import Path


def main():
    rows = [r for r in csv.DictReader(open("scaling_runs.csv", encoding="utf-8")) if r["phase"] == "search"]   # 같은 칸은 뒤 줄이 앞 줄을 덮는다
    by = defaultdict(dict)
    for r in rows:
        by[r["size"]][float(r["lr"])] = (float(r["val_select_loss"]), int(r["steps"]))
    choice = {}
    for size in sorted(by):
        tried = sorted(by[size])
        ok = {lr: v for lr, (v, _) in by[size].items() if math.isfinite(v)}
        if not ok:
            print(f"{size}: 시험한 학습률이 모두 발산 — 더 작은 값으로 다시 탐색한다")
            continue
        best = min(ok, key=ok.get)
        edge = len(tried) < 3 or best in (tried[0], tried[-1])   # 가장자리면 최선이 구간 밖에 있을 수 있다
        choice[size] = {"lr": best, "edge": edge, "tried": tried, "val_select_loss": ok[best], "steps": by[size][best][1],
                        "method": "크기마다 그 크기 20N 토큰의 1/4(최소 200걸음 · 20N 안)로 다시 찾음(고르기용 검증 조각)"}
        line = " · ".join(f"{lr:g}={by[size][lr][0]:.4f}" for lr in tried)
        print(f"{size}: {line} → {best:g}({by[size][best][1]:,}걸음)" + ("  ※ 가장자리 — 한 칸 더 넓혀 탐색한다" if edge else ""))
    Path("lr_choice.json").write_text(json.dumps(choice, ensure_ascii=False, indent=2), encoding="utf-8")
    print("저장: lr_choice.json")


if __name__ == "__main__":
    main()
