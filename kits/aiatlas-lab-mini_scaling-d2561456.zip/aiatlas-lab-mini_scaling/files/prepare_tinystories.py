"""prepare_tinystories.py — TinyStories 두 파일을 SHA-256 으로 확인하고, BPE 토크나이저 하나를 학습해, 이야기를 토큰 번호 파일로 바꾼다.

실행: python prepare_tinystories.py
읽는 것: data\\TinyStories-train.txt · data\\TinyStories-valid.txt
만드는 것: data\\tokenizer.json · data\\train.bin · data\\val_select.bin · data\\val_final.bin · data\\meta.json
"""
import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

DATASET_COMMIT = "f54c09fd23315a6f9c86f9dc80f725de7d8f9c64"   # roneneldan/TinyStories 저장소의 커밋(받을 때 주소에 넣은 값)
SHA256 = {   # 허브가 파일마다 적어 둔 SHA-256(대용량 파일의 내용 해시)
    "TinyStories-train.txt": "c5cf5e22ff13614e830afbe61a99fbcbe8bcb7dd72252b989fa1117a368d401f",
    "TinyStories-valid.txt": "94e431816c4cce81ff71e4408ff8d3bda9a42e8d2663986697c3954288cb38b4",
}
EOT = "<|endoftext|>"          # 이야기 사이 구분 줄 — 토큰 하나로 남겨 '이야기 끝'을 배우게 한다
VOCAB = 4096                   # 어휘 크기(이 실습이 정한 값 — 모든 실행이 같은 토크나이저를 쓴다)
TOK_TRAIN_STORIES = 200_000    # 토크나이저는 학습 파일 앞 20만 편으로만 배운다(이 실습이 정한 값)
CHUNK = 20_000                 # 한 번에 토큰으로 바꾸는 이야기 수


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def stories(path):
    """'<|endoftext|>' 한 줄로 나뉜 이야기를 하나씩 내놓는다 — 파일 전체를 메모리에 올리지 않는다."""
    buf = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.rstrip("\n") == EOT:
                text = "".join(buf).strip()
                if text:
                    yield text
                buf = []
            else:
                buf.append(line)
    text = "".join(buf).strip()
    if text:
        yield text


def train_tokenizer(train_path, out_path):
    tok = Tokenizer(models.BPE())
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(vocab_size=VOCAB, min_frequency=2, special_tokens=[EOT],
                                  initial_alphabet=pre_tokenizers.ByteLevel.alphabet(), show_progress=False)
    tok.train_from_iterator(itertools.islice(stories(train_path), TOK_TRAIN_STORIES), trainer=trainer)
    tok.save(str(out_path))
    return tok


def encode_to_bin(tok, story_iter, out_path):
    """이야기마다 '토큰들 + 끝 토큰'을 이어 붙여 uint16 번호 파일로 쓴다. (이야기 수, 토큰 수, 바이트 수)를 돌려준다."""
    eot = tok.token_to_id(EOT)
    n_st = n_tok = n_byte = 0
    with open(out_path, "wb") as f:
        while True:
            batch = list(itertools.islice(story_iter, CHUNK))
            if not batch:
                break
            for enc in tok.encode_batch_fast(batch):
                ids = np.array(enc.ids + [eot], dtype=np.uint16)
                ids.tofile(f)
                n_tok += len(ids)
            n_st += len(batch)
            n_byte += sum(len(s.encode("utf-8")) for s in batch)
    return n_st, n_tok, n_byte


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data")
    args = p.parse_args()
    d = Path(args.data)
    train_txt, valid_txt = d / "TinyStories-train.txt", d / "TinyStories-valid.txt"
    for path in (train_txt, valid_txt):
        got = sha256(path)
        if got != SHA256[path.name]:
            raise SystemExit(f"SHA-256 이 다르다: {path.name} — 기대 {SHA256[path.name]} · 파일 {got}. 다시 받는다")
        print(f"SHA-256 일치: {path.name}")

    t0 = time.perf_counter()
    tok = train_tokenizer(train_txt, d / "tokenizer.json")
    assert tok.get_vocab_size() <= 65536, "uint16 에 들어가지 않는다"
    print(f"토크나이저: 어휘 {tok.get_vocab_size():,} · 끝 토큰 번호 {tok.token_to_id(EOT)} · {time.perf_counter() - t0:.0f}초")

    meta = {"dataset": "roneneldan/TinyStories", "dataset_commit": DATASET_COMMIT,
            "files_sha256": SHA256, "vocab_size": tok.get_vocab_size(), "eot_id": tok.token_to_id(EOT),
            "tokenizer_sha256": sha256(d / "tokenizer.json"), "tokenizer_train_stories": TOK_TRAIN_STORIES,
            "dtype": "uint16", "splits": {}}
    n_st, n_tok, n_byte = encode_to_bin(tok, stories(train_txt), d / "train.bin")
    meta["splits"]["train"] = {"stories": n_st, "tokens": n_tok, "bytes": n_byte}
    # 검증 파일은 이야기 순서대로 반으로 나눈다 — 앞 반 = 학습률 고르기용 · 뒤 반 = 마지막 보고용
    valid = list(stories(valid_txt))
    half = len(valid) // 2
    for name, part in (("val_select", valid[:half]), ("val_final", valid[half:])):
        n_st, n_tok, n_byte = encode_to_bin(tok, iter(part), d / f"{name}.bin")
        meta["splits"][name] = {"stories": n_st, "tokens": n_tok, "bytes": n_byte}
    (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    for name, s in meta["splits"].items():
        print(f"{name}: 이야기 {s['stories']:,} · 토큰 {s['tokens']:,} · 바이트 {s['bytes']:,} · "
              f"토큰당 바이트 {s['bytes'] / s['tokens']:.2f}")
    print(f"걸린 시간 {time.perf_counter() - t0:.0f}초 · 저장: {d / 'meta.json'}")


if __name__ == "__main__":
    main()
