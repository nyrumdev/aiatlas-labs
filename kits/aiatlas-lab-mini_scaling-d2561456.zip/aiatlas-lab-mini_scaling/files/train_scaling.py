"""train_scaling.py — 크기 한 칸을 정해 둔 토큰 수만큼 '한 바퀴 안에서' 사전학습하고, 결과 한 줄을 scaling_runs.csv 에 더한다.

실행 예: python train_scaling.py --phase probe --size s3 --amp bf16      (시간·메모리만 잰다)
         python train_scaling.py --phase search --size s1 --lr 0.004      (학습률 탐색 — 사다리 길이의 1/4)
         python train_scaling.py --phase ladder --size s1 --seed 0        (사다리 — 토큰 = 파라미터 × 20)
         python train_scaling.py --phase iso --size s2 --budget_of s3     (등연산 — s3 사다리 칸과 같은 연산량)
         python train_scaling.py --phase iso --size s1 --budget_of s3 --lr 0.004   (선택 — 등연산 칸 하나의 학습률 민감도 확인)
만드는 것: runs\\<이름>\\config.json · history.json · result.json (+ ladder 는 samples.txt) · scaling_runs.csv 한 줄 · probe.csv 한 줄
"""
import argparse
import csv
import hashlib
import json
import math
import platform
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "char_gpt"))
from chargpt import CharGPT  # noqa: E402 — 앞 실습의 완성형(layernorm 단계)을 그대로 쓴다

SIZES = {   # 헤드 하나의 폭을 32 로 묶고 층 수와 폭을 함께 키운다 · 작은 것부터(이 실습이 정한 값)
    "s1": dict(n_layer=2, n_head=2, n_embd=64),
    "s1h": dict(n_layer=2, n_head=3, n_embd=96),     # 'h' = 등연산 전용 중간 크기(사다리에는 쓰지 않는다)
    "s2": dict(n_layer=3, n_head=4, n_embd=128),
    "s2h": dict(n_layer=3, n_head=5, n_embd=160),
    "s3": dict(n_layer=4, n_head=6, n_embd=192),
    "s3h": dict(n_layer=5, n_head=7, n_embd=224),
    "s4": dict(n_layer=6, n_head=8, n_embd=256),
    "s4h": dict(n_layer=7, n_head=10, n_embd=320),
    "s5": dict(n_layer=8, n_head=12, n_embd=384),
}
LADDER = ("s1", "s2", "s3", "s4", "s5")   # 크기 사다리 다섯 칸 — 등연산 예산도 이 칸들의 연산량으로만 둔다
BLOCK = 256          # 문맥 길이 — 모든 칸이 같다
BATCH = 64           # 한 걸음의 조각 수 — 한 걸음 = 64 × 256 = 16,384 토큰(모든 칸이 같다)
RATIO = 20           # 사다리 칸의 토큰 ÷ 파라미터
SEARCH_FRAC = 0.25   # 학습률 탐색은 사다리 길이의 1/4 로
LR_FLOOR = 0.1       # 코사인 감쇠의 끝 = 최고 학습률의 10%
MIN_STEPS = 200      # 이보다 짧은 칸은 돌리지 않는다
DATA_SEED = 0        # 데이터를 읽는 순서 — 모든 실행이 같다
EVAL_EVERY = 10      # 학습 중 평가 횟수(곡선용 · 학습률 고르기 조각의 앞 512창만)
CSV_COLS = ["run", "phase", "size", "seed", "lr", "lr_source", "lr_search_steps", "amp", "n_layer", "n_head", "n_embd",
            "p_body", "p_out", "p_emb", "n_params", "tokens", "steps", "warmup_steps", "tokens_per_param",
            "flops_6nd", "flops_6nd_body", "budget", "budget_gap_pct", "epoch_frac",
            "val_select_loss", "val_final_loss", "val_final_bpb", "last_drop", "late_drop_frac",
            "train_sec", "tokens_per_sec", "peak_mib", "tokenizer_sha256", "git_commit", "git_dirty"]


def git_commit():
    def run(*cmd):
        return subprocess.run(["git", *cmd], capture_output=True, text=True).stdout.strip()
    return run("rev-parse", "HEAD"), run("describe", "--always", "--dirty").endswith("-dirty")


def build(size, vocab, seed):
    torch.manual_seed(seed)
    c = SIZES[size]
    return CharGPT(vocab, "layernorm", c["n_layer"], c["n_head"], c["n_embd"], BLOCK, dropout=0.0)


def count(model):
    """비임베딩 파라미터 N = 몸통(블록·마지막 LayerNorm) + 출력층. 글자·자리 임베딩 표는 뺀다."""
    total = sum(p.numel() for p in model.parameters())
    emb = model.tok.weight.numel() + model.pos.weight.numel()
    out = sum(p.numel() for p in model.lm_head.parameters())
    return {"p_body": total - emb - out, "p_out": out, "p_emb": emb, "n_params": total - emb}


def size_params(size, vocab):
    return count(build(size, vocab, 0))["n_params"]


def lr_at(step, steps, warmup, lr):
    """워밍업 동안 선형으로 올리고, 그 뒤 이 실행의 마지막 걸음에서 LR_FLOOR × lr 에 닿도록 코사인으로 내린다."""
    if step < warmup:
        return lr * (step + 1) / warmup
    r = (step - warmup) / max(1, steps - warmup)
    return lr * (LR_FLOOR + (1 - LR_FLOOR) * 0.5 * (1 + math.cos(math.pi * r)))


def windows(data, idx, device):
    """겹치지 않는 창 번호들 → 입력 x 와 한 칸 민 정답 y. i 번째 창 = 토큰 [i·BLOCK, i·BLOCK + BLOCK]."""
    starts = np.asarray(idx, dtype=np.int64) * BLOCK
    block = torch.from_numpy(data[starts[:, None] + np.arange(BLOCK + 1)].astype(np.int64))
    block = block.to(device, non_blocking=True)
    return block[:, :-1].contiguous(), block[:, 1:].contiguous()   # chargpt 가 정답을 .view 로 펴므로 연속 메모리로


@torch.no_grad()
def evaluate(model, data, n_win, device, amp, limit=None):
    """정해 둔 검증 조각의 창을 앞에서부터 차례로 모두(또는 limit 개) 재어 토큰당 평균 손실을 돌려준다."""
    model.eval()
    n = n_win if limit is None else min(limit, n_win)
    tot, cnt = 0.0, 0
    for i in range(0, n, BATCH):
        x, y = windows(data, range(i, min(i + BATCH, n)), device)
        with torch.autocast("cuda", dtype=torch.bfloat16, enabled=amp):
            _, loss, _ = model(x, y)
        tot += loss.item() * x.shape[0]
        cnt += x.shape[0]
    model.train()
    return tot / cnt


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--phase", required=True, choices=["probe", "search", "ladder", "iso"])
    p.add_argument("--size", required=True, choices=list(SIZES))
    p.add_argument("--lr", type=float, default=None,
                   help="search 는 필수 · ladder 는 받지 않음 · iso 는 보통 lr_choice.json 에서(주면 민감도 확인 칸)")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--budget_of", choices=list(LADDER), default=None, help="iso: 이 크기 사다리 칸의 연산량을 예산으로")
    p.add_argument("--amp", default="bf16", choices=["bf16", "off"])
    p.add_argument("--probe_steps", type=int, default=30)
    p.add_argument("--data", default="data")
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    cuda = args.device == "cuda"
    if cuda and not torch.cuda.is_available():
        raise SystemExit("CUDA 를 쓸 수 없다 — 앞 실습의 env_report.json 부터 다시 본다")
    amp = args.amp == "bf16"
    if amp and not cuda:
        raise SystemExit("bf16 자동 혼합 정밀도는 이 스크립트에서 GPU 로만 쓴다 — --amp off 로 돌린다")
    if amp and not torch.cuda.is_bf16_supported(including_emulation=False):
        raise SystemExit("이 GPU 는 bfloat16 을 하드웨어로 지원하지 않는다 — --amp off 로 돌린다")

    d = Path(args.data)
    meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
    tok_sha = hashlib.sha256((d / "tokenizer.json").read_bytes()).hexdigest()
    if tok_sha != meta["tokenizer_sha256"]:
        raise SystemExit("tokenizer.json 이 번호 파일을 만들 때와 다르다 — prepare 를 다시 돌린다")
    vocab = meta["vocab_size"]
    train = np.memmap(d / "train.bin", dtype=np.uint16, mode="r")
    vsel = np.memmap(d / "val_select.bin", dtype=np.uint16, mode="r")
    vfin = np.memmap(d / "val_final.bin", dtype=np.uint16, mode="r")
    n_train, n_vsel, n_vfin = [(len(a) - 1) // BLOCK for a in (train, vsel, vfin)]

    # ----- 학습률: 탐색은 손으로 주고, 사다리·등연산은 pick_lr.py 가 고른 값을 읽는다
    if args.phase == "search" and args.lr is None:
        raise SystemExit("--lr 를 준다")
    if args.phase == "ladder" and args.lr is not None:
        raise SystemExit("사다리는 lr_choice.json 의 학습률만 쓴다 — --lr 를 빼고 다시 친다")
    if args.phase == "ladder" and args.size not in LADDER:
        raise SystemExit(f"{args.size} 는 등연산 전용 중간 크기다 — 사다리는 {', '.join(LADDER)} 만 돈다")
    lr, lr_source, lr_search_steps = args.lr, {"probe": "probe", "search": "search"}.get(args.phase, "manual"), ""
    if args.phase in ("ladder", "iso"):
        choices = json.loads(Path("lr_choice.json").read_text(encoding="utf-8"))
        if args.size not in choices:
            raise SystemExit(f"lr_choice.json 에 {args.size} 가 없다 — 그 크기의 search 를 돌리고 pick_lr.py 를 다시 돌린다")
        choice = choices[args.size]
        if choice["edge"]:
            raise SystemExit(f"{args.size} 의 최선 학습률이 탐색 구간의 가장자리다 — 한 칸 더 넓혀 탐색한 뒤 pick_lr.py 를 다시 돌린다")
        lr_search_steps = choice["steps"]                      # 그 학습률을 고른 탐색 실행의 걸음 수
        if lr is None:
            lr, lr_source = choice["lr"], "choice"
    if lr is None:
        lr = 1e-3                                              # probe 는 시간만 잰다 — 학습률은 결과에 쓰지 않는다

    model = build(args.size, vocab, args.seed).to(args.device)
    cnt = count(model)
    N = cnt["n_params"]
    tok_per_step = BATCH * BLOCK

    # ----- 이 칸의 토큰 수 D 와 걸음 수
    budget = None
    if args.phase == "probe":
        steps = args.probe_steps + 5
    else:
        if args.phase in ("ladder", "search"):
            target = RATIO * N * (SEARCH_FRAC if args.phase == "search" else 1.0)
        else:
            if args.budget_of is None:
                raise SystemExit("iso 는 --budget_of 를 준다")
            if args.budget_of == args.size:
                raise SystemExit(f"이 칸은 사다리 {args.size} 시드 0 실행과 같다 — fit_report.py 가 그 결과를 쓴다")
            nb = size_params(args.budget_of, vocab)
            budget = 6 * nb * (RATIO * nb)                   # 그 크기 사다리 칸의 6ND
            target = budget / (6 * N)
        steps = int(target // tok_per_step)
        if args.phase == "search":                               # 가장 작은 칸도 탐색이 너무 짧아지지 않게
            steps = min(max(steps, MIN_STEPS), int(RATIO * N // tok_per_step))
        if steps < MIN_STEPS:
            raise SystemExit(f"범위 밖: {steps}걸음 < {MIN_STEPS} — 이 칸은 돌리지 않고 표에 '범위 밖'으로 적는다")
        if steps * BATCH > n_train:
            raise SystemExit(f"범위 밖: 토큰 {steps * tok_per_step:,} 이 한 바퀴({n_train * BLOCK:,})를 넘는다 — 같은 글을 다시 보게 되므로 돌리지 않는다")
    D = steps * tok_per_step
    warmup = max(1, math.ceil(N / tok_per_step))              # 워밍업 토큰 수 ≈ 파라미터 수 N
    if args.phase != "probe" and warmup > steps // 2:
        raise SystemExit(f"범위 밖: 워밍업 {warmup}걸음이 전체 {steps}걸음의 절반을 넘는다 — 이 칸은 돌리지 않고 표에 적는다")

    tag = {"probe": f"probe_{args.amp}", "search": f"search_lr{lr:g}", "ladder": f"ladder_s{args.seed}",
           "iso": f"iso_{args.budget_of}_s{args.seed}" + (f"_lr{lr:g}" if lr_source == "manual" else "")}[args.phase]
    name = f"{args.size}_{tag}"
    run_dir = Path("runs") / name
    if args.phase != "probe" and (run_dir / "result.json").exists():
        raise SystemExit(f"{run_dir} 에 결과가 이미 있다 — 같은 칸을 두 번 적지 않는다(다시 돌리려면 그 폴더를 지운다)")
    run_dir.mkdir(parents=True, exist_ok=True)

    decay = [q for q in model.parameters() if q.dim() >= 2]
    no_decay = [q for q in model.parameters() if q.dim() < 2]
    opt = torch.optim.AdamW([{"params": decay, "weight_decay": 0.1}, {"params": no_decay, "weight_decay": 0.0}],
                            lr=lr, betas=(0.9, 0.99))
    commit, dirty = git_commit()
    config = {**vars(args), **SIZES[args.size], **cnt, "lr": lr, "lr_source": lr_source,
              "lr_search_steps": lr_search_steps, "block": BLOCK, "batch": BATCH,
              "tokens": D, "steps": steps, "warmup_steps": warmup, "lr_floor": LR_FLOOR, "betas": [0.9, 0.99],
              "weight_decay": 0.1, "grad_clip": 1.0, "data_seed": DATA_SEED, "budget": budget,
              "train_tokens_available": n_train * BLOCK, "tokenizer_sha256": tok_sha,
              "torch": str(torch.__version__), "python": platform.python_version(),
              "device_name": torch.cuda.get_device_name(0) if cuda else platform.processor(),
              "git_commit": commit, "git_dirty": dirty}
    (run_dir / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{name} · N {N:,}(몸통 {cnt['p_body']:,} + 출력층 {cnt['p_out']:,}) · 임베딩 {cnt['p_emb']:,} · "
          f"토큰 {D:,}({steps:,}걸음 · 워밍업 {warmup}) · 학습률 {lr:g} · {config['device_name']}")

    order = np.random.default_rng(DATA_SEED).permutation(n_train)   # 겹치지 않는 창을 섞은 순서 — 앞에서부터 쓴다
    history = []
    eval_at = set() if args.phase == "probe" else {round(steps * k / EVAL_EVERY) for k in range(1, EVAL_EVERY + 1)}
    if cuda:
        torch.cuda.reset_peak_memory_stats()
    model.train()
    train_sec, timed, diverged = 0.0, 0, False
    for step in range(steps):
        if cuda:
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        for g in opt.param_groups:
            g["lr"] = lr_at(step, steps, warmup, lr)
        x, y = windows(train, order[step * BATCH:(step + 1) * BATCH], args.device)
        with torch.autocast("cuda", dtype=torch.bfloat16, enabled=amp):
            _, loss, _ = model(x, y)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if cuda:
            torch.cuda.synchronize()
        if args.phase != "probe" or step >= 5:                # probe 는 앞 5걸음(준비 시간)을 빼고 잰다
            train_sec += time.perf_counter() - t0
            timed += 1
        if not math.isfinite(loss.item()):
            print(f"걸음 {step} 에서 손실이 {loss.item()} — 발산. 검증 손실을 inf 로 적는다")
            diverged = True
            break
        if step + 1 in eval_at:
            v = evaluate(model, vsel, n_vsel, args.device, amp, limit=512)
            history.append({"step": step + 1, "tokens": (step + 1) * tok_per_step, "train_batch_loss": loss.item(),
                            "val_select_512": v, "lr": lr_at(step, steps, warmup, lr)})
            print(f"걸음 {step + 1:6d}/{steps} | 묶음 손실 {loss.item():.4f} | 검증(고르기용 512창) {v:.4f}")
    peak = torch.cuda.max_memory_allocated() / 2**20 if cuda else None
    tps = timed * tok_per_step / train_sec if train_sec > 0 else float("nan")

    if args.phase == "probe":
        row = {"size": args.size, "amp": args.amp, "n_params": N, "tokens_per_sec": round(tps),
               "peak_mib": round(peak) if peak else "", "device": config["device_name"]}
        new = not Path("probe.csv").exists()
        with open("probe.csv", "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(row))
            if new:
                w.writeheader()
            w.writerow(row)
        print(f"probe: {args.size} · {args.amp} · 초당 토큰 {tps:,.0f} · 최대 GPU 메모리 {peak:.0f} MiB" if peak else
              f"probe: {args.size} · {args.amp} · 초당 토큰 {tps:,.0f}")
        return

    if diverged:
        v_sel = v_fin = float("inf")
    else:
        v_sel = evaluate(model, vsel, n_vsel, args.device, amp)
        v_fin = evaluate(model, vfin, n_vfin, args.device, amp)
    vf = meta["splits"]["val_final"]
    bpb = v_fin * vf["tokens"] / vf["bytes"] / math.log(2)        # 토큰당 nats → 바이트당 비트(끝 토큰 몫 포함 · 어림)
    # 끝까지 감쇠하는 일정에서는 마지막 구간에도 손실이 대개 조금 내려간다 — 내려갔는지가 아니라 '얼마나'를 남긴다
    curve = [h["val_select_512"] for h in history]
    last_drop = curve[-2] - curve[-1] if len(curve) >= 2 else float("nan")          # 90% → 100% 지점의 하락
    half_drop = curve[-1 - len(curve) // 2] - curve[-1] if len(curve) >= 4 else float("nan")   # 50% → 100% 지점의 하락
    late_frac = last_drop / half_drop if half_drop > 0 else float("nan")             # 후반 하락 가운데 마지막 10% 몫
    result = {"val_select_loss": v_sel, "val_final_loss": v_fin, "val_final_bpb": bpb,
              "last_drop": last_drop, "late_drop_frac": late_frac,
              "train_sec": train_sec, "tokens_per_sec": tps, "peak_mib": peak if peak is not None else ""}
    (run_dir / "history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    if args.phase == "ladder" and not diverged:                    # 눈으로 볼 표본 — 끝 토큰에서 시작
        from tokenizers import Tokenizer
        tk = Tokenizer.from_file(str(d / "tokenizer.json"))
        model.eval()
        gen = torch.Generator(device=args.device).manual_seed(args.seed)
        with torch.autocast("cuda", dtype=torch.bfloat16, enabled=amp):
            out = model.generate(torch.tensor([[meta["eot_id"]]], device=args.device), 200, temperature=1.0,
                                 generator=gen)
        (run_dir / "samples.txt").write_text(tk.decode(out[0].tolist()[1:], skip_special_tokens=False),
                                             encoding="utf-8")

    row = {"run": name, "phase": args.phase, "size": args.size, "seed": args.seed, "lr": lr, "lr_source": lr_source,
           "lr_search_steps": lr_search_steps, "amp": args.amp,
           **SIZES[args.size], **cnt, "tokens": D, "steps": steps, "warmup_steps": warmup,
           "tokens_per_param": D / N, "flops_6nd": 6 * N * D, "flops_6nd_body": 6 * cnt["p_body"] * D,
           "budget": budget if budget else "", "budget_gap_pct": 100 * (6 * N * D - budget) / budget if budget else "",
           "epoch_frac": D / (n_train * BLOCK), **result, "tokenizer_sha256": tok_sha,
           "git_commit": commit, "git_dirty": dirty}
    new = not Path("scaling_runs.csv").exists()
    with open("scaling_runs.csv", "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLS)
        if new:
            w.writeheader()
        w.writerow(row)
    print(f"끝: 검증(고르기용) {v_sel:.4f} · 검증(보고용) {v_fin:.4f} · bpb {bpb:.4f} · "
          f"{train_sec / 60:.1f}분 · 초당 토큰 {tps:,.0f}" + (f" · 최대 GPU 메모리 {peak:.0f} MiB" if peak else ""))


if __name__ == "__main__":
    main()
