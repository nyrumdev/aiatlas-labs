"""plan.py — 돌리기 전에 모든 칸의 토큰 수·걸음 수·연산량과 어림 시간을 계산하고, 한 바퀴를 넘거나 너무 짧은 칸을 미리 가린다.

실행: python plan.py  (probe.csv 가 있으면 그 초당 토큰으로 시간을 어림한다)
만드는 것: plan.md
"""
import csv
import json
import math
from pathlib import Path

import numpy as np

from train_scaling import BATCH, BLOCK, LADDER, MIN_STEPS, RATIO, SEARCH_FRAC, SIZES, size_params

SEEDS = (0, 1)
N_LR = 4                         # 크기마다 시험할 학습률 수
BUDGETS = ("s2", "s3", "s4")     # 등연산 예산 = 이 크기들 사다리 칸의 연산량
MIN_ISO_POINTS = 5               # 예산마다 범위 안에 있어야 할 크기 수(이 실습이 정한 값)


def main():
    meta = json.loads(Path("data/meta.json").read_text(encoding="utf-8"))
    vocab = meta["vocab_size"]
    n_train = (len(np.memmap("data/train.bin", dtype=np.uint16, mode="r")) - 1) // BLOCK
    tps = {}
    if Path("probe.csv").exists():
        for r in csv.DictReader(open("probe.csv", encoding="utf-8")):
            if r["amp"] == "bf16" or r["size"] not in tps:   # bf16 줄을 우선 · bf16 줄이 없는 크기는 off 줄로 어림
                tps[r["size"]] = float(r["tokens_per_sec"])
    N = {s: size_params(s, vocab) for s in SIZES}
    step_tok = BATCH * BLOCK

    def cell(size, tokens):
        steps = int(tokens // step_tok)
        if steps < MIN_STEPS:
            return steps, "범위 밖(짧음)"
        if steps * BATCH > n_train:
            return steps, "범위 밖(한 바퀴 넘음)"
        if math.ceil(N[size] / step_tok) > steps // 2:
            return steps, "범위 밖(워밍업이 절반 넘음)"
        return steps, ""

    L = ["# 실행 계획", "", f"학습 조각 한 바퀴 = {n_train * BLOCK:,} 토큰 · 한 걸음 = {step_tok:,} 토큰", "",
         "| 단계 | 크기 | N | 토큰 D | D/N | 걸음 | 6ND | 횟수 | 어림 시간(분) | 비고 |", "|---|---|---|---|---|---|---|---|---|---|"]
    total_min = 0.0

    def add(phase, size, tokens, times, note_extra=""):
        nonlocal total_min
        steps, note = cell(size, tokens)
        D = steps * step_tok
        est = ""
        if not note and size in tps:
            m = D / tps[size] / 60 * times
            total_min += m
            est = f"{m:.0f}"
        L.append(f"| {phase} | {size} | {N[size]:,} | {D:,} | {D / N[size]:.1f} | {steps:,} | {6 * N[size] * D:.2e} | "
                 f"{times} | {est} | {note or note_extra} |")
        return not note

    for s in SIZES:   # train_scaling.py 와 같게 — 탐색도 MIN_STEPS 걸음보다 짧게 하지 않는다(그 크기 20N 안에서)
        add("search", s, min(max(RATIO * N[s] * SEARCH_FRAC, MIN_STEPS * step_tok), RATIO * N[s]), N_LR)
    for s in LADDER:
        add("ladder", s, RATIO * N[s], len(SEEDS))
    counts = []
    for b in BUDGETS:
        C = 6 * N[b] * RATIO * N[b]
        inside = []
        for s in SIZES:
            if s == b:   # 주인 칸도 사다리 칸이 범위 안일 때만 점으로 센다
                _, note_b = cell(b, RATIO * N[b])
                L.append(f"| iso({b}) | {s} | {N[s]:,} | - | {RATIO} | - | {C:.2e} | 0 | - | "
                         + ("사다리 시드 0 칸을 그대로 씀" if not note_b else "사다리 칸이 " + note_b) + " |")
                if not note_b:
                    inside.append(s)
            elif add(f"iso({b})", s, C / (6 * N[s]), 1):
                inside.append(s)
        gap = max((N[y] / N[x] for x, y in zip(inside, inside[1:])), default=float("nan"))
        gap_txt = f"{gap:.2f}배(D/N 으로는 {gap ** 2:.1f}배)" if len(inside) >= 2 else "-(점이 둘 미만)"
        verdict = "" if len(inside) >= MIN_ISO_POINTS else f" · 점 부족({MIN_ISO_POINTS} 미만)"
        counts.append(f"- 예산 {b}: 범위 안 크기 {len(inside)}개({', '.join(inside)}) · 이웃 크기의 N 비 최대 {gap_txt}{verdict}")
    L += ["", "## 등연산 예산마다 범위 안 점", ""] + counts
    L += ["", f"어림 합계: {total_min / 60:.1f}시간(probe 가 없는 크기·범위 밖 칸·평가 시간은 빠짐 · 탐색은 학습률 {N_LR}개 기준 — 넓히면 한 칸에 1회씩 더)"]
    Path("plan.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))


if __name__ == "__main__":
    main()
