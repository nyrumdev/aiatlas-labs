"""fit_report.py — scaling_runs.csv 로 ① 통제 점검 ② 맨 윗칸을 뺀 거듭제곱 직선과 그 칸의 예측 검증 ③ 예산별 U자 바닥을 계산하고 그림을 그린다.

실행: python fit_report.py
만드는 것: fit_summary.md · scaling_fit.png
"""
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import NullFormatter
from numpy.polynomial import Polynomial

from train_scaling import LADDER, RATIO, SIZES

TOP = LADDER[-1]   # 맨 윗칸 — 직선 맞추기에서 뺀다
MIN_ISO_POINTS = 5


def load():
    """실행 이름마다 마지막 줄만 쓴다 — 폴더를 지우고 다시 돌린 칸이 두 번 세이지 않게."""
    rows = list({r["run"]: r for r in csv.DictReader(open("scaling_runs.csv", encoding="utf-8"))}.values())
    for r in rows:
        for k in ("n_params", "p_body", "p_emb", "tokens", "steps", "flops_6nd", "val_select_loss", "val_final_loss",
                  "val_final_bpb", "last_drop", "late_drop_frac", "tokens_per_param", "epoch_frac", "lr", "train_sec"):
            r[k] = float(r[k])
        r["seed"] = int(r["seed"])
    return rows


def controls(rows):
    """체크리스트의 '지켰나' 칸에 붙일 증거 — 표에서 바로 확인되는 통제만 기계로 본다."""
    out = []
    shas = {r["tokenizer_sha256"] for r in rows}
    out.append(f"- 같은 토크나이저: {'예' if len(shas) == 1 else '아니오'}(SHA-256 {len(shas)}종)")
    out.append(f"- 한 바퀴 안: {'예' if all(r['epoch_frac'] <= 1 for r in rows) else '아니오'}"
               f"(가장 큰 epoch_frac {max(r['epoch_frac'] for r in rows):.3f})")
    commits = sorted({r["git_commit"] for r in rows})
    out.append(f"- 같은 코드: {'예' if len(commits) == 1 else '아니오'}(커밋 {len(commits)}종: "
               f"{', '.join(c[:12] for c in commits)}) · 커밋 안 한 수정으로 돈 실행 {sum(r['git_dirty'] == 'True' for r in rows)}개")
    amps = {r["amp"] for r in rows}
    out.append(f"- 정밀도 설정: {', '.join(sorted(amps))}")
    choice = json.loads(Path("lr_choice.json").read_text(encoding="utf-8")) if Path("lr_choice.json").exists() else {}
    bad = [r["run"] for r in rows if r["phase"] in ("ladder", "iso") and r["lr_source"] != "manual" and r["size"] in choice
           and abs(r["lr"] - choice[r["size"]]["lr"]) > 1e-12]
    manual = [r["run"] for r in rows if r["lr_source"] == "manual"]
    out.append(f"- 사다리·등연산이 크기별로 고른 학습률을 씀: {'예' if not bad else '아니오 — ' + ', '.join(bad)}"
               f" · 민감도 확인 칸(학습률을 손으로 준 칸 · 맞춤에서 뺌) {len(manual)}개")
    gaps = [abs(float(r["budget_gap_pct"])) for r in rows if r["phase"] == "iso" and r["budget_gap_pct"]]
    if gaps:
        out.append(f"- 등연산 칸의 예산 오차: 가장 큰 것 {max(gaps):.2f}%(걸음 단위로 자른 몫)")
    return out


def main():
    rows = [r for r in load() if math.isfinite(r["val_final_loss"])]
    L = ["# 미니 스케일링 결과", "", "## 0. 통제 점검(기계로 본 것)", ""] + controls(rows)

    # ---------- 1. 사다리: 시드 평균과 흩어짐
    lad = defaultdict(list)
    for r in rows:
        if r["phase"] == "ladder":
            lad[r["size"]].append(r)
    sizes = [s for s in LADDER if s in lad]
    L += ["", f"## 1. 사다리(토큰 = 파라미터 × {RATIO} · 보고용 검증 조각)", "",
          "| 크기 | N(비임베딩·출력층 포함) | 몸통만 | 임베딩 포함 총수 | D | 6ND | 학습률 | 시드별 손실 | 평균 | 흩어짐(최대-최소) "
          "| bpb 평균 | 마지막 10% 하락(후반 하락 중 몫) |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    mean, spread, N, C = {}, {}, {}, {}
    for s in sizes:
        rs = sorted(lad[s], key=lambda r: r["seed"])
        v = [r["val_final_loss"] for r in rs]
        mean[s], spread[s] = float(np.mean(v)), max(v) - min(v)
        N[s], C[s] = rs[0]["n_params"], rs[0]["flops_6nd"]
        L.append(f"| {s} | {N[s]:,.0f} | {rs[0]['p_body']:,.0f} | {N[s] + rs[0]['p_emb']:,.0f} | {rs[0]['tokens']:,.0f} | "
                 f"{C[s]:.2e} | {rs[0]['lr']:g} | " + " · ".join(f"{x:.4f}" for x in v) + f" | {mean[s]:.4f} | "
                 f"{spread[s]:.4f} | {np.mean([r['val_final_bpb'] for r in rs]):.4f} | "
                 + " · ".join(f"{r['last_drop']:.4f}({r['late_drop_frac']:.2f})" for r in rs) + " |")

    # ---------- 2. 맨 윗칸을 빼고 직선 맞추기 → 맨 윗칸 예측
    fit_sizes = [s for s in sizes if s != TOP]
    pred = None
    if len(fit_sizes) >= 3 and TOP in mean:
        x = np.log([N[s] for s in fit_sizes])
        y = np.log([mean[s] for s in fit_sizes])
        c0, c1 = Polynomial.fit(x, y, 1).convert().coef          # log L = c0 + c1 · log N
        pred = math.exp(c0 + c1 * math.log(N[TOP]))
        err = mean[TOP] - pred
        xc = np.log([C[s] for s in fit_sizes])
        k0, k1 = Polynomial.fit(xc, y, 1).convert().coef
        prev = fit_sizes[-1]
        step_gap = mean[prev] - mean[TOP]
        if abs(err) <= spread[TOP]:
            verdict = "시드 흩어짐 안 — 한 칸 바깥을 맞혔다(시드 둘로 잰 흩어짐이라 거친 잣대)"
        elif abs(err) >= step_gap / 2:
            verdict = "칸 간격의 절반 이상 — 아직 바깥으로 연장할 자격이 없다"
        else:
            verdict = "그 사이 — 유보(시드를 더 돌려 흩어짐을 다시 잰 뒤 판정)"
        sign = "실제가 예측보다 높다(큰 칸에서 곡선이 눕는 쪽)" if err > 0 else "실제가 예측보다 낮다"
        L += ["", f"## 2. 맨 윗칸({TOP})을 뺀 직선과 예측 검증", "",
              f"- N 에 대해: log L = {c0:.4f} + ({c1:.4f}) · log N → 기울기 {c1:.4f}(= −알파)",
              f"- 6ND 에 대해: log L = {k0:.4f} + ({k1:.4f}) · log C",
              f"- {TOP} 예측 {pred:.4f} · 실제 평균 {mean[TOP]:.4f} · 차이 {err:+.4f}({100 * err / pred:+.2f}%) · {sign}",
              f"- 견줄 잣대: {TOP} 시드 흩어짐 {spread[TOP]:.4f} · 바로 아래 칸({prev})과의 차이 {step_gap:.4f}",
              f"- 판정: {verdict}"]

    # ---------- 3. 등연산: 예산마다 U자와 바닥
    iso = defaultdict(dict)
    probe_lr = []
    for r in rows:
        if r["phase"] == "iso" and r["seed"] == 0:
            b = r["run"].split("_iso_")[1].split("_")[0]
            if r["lr_source"] == "manual":
                probe_lr.append((b, r))                            # 학습률 민감도 확인 칸 — 맞춤에 넣지 않는다
            else:
                iso[b][r["size"]] = r
    for b in list(iso):
        for r in lad.get(b, []):
            if r["seed"] == 0:
                iso[b][b] = r                                      # 예산의 주인 칸 = 사다리 시드 0
    L += ["", "## 3. 등연산 탐색(예산마다 크기를 훑음 · 시드 0)", "",
          "| 예산(=사다리 칸) | 6ND | 크기별 손실(D/N · 칸 걸음 ÷ 탐색 걸음) | 범위 안 점 | 이웃 N 비 최대 | 측정 최저(D/N · 임베딩 포함 D/N) "
          "| 포물선 바닥 N* | D*/N* | 판정 |", "|---|---|---|---|---|---|---|---|---|"]
    fits = {}
    for b in sorted(iso, key=lambda k: list(SIZES).index(k)):
        if b not in N:
            L.append(f"| {b} | - | 사다리 {b} 칸이 아직 없다 | - | - | - | - | - | 사다리를 먼저 돌린다 |")
            continue
        cells = sorted(iso[b].values(), key=lambda r: r["n_params"])
        budget = 6 * N[b] * RATIO * N[b]
        txt = " · ".join(f"{r['size']} {r['val_final_loss']:.4f}({r['tokens_per_param']:.0f} · "
                         f"{r['steps'] / float(r['lr_search_steps']):.1f}배)" if r["lr_search_steps"] else
                         f"{r['size']} {r['val_final_loss']:.4f}({r['tokens_per_param']:.0f})" for r in cells)
        gap = max((y["n_params"] / x["n_params"] for x, y in zip(cells, cells[1:])), default=float("nan"))
        best = min(cells, key=lambda r: r["val_final_loss"])
        best_txt = f"{best['size']}({best['tokens_per_param']:.1f} · {best['tokens'] / (best['n_params'] + best['p_emb']):.1f})"
        verdict, nstar, ratio = "점이 셋 미만", "-", "-"
        if len(cells) >= 3:
            x = np.log([r["n_params"] for r in cells])
            y = np.array([r["val_final_loss"] for r in cells])
            q0, q1, q2 = Polynomial.fit(x, y, 2).convert().coef    # L = q0 + q1·logN + q2·logN²
            if q2 > 0 and x.min() <= -q1 / (2 * q2) <= x.max():
                ns = math.exp(-q1 / (2 * q2))                       # 포물선의 꼭짓점 = 바닥
                ds = budget / (6 * ns)
                nstar, ratio, verdict = f"{ns:,.0f}", f"{ds / ns:.1f}", "바닥이 훑은 범위 안"
                fits[b] = (q0, q1, q2, ns)
            else:
                verdict = "바닥이 범위 밖 — 크기를 넓혀 다시 훑는다"
            if len(cells) < MIN_ISO_POINTS:
                verdict += f" · 점 {len(cells)}개(보간에 가까움)"
        L.append(f"| {b} | {budget:.2e} | {txt} | {len(cells)} | {gap:.2f} | {best_txt} | {nstar} | {ratio} | {verdict} |")
    if probe_lr:
        L += ["", "### 3-1. 학습률 민감도 확인(선택 · 맞춤에 넣지 않음)", ""]
        for b, r in probe_lr:
            base = iso.get(b, {}).get(r["size"])
            ref = f" · 고른 학습률 {base['lr']:g} 의 손실 {base['val_final_loss']:.4f}" if base else ""
            L.append(f"- 예산 {b} · {r['size']} · 학습률 {r['lr']:g} → 손실 {r['val_final_loss']:.4f}{ref}")

    # ---------- 4. bf16 켬/끔
    if Path("probe.csv").exists():
        L += ["", "## 4. 정밀도별 처리량·메모리(probe)", "", "| 크기 | 정밀도 | 초당 토큰 | 최대 GPU 메모리(MiB) |", "|---|---|---|---|"]
        for r in csv.DictReader(open("probe.csv", encoding="utf-8")):
            L.append(f"| {r['size']} | {r['amp']} | {float(r['tokens_per_sec']):,.0f} | {r['peak_mib']} |")
    Path("fit_summary.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))

    # ---------- 그림: 왼쪽 = 사다리 로그-로그 · 오른쪽 = 등연산 U자
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12.5, 4.6))
    for s in sizes:
        xs = [N[s]] * len(lad[s])
        a1.scatter(xs, [r["val_final_loss"] for r in lad[s]], color="tab:red" if s == TOP else "tab:blue",
                   zorder=3, label=None)
    if pred is not None:
        grid = np.geomspace(min(N.values()) * 0.8, N[TOP] * 1.25, 50)
        a1.plot(grid, np.exp(c0 + c1 * np.log(grid)), "k--", lw=1, label=f"fit without {TOP} (slope {c1:.3f})")
        a1.scatter([N[TOP]], [pred], marker="x", s=80, color="k", zorder=4, label=f"predicted {TOP}")
    a1.scatter([], [], color="tab:blue", label="ladder runs (fit)")
    a1.scatter([], [], color="tab:red", label=f"{TOP} (held out)")
    a1.set_xscale("log")
    a1.set_yscale("log")
    a1.xaxis.set_minor_formatter(NullFormatter())               # 가로축 작은 눈금 글자가 서로 겹치지 않게
    a1.set_xlabel("non-embedding params N (incl. output layer)")
    a1.set_ylabel("val loss (nats/token)")
    a1.set_title(f"ladder: D = {RATIO} N")
    a1.legend(fontsize=8)
    for i, (b, color) in enumerate(zip(sorted(iso, key=lambda k: list(SIZES).index(k)),
                                       ("tab:green", "tab:orange", "tab:purple", "tab:gray"))):
        if b not in N:
            continue
        cells = sorted(iso[b].values(), key=lambda r: r["n_params"])
        a2.plot([r["n_params"] for r in cells], [r["val_final_loss"] for r in cells], "o-", color=color,
                label=f"budget = {b} ladder (C = {6 * N[b] * RATIO * N[b]:.1e})")
        if b in fits:
            q0, q1, q2, ns = fits[b]
            g = np.geomspace(cells[0]["n_params"], cells[-1]["n_params"], 60)
            a2.plot(g, q0 + q1 * np.log(g) + q2 * np.log(g) ** 2, ":", color=color)
            a2.axvline(ns, color=color, lw=0.8, ls="--")
            a2.annotate(f"N* {ns:.2g}", xy=(ns, 1), xycoords=("data", "axes fraction"), xytext=(3, -12 * (i + 1)),
                        textcoords="offset points", color=color, fontsize=8,
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.85))   # 바닥의 크기를 글자로 — 축 눈금만으로는 읽기 어렵다
    a2.set_xscale("log")
    a2.xaxis.set_minor_formatter(NullFormatter())
    a2.set_xticks([r["n_params"] for b in iso if b in N for r in iso[b].values()], minor=True)
    a2.set_xlabel("non-embedding params N (incl. output layer) — small ticks = sizes run")
    a2.set_ylabel("val loss (nats/token)")
    a2.set_title("isoFLOP: fixed 6ND, vary N")
    if a2.get_legend_handles_labels()[0]:                      # 등연산 줄이 아직 없으면 범례를 그리지 않는다
        a2.legend(fontsize=8, loc="upper left", bbox_to_anchor=(1.02, 1))   # 범례는 축 바깥 오른쪽 — 점·곡선·N* 글자를 가리지 않게
    fig.savefig("scaling_fit.png", dpi=120, bbox_inches="tight")
    print("저장: fit_summary.md · scaling_fit.png")


if __name__ == "__main__":
    main()
