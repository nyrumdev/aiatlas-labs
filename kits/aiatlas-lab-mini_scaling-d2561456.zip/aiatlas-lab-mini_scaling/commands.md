# 작은 GPT 사전학습으로 미니 스케일링 사다리 그리기 — 명령·코드 모음

실습 id: `lab.c.lab.mini_scaling`

앱 실습 화면의 절차와 같은 차례입니다. 파일로 저장할 코드는 `files/` 폴더에 이미 들어 있어 여기에는 이름만 적었습니다. 명령은 키트를 푼 폴더가 아니라 절차가 정한 작업 폴더에서 칩니다.

## 1. 작업대

```powershell
cd C:\work\ai-lab
.\.venv\Scripts\Activate.ps1
python -m pip install tokenizers==0.23.3
python -c "import tokenizers, torch; print(tokenizers.__version__, torch.__version__, torch.cuda.is_available())"
Test-Path char_gpt\chargpt.py
mkdir mini_scaling
cd mini_scaling
mkdir data
```

## 2. 통제 체크리스트 먼저

- `files/control_checklist.md` — 키트에 들어 있음 (markdown)

## 3. 데이터 받기

```powershell
curl.exe -L -o data\TinyStories-train.txt https://huggingface.co/datasets/roneneldan/TinyStories/resolve/f54c09fd23315a6f9c86f9dc80f725de7d8f9c64/TinyStories-train.txt
curl.exe -L -o data\TinyStories-valid.txt https://huggingface.co/datasets/roneneldan/TinyStories/resolve/f54c09fd23315a6f9c86f9dc80f725de7d8f9c64/TinyStories-valid.txt
```

## 4. 토크나이저와 토큰 번호

- `files/prepare_tinystories.py` — 키트에 들어 있음 (python)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git status --short` — train 줄의 토큰 수가 이 실습의 '한 바퀴'다 — 어떤 칸도 이 수보다 많은 토큰을 쓰지 않는다. 이어서 `git status --short` 를 쳐서 data 폴더의 파일이 목록에 보이지 않는지 확인한다(S763).

## 5. 학습 스크립트

- `files/train_scaling.py` — 키트에 들어 있음 (python)

- `files/pick_lr.py` — 키트에 들어 있음 (python)

- `files/plan.py` — 키트에 들어 있음 (python)

- `files/fit_report.py` — 키트에 들어 있음 (python)

```powershell
cd C:\work\ai-lab
git add .
git commit -m "미니 스케일링 실습 — 통제 체크리스트와 데이터·학습·맞춤 코드"
git rev-parse HEAD
cd mini_scaling
```

## 6. 시간 먼저

```powershell
foreach ($s in "s1","s1h","s2","s2h","s3","s3h","s4","s4h","s5") { foreach ($a in "bf16","off") { python train_scaling.py --phase probe --size $s --amp $a } }
python plan.py
```

## 7. 학습률 탐색

```powershell
foreach ($s in "s1","s1h","s2","s2h","s3","s3h","s4","s4h","s5") { foreach ($lr in 0.002,0.004,0.008,0.016) { python train_scaling.py --phase search --size $s --lr $lr } }
python pick_lr.py
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python train_scaling.py --phase search --size s1 --lr 0.032` — 예를 들어 s1 의 최선이 0.016 이면 `python train_scaling.py --phase search --size s1 --lr 0.032` 를 친다.

## 8. 사다리

```powershell
foreach ($s in "s1","s2","s3","s4","s5") { foreach ($seed in 0,1) { python train_scaling.py --phase ladder --size $s --seed $seed } }
```

## 9. 등연산 탐색

```powershell
foreach ($b in "s2","s3","s4") { foreach ($s in "s1","s1h","s2","s2h","s3","s3h","s4","s4h","s5") { python train_scaling.py --phase iso --size $s --budget_of $b } }
```

```powershell
python train_scaling.py --phase iso --size s1 --budget_of s3 --lr 0.004
python train_scaling.py --phase iso --size s1 --budget_of s3 --lr 0.016
```

## 10. 맞추기·그리기

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `python fit_report.py` — 맞추기·그리기 — `python fit_report.py` 를 친다.
- `git log --oneline -- control_checklist.md` — 찍힌 커밋이 control_checklist.md 를 처음 넣은 커밋(`git log --oneline -- control_checklist.md` 의 맨 아래 줄)과 같은지도 본다.
- `python train_scaling.py --phase ladder --size s4 --seed 2` — 그러니 '유보'가 나오거나 판정이 경계에 걸리면 s4·s5 에 시드 2 를 하나 더 돌려(`python train_scaling.py --phase ladder --size s4 --seed 2` 와 …
- `python train_scaling.py --phase ladder --size s5 --seed 2` — … 시드 2 를 하나 더 돌려(`python train_scaling.py --phase ladder --size s4 --seed 2` 와 `python train_scaling.py --phase ladder --size s5 --seed 2`) 흩어짐을 다시 잰 뒤 판정해도 된다.

## 11. 보고서와 커밋

```powershell
cd C:\work\ai-lab
python -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
```

```powershell
git add mini_scaling\mini_scaling_report.md
git commit -m "미니 스케일링 실습 보고서 — 결과 커밋 해시"
git status
```

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git add .` — 그 뒤 `git add .` 와 `git commit -m "미니 스케일링 실습 — 결과 표·그림·보고서"` 를 친다.
- `git commit -m "미니 스케일링 실습 — 결과 표·그림·보고서"` — 그 뒤 `git add .` 와 `git commit -m "미니 스케일링 실습 — 결과 표·그림·보고서"` 를 친다.
- `git rev-parse HEAD` — `git rev-parse HEAD` 의 40자리를 '결과 커밋'으로 적는다.

## 12. (선택) nanochat 과 견주기

```bash
git clone https://github.com/karpathy/nanochat.git
cd nanochat
git checkout 92d63d4e8bb4df75c3b71618f31ddde2378b2bcd
uv sync --extra gpu
source .venv/bin/activate
python -m nanochat.dataset -n 8
python -m scripts.tok_train --max-chars=2000000000
python -m scripts.base_train --depth=4 --head-dim=64 --window-pattern=L --max-seq-len=512 --device-batch-size=32 --total-batch-size=16384 --eval-every=100 --eval-tokens=524288 --core-metric-every=-1 --sample-every=-1 --num-iterations=50 --run=dummy
```

## 검증(자가)

본문 글 속에 나온 명령 — 설명 속 낱말이나 하지 말라는 예도 섞여 있으니, 함께 적은 본문 문장을 보고 칠지 정합니다:

- `git ls-files` — … 의 'Chinchilla 와 견주기'가 다섯 문장이고, 그중 하나가 규모의 한계를 말하는가 · '출처 표기' 절이 있는가 · 그 파일이 UTF-8 이고 64KiB 안이며 lab_id 줄로 시작하는가 · `git ls-files` 에 data 폴더가 없는가
